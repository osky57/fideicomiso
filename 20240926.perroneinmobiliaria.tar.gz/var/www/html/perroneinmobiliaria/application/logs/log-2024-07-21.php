<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-21 04:06:20 --> Config Class Initialized
INFO - 2024-07-21 04:06:20 --> Hooks Class Initialized
DEBUG - 2024-07-21 04:06:20 --> UTF-8 Support Enabled
INFO - 2024-07-21 04:06:20 --> Utf8 Class Initialized
INFO - 2024-07-21 04:06:20 --> URI Class Initialized
DEBUG - 2024-07-21 04:06:20 --> No URI present. Default controller set.
INFO - 2024-07-21 04:06:20 --> Router Class Initialized
INFO - 2024-07-21 04:06:20 --> Output Class Initialized
INFO - 2024-07-21 04:06:20 --> Security Class Initialized
DEBUG - 2024-07-21 04:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-21 04:06:20 --> Input Class Initialized
INFO - 2024-07-21 04:06:20 --> Language Class Initialized
INFO - 2024-07-21 04:06:20 --> Loader Class Initialized
INFO - 2024-07-21 04:06:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-21 04:06:20 --> Helper loaded: url_helper
DEBUG - 2024-07-21 04:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-21 04:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-21 04:06:20 --> Controller Class Initialized
INFO - 2024-07-21 06:15:40 --> Config Class Initialized
INFO - 2024-07-21 06:15:40 --> Hooks Class Initialized
DEBUG - 2024-07-21 06:15:40 --> UTF-8 Support Enabled
INFO - 2024-07-21 06:15:40 --> Utf8 Class Initialized
INFO - 2024-07-21 06:15:40 --> URI Class Initialized
DEBUG - 2024-07-21 06:15:40 --> No URI present. Default controller set.
INFO - 2024-07-21 06:15:40 --> Router Class Initialized
INFO - 2024-07-21 06:15:40 --> Output Class Initialized
INFO - 2024-07-21 06:15:40 --> Security Class Initialized
DEBUG - 2024-07-21 06:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-21 06:15:40 --> Input Class Initialized
INFO - 2024-07-21 06:15:40 --> Language Class Initialized
INFO - 2024-07-21 06:15:40 --> Loader Class Initialized
INFO - 2024-07-21 06:15:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-21 06:15:40 --> Helper loaded: url_helper
DEBUG - 2024-07-21 06:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-21 06:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-21 06:15:40 --> Controller Class Initialized
