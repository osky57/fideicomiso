<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-21 02:58:35 --> Config Class Initialized
INFO - 2024-09-21 02:58:35 --> Hooks Class Initialized
DEBUG - 2024-09-21 02:58:35 --> UTF-8 Support Enabled
INFO - 2024-09-21 02:58:35 --> Utf8 Class Initialized
INFO - 2024-09-21 02:58:35 --> URI Class Initialized
DEBUG - 2024-09-21 02:58:35 --> No URI present. Default controller set.
INFO - 2024-09-21 02:58:35 --> Router Class Initialized
INFO - 2024-09-21 02:58:35 --> Output Class Initialized
INFO - 2024-09-21 02:58:35 --> Security Class Initialized
DEBUG - 2024-09-21 02:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 02:58:35 --> Input Class Initialized
INFO - 2024-09-21 02:58:35 --> Language Class Initialized
INFO - 2024-09-21 02:58:35 --> Loader Class Initialized
INFO - 2024-09-21 02:58:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-21 02:58:35 --> Helper loaded: url_helper
DEBUG - 2024-09-21 02:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 02:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 02:58:35 --> Controller Class Initialized
INFO - 2024-09-21 05:48:58 --> Config Class Initialized
INFO - 2024-09-21 05:48:58 --> Hooks Class Initialized
DEBUG - 2024-09-21 05:48:58 --> UTF-8 Support Enabled
INFO - 2024-09-21 05:48:58 --> Utf8 Class Initialized
INFO - 2024-09-21 05:48:58 --> URI Class Initialized
DEBUG - 2024-09-21 05:48:58 --> No URI present. Default controller set.
INFO - 2024-09-21 05:48:58 --> Router Class Initialized
INFO - 2024-09-21 05:48:58 --> Output Class Initialized
INFO - 2024-09-21 05:48:58 --> Security Class Initialized
DEBUG - 2024-09-21 05:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 05:48:58 --> Input Class Initialized
INFO - 2024-09-21 05:48:58 --> Language Class Initialized
INFO - 2024-09-21 05:48:58 --> Loader Class Initialized
INFO - 2024-09-21 05:48:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-21 05:48:58 --> Helper loaded: url_helper
DEBUG - 2024-09-21 05:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 05:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 05:48:58 --> Controller Class Initialized
INFO - 2024-09-21 05:48:58 --> Config Class Initialized
INFO - 2024-09-21 05:48:58 --> Hooks Class Initialized
DEBUG - 2024-09-21 05:48:58 --> UTF-8 Support Enabled
INFO - 2024-09-21 05:48:58 --> Utf8 Class Initialized
INFO - 2024-09-21 05:48:58 --> URI Class Initialized
DEBUG - 2024-09-21 05:48:58 --> No URI present. Default controller set.
INFO - 2024-09-21 05:48:58 --> Router Class Initialized
INFO - 2024-09-21 05:48:58 --> Output Class Initialized
INFO - 2024-09-21 05:48:58 --> Security Class Initialized
DEBUG - 2024-09-21 05:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 05:48:58 --> Input Class Initialized
INFO - 2024-09-21 05:48:58 --> Language Class Initialized
INFO - 2024-09-21 05:48:58 --> Loader Class Initialized
INFO - 2024-09-21 05:48:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-21 05:48:58 --> Helper loaded: url_helper
DEBUG - 2024-09-21 05:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 05:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 05:48:58 --> Controller Class Initialized
INFO - 2024-09-21 07:37:19 --> Config Class Initialized
INFO - 2024-09-21 07:37:19 --> Hooks Class Initialized
DEBUG - 2024-09-21 07:37:19 --> UTF-8 Support Enabled
INFO - 2024-09-21 07:37:19 --> Utf8 Class Initialized
INFO - 2024-09-21 07:37:19 --> URI Class Initialized
DEBUG - 2024-09-21 07:37:19 --> No URI present. Default controller set.
INFO - 2024-09-21 07:37:19 --> Router Class Initialized
INFO - 2024-09-21 07:37:19 --> Output Class Initialized
INFO - 2024-09-21 07:37:19 --> Security Class Initialized
DEBUG - 2024-09-21 07:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 07:37:19 --> Input Class Initialized
INFO - 2024-09-21 07:37:19 --> Language Class Initialized
INFO - 2024-09-21 07:37:19 --> Loader Class Initialized
INFO - 2024-09-21 07:37:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-21 07:37:19 --> Helper loaded: url_helper
DEBUG - 2024-09-21 07:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 07:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 07:37:19 --> Controller Class Initialized
INFO - 2024-09-21 17:30:59 --> Config Class Initialized
INFO - 2024-09-21 17:30:59 --> Hooks Class Initialized
DEBUG - 2024-09-21 17:30:59 --> UTF-8 Support Enabled
INFO - 2024-09-21 17:30:59 --> Utf8 Class Initialized
INFO - 2024-09-21 17:30:59 --> URI Class Initialized
DEBUG - 2024-09-21 17:30:59 --> No URI present. Default controller set.
INFO - 2024-09-21 17:30:59 --> Router Class Initialized
INFO - 2024-09-21 17:30:59 --> Output Class Initialized
INFO - 2024-09-21 17:30:59 --> Security Class Initialized
DEBUG - 2024-09-21 17:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 17:30:59 --> Input Class Initialized
INFO - 2024-09-21 17:30:59 --> Language Class Initialized
INFO - 2024-09-21 17:30:59 --> Loader Class Initialized
INFO - 2024-09-21 17:30:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-21 17:30:59 --> Helper loaded: url_helper
DEBUG - 2024-09-21 17:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 17:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 17:30:59 --> Controller Class Initialized
