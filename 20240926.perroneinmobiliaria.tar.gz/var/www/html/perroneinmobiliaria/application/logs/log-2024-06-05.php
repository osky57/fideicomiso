<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-05 07:41:20 --> Config Class Initialized
INFO - 2024-06-05 07:41:20 --> Hooks Class Initialized
DEBUG - 2024-06-05 07:41:20 --> UTF-8 Support Enabled
INFO - 2024-06-05 07:41:20 --> Utf8 Class Initialized
INFO - 2024-06-05 07:41:20 --> URI Class Initialized
DEBUG - 2024-06-05 07:41:20 --> No URI present. Default controller set.
INFO - 2024-06-05 07:41:20 --> Router Class Initialized
INFO - 2024-06-05 07:41:20 --> Output Class Initialized
INFO - 2024-06-05 07:41:20 --> Security Class Initialized
DEBUG - 2024-06-05 07:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 07:41:20 --> Input Class Initialized
INFO - 2024-06-05 07:41:20 --> Language Class Initialized
INFO - 2024-06-05 07:41:20 --> Loader Class Initialized
INFO - 2024-06-05 07:41:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 07:41:20 --> Helper loaded: url_helper
DEBUG - 2024-06-05 07:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 07:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 07:41:20 --> Controller Class Initialized
INFO - 2024-06-05 17:30:49 --> Config Class Initialized
INFO - 2024-06-05 17:30:49 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:30:49 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:30:49 --> Utf8 Class Initialized
INFO - 2024-06-05 17:30:49 --> URI Class Initialized
DEBUG - 2024-06-05 17:30:49 --> No URI present. Default controller set.
INFO - 2024-06-05 17:30:49 --> Router Class Initialized
INFO - 2024-06-05 17:30:49 --> Output Class Initialized
INFO - 2024-06-05 17:30:49 --> Security Class Initialized
DEBUG - 2024-06-05 17:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:30:49 --> Input Class Initialized
INFO - 2024-06-05 17:30:49 --> Language Class Initialized
INFO - 2024-06-05 17:30:49 --> Loader Class Initialized
INFO - 2024-06-05 17:30:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:30:49 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:30:49 --> Controller Class Initialized
INFO - 2024-06-05 17:31:41 --> Config Class Initialized
INFO - 2024-06-05 17:31:41 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:41 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:41 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:41 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:41 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:41 --> Router Class Initialized
INFO - 2024-06-05 17:31:41 --> Output Class Initialized
INFO - 2024-06-05 17:31:41 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:41 --> Input Class Initialized
INFO - 2024-06-05 17:31:41 --> Language Class Initialized
INFO - 2024-06-05 17:31:41 --> Loader Class Initialized
INFO - 2024-06-05 17:31:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:41 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:41 --> Controller Class Initialized
INFO - 2024-06-05 17:31:41 --> Config Class Initialized
INFO - 2024-06-05 17:31:41 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:41 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:41 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:41 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:41 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:41 --> Router Class Initialized
INFO - 2024-06-05 17:31:41 --> Output Class Initialized
INFO - 2024-06-05 17:31:41 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:41 --> Input Class Initialized
INFO - 2024-06-05 17:31:41 --> Language Class Initialized
INFO - 2024-06-05 17:31:41 --> Loader Class Initialized
INFO - 2024-06-05 17:31:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:41 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:41 --> Controller Class Initialized
INFO - 2024-06-05 17:31:41 --> Config Class Initialized
INFO - 2024-06-05 17:31:41 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:41 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:41 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:41 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:41 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:41 --> Router Class Initialized
INFO - 2024-06-05 17:31:41 --> Output Class Initialized
INFO - 2024-06-05 17:31:41 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:41 --> Input Class Initialized
INFO - 2024-06-05 17:31:41 --> Language Class Initialized
INFO - 2024-06-05 17:31:41 --> Loader Class Initialized
INFO - 2024-06-05 17:31:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:41 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:41 --> Controller Class Initialized
INFO - 2024-06-05 17:31:42 --> Config Class Initialized
INFO - 2024-06-05 17:31:42 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:42 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:42 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:42 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:42 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:42 --> Router Class Initialized
INFO - 2024-06-05 17:31:42 --> Output Class Initialized
INFO - 2024-06-05 17:31:42 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:42 --> Input Class Initialized
INFO - 2024-06-05 17:31:42 --> Language Class Initialized
INFO - 2024-06-05 17:31:42 --> Loader Class Initialized
INFO - 2024-06-05 17:31:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:42 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:42 --> Controller Class Initialized
INFO - 2024-06-05 17:31:42 --> Config Class Initialized
INFO - 2024-06-05 17:31:42 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:42 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:42 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:42 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:42 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:42 --> Router Class Initialized
INFO - 2024-06-05 17:31:42 --> Output Class Initialized
INFO - 2024-06-05 17:31:42 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:42 --> Input Class Initialized
INFO - 2024-06-05 17:31:42 --> Language Class Initialized
INFO - 2024-06-05 17:31:42 --> Loader Class Initialized
INFO - 2024-06-05 17:31:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:42 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:42 --> Controller Class Initialized
INFO - 2024-06-05 17:31:43 --> Config Class Initialized
INFO - 2024-06-05 17:31:43 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:43 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:43 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:43 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:43 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:43 --> Router Class Initialized
INFO - 2024-06-05 17:31:43 --> Output Class Initialized
INFO - 2024-06-05 17:31:43 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:43 --> Input Class Initialized
INFO - 2024-06-05 17:31:43 --> Language Class Initialized
INFO - 2024-06-05 17:31:43 --> Loader Class Initialized
INFO - 2024-06-05 17:31:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:43 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:43 --> Controller Class Initialized
INFO - 2024-06-05 17:31:44 --> Config Class Initialized
INFO - 2024-06-05 17:31:44 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:44 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:44 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:44 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:44 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:44 --> Router Class Initialized
INFO - 2024-06-05 17:31:44 --> Output Class Initialized
INFO - 2024-06-05 17:31:44 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:44 --> Input Class Initialized
INFO - 2024-06-05 17:31:44 --> Language Class Initialized
INFO - 2024-06-05 17:31:44 --> Loader Class Initialized
INFO - 2024-06-05 17:31:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:44 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:44 --> Controller Class Initialized
INFO - 2024-06-05 17:31:47 --> Config Class Initialized
INFO - 2024-06-05 17:31:47 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:31:47 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:31:47 --> Utf8 Class Initialized
INFO - 2024-06-05 17:31:47 --> URI Class Initialized
DEBUG - 2024-06-05 17:31:47 --> No URI present. Default controller set.
INFO - 2024-06-05 17:31:47 --> Router Class Initialized
INFO - 2024-06-05 17:31:47 --> Output Class Initialized
INFO - 2024-06-05 17:31:47 --> Security Class Initialized
DEBUG - 2024-06-05 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:31:47 --> Input Class Initialized
INFO - 2024-06-05 17:31:47 --> Language Class Initialized
INFO - 2024-06-05 17:31:47 --> Loader Class Initialized
INFO - 2024-06-05 17:31:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:31:47 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:31:47 --> Controller Class Initialized
INFO - 2024-06-05 17:32:00 --> Config Class Initialized
INFO - 2024-06-05 17:32:00 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:00 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:00 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:00 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:00 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:00 --> Router Class Initialized
INFO - 2024-06-05 17:32:00 --> Output Class Initialized
INFO - 2024-06-05 17:32:00 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:00 --> Input Class Initialized
INFO - 2024-06-05 17:32:00 --> Language Class Initialized
INFO - 2024-06-05 17:32:00 --> Loader Class Initialized
INFO - 2024-06-05 17:32:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:00 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:00 --> Controller Class Initialized
INFO - 2024-06-05 17:32:01 --> Config Class Initialized
INFO - 2024-06-05 17:32:01 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:01 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:01 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:01 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:01 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:01 --> Router Class Initialized
INFO - 2024-06-05 17:32:01 --> Output Class Initialized
INFO - 2024-06-05 17:32:01 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:01 --> Input Class Initialized
INFO - 2024-06-05 17:32:01 --> Language Class Initialized
INFO - 2024-06-05 17:32:01 --> Loader Class Initialized
INFO - 2024-06-05 17:32:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:01 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:01 --> Controller Class Initialized
INFO - 2024-06-05 17:32:02 --> Config Class Initialized
INFO - 2024-06-05 17:32:02 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:02 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:02 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:02 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:02 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:02 --> Router Class Initialized
INFO - 2024-06-05 17:32:02 --> Output Class Initialized
INFO - 2024-06-05 17:32:02 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:02 --> Input Class Initialized
INFO - 2024-06-05 17:32:02 --> Language Class Initialized
INFO - 2024-06-05 17:32:02 --> Loader Class Initialized
INFO - 2024-06-05 17:32:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:02 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:02 --> Controller Class Initialized
INFO - 2024-06-05 17:32:03 --> Config Class Initialized
INFO - 2024-06-05 17:32:03 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:03 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:03 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:03 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:03 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:03 --> Router Class Initialized
INFO - 2024-06-05 17:32:03 --> Output Class Initialized
INFO - 2024-06-05 17:32:03 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:03 --> Input Class Initialized
INFO - 2024-06-05 17:32:03 --> Language Class Initialized
INFO - 2024-06-05 17:32:03 --> Loader Class Initialized
INFO - 2024-06-05 17:32:03 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:03 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:03 --> Controller Class Initialized
INFO - 2024-06-05 17:32:17 --> Config Class Initialized
INFO - 2024-06-05 17:32:17 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:17 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:17 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:17 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:17 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:17 --> Router Class Initialized
INFO - 2024-06-05 17:32:17 --> Output Class Initialized
INFO - 2024-06-05 17:32:17 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:17 --> Input Class Initialized
INFO - 2024-06-05 17:32:17 --> Language Class Initialized
INFO - 2024-06-05 17:32:17 --> Loader Class Initialized
INFO - 2024-06-05 17:32:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:17 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:17 --> Controller Class Initialized
INFO - 2024-06-05 17:32:21 --> Config Class Initialized
INFO - 2024-06-05 17:32:21 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:21 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:21 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:21 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:21 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:21 --> Router Class Initialized
INFO - 2024-06-05 17:32:21 --> Output Class Initialized
INFO - 2024-06-05 17:32:21 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:21 --> Input Class Initialized
INFO - 2024-06-05 17:32:21 --> Language Class Initialized
INFO - 2024-06-05 17:32:21 --> Loader Class Initialized
INFO - 2024-06-05 17:32:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:21 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:21 --> Controller Class Initialized
INFO - 2024-06-05 17:32:21 --> Config Class Initialized
INFO - 2024-06-05 17:32:21 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:21 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:21 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:21 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:21 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:21 --> Router Class Initialized
INFO - 2024-06-05 17:32:21 --> Output Class Initialized
INFO - 2024-06-05 17:32:21 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:21 --> Input Class Initialized
INFO - 2024-06-05 17:32:21 --> Language Class Initialized
INFO - 2024-06-05 17:32:21 --> Loader Class Initialized
INFO - 2024-06-05 17:32:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:21 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:21 --> Controller Class Initialized
INFO - 2024-06-05 17:32:24 --> Config Class Initialized
INFO - 2024-06-05 17:32:24 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:24 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:24 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:24 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:24 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:24 --> Router Class Initialized
INFO - 2024-06-05 17:32:24 --> Output Class Initialized
INFO - 2024-06-05 17:32:24 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:24 --> Input Class Initialized
INFO - 2024-06-05 17:32:24 --> Language Class Initialized
INFO - 2024-06-05 17:32:24 --> Loader Class Initialized
INFO - 2024-06-05 17:32:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:24 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:24 --> Controller Class Initialized
INFO - 2024-06-05 17:32:32 --> Config Class Initialized
INFO - 2024-06-05 17:32:32 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:32 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:32 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:32 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:32 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:32 --> Router Class Initialized
INFO - 2024-06-05 17:32:32 --> Output Class Initialized
INFO - 2024-06-05 17:32:32 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:32 --> Input Class Initialized
INFO - 2024-06-05 17:32:32 --> Language Class Initialized
INFO - 2024-06-05 17:32:32 --> Loader Class Initialized
INFO - 2024-06-05 17:32:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:32 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:32 --> Controller Class Initialized
INFO - 2024-06-05 17:32:32 --> Config Class Initialized
INFO - 2024-06-05 17:32:32 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:32 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:32 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:32 --> URI Class Initialized
INFO - 2024-06-05 17:32:32 --> Router Class Initialized
INFO - 2024-06-05 17:32:32 --> Output Class Initialized
INFO - 2024-06-05 17:32:32 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:32 --> Input Class Initialized
INFO - 2024-06-05 17:32:32 --> Language Class Initialized
INFO - 2024-06-05 17:32:32 --> Loader Class Initialized
INFO - 2024-06-05 17:32:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:32 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:32 --> Controller Class Initialized
DEBUG - 2024-06-05 17:32:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-05 17:32:32 --> Database Driver Class Initialized
INFO - 2024-06-05 17:32:32 --> Helper loaded: cookie_helper
INFO - 2024-06-05 17:32:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-05 17:32:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-05 17:32:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-05 17:32:32 --> Final output sent to browser
DEBUG - 2024-06-05 17:32:32 --> Total execution time: 0.1644
INFO - 2024-06-05 17:32:33 --> Config Class Initialized
INFO - 2024-06-05 17:32:33 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:33 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:33 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:33 --> URI Class Initialized
INFO - 2024-06-05 17:32:33 --> Router Class Initialized
INFO - 2024-06-05 17:32:33 --> Output Class Initialized
INFO - 2024-06-05 17:32:33 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:33 --> Input Class Initialized
INFO - 2024-06-05 17:32:33 --> Language Class Initialized
INFO - 2024-06-05 17:32:33 --> Loader Class Initialized
INFO - 2024-06-05 17:32:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:33 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:33 --> Controller Class Initialized
INFO - 2024-06-05 17:32:38 --> Config Class Initialized
INFO - 2024-06-05 17:32:38 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:38 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:38 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:38 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:38 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:38 --> Router Class Initialized
INFO - 2024-06-05 17:32:38 --> Output Class Initialized
INFO - 2024-06-05 17:32:38 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:38 --> Input Class Initialized
INFO - 2024-06-05 17:32:38 --> Language Class Initialized
INFO - 2024-06-05 17:32:38 --> Loader Class Initialized
INFO - 2024-06-05 17:32:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:38 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:38 --> Controller Class Initialized
INFO - 2024-06-05 17:32:51 --> Config Class Initialized
INFO - 2024-06-05 17:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:51 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:51 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:51 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:51 --> Router Class Initialized
INFO - 2024-06-05 17:32:51 --> Output Class Initialized
INFO - 2024-06-05 17:32:51 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:51 --> Input Class Initialized
INFO - 2024-06-05 17:32:51 --> Language Class Initialized
INFO - 2024-06-05 17:32:51 --> Loader Class Initialized
INFO - 2024-06-05 17:32:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:51 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:51 --> Controller Class Initialized
INFO - 2024-06-05 17:32:51 --> Config Class Initialized
INFO - 2024-06-05 17:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:51 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:51 --> URI Class Initialized
INFO - 2024-06-05 17:32:51 --> Router Class Initialized
INFO - 2024-06-05 17:32:51 --> Output Class Initialized
INFO - 2024-06-05 17:32:51 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:51 --> Input Class Initialized
INFO - 2024-06-05 17:32:51 --> Language Class Initialized
INFO - 2024-06-05 17:32:51 --> Loader Class Initialized
INFO - 2024-06-05 17:32:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:51 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:51 --> Controller Class Initialized
DEBUG - 2024-06-05 17:32:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-05 17:32:51 --> Database Driver Class Initialized
INFO - 2024-06-05 17:32:51 --> Helper loaded: cookie_helper
INFO - 2024-06-05 17:32:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-05 17:32:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-05 17:32:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-05 17:32:51 --> Final output sent to browser
DEBUG - 2024-06-05 17:32:51 --> Total execution time: 0.0211
INFO - 2024-06-05 17:32:53 --> Config Class Initialized
INFO - 2024-06-05 17:32:53 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:53 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:53 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:53 --> URI Class Initialized
INFO - 2024-06-05 17:32:53 --> Router Class Initialized
INFO - 2024-06-05 17:32:53 --> Output Class Initialized
INFO - 2024-06-05 17:32:53 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:53 --> Input Class Initialized
INFO - 2024-06-05 17:32:53 --> Language Class Initialized
INFO - 2024-06-05 17:32:53 --> Loader Class Initialized
INFO - 2024-06-05 17:32:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:53 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:53 --> Controller Class Initialized
INFO - 2024-06-05 17:32:55 --> Config Class Initialized
INFO - 2024-06-05 17:32:55 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:55 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:55 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:55 --> URI Class Initialized
DEBUG - 2024-06-05 17:32:55 --> No URI present. Default controller set.
INFO - 2024-06-05 17:32:55 --> Router Class Initialized
INFO - 2024-06-05 17:32:55 --> Output Class Initialized
INFO - 2024-06-05 17:32:55 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:55 --> Input Class Initialized
INFO - 2024-06-05 17:32:55 --> Language Class Initialized
INFO - 2024-06-05 17:32:55 --> Loader Class Initialized
INFO - 2024-06-05 17:32:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:55 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:55 --> Controller Class Initialized
INFO - 2024-06-05 17:32:55 --> Config Class Initialized
INFO - 2024-06-05 17:32:55 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:55 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:55 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:55 --> URI Class Initialized
INFO - 2024-06-05 17:32:55 --> Router Class Initialized
INFO - 2024-06-05 17:32:55 --> Output Class Initialized
INFO - 2024-06-05 17:32:55 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:55 --> Input Class Initialized
INFO - 2024-06-05 17:32:55 --> Language Class Initialized
INFO - 2024-06-05 17:32:55 --> Loader Class Initialized
INFO - 2024-06-05 17:32:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:55 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:55 --> Controller Class Initialized
DEBUG - 2024-06-05 17:32:55 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-05 17:32:55 --> Database Driver Class Initialized
INFO - 2024-06-05 17:32:55 --> Helper loaded: cookie_helper
INFO - 2024-06-05 17:32:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-05 17:32:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-05 17:32:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-05 17:32:55 --> Final output sent to browser
DEBUG - 2024-06-05 17:32:55 --> Total execution time: 0.0317
INFO - 2024-06-05 17:32:56 --> Config Class Initialized
INFO - 2024-06-05 17:32:56 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:32:56 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:32:56 --> Utf8 Class Initialized
INFO - 2024-06-05 17:32:56 --> URI Class Initialized
INFO - 2024-06-05 17:32:56 --> Router Class Initialized
INFO - 2024-06-05 17:32:56 --> Output Class Initialized
INFO - 2024-06-05 17:32:56 --> Security Class Initialized
DEBUG - 2024-06-05 17:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:32:56 --> Input Class Initialized
INFO - 2024-06-05 17:32:56 --> Language Class Initialized
INFO - 2024-06-05 17:32:56 --> Loader Class Initialized
INFO - 2024-06-05 17:32:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:32:56 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:32:56 --> Controller Class Initialized
INFO - 2024-06-05 17:49:17 --> Config Class Initialized
INFO - 2024-06-05 17:49:17 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:49:17 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:49:17 --> Utf8 Class Initialized
INFO - 2024-06-05 17:49:17 --> URI Class Initialized
DEBUG - 2024-06-05 17:49:17 --> No URI present. Default controller set.
INFO - 2024-06-05 17:49:17 --> Router Class Initialized
INFO - 2024-06-05 17:49:17 --> Output Class Initialized
INFO - 2024-06-05 17:49:17 --> Security Class Initialized
DEBUG - 2024-06-05 17:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:49:17 --> Input Class Initialized
INFO - 2024-06-05 17:49:17 --> Language Class Initialized
INFO - 2024-06-05 17:49:17 --> Loader Class Initialized
INFO - 2024-06-05 17:49:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:49:17 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:49:17 --> Controller Class Initialized
INFO - 2024-06-05 17:49:17 --> Config Class Initialized
INFO - 2024-06-05 17:49:17 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:49:17 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:49:17 --> Utf8 Class Initialized
INFO - 2024-06-05 17:49:17 --> URI Class Initialized
INFO - 2024-06-05 17:49:17 --> Router Class Initialized
INFO - 2024-06-05 17:49:17 --> Output Class Initialized
INFO - 2024-06-05 17:49:17 --> Security Class Initialized
DEBUG - 2024-06-05 17:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:49:17 --> Input Class Initialized
INFO - 2024-06-05 17:49:17 --> Language Class Initialized
INFO - 2024-06-05 17:49:17 --> Loader Class Initialized
INFO - 2024-06-05 17:49:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:49:17 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:49:17 --> Controller Class Initialized
DEBUG - 2024-06-05 17:49:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-05 17:49:17 --> Database Driver Class Initialized
INFO - 2024-06-05 17:49:17 --> Helper loaded: cookie_helper
INFO - 2024-06-05 17:49:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-05 17:49:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-05 17:49:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-05 17:49:17 --> Final output sent to browser
DEBUG - 2024-06-05 17:49:17 --> Total execution time: 0.0174
INFO - 2024-06-05 17:49:18 --> Config Class Initialized
INFO - 2024-06-05 17:49:18 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:49:18 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:49:18 --> Utf8 Class Initialized
INFO - 2024-06-05 17:49:18 --> URI Class Initialized
INFO - 2024-06-05 17:49:18 --> Router Class Initialized
INFO - 2024-06-05 17:49:18 --> Output Class Initialized
INFO - 2024-06-05 17:49:18 --> Security Class Initialized
DEBUG - 2024-06-05 17:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:49:18 --> Input Class Initialized
INFO - 2024-06-05 17:49:18 --> Language Class Initialized
INFO - 2024-06-05 17:49:18 --> Loader Class Initialized
INFO - 2024-06-05 17:49:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:49:18 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:49:18 --> Controller Class Initialized
INFO - 2024-06-05 17:49:56 --> Config Class Initialized
INFO - 2024-06-05 17:49:56 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:49:56 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:49:56 --> Utf8 Class Initialized
INFO - 2024-06-05 17:49:56 --> URI Class Initialized
DEBUG - 2024-06-05 17:49:56 --> No URI present. Default controller set.
INFO - 2024-06-05 17:49:56 --> Router Class Initialized
INFO - 2024-06-05 17:49:56 --> Output Class Initialized
INFO - 2024-06-05 17:49:56 --> Security Class Initialized
DEBUG - 2024-06-05 17:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:49:56 --> Input Class Initialized
INFO - 2024-06-05 17:49:56 --> Language Class Initialized
INFO - 2024-06-05 17:49:56 --> Loader Class Initialized
INFO - 2024-06-05 17:49:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:49:56 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:49:56 --> Controller Class Initialized
INFO - 2024-06-05 17:52:15 --> Config Class Initialized
INFO - 2024-06-05 17:52:15 --> Hooks Class Initialized
DEBUG - 2024-06-05 17:52:15 --> UTF-8 Support Enabled
INFO - 2024-06-05 17:52:15 --> Utf8 Class Initialized
INFO - 2024-06-05 17:52:15 --> URI Class Initialized
DEBUG - 2024-06-05 17:52:15 --> No URI present. Default controller set.
INFO - 2024-06-05 17:52:15 --> Router Class Initialized
INFO - 2024-06-05 17:52:15 --> Output Class Initialized
INFO - 2024-06-05 17:52:15 --> Security Class Initialized
DEBUG - 2024-06-05 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 17:52:15 --> Input Class Initialized
INFO - 2024-06-05 17:52:15 --> Language Class Initialized
INFO - 2024-06-05 17:52:15 --> Loader Class Initialized
INFO - 2024-06-05 17:52:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 17:52:15 --> Helper loaded: url_helper
DEBUG - 2024-06-05 17:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 17:52:15 --> Controller Class Initialized
INFO - 2024-06-05 20:31:35 --> Config Class Initialized
INFO - 2024-06-05 20:31:35 --> Hooks Class Initialized
DEBUG - 2024-06-05 20:31:35 --> UTF-8 Support Enabled
INFO - 2024-06-05 20:31:35 --> Utf8 Class Initialized
INFO - 2024-06-05 20:31:35 --> URI Class Initialized
DEBUG - 2024-06-05 20:31:35 --> No URI present. Default controller set.
INFO - 2024-06-05 20:31:35 --> Router Class Initialized
INFO - 2024-06-05 20:31:35 --> Output Class Initialized
INFO - 2024-06-05 20:31:35 --> Security Class Initialized
DEBUG - 2024-06-05 20:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 20:31:35 --> Input Class Initialized
INFO - 2024-06-05 20:31:35 --> Language Class Initialized
INFO - 2024-06-05 20:31:35 --> Loader Class Initialized
INFO - 2024-06-05 20:31:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 20:31:35 --> Helper loaded: url_helper
DEBUG - 2024-06-05 20:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 20:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 20:31:35 --> Controller Class Initialized
INFO - 2024-06-05 20:31:35 --> Config Class Initialized
INFO - 2024-06-05 20:31:35 --> Hooks Class Initialized
DEBUG - 2024-06-05 20:31:35 --> UTF-8 Support Enabled
INFO - 2024-06-05 20:31:35 --> Utf8 Class Initialized
INFO - 2024-06-05 20:31:35 --> URI Class Initialized
INFO - 2024-06-05 20:31:35 --> Router Class Initialized
INFO - 2024-06-05 20:31:35 --> Output Class Initialized
INFO - 2024-06-05 20:31:35 --> Security Class Initialized
DEBUG - 2024-06-05 20:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 20:31:35 --> Input Class Initialized
INFO - 2024-06-05 20:31:35 --> Language Class Initialized
INFO - 2024-06-05 20:31:35 --> Loader Class Initialized
INFO - 2024-06-05 20:31:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 20:31:35 --> Helper loaded: url_helper
DEBUG - 2024-06-05 20:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 20:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 20:31:35 --> Controller Class Initialized
DEBUG - 2024-06-05 20:31:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-05 20:31:35 --> Database Driver Class Initialized
INFO - 2024-06-05 20:31:35 --> Helper loaded: cookie_helper
INFO - 2024-06-05 20:31:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-05 20:31:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-05 20:31:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-05 20:31:35 --> Final output sent to browser
DEBUG - 2024-06-05 20:31:35 --> Total execution time: 0.0180
INFO - 2024-06-05 21:32:00 --> Config Class Initialized
INFO - 2024-06-05 21:32:00 --> Hooks Class Initialized
DEBUG - 2024-06-05 21:32:00 --> UTF-8 Support Enabled
INFO - 2024-06-05 21:32:00 --> Utf8 Class Initialized
INFO - 2024-06-05 21:32:00 --> URI Class Initialized
DEBUG - 2024-06-05 21:32:00 --> No URI present. Default controller set.
INFO - 2024-06-05 21:32:00 --> Router Class Initialized
INFO - 2024-06-05 21:32:00 --> Output Class Initialized
INFO - 2024-06-05 21:32:00 --> Security Class Initialized
DEBUG - 2024-06-05 21:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 21:32:00 --> Input Class Initialized
INFO - 2024-06-05 21:32:00 --> Language Class Initialized
INFO - 2024-06-05 21:32:00 --> Loader Class Initialized
INFO - 2024-06-05 21:32:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 21:32:00 --> Helper loaded: url_helper
DEBUG - 2024-06-05 21:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 21:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 21:32:00 --> Controller Class Initialized
INFO - 2024-06-05 22:19:08 --> Config Class Initialized
INFO - 2024-06-05 22:19:08 --> Hooks Class Initialized
DEBUG - 2024-06-05 22:19:08 --> UTF-8 Support Enabled
INFO - 2024-06-05 22:19:08 --> Utf8 Class Initialized
INFO - 2024-06-05 22:19:08 --> URI Class Initialized
DEBUG - 2024-06-05 22:19:08 --> No URI present. Default controller set.
INFO - 2024-06-05 22:19:08 --> Router Class Initialized
INFO - 2024-06-05 22:19:08 --> Output Class Initialized
INFO - 2024-06-05 22:19:08 --> Security Class Initialized
DEBUG - 2024-06-05 22:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 22:19:08 --> Input Class Initialized
INFO - 2024-06-05 22:19:08 --> Language Class Initialized
INFO - 2024-06-05 22:19:08 --> Loader Class Initialized
INFO - 2024-06-05 22:19:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-05 22:19:08 --> Helper loaded: url_helper
DEBUG - 2024-06-05 22:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-05 22:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 22:19:08 --> Controller Class Initialized
