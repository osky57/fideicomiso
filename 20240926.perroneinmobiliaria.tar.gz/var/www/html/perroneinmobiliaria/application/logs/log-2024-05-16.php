<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-16 11:42:05 --> Config Class Initialized
INFO - 2024-05-16 11:42:05 --> Hooks Class Initialized
DEBUG - 2024-05-16 11:42:05 --> UTF-8 Support Enabled
INFO - 2024-05-16 11:42:05 --> Utf8 Class Initialized
INFO - 2024-05-16 11:42:05 --> URI Class Initialized
DEBUG - 2024-05-16 11:42:05 --> No URI present. Default controller set.
INFO - 2024-05-16 11:42:05 --> Router Class Initialized
INFO - 2024-05-16 11:42:05 --> Output Class Initialized
INFO - 2024-05-16 11:42:05 --> Security Class Initialized
DEBUG - 2024-05-16 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-16 11:42:05 --> Input Class Initialized
INFO - 2024-05-16 11:42:05 --> Language Class Initialized
INFO - 2024-05-16 11:42:05 --> Loader Class Initialized
INFO - 2024-05-16 11:42:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-16 11:42:05 --> Helper loaded: url_helper
DEBUG - 2024-05-16 11:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-16 11:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-16 11:42:05 --> Controller Class Initialized
INFO - 2024-05-16 11:42:05 --> Config Class Initialized
INFO - 2024-05-16 11:42:05 --> Hooks Class Initialized
DEBUG - 2024-05-16 11:42:05 --> UTF-8 Support Enabled
INFO - 2024-05-16 11:42:05 --> Utf8 Class Initialized
INFO - 2024-05-16 11:42:05 --> URI Class Initialized
INFO - 2024-05-16 11:42:05 --> Router Class Initialized
INFO - 2024-05-16 11:42:05 --> Output Class Initialized
INFO - 2024-05-16 11:42:05 --> Security Class Initialized
DEBUG - 2024-05-16 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-16 11:42:05 --> Input Class Initialized
INFO - 2024-05-16 11:42:05 --> Language Class Initialized
INFO - 2024-05-16 11:42:05 --> Loader Class Initialized
INFO - 2024-05-16 11:42:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-16 11:42:05 --> Helper loaded: url_helper
DEBUG - 2024-05-16 11:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-16 11:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-16 11:42:05 --> Controller Class Initialized
DEBUG - 2024-05-16 11:42:05 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-16 11:42:05 --> Database Driver Class Initialized
INFO - 2024-05-16 11:42:05 --> Helper loaded: cookie_helper
INFO - 2024-05-16 11:42:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-16 11:42:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-16 11:42:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-16 11:42:05 --> Final output sent to browser
DEBUG - 2024-05-16 11:42:05 --> Total execution time: 0.0446
INFO - 2024-05-16 11:42:06 --> Config Class Initialized
INFO - 2024-05-16 11:42:06 --> Hooks Class Initialized
DEBUG - 2024-05-16 11:42:06 --> UTF-8 Support Enabled
INFO - 2024-05-16 11:42:06 --> Utf8 Class Initialized
INFO - 2024-05-16 11:42:06 --> URI Class Initialized
INFO - 2024-05-16 11:42:06 --> Router Class Initialized
INFO - 2024-05-16 11:42:06 --> Output Class Initialized
INFO - 2024-05-16 11:42:06 --> Security Class Initialized
DEBUG - 2024-05-16 11:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-16 11:42:06 --> Input Class Initialized
INFO - 2024-05-16 11:42:06 --> Language Class Initialized
INFO - 2024-05-16 11:42:06 --> Loader Class Initialized
INFO - 2024-05-16 11:42:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-16 11:42:06 --> Helper loaded: url_helper
DEBUG - 2024-05-16 11:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-16 11:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-16 11:42:06 --> Controller Class Initialized
INFO - 2024-05-16 16:51:27 --> Config Class Initialized
INFO - 2024-05-16 16:51:27 --> Hooks Class Initialized
DEBUG - 2024-05-16 16:51:27 --> UTF-8 Support Enabled
INFO - 2024-05-16 16:51:27 --> Utf8 Class Initialized
INFO - 2024-05-16 16:51:27 --> URI Class Initialized
DEBUG - 2024-05-16 16:51:27 --> No URI present. Default controller set.
INFO - 2024-05-16 16:51:27 --> Router Class Initialized
INFO - 2024-05-16 16:51:27 --> Output Class Initialized
INFO - 2024-05-16 16:51:27 --> Security Class Initialized
DEBUG - 2024-05-16 16:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-16 16:51:27 --> Input Class Initialized
INFO - 2024-05-16 16:51:27 --> Language Class Initialized
INFO - 2024-05-16 16:51:27 --> Loader Class Initialized
INFO - 2024-05-16 16:51:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-16 16:51:27 --> Helper loaded: url_helper
DEBUG - 2024-05-16 16:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-16 16:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-16 16:51:27 --> Controller Class Initialized
