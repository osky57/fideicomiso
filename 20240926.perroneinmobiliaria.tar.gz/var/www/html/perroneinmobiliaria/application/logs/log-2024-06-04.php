<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-04 17:08:30 --> Config Class Initialized
INFO - 2024-06-04 17:08:30 --> Hooks Class Initialized
DEBUG - 2024-06-04 17:08:30 --> UTF-8 Support Enabled
INFO - 2024-06-04 17:08:30 --> Utf8 Class Initialized
INFO - 2024-06-04 17:08:30 --> URI Class Initialized
DEBUG - 2024-06-04 17:08:30 --> No URI present. Default controller set.
INFO - 2024-06-04 17:08:30 --> Router Class Initialized
INFO - 2024-06-04 17:08:30 --> Output Class Initialized
INFO - 2024-06-04 17:08:30 --> Security Class Initialized
DEBUG - 2024-06-04 17:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-04 17:08:30 --> Input Class Initialized
INFO - 2024-06-04 17:08:30 --> Language Class Initialized
INFO - 2024-06-04 17:08:30 --> Loader Class Initialized
INFO - 2024-06-04 17:08:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-04 17:08:30 --> Helper loaded: url_helper
DEBUG - 2024-06-04 17:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-04 17:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-04 17:08:30 --> Controller Class Initialized
INFO - 2024-06-04 19:43:46 --> Config Class Initialized
INFO - 2024-06-04 19:43:46 --> Hooks Class Initialized
DEBUG - 2024-06-04 19:43:46 --> UTF-8 Support Enabled
INFO - 2024-06-04 19:43:46 --> Utf8 Class Initialized
INFO - 2024-06-04 19:43:46 --> URI Class Initialized
DEBUG - 2024-06-04 19:43:46 --> No URI present. Default controller set.
INFO - 2024-06-04 19:43:46 --> Router Class Initialized
INFO - 2024-06-04 19:43:46 --> Output Class Initialized
INFO - 2024-06-04 19:43:46 --> Security Class Initialized
DEBUG - 2024-06-04 19:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-04 19:43:46 --> Input Class Initialized
INFO - 2024-06-04 19:43:46 --> Language Class Initialized
INFO - 2024-06-04 19:43:46 --> Loader Class Initialized
INFO - 2024-06-04 19:43:46 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-04 19:43:46 --> Helper loaded: url_helper
DEBUG - 2024-06-04 19:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-04 19:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-04 19:43:46 --> Controller Class Initialized
