<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-27 09:30:43 --> Config Class Initialized
INFO - 2024-05-27 09:30:43 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:43 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:43 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:43 --> URI Class Initialized
DEBUG - 2024-05-27 09:30:43 --> No URI present. Default controller set.
INFO - 2024-05-27 09:30:43 --> Router Class Initialized
INFO - 2024-05-27 09:30:43 --> Output Class Initialized
INFO - 2024-05-27 09:30:43 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:43 --> Input Class Initialized
INFO - 2024-05-27 09:30:43 --> Language Class Initialized
INFO - 2024-05-27 09:30:43 --> Loader Class Initialized
INFO - 2024-05-27 09:30:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:43 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:43 --> Controller Class Initialized
INFO - 2024-05-27 09:30:43 --> Config Class Initialized
INFO - 2024-05-27 09:30:43 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:43 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:43 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:43 --> URI Class Initialized
INFO - 2024-05-27 09:30:43 --> Router Class Initialized
INFO - 2024-05-27 09:30:43 --> Output Class Initialized
INFO - 2024-05-27 09:30:43 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:43 --> Input Class Initialized
INFO - 2024-05-27 09:30:43 --> Language Class Initialized
INFO - 2024-05-27 09:30:43 --> Loader Class Initialized
INFO - 2024-05-27 09:30:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:43 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:43 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-27 09:30:43 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:43 --> Helper loaded: cookie_helper
INFO - 2024-05-27 09:30:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:30:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:30:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-27 09:30:43 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:43 --> Total execution time: 0.0387
INFO - 2024-05-27 09:30:44 --> Config Class Initialized
INFO - 2024-05-27 09:30:44 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:44 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:44 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:44 --> URI Class Initialized
INFO - 2024-05-27 09:30:44 --> Router Class Initialized
INFO - 2024-05-27 09:30:44 --> Output Class Initialized
INFO - 2024-05-27 09:30:44 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:44 --> Input Class Initialized
INFO - 2024-05-27 09:30:44 --> Language Class Initialized
INFO - 2024-05-27 09:30:44 --> Loader Class Initialized
INFO - 2024-05-27 09:30:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:44 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:44 --> Controller Class Initialized
INFO - 2024-05-27 09:30:47 --> Config Class Initialized
INFO - 2024-05-27 09:30:47 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:47 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:47 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:47 --> URI Class Initialized
INFO - 2024-05-27 09:30:47 --> Router Class Initialized
INFO - 2024-05-27 09:30:47 --> Output Class Initialized
INFO - 2024-05-27 09:30:47 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:47 --> Input Class Initialized
INFO - 2024-05-27 09:30:47 --> Language Class Initialized
INFO - 2024-05-27 09:30:47 --> Loader Class Initialized
INFO - 2024-05-27 09:30:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:47 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:47 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:47 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-27 09:30:47 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:47 --> Helper loaded: cookie_helper
INFO - 2024-05-27 09:30:47 --> Helper loaded: form_helper
INFO - 2024-05-27 09:30:47 --> Form Validation Class Initialized
INFO - 2024-05-27 09:30:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-27 09:30:47 --> Config Class Initialized
INFO - 2024-05-27 09:30:47 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:47 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:47 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:47 --> URI Class Initialized
INFO - 2024-05-27 09:30:47 --> Router Class Initialized
INFO - 2024-05-27 09:30:47 --> Output Class Initialized
INFO - 2024-05-27 09:30:47 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:47 --> Input Class Initialized
INFO - 2024-05-27 09:30:47 --> Language Class Initialized
INFO - 2024-05-27 09:30:47 --> Loader Class Initialized
INFO - 2024-05-27 09:30:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:47 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:47 --> Controller Class Initialized
INFO - 2024-05-27 09:30:47 --> Database Driver Class Initialized
DEBUG - 2024-05-27 09:30:47 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-27 09:30:47 --> Helper loaded: cookie_helper
INFO - 2024-05-27 09:30:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:30:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:30:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-27 09:30:47 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:47 --> Total execution time: 0.0140
INFO - 2024-05-27 09:30:48 --> Config Class Initialized
INFO - 2024-05-27 09:30:48 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:48 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:48 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:48 --> URI Class Initialized
INFO - 2024-05-27 09:30:48 --> Router Class Initialized
INFO - 2024-05-27 09:30:48 --> Output Class Initialized
INFO - 2024-05-27 09:30:48 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:48 --> Input Class Initialized
INFO - 2024-05-27 09:30:48 --> Language Class Initialized
INFO - 2024-05-27 09:30:48 --> Loader Class Initialized
INFO - 2024-05-27 09:30:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:48 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:48 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:30:48 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:48 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:30:48 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:48 --> Total execution time: 0.0308
INFO - 2024-05-27 09:30:51 --> Config Class Initialized
INFO - 2024-05-27 09:30:51 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:51 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:51 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:51 --> URI Class Initialized
INFO - 2024-05-27 09:30:51 --> Router Class Initialized
INFO - 2024-05-27 09:30:51 --> Output Class Initialized
INFO - 2024-05-27 09:30:51 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:51 --> Input Class Initialized
INFO - 2024-05-27 09:30:51 --> Language Class Initialized
INFO - 2024-05-27 09:30:51 --> Loader Class Initialized
INFO - 2024-05-27 09:30:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:51 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:51 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:30:51 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:51 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:30:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:30:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:30:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-27 09:30:51 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:51 --> Total execution time: 0.0142
INFO - 2024-05-27 09:30:51 --> Config Class Initialized
INFO - 2024-05-27 09:30:51 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:51 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:51 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:51 --> URI Class Initialized
INFO - 2024-05-27 09:30:51 --> Router Class Initialized
INFO - 2024-05-27 09:30:51 --> Output Class Initialized
INFO - 2024-05-27 09:30:51 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:51 --> Input Class Initialized
INFO - 2024-05-27 09:30:51 --> Language Class Initialized
INFO - 2024-05-27 09:30:51 --> Loader Class Initialized
INFO - 2024-05-27 09:30:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:51 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:51 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:30:51 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:51 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:30:51 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:51 --> Total execution time: 0.0148
INFO - 2024-05-27 09:30:56 --> Config Class Initialized
INFO - 2024-05-27 09:30:56 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:56 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:56 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:56 --> URI Class Initialized
INFO - 2024-05-27 09:30:56 --> Router Class Initialized
INFO - 2024-05-27 09:30:56 --> Output Class Initialized
INFO - 2024-05-27 09:30:56 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:56 --> Input Class Initialized
INFO - 2024-05-27 09:30:56 --> Language Class Initialized
INFO - 2024-05-27 09:30:56 --> Loader Class Initialized
INFO - 2024-05-27 09:30:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:56 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:56 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-27 09:30:56 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:56 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:30:56 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:30:56 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:30:56 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-27 09:30:56 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:56 --> Total execution time: 0.0409
INFO - 2024-05-27 09:30:56 --> Config Class Initialized
INFO - 2024-05-27 09:30:56 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:56 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:56 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:56 --> URI Class Initialized
INFO - 2024-05-27 09:30:56 --> Router Class Initialized
INFO - 2024-05-27 09:30:56 --> Output Class Initialized
INFO - 2024-05-27 09:30:56 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:56 --> Input Class Initialized
INFO - 2024-05-27 09:30:56 --> Language Class Initialized
INFO - 2024-05-27 09:30:56 --> Loader Class Initialized
INFO - 2024-05-27 09:30:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:56 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:56 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-27 09:30:56 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:56 --> Config Class Initialized
INFO - 2024-05-27 09:30:56 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:30:56 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:30:56 --> Utf8 Class Initialized
INFO - 2024-05-27 09:30:56 --> URI Class Initialized
INFO - 2024-05-27 09:30:56 --> Router Class Initialized
INFO - 2024-05-27 09:30:56 --> Output Class Initialized
INFO - 2024-05-27 09:30:56 --> Security Class Initialized
DEBUG - 2024-05-27 09:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:30:56 --> Input Class Initialized
INFO - 2024-05-27 09:30:56 --> Language Class Initialized
INFO - 2024-05-27 09:30:56 --> Loader Class Initialized
INFO - 2024-05-27 09:30:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:30:56 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:30:56 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:30:56 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:56 --> Total execution time: 0.0621
INFO - 2024-05-27 09:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:30:56 --> Controller Class Initialized
DEBUG - 2024-05-27 09:30:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:30:56 --> Database Driver Class Initialized
INFO - 2024-05-27 09:30:56 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:30:56 --> Final output sent to browser
DEBUG - 2024-05-27 09:30:56 --> Total execution time: 0.0815
INFO - 2024-05-27 09:31:01 --> Config Class Initialized
INFO - 2024-05-27 09:31:01 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:01 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:01 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:01 --> URI Class Initialized
INFO - 2024-05-27 09:31:01 --> Router Class Initialized
INFO - 2024-05-27 09:31:01 --> Output Class Initialized
INFO - 2024-05-27 09:31:01 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:01 --> Input Class Initialized
INFO - 2024-05-27 09:31:01 --> Language Class Initialized
INFO - 2024-05-27 09:31:01 --> Loader Class Initialized
INFO - 2024-05-27 09:31:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:01 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:01 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-27 09:31:01 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:01 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:31:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:31:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresta.php
INFO - 2024-05-27 09:31:01 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:01 --> Total execution time: 0.0402
INFO - 2024-05-27 09:31:01 --> Config Class Initialized
INFO - 2024-05-27 09:31:01 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:01 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:01 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:01 --> URI Class Initialized
INFO - 2024-05-27 09:31:01 --> Router Class Initialized
INFO - 2024-05-27 09:31:01 --> Output Class Initialized
INFO - 2024-05-27 09:31:01 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:01 --> Input Class Initialized
INFO - 2024-05-27 09:31:01 --> Language Class Initialized
INFO - 2024-05-27 09:31:01 --> Loader Class Initialized
INFO - 2024-05-27 09:31:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:01 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:01 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:31:01 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:01 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:01 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:01 --> Total execution time: 0.0232
INFO - 2024-05-27 09:31:03 --> Config Class Initialized
INFO - 2024-05-27 09:31:03 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:03 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:03 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:03 --> URI Class Initialized
INFO - 2024-05-27 09:31:03 --> Router Class Initialized
INFO - 2024-05-27 09:31:03 --> Output Class Initialized
INFO - 2024-05-27 09:31:03 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:03 --> Input Class Initialized
INFO - 2024-05-27 09:31:03 --> Language Class Initialized
INFO - 2024-05-27 09:31:03 --> Loader Class Initialized
INFO - 2024-05-27 09:31:03 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:03 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:03 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:03 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-27 09:31:03 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:03 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:03 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:03 --> Total execution time: 0.0602
INFO - 2024-05-27 09:31:22 --> Config Class Initialized
INFO - 2024-05-27 09:31:22 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:22 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:22 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:22 --> URI Class Initialized
INFO - 2024-05-27 09:31:22 --> Router Class Initialized
INFO - 2024-05-27 09:31:22 --> Output Class Initialized
INFO - 2024-05-27 09:31:22 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:22 --> Input Class Initialized
INFO - 2024-05-27 09:31:22 --> Language Class Initialized
INFO - 2024-05-27 09:31:22 --> Loader Class Initialized
INFO - 2024-05-27 09:31:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:22 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:22 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:31:22 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:22 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:31:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:31:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-27 09:31:22 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:22 --> Total execution time: 0.0128
INFO - 2024-05-27 09:31:22 --> Config Class Initialized
INFO - 2024-05-27 09:31:22 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:22 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:22 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:22 --> URI Class Initialized
INFO - 2024-05-27 09:31:22 --> Router Class Initialized
INFO - 2024-05-27 09:31:22 --> Output Class Initialized
INFO - 2024-05-27 09:31:22 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:22 --> Input Class Initialized
INFO - 2024-05-27 09:31:22 --> Language Class Initialized
INFO - 2024-05-27 09:31:22 --> Loader Class Initialized
INFO - 2024-05-27 09:31:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:22 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:22 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:31:22 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:22 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:22 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:22 --> Total execution time: 0.0192
INFO - 2024-05-27 09:31:26 --> Config Class Initialized
INFO - 2024-05-27 09:31:26 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:26 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:26 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:26 --> URI Class Initialized
INFO - 2024-05-27 09:31:26 --> Router Class Initialized
INFO - 2024-05-27 09:31:26 --> Output Class Initialized
INFO - 2024-05-27 09:31:26 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:26 --> Input Class Initialized
INFO - 2024-05-27 09:31:26 --> Language Class Initialized
INFO - 2024-05-27 09:31:26 --> Loader Class Initialized
INFO - 2024-05-27 09:31:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:26 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:26 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:31:26 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:26 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:31:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:31:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-27 09:31:26 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:26 --> Total execution time: 0.0133
INFO - 2024-05-27 09:31:26 --> Config Class Initialized
INFO - 2024-05-27 09:31:26 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:26 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:26 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:26 --> URI Class Initialized
INFO - 2024-05-27 09:31:26 --> Router Class Initialized
INFO - 2024-05-27 09:31:26 --> Output Class Initialized
INFO - 2024-05-27 09:31:26 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:26 --> Input Class Initialized
INFO - 2024-05-27 09:31:26 --> Language Class Initialized
INFO - 2024-05-27 09:31:26 --> Loader Class Initialized
INFO - 2024-05-27 09:31:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:26 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:26 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:31:26 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:26 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:26 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:26 --> Total execution time: 0.0207
INFO - 2024-05-27 09:31:34 --> Config Class Initialized
INFO - 2024-05-27 09:31:34 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:34 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:34 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:34 --> URI Class Initialized
INFO - 2024-05-27 09:31:34 --> Router Class Initialized
INFO - 2024-05-27 09:31:34 --> Output Class Initialized
INFO - 2024-05-27 09:31:34 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:34 --> Input Class Initialized
INFO - 2024-05-27 09:31:34 --> Language Class Initialized
INFO - 2024-05-27 09:31:34 --> Loader Class Initialized
INFO - 2024-05-27 09:31:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:34 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:34 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-27 09:31:34 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:34 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:31:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:31:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresta.php
INFO - 2024-05-27 09:31:34 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:34 --> Total execution time: 0.0412
INFO - 2024-05-27 09:31:34 --> Config Class Initialized
INFO - 2024-05-27 09:31:34 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:34 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:34 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:34 --> URI Class Initialized
INFO - 2024-05-27 09:31:34 --> Router Class Initialized
INFO - 2024-05-27 09:31:34 --> Output Class Initialized
INFO - 2024-05-27 09:31:34 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:34 --> Input Class Initialized
INFO - 2024-05-27 09:31:34 --> Language Class Initialized
INFO - 2024-05-27 09:31:34 --> Loader Class Initialized
INFO - 2024-05-27 09:31:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:34 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:34 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:31:34 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:34 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:34 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:34 --> Total execution time: 0.0158
INFO - 2024-05-27 09:31:36 --> Config Class Initialized
INFO - 2024-05-27 09:31:36 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:36 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:36 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:36 --> URI Class Initialized
INFO - 2024-05-27 09:31:36 --> Router Class Initialized
INFO - 2024-05-27 09:31:36 --> Output Class Initialized
INFO - 2024-05-27 09:31:36 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:36 --> Input Class Initialized
INFO - 2024-05-27 09:31:36 --> Language Class Initialized
INFO - 2024-05-27 09:31:36 --> Loader Class Initialized
INFO - 2024-05-27 09:31:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:36 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:36 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-27 09:31:36 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:36 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:36 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:36 --> Total execution time: 0.0463
INFO - 2024-05-27 09:31:47 --> Config Class Initialized
INFO - 2024-05-27 09:31:47 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:47 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:47 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:47 --> URI Class Initialized
INFO - 2024-05-27 09:31:47 --> Router Class Initialized
INFO - 2024-05-27 09:31:47 --> Output Class Initialized
INFO - 2024-05-27 09:31:47 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:47 --> Input Class Initialized
INFO - 2024-05-27 09:31:47 --> Language Class Initialized
INFO - 2024-05-27 09:31:47 --> Loader Class Initialized
INFO - 2024-05-27 09:31:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:47 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:47 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:47 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-27 09:31:47 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:47 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:47 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:47 --> Total execution time: 0.0606
INFO - 2024-05-27 09:31:49 --> Config Class Initialized
INFO - 2024-05-27 09:31:49 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:31:49 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:31:49 --> Utf8 Class Initialized
INFO - 2024-05-27 09:31:49 --> URI Class Initialized
INFO - 2024-05-27 09:31:49 --> Router Class Initialized
INFO - 2024-05-27 09:31:49 --> Output Class Initialized
INFO - 2024-05-27 09:31:49 --> Security Class Initialized
DEBUG - 2024-05-27 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:31:49 --> Input Class Initialized
INFO - 2024-05-27 09:31:49 --> Language Class Initialized
INFO - 2024-05-27 09:31:49 --> Loader Class Initialized
INFO - 2024-05-27 09:31:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:31:49 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:31:49 --> Controller Class Initialized
DEBUG - 2024-05-27 09:31:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-27 09:31:49 --> Database Driver Class Initialized
INFO - 2024-05-27 09:31:49 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:31:49 --> Final output sent to browser
DEBUG - 2024-05-27 09:31:49 --> Total execution time: 0.0357
INFO - 2024-05-27 09:40:07 --> Config Class Initialized
INFO - 2024-05-27 09:40:07 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:40:07 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:40:07 --> Utf8 Class Initialized
INFO - 2024-05-27 09:40:07 --> URI Class Initialized
INFO - 2024-05-27 09:40:07 --> Router Class Initialized
INFO - 2024-05-27 09:40:07 --> Output Class Initialized
INFO - 2024-05-27 09:40:07 --> Security Class Initialized
DEBUG - 2024-05-27 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:40:07 --> Input Class Initialized
INFO - 2024-05-27 09:40:07 --> Language Class Initialized
INFO - 2024-05-27 09:40:07 --> Loader Class Initialized
INFO - 2024-05-27 09:40:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:40:07 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:40:07 --> Controller Class Initialized
DEBUG - 2024-05-27 09:40:07 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-27 09:40:07 --> Database Driver Class Initialized
INFO - 2024-05-27 09:40:07 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:40:07 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-27 09:40:07 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-27 09:40:07 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-27 09:40:07 --> Final output sent to browser
DEBUG - 2024-05-27 09:40:07 --> Total execution time: 0.1172
INFO - 2024-05-27 09:40:07 --> Config Class Initialized
INFO - 2024-05-27 09:40:07 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:40:07 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:40:07 --> Utf8 Class Initialized
INFO - 2024-05-27 09:40:07 --> URI Class Initialized
INFO - 2024-05-27 09:40:07 --> Router Class Initialized
INFO - 2024-05-27 09:40:07 --> Output Class Initialized
INFO - 2024-05-27 09:40:07 --> Security Class Initialized
DEBUG - 2024-05-27 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:40:07 --> Input Class Initialized
INFO - 2024-05-27 09:40:07 --> Language Class Initialized
INFO - 2024-05-27 09:40:07 --> Loader Class Initialized
INFO - 2024-05-27 09:40:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:40:07 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:40:07 --> Controller Class Initialized
DEBUG - 2024-05-27 09:40:07 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-27 09:40:07 --> Database Driver Class Initialized
INFO - 2024-05-27 09:40:07 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:40:07 --> Final output sent to browser
DEBUG - 2024-05-27 09:40:07 --> Total execution time: 0.0557
INFO - 2024-05-27 09:40:08 --> Config Class Initialized
INFO - 2024-05-27 09:40:08 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:40:08 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:40:08 --> Utf8 Class Initialized
INFO - 2024-05-27 09:40:08 --> URI Class Initialized
INFO - 2024-05-27 09:40:08 --> Router Class Initialized
INFO - 2024-05-27 09:40:08 --> Output Class Initialized
INFO - 2024-05-27 09:40:08 --> Security Class Initialized
DEBUG - 2024-05-27 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:40:08 --> Input Class Initialized
INFO - 2024-05-27 09:40:08 --> Language Class Initialized
INFO - 2024-05-27 09:40:08 --> Loader Class Initialized
INFO - 2024-05-27 09:40:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 09:40:08 --> Helper loaded: url_helper
DEBUG - 2024-05-27 09:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:40:08 --> Controller Class Initialized
DEBUG - 2024-05-27 09:40:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-27 09:40:08 --> Database Driver Class Initialized
INFO - 2024-05-27 09:40:08 --> Helper loaded: funciones_helper
INFO - 2024-05-27 09:40:08 --> Final output sent to browser
DEBUG - 2024-05-27 09:40:08 --> Total execution time: 0.0265
INFO - 2024-05-27 11:20:15 --> Config Class Initialized
INFO - 2024-05-27 11:20:15 --> Hooks Class Initialized
DEBUG - 2024-05-27 11:20:15 --> UTF-8 Support Enabled
INFO - 2024-05-27 11:20:15 --> Utf8 Class Initialized
INFO - 2024-05-27 11:20:15 --> URI Class Initialized
INFO - 2024-05-27 11:20:15 --> Router Class Initialized
INFO - 2024-05-27 11:20:15 --> Output Class Initialized
INFO - 2024-05-27 11:20:15 --> Security Class Initialized
DEBUG - 2024-05-27 11:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 11:20:15 --> Input Class Initialized
INFO - 2024-05-27 11:20:15 --> Language Class Initialized
INFO - 2024-05-27 11:20:15 --> Loader Class Initialized
INFO - 2024-05-27 11:20:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 11:20:15 --> Helper loaded: url_helper
DEBUG - 2024-05-27 11:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 11:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 11:20:15 --> Controller Class Initialized
DEBUG - 2024-05-27 11:20:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-27 11:20:15 --> Database Driver Class Initialized
INFO - 2024-05-27 11:20:15 --> Helper loaded: funciones_helper
INFO - 2024-05-27 11:20:15 --> Final output sent to browser
DEBUG - 2024-05-27 11:20:15 --> Total execution time: 0.0950
INFO - 2024-05-27 11:20:18 --> Config Class Initialized
INFO - 2024-05-27 11:20:18 --> Hooks Class Initialized
DEBUG - 2024-05-27 11:20:18 --> UTF-8 Support Enabled
INFO - 2024-05-27 11:20:18 --> Utf8 Class Initialized
INFO - 2024-05-27 11:20:18 --> URI Class Initialized
INFO - 2024-05-27 11:20:18 --> Router Class Initialized
INFO - 2024-05-27 11:20:18 --> Output Class Initialized
INFO - 2024-05-27 11:20:18 --> Security Class Initialized
DEBUG - 2024-05-27 11:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 11:20:18 --> Input Class Initialized
INFO - 2024-05-27 11:20:18 --> Language Class Initialized
INFO - 2024-05-27 11:20:18 --> Loader Class Initialized
INFO - 2024-05-27 11:20:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 11:20:18 --> Helper loaded: url_helper
DEBUG - 2024-05-27 11:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 11:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 11:20:18 --> Controller Class Initialized
DEBUG - 2024-05-27 11:20:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-27 11:20:18 --> Database Driver Class Initialized
INFO - 2024-05-27 11:20:18 --> Helper loaded: funciones_helper
INFO - 2024-05-27 11:20:18 --> Final output sent to browser
DEBUG - 2024-05-27 11:20:18 --> Total execution time: 0.0749
INFO - 2024-05-27 11:20:20 --> Config Class Initialized
INFO - 2024-05-27 11:20:20 --> Hooks Class Initialized
DEBUG - 2024-05-27 11:20:20 --> UTF-8 Support Enabled
INFO - 2024-05-27 11:20:20 --> Utf8 Class Initialized
INFO - 2024-05-27 11:20:20 --> URI Class Initialized
INFO - 2024-05-27 11:20:20 --> Router Class Initialized
INFO - 2024-05-27 11:20:20 --> Output Class Initialized
INFO - 2024-05-27 11:20:20 --> Security Class Initialized
DEBUG - 2024-05-27 11:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 11:20:20 --> Input Class Initialized
INFO - 2024-05-27 11:20:20 --> Language Class Initialized
INFO - 2024-05-27 11:20:20 --> Loader Class Initialized
INFO - 2024-05-27 11:20:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 11:20:20 --> Helper loaded: url_helper
DEBUG - 2024-05-27 11:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 11:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 11:20:20 --> Controller Class Initialized
DEBUG - 2024-05-27 11:20:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-27 11:20:20 --> Database Driver Class Initialized
INFO - 2024-05-27 11:20:20 --> Helper loaded: funciones_helper
INFO - 2024-05-27 11:20:20 --> Final output sent to browser
DEBUG - 2024-05-27 11:20:20 --> Total execution time: 0.2610
INFO - 2024-05-27 16:42:41 --> Config Class Initialized
INFO - 2024-05-27 16:42:41 --> Hooks Class Initialized
DEBUG - 2024-05-27 16:42:41 --> UTF-8 Support Enabled
INFO - 2024-05-27 16:42:41 --> Utf8 Class Initialized
INFO - 2024-05-27 16:42:41 --> URI Class Initialized
DEBUG - 2024-05-27 16:42:41 --> No URI present. Default controller set.
INFO - 2024-05-27 16:42:41 --> Router Class Initialized
INFO - 2024-05-27 16:42:41 --> Output Class Initialized
INFO - 2024-05-27 16:42:41 --> Security Class Initialized
DEBUG - 2024-05-27 16:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 16:42:41 --> Input Class Initialized
INFO - 2024-05-27 16:42:41 --> Language Class Initialized
INFO - 2024-05-27 16:42:41 --> Loader Class Initialized
INFO - 2024-05-27 16:42:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 16:42:41 --> Helper loaded: url_helper
DEBUG - 2024-05-27 16:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 16:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 16:42:41 --> Controller Class Initialized
INFO - 2024-05-27 23:12:01 --> Config Class Initialized
INFO - 2024-05-27 23:12:01 --> Hooks Class Initialized
DEBUG - 2024-05-27 23:12:01 --> UTF-8 Support Enabled
INFO - 2024-05-27 23:12:01 --> Utf8 Class Initialized
INFO - 2024-05-27 23:12:01 --> URI Class Initialized
DEBUG - 2024-05-27 23:12:01 --> No URI present. Default controller set.
INFO - 2024-05-27 23:12:01 --> Router Class Initialized
INFO - 2024-05-27 23:12:01 --> Output Class Initialized
INFO - 2024-05-27 23:12:01 --> Security Class Initialized
DEBUG - 2024-05-27 23:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 23:12:01 --> Input Class Initialized
INFO - 2024-05-27 23:12:01 --> Language Class Initialized
INFO - 2024-05-27 23:12:01 --> Loader Class Initialized
INFO - 2024-05-27 23:12:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 23:12:01 --> Helper loaded: url_helper
DEBUG - 2024-05-27 23:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 23:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 23:12:01 --> Controller Class Initialized
INFO - 2024-05-27 23:12:09 --> Config Class Initialized
INFO - 2024-05-27 23:12:09 --> Hooks Class Initialized
DEBUG - 2024-05-27 23:12:09 --> UTF-8 Support Enabled
INFO - 2024-05-27 23:12:09 --> Utf8 Class Initialized
INFO - 2024-05-27 23:12:09 --> URI Class Initialized
DEBUG - 2024-05-27 23:12:09 --> No URI present. Default controller set.
INFO - 2024-05-27 23:12:09 --> Router Class Initialized
INFO - 2024-05-27 23:12:09 --> Output Class Initialized
INFO - 2024-05-27 23:12:09 --> Security Class Initialized
DEBUG - 2024-05-27 23:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 23:12:09 --> Input Class Initialized
INFO - 2024-05-27 23:12:09 --> Language Class Initialized
INFO - 2024-05-27 23:12:09 --> Loader Class Initialized
INFO - 2024-05-27 23:12:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-27 23:12:09 --> Helper loaded: url_helper
DEBUG - 2024-05-27 23:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-27 23:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 23:12:09 --> Controller Class Initialized
