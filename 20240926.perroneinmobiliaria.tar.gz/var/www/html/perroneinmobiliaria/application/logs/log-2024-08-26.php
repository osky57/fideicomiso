<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-26 12:07:57 --> Config Class Initialized
INFO - 2024-08-26 12:07:57 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:07:57 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:07:57 --> Utf8 Class Initialized
INFO - 2024-08-26 12:07:57 --> URI Class Initialized
DEBUG - 2024-08-26 12:07:57 --> No URI present. Default controller set.
INFO - 2024-08-26 12:07:57 --> Router Class Initialized
INFO - 2024-08-26 12:07:57 --> Output Class Initialized
INFO - 2024-08-26 12:07:57 --> Security Class Initialized
DEBUG - 2024-08-26 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:07:57 --> Input Class Initialized
INFO - 2024-08-26 12:07:57 --> Language Class Initialized
INFO - 2024-08-26 12:07:57 --> Loader Class Initialized
INFO - 2024-08-26 12:07:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 12:07:57 --> Helper loaded: url_helper
DEBUG - 2024-08-26 12:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 12:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:07:57 --> Controller Class Initialized
INFO - 2024-08-26 12:07:57 --> Config Class Initialized
INFO - 2024-08-26 12:07:57 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:07:57 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:07:57 --> Utf8 Class Initialized
INFO - 2024-08-26 12:07:57 --> URI Class Initialized
INFO - 2024-08-26 12:07:57 --> Router Class Initialized
INFO - 2024-08-26 12:07:57 --> Output Class Initialized
INFO - 2024-08-26 12:07:57 --> Security Class Initialized
DEBUG - 2024-08-26 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:07:57 --> Input Class Initialized
INFO - 2024-08-26 12:07:57 --> Language Class Initialized
INFO - 2024-08-26 12:07:57 --> Loader Class Initialized
INFO - 2024-08-26 12:07:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 12:07:57 --> Helper loaded: url_helper
DEBUG - 2024-08-26 12:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 12:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:07:57 --> Controller Class Initialized
DEBUG - 2024-08-26 12:07:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-26 12:07:57 --> Database Driver Class Initialized
INFO - 2024-08-26 12:07:57 --> Helper loaded: cookie_helper
INFO - 2024-08-26 12:07:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-26 12:07:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-26 12:07:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-26 12:07:57 --> Final output sent to browser
DEBUG - 2024-08-26 12:07:57 --> Total execution time: 0.0435
INFO - 2024-08-26 12:07:58 --> Config Class Initialized
INFO - 2024-08-26 12:07:58 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:07:58 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:07:58 --> Utf8 Class Initialized
INFO - 2024-08-26 12:07:58 --> URI Class Initialized
INFO - 2024-08-26 12:07:58 --> Router Class Initialized
INFO - 2024-08-26 12:07:58 --> Output Class Initialized
INFO - 2024-08-26 12:07:58 --> Security Class Initialized
DEBUG - 2024-08-26 12:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:07:58 --> Input Class Initialized
INFO - 2024-08-26 12:07:58 --> Language Class Initialized
INFO - 2024-08-26 12:07:58 --> Loader Class Initialized
INFO - 2024-08-26 12:07:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 12:07:58 --> Helper loaded: url_helper
DEBUG - 2024-08-26 12:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 12:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:07:58 --> Controller Class Initialized
INFO - 2024-08-26 12:55:35 --> Config Class Initialized
INFO - 2024-08-26 12:55:35 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:55:35 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:55:35 --> Utf8 Class Initialized
INFO - 2024-08-26 12:55:35 --> URI Class Initialized
DEBUG - 2024-08-26 12:55:35 --> No URI present. Default controller set.
INFO - 2024-08-26 12:55:35 --> Router Class Initialized
INFO - 2024-08-26 12:55:35 --> Output Class Initialized
INFO - 2024-08-26 12:55:35 --> Security Class Initialized
DEBUG - 2024-08-26 12:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:55:35 --> Input Class Initialized
INFO - 2024-08-26 12:55:35 --> Language Class Initialized
INFO - 2024-08-26 12:55:35 --> Loader Class Initialized
INFO - 2024-08-26 12:55:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 12:55:35 --> Helper loaded: url_helper
DEBUG - 2024-08-26 12:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 12:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:55:35 --> Controller Class Initialized
INFO - 2024-08-26 14:24:41 --> Config Class Initialized
INFO - 2024-08-26 14:24:41 --> Hooks Class Initialized
DEBUG - 2024-08-26 14:24:41 --> UTF-8 Support Enabled
INFO - 2024-08-26 14:24:41 --> Utf8 Class Initialized
INFO - 2024-08-26 14:24:41 --> URI Class Initialized
DEBUG - 2024-08-26 14:24:41 --> No URI present. Default controller set.
INFO - 2024-08-26 14:24:41 --> Router Class Initialized
INFO - 2024-08-26 14:24:41 --> Output Class Initialized
INFO - 2024-08-26 14:24:41 --> Security Class Initialized
DEBUG - 2024-08-26 14:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 14:24:41 --> Input Class Initialized
INFO - 2024-08-26 14:24:41 --> Language Class Initialized
INFO - 2024-08-26 14:24:41 --> Loader Class Initialized
INFO - 2024-08-26 14:24:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 14:24:41 --> Helper loaded: url_helper
DEBUG - 2024-08-26 14:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 14:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 14:24:41 --> Controller Class Initialized
INFO - 2024-08-26 14:30:52 --> Config Class Initialized
INFO - 2024-08-26 14:30:52 --> Hooks Class Initialized
DEBUG - 2024-08-26 14:30:52 --> UTF-8 Support Enabled
INFO - 2024-08-26 14:30:52 --> Utf8 Class Initialized
INFO - 2024-08-26 14:30:52 --> URI Class Initialized
DEBUG - 2024-08-26 14:30:52 --> No URI present. Default controller set.
INFO - 2024-08-26 14:30:52 --> Router Class Initialized
INFO - 2024-08-26 14:30:52 --> Output Class Initialized
INFO - 2024-08-26 14:30:52 --> Security Class Initialized
DEBUG - 2024-08-26 14:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 14:30:52 --> Input Class Initialized
INFO - 2024-08-26 14:30:52 --> Language Class Initialized
INFO - 2024-08-26 14:30:52 --> Loader Class Initialized
INFO - 2024-08-26 14:30:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 14:30:52 --> Helper loaded: url_helper
DEBUG - 2024-08-26 14:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 14:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 14:30:52 --> Controller Class Initialized
INFO - 2024-08-26 15:03:10 --> Config Class Initialized
INFO - 2024-08-26 15:03:10 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:03:10 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:03:10 --> Utf8 Class Initialized
INFO - 2024-08-26 15:03:10 --> URI Class Initialized
DEBUG - 2024-08-26 15:03:10 --> No URI present. Default controller set.
INFO - 2024-08-26 15:03:10 --> Router Class Initialized
INFO - 2024-08-26 15:03:10 --> Output Class Initialized
INFO - 2024-08-26 15:03:10 --> Security Class Initialized
DEBUG - 2024-08-26 15:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:03:10 --> Input Class Initialized
INFO - 2024-08-26 15:03:10 --> Language Class Initialized
INFO - 2024-08-26 15:03:10 --> Loader Class Initialized
INFO - 2024-08-26 15:03:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 15:03:10 --> Helper loaded: url_helper
DEBUG - 2024-08-26 15:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:03:10 --> Controller Class Initialized
INFO - 2024-08-26 22:32:55 --> Config Class Initialized
INFO - 2024-08-26 22:32:55 --> Hooks Class Initialized
DEBUG - 2024-08-26 22:32:55 --> UTF-8 Support Enabled
INFO - 2024-08-26 22:32:55 --> Utf8 Class Initialized
INFO - 2024-08-26 22:32:55 --> URI Class Initialized
DEBUG - 2024-08-26 22:32:55 --> No URI present. Default controller set.
INFO - 2024-08-26 22:32:55 --> Router Class Initialized
INFO - 2024-08-26 22:32:55 --> Output Class Initialized
INFO - 2024-08-26 22:32:55 --> Security Class Initialized
DEBUG - 2024-08-26 22:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 22:32:55 --> Input Class Initialized
INFO - 2024-08-26 22:32:55 --> Language Class Initialized
INFO - 2024-08-26 22:32:55 --> Loader Class Initialized
INFO - 2024-08-26 22:32:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-26 22:32:55 --> Helper loaded: url_helper
DEBUG - 2024-08-26 22:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 22:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 22:32:55 --> Controller Class Initialized
