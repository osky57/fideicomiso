<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-24 09:01:55 --> Config Class Initialized
INFO - 2024-08-24 09:01:55 --> Hooks Class Initialized
DEBUG - 2024-08-24 09:01:55 --> UTF-8 Support Enabled
INFO - 2024-08-24 09:01:55 --> Utf8 Class Initialized
INFO - 2024-08-24 09:01:55 --> URI Class Initialized
DEBUG - 2024-08-24 09:01:55 --> No URI present. Default controller set.
INFO - 2024-08-24 09:01:55 --> Router Class Initialized
INFO - 2024-08-24 09:01:55 --> Output Class Initialized
INFO - 2024-08-24 09:01:55 --> Security Class Initialized
DEBUG - 2024-08-24 09:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 09:01:55 --> Input Class Initialized
INFO - 2024-08-24 09:01:55 --> Language Class Initialized
INFO - 2024-08-24 09:01:55 --> Loader Class Initialized
INFO - 2024-08-24 09:01:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-24 09:01:55 --> Helper loaded: url_helper
DEBUG - 2024-08-24 09:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-24 09:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 09:01:55 --> Controller Class Initialized
