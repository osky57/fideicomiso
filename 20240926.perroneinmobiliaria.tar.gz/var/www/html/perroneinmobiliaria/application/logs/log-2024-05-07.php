<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-07 02:48:42 --> Config Class Initialized
INFO - 2024-05-07 02:48:42 --> Hooks Class Initialized
DEBUG - 2024-05-07 02:48:42 --> UTF-8 Support Enabled
INFO - 2024-05-07 02:48:42 --> Utf8 Class Initialized
INFO - 2024-05-07 02:48:42 --> URI Class Initialized
DEBUG - 2024-05-07 02:48:42 --> No URI present. Default controller set.
INFO - 2024-05-07 02:48:42 --> Router Class Initialized
INFO - 2024-05-07 02:48:42 --> Output Class Initialized
INFO - 2024-05-07 02:48:42 --> Security Class Initialized
DEBUG - 2024-05-07 02:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 02:48:42 --> Input Class Initialized
INFO - 2024-05-07 02:48:42 --> Language Class Initialized
INFO - 2024-05-07 02:48:42 --> Loader Class Initialized
INFO - 2024-05-07 02:48:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 02:48:42 --> Helper loaded: url_helper
DEBUG - 2024-05-07 02:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 02:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 02:48:42 --> Controller Class Initialized
INFO - 2024-05-07 10:08:23 --> Config Class Initialized
INFO - 2024-05-07 10:08:23 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:23 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:23 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:23 --> URI Class Initialized
INFO - 2024-05-07 10:08:23 --> Router Class Initialized
INFO - 2024-05-07 10:08:23 --> Output Class Initialized
INFO - 2024-05-07 10:08:23 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:23 --> Input Class Initialized
INFO - 2024-05-07 10:08:23 --> Language Class Initialized
INFO - 2024-05-07 10:08:23 --> Loader Class Initialized
INFO - 2024-05-07 10:08:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:23 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:23 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-07 10:08:23 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:23 --> Helper loaded: cookie_helper
INFO - 2024-05-07 10:08:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:08:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:08:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-07 10:08:23 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:23 --> Total execution time: 0.0613
INFO - 2024-05-07 10:08:24 --> Config Class Initialized
INFO - 2024-05-07 10:08:24 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:24 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:24 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:24 --> URI Class Initialized
INFO - 2024-05-07 10:08:24 --> Router Class Initialized
INFO - 2024-05-07 10:08:24 --> Output Class Initialized
INFO - 2024-05-07 10:08:24 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:24 --> Input Class Initialized
INFO - 2024-05-07 10:08:24 --> Language Class Initialized
INFO - 2024-05-07 10:08:24 --> Loader Class Initialized
INFO - 2024-05-07 10:08:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:24 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:24 --> Controller Class Initialized
INFO - 2024-05-07 10:08:25 --> Config Class Initialized
INFO - 2024-05-07 10:08:25 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:25 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:25 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:25 --> URI Class Initialized
INFO - 2024-05-07 10:08:25 --> Router Class Initialized
INFO - 2024-05-07 10:08:25 --> Output Class Initialized
INFO - 2024-05-07 10:08:25 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:25 --> Input Class Initialized
INFO - 2024-05-07 10:08:25 --> Language Class Initialized
INFO - 2024-05-07 10:08:25 --> Loader Class Initialized
INFO - 2024-05-07 10:08:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:25 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:25 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-07 10:08:25 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:25 --> Helper loaded: cookie_helper
INFO - 2024-05-07 10:08:25 --> Helper loaded: form_helper
INFO - 2024-05-07 10:08:25 --> Form Validation Class Initialized
INFO - 2024-05-07 10:08:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-07 10:08:25 --> Config Class Initialized
INFO - 2024-05-07 10:08:25 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:25 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:25 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:25 --> URI Class Initialized
INFO - 2024-05-07 10:08:25 --> Router Class Initialized
INFO - 2024-05-07 10:08:25 --> Output Class Initialized
INFO - 2024-05-07 10:08:25 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:25 --> Input Class Initialized
INFO - 2024-05-07 10:08:25 --> Language Class Initialized
INFO - 2024-05-07 10:08:25 --> Loader Class Initialized
INFO - 2024-05-07 10:08:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:25 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:25 --> Controller Class Initialized
INFO - 2024-05-07 10:08:25 --> Database Driver Class Initialized
DEBUG - 2024-05-07 10:08:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-07 10:08:26 --> Helper loaded: cookie_helper
INFO - 2024-05-07 10:08:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:08:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:08:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-07 10:08:26 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:26 --> Total execution time: 0.0161
INFO - 2024-05-07 10:08:26 --> Config Class Initialized
INFO - 2024-05-07 10:08:26 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:26 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:26 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:26 --> URI Class Initialized
INFO - 2024-05-07 10:08:26 --> Router Class Initialized
INFO - 2024-05-07 10:08:26 --> Output Class Initialized
INFO - 2024-05-07 10:08:26 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:26 --> Input Class Initialized
INFO - 2024-05-07 10:08:26 --> Language Class Initialized
INFO - 2024-05-07 10:08:26 --> Loader Class Initialized
INFO - 2024-05-07 10:08:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:26 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:26 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:08:26 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:26 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:08:26 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:26 --> Total execution time: 0.0310
INFO - 2024-05-07 10:08:42 --> Config Class Initialized
INFO - 2024-05-07 10:08:42 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:42 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:42 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:42 --> URI Class Initialized
INFO - 2024-05-07 10:08:42 --> Router Class Initialized
INFO - 2024-05-07 10:08:42 --> Output Class Initialized
INFO - 2024-05-07 10:08:42 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:42 --> Input Class Initialized
INFO - 2024-05-07 10:08:42 --> Language Class Initialized
INFO - 2024-05-07 10:08:42 --> Loader Class Initialized
INFO - 2024-05-07 10:08:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:42 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:42 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:08:42 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:42 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:08:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:08:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:08:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-07 10:08:42 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:42 --> Total execution time: 0.0246
INFO - 2024-05-07 10:08:42 --> Config Class Initialized
INFO - 2024-05-07 10:08:42 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:42 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:42 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:42 --> URI Class Initialized
INFO - 2024-05-07 10:08:42 --> Router Class Initialized
INFO - 2024-05-07 10:08:42 --> Output Class Initialized
INFO - 2024-05-07 10:08:42 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:42 --> Input Class Initialized
INFO - 2024-05-07 10:08:42 --> Language Class Initialized
INFO - 2024-05-07 10:08:42 --> Loader Class Initialized
INFO - 2024-05-07 10:08:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:42 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:42 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:08:42 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:42 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:08:42 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:42 --> Total execution time: 0.0193
INFO - 2024-05-07 10:08:48 --> Config Class Initialized
INFO - 2024-05-07 10:08:48 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:48 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:48 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:48 --> URI Class Initialized
INFO - 2024-05-07 10:08:48 --> Router Class Initialized
INFO - 2024-05-07 10:08:48 --> Output Class Initialized
INFO - 2024-05-07 10:08:48 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:48 --> Input Class Initialized
INFO - 2024-05-07 10:08:48 --> Language Class Initialized
INFO - 2024-05-07 10:08:48 --> Loader Class Initialized
INFO - 2024-05-07 10:08:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:48 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:48 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:08:48 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:48 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:08:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:08:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:08:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-07 10:08:48 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:48 --> Total execution time: 0.0392
INFO - 2024-05-07 10:08:48 --> Config Class Initialized
INFO - 2024-05-07 10:08:48 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:48 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:48 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:48 --> URI Class Initialized
INFO - 2024-05-07 10:08:48 --> Router Class Initialized
INFO - 2024-05-07 10:08:48 --> Output Class Initialized
INFO - 2024-05-07 10:08:48 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:48 --> Input Class Initialized
INFO - 2024-05-07 10:08:48 --> Language Class Initialized
INFO - 2024-05-07 10:08:48 --> Loader Class Initialized
INFO - 2024-05-07 10:08:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:48 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:48 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:08:48 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:48 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:08:48 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:48 --> Total execution time: 0.0524
INFO - 2024-05-07 10:08:48 --> Config Class Initialized
INFO - 2024-05-07 10:08:48 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:08:48 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:08:48 --> Utf8 Class Initialized
INFO - 2024-05-07 10:08:48 --> URI Class Initialized
INFO - 2024-05-07 10:08:48 --> Router Class Initialized
INFO - 2024-05-07 10:08:48 --> Output Class Initialized
INFO - 2024-05-07 10:08:48 --> Security Class Initialized
DEBUG - 2024-05-07 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:08:48 --> Input Class Initialized
INFO - 2024-05-07 10:08:48 --> Language Class Initialized
INFO - 2024-05-07 10:08:48 --> Loader Class Initialized
INFO - 2024-05-07 10:08:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:08:48 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:08:48 --> Controller Class Initialized
DEBUG - 2024-05-07 10:08:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:08:48 --> Database Driver Class Initialized
INFO - 2024-05-07 10:08:48 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:08:48 --> Final output sent to browser
DEBUG - 2024-05-07 10:08:48 --> Total execution time: 0.0258
INFO - 2024-05-07 10:09:10 --> Config Class Initialized
INFO - 2024-05-07 10:09:10 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:09:10 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:09:10 --> Utf8 Class Initialized
INFO - 2024-05-07 10:09:10 --> URI Class Initialized
INFO - 2024-05-07 10:09:10 --> Router Class Initialized
INFO - 2024-05-07 10:09:10 --> Output Class Initialized
INFO - 2024-05-07 10:09:10 --> Security Class Initialized
DEBUG - 2024-05-07 10:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:09:10 --> Input Class Initialized
INFO - 2024-05-07 10:09:10 --> Language Class Initialized
INFO - 2024-05-07 10:09:10 --> Loader Class Initialized
INFO - 2024-05-07 10:09:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:09:10 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:09:10 --> Controller Class Initialized
DEBUG - 2024-05-07 10:09:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:09:10 --> Database Driver Class Initialized
INFO - 2024-05-07 10:09:10 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:09:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:09:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:09:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-07 10:09:10 --> Final output sent to browser
DEBUG - 2024-05-07 10:09:10 --> Total execution time: 0.0145
INFO - 2024-05-07 10:09:10 --> Config Class Initialized
INFO - 2024-05-07 10:09:10 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:09:10 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:09:10 --> Utf8 Class Initialized
INFO - 2024-05-07 10:09:10 --> URI Class Initialized
INFO - 2024-05-07 10:09:10 --> Router Class Initialized
INFO - 2024-05-07 10:09:10 --> Output Class Initialized
INFO - 2024-05-07 10:09:10 --> Security Class Initialized
DEBUG - 2024-05-07 10:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:09:10 --> Input Class Initialized
INFO - 2024-05-07 10:09:10 --> Language Class Initialized
INFO - 2024-05-07 10:09:10 --> Loader Class Initialized
INFO - 2024-05-07 10:09:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:09:10 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:09:10 --> Controller Class Initialized
DEBUG - 2024-05-07 10:09:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:09:10 --> Database Driver Class Initialized
INFO - 2024-05-07 10:09:10 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:09:10 --> Final output sent to browser
DEBUG - 2024-05-07 10:09:10 --> Total execution time: 0.0191
INFO - 2024-05-07 10:09:16 --> Config Class Initialized
INFO - 2024-05-07 10:09:16 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:09:16 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:09:16 --> Utf8 Class Initialized
INFO - 2024-05-07 10:09:16 --> URI Class Initialized
INFO - 2024-05-07 10:09:16 --> Router Class Initialized
INFO - 2024-05-07 10:09:16 --> Output Class Initialized
INFO - 2024-05-07 10:09:16 --> Security Class Initialized
DEBUG - 2024-05-07 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:09:16 --> Input Class Initialized
INFO - 2024-05-07 10:09:16 --> Language Class Initialized
INFO - 2024-05-07 10:09:16 --> Loader Class Initialized
INFO - 2024-05-07 10:09:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:09:16 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:09:16 --> Controller Class Initialized
DEBUG - 2024-05-07 10:09:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:09:16 --> Database Driver Class Initialized
INFO - 2024-05-07 10:09:16 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:09:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:09:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:09:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-05-07 10:09:16 --> Final output sent to browser
DEBUG - 2024-05-07 10:09:16 --> Total execution time: 0.0238
INFO - 2024-05-07 10:09:16 --> Config Class Initialized
INFO - 2024-05-07 10:09:16 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:09:16 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:09:16 --> Utf8 Class Initialized
INFO - 2024-05-07 10:09:16 --> URI Class Initialized
INFO - 2024-05-07 10:09:16 --> Router Class Initialized
INFO - 2024-05-07 10:09:16 --> Output Class Initialized
INFO - 2024-05-07 10:09:16 --> Security Class Initialized
DEBUG - 2024-05-07 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:09:16 --> Input Class Initialized
INFO - 2024-05-07 10:09:16 --> Language Class Initialized
INFO - 2024-05-07 10:09:16 --> Loader Class Initialized
INFO - 2024-05-07 10:09:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:09:16 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:09:16 --> Controller Class Initialized
DEBUG - 2024-05-07 10:09:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:09:16 --> Database Driver Class Initialized
INFO - 2024-05-07 10:09:16 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:09:16 --> Final output sent to browser
DEBUG - 2024-05-07 10:09:16 --> Total execution time: 0.0586
INFO - 2024-05-07 10:09:16 --> Config Class Initialized
INFO - 2024-05-07 10:09:16 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:09:16 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:09:16 --> Utf8 Class Initialized
INFO - 2024-05-07 10:09:16 --> URI Class Initialized
INFO - 2024-05-07 10:09:16 --> Router Class Initialized
INFO - 2024-05-07 10:09:16 --> Output Class Initialized
INFO - 2024-05-07 10:09:16 --> Security Class Initialized
DEBUG - 2024-05-07 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:09:16 --> Input Class Initialized
INFO - 2024-05-07 10:09:16 --> Language Class Initialized
INFO - 2024-05-07 10:09:16 --> Loader Class Initialized
INFO - 2024-05-07 10:09:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:09:16 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:09:16 --> Controller Class Initialized
DEBUG - 2024-05-07 10:09:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:09:16 --> Database Driver Class Initialized
INFO - 2024-05-07 10:09:16 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:09:16 --> Final output sent to browser
DEBUG - 2024-05-07 10:09:16 --> Total execution time: 0.0223
INFO - 2024-05-07 10:09:21 --> Config Class Initialized
INFO - 2024-05-07 10:09:21 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:09:21 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:09:21 --> Utf8 Class Initialized
INFO - 2024-05-07 10:09:21 --> URI Class Initialized
INFO - 2024-05-07 10:09:21 --> Router Class Initialized
INFO - 2024-05-07 10:09:21 --> Output Class Initialized
INFO - 2024-05-07 10:09:21 --> Security Class Initialized
DEBUG - 2024-05-07 10:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:09:21 --> Input Class Initialized
INFO - 2024-05-07 10:09:21 --> Language Class Initialized
INFO - 2024-05-07 10:09:21 --> Loader Class Initialized
INFO - 2024-05-07 10:09:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:09:21 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:09:21 --> Controller Class Initialized
DEBUG - 2024-05-07 10:09:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:09:21 --> Database Driver Class Initialized
INFO - 2024-05-07 10:09:21 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:09:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-entidad.php
INFO - 2024-05-07 10:09:21 --> Final output sent to browser
DEBUG - 2024-05-07 10:09:21 --> Total execution time: 0.0276
INFO - 2024-05-07 10:10:41 --> Config Class Initialized
INFO - 2024-05-07 10:10:41 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:10:41 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:10:41 --> Utf8 Class Initialized
INFO - 2024-05-07 10:10:41 --> URI Class Initialized
INFO - 2024-05-07 10:10:41 --> Router Class Initialized
INFO - 2024-05-07 10:10:41 --> Output Class Initialized
INFO - 2024-05-07 10:10:41 --> Security Class Initialized
DEBUG - 2024-05-07 10:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:10:41 --> Input Class Initialized
INFO - 2024-05-07 10:10:41 --> Language Class Initialized
INFO - 2024-05-07 10:10:41 --> Loader Class Initialized
INFO - 2024-05-07 10:10:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:10:41 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:10:41 --> Controller Class Initialized
DEBUG - 2024-05-07 10:10:41 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:10:41 --> Database Driver Class Initialized
INFO - 2024-05-07 10:10:41 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:10:41 --> Final output sent to browser
DEBUG - 2024-05-07 10:10:41 --> Total execution time: 0.0160
INFO - 2024-05-07 10:10:42 --> Config Class Initialized
INFO - 2024-05-07 10:10:42 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:10:42 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:10:42 --> Utf8 Class Initialized
INFO - 2024-05-07 10:10:42 --> URI Class Initialized
INFO - 2024-05-07 10:10:42 --> Router Class Initialized
INFO - 2024-05-07 10:10:42 --> Output Class Initialized
INFO - 2024-05-07 10:10:42 --> Security Class Initialized
DEBUG - 2024-05-07 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:10:42 --> Input Class Initialized
INFO - 2024-05-07 10:10:42 --> Language Class Initialized
INFO - 2024-05-07 10:10:42 --> Loader Class Initialized
INFO - 2024-05-07 10:10:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:10:42 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:10:42 --> Controller Class Initialized
DEBUG - 2024-05-07 10:10:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:10:42 --> Database Driver Class Initialized
INFO - 2024-05-07 10:10:42 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:10:42 --> Final output sent to browser
DEBUG - 2024-05-07 10:10:42 --> Total execution time: 0.0240
INFO - 2024-05-07 10:10:42 --> Config Class Initialized
INFO - 2024-05-07 10:10:42 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:10:42 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:10:42 --> Utf8 Class Initialized
INFO - 2024-05-07 10:10:42 --> URI Class Initialized
INFO - 2024-05-07 10:10:42 --> Router Class Initialized
INFO - 2024-05-07 10:10:42 --> Output Class Initialized
INFO - 2024-05-07 10:10:42 --> Security Class Initialized
DEBUG - 2024-05-07 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:10:42 --> Input Class Initialized
INFO - 2024-05-07 10:10:42 --> Language Class Initialized
INFO - 2024-05-07 10:10:42 --> Loader Class Initialized
INFO - 2024-05-07 10:10:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:10:42 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:10:42 --> Controller Class Initialized
DEBUG - 2024-05-07 10:10:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:10:42 --> Database Driver Class Initialized
INFO - 2024-05-07 10:10:42 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:10:42 --> Final output sent to browser
DEBUG - 2024-05-07 10:10:42 --> Total execution time: 0.0509
INFO - 2024-05-07 10:11:26 --> Config Class Initialized
INFO - 2024-05-07 10:11:26 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:26 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:26 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:26 --> URI Class Initialized
INFO - 2024-05-07 10:11:26 --> Router Class Initialized
INFO - 2024-05-07 10:11:26 --> Output Class Initialized
INFO - 2024-05-07 10:11:26 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:26 --> Input Class Initialized
INFO - 2024-05-07 10:11:26 --> Language Class Initialized
INFO - 2024-05-07 10:11:26 --> Loader Class Initialized
INFO - 2024-05-07 10:11:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:26 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:26 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:11:26 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:26 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:11:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:11:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-07 10:11:26 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:26 --> Total execution time: 0.0171
INFO - 2024-05-07 10:11:26 --> Config Class Initialized
INFO - 2024-05-07 10:11:26 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:26 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:26 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:26 --> URI Class Initialized
INFO - 2024-05-07 10:11:26 --> Router Class Initialized
INFO - 2024-05-07 10:11:26 --> Output Class Initialized
INFO - 2024-05-07 10:11:26 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:26 --> Input Class Initialized
INFO - 2024-05-07 10:11:26 --> Language Class Initialized
INFO - 2024-05-07 10:11:26 --> Loader Class Initialized
INFO - 2024-05-07 10:11:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:26 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:26 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:11:26 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:26 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:26 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:26 --> Total execution time: 0.0212
INFO - 2024-05-07 10:11:35 --> Config Class Initialized
INFO - 2024-05-07 10:11:35 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:35 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:35 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:35 --> URI Class Initialized
INFO - 2024-05-07 10:11:35 --> Router Class Initialized
INFO - 2024-05-07 10:11:35 --> Output Class Initialized
INFO - 2024-05-07 10:11:35 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:35 --> Input Class Initialized
INFO - 2024-05-07 10:11:35 --> Language Class Initialized
INFO - 2024-05-07 10:11:35 --> Loader Class Initialized
INFO - 2024-05-07 10:11:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:35 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:35 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:11:35 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:36 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:11:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:11:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-07 10:11:36 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:36 --> Total execution time: 0.0264
INFO - 2024-05-07 10:11:36 --> Config Class Initialized
INFO - 2024-05-07 10:11:36 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:36 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:36 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:36 --> URI Class Initialized
INFO - 2024-05-07 10:11:36 --> Router Class Initialized
INFO - 2024-05-07 10:11:36 --> Output Class Initialized
INFO - 2024-05-07 10:11:36 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:36 --> Input Class Initialized
INFO - 2024-05-07 10:11:36 --> Language Class Initialized
INFO - 2024-05-07 10:11:36 --> Loader Class Initialized
INFO - 2024-05-07 10:11:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:36 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:36 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:11:36 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:36 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:36 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:36 --> Total execution time: 0.0556
INFO - 2024-05-07 10:11:36 --> Config Class Initialized
INFO - 2024-05-07 10:11:36 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:36 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:36 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:36 --> URI Class Initialized
INFO - 2024-05-07 10:11:36 --> Router Class Initialized
INFO - 2024-05-07 10:11:36 --> Output Class Initialized
INFO - 2024-05-07 10:11:36 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:36 --> Input Class Initialized
INFO - 2024-05-07 10:11:36 --> Language Class Initialized
INFO - 2024-05-07 10:11:36 --> Loader Class Initialized
INFO - 2024-05-07 10:11:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:36 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:36 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:11:36 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:36 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:36 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:36 --> Total execution time: 0.0167
INFO - 2024-05-07 10:11:43 --> Config Class Initialized
INFO - 2024-05-07 10:11:43 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:43 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:43 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:43 --> URI Class Initialized
INFO - 2024-05-07 10:11:43 --> Router Class Initialized
INFO - 2024-05-07 10:11:43 --> Output Class Initialized
INFO - 2024-05-07 10:11:43 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:43 --> Input Class Initialized
INFO - 2024-05-07 10:11:43 --> Language Class Initialized
INFO - 2024-05-07 10:11:43 --> Loader Class Initialized
INFO - 2024-05-07 10:11:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:43 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:43 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:11:43 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:43 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:43 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:43 --> Total execution time: 0.0273
INFO - 2024-05-07 10:11:48 --> Config Class Initialized
INFO - 2024-05-07 10:11:48 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:48 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:48 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:48 --> URI Class Initialized
INFO - 2024-05-07 10:11:48 --> Router Class Initialized
INFO - 2024-05-07 10:11:48 --> Output Class Initialized
INFO - 2024-05-07 10:11:48 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:48 --> Input Class Initialized
INFO - 2024-05-07 10:11:48 --> Language Class Initialized
INFO - 2024-05-07 10:11:48 --> Loader Class Initialized
INFO - 2024-05-07 10:11:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:48 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:48 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:11:48 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:48 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-07 10:11:48 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:48 --> Total execution time: 0.0442
INFO - 2024-05-07 10:11:48 --> Config Class Initialized
INFO - 2024-05-07 10:11:48 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:48 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:48 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:48 --> URI Class Initialized
INFO - 2024-05-07 10:11:48 --> Router Class Initialized
INFO - 2024-05-07 10:11:48 --> Output Class Initialized
INFO - 2024-05-07 10:11:48 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:48 --> Input Class Initialized
INFO - 2024-05-07 10:11:48 --> Language Class Initialized
INFO - 2024-05-07 10:11:48 --> Loader Class Initialized
INFO - 2024-05-07 10:11:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:48 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:48 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:11:48 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:48 --> Config Class Initialized
INFO - 2024-05-07 10:11:48 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:11:48 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:11:48 --> Utf8 Class Initialized
INFO - 2024-05-07 10:11:48 --> URI Class Initialized
INFO - 2024-05-07 10:11:48 --> Router Class Initialized
INFO - 2024-05-07 10:11:48 --> Output Class Initialized
INFO - 2024-05-07 10:11:48 --> Security Class Initialized
DEBUG - 2024-05-07 10:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:11:48 --> Input Class Initialized
INFO - 2024-05-07 10:11:48 --> Language Class Initialized
INFO - 2024-05-07 10:11:48 --> Loader Class Initialized
INFO - 2024-05-07 10:11:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:11:48 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:11:48 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:48 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:48 --> Total execution time: 0.0260
INFO - 2024-05-07 10:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:11:48 --> Controller Class Initialized
DEBUG - 2024-05-07 10:11:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:11:48 --> Database Driver Class Initialized
INFO - 2024-05-07 10:11:48 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:11:48 --> Final output sent to browser
DEBUG - 2024-05-07 10:11:48 --> Total execution time: 0.0476
INFO - 2024-05-07 10:20:25 --> Config Class Initialized
INFO - 2024-05-07 10:20:25 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:20:25 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:20:25 --> Utf8 Class Initialized
INFO - 2024-05-07 10:20:25 --> URI Class Initialized
INFO - 2024-05-07 10:20:25 --> Router Class Initialized
INFO - 2024-05-07 10:20:25 --> Output Class Initialized
INFO - 2024-05-07 10:20:25 --> Security Class Initialized
DEBUG - 2024-05-07 10:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:20:25 --> Input Class Initialized
INFO - 2024-05-07 10:20:25 --> Language Class Initialized
INFO - 2024-05-07 10:20:25 --> Loader Class Initialized
INFO - 2024-05-07 10:20:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:20:25 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:20:25 --> Controller Class Initialized
DEBUG - 2024-05-07 10:20:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_tiposprop.php
INFO - 2024-05-07 10:20:25 --> Database Driver Class Initialized
INFO - 2024-05-07 10:20:25 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:20:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:20:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:20:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/tiposprop.php
INFO - 2024-05-07 10:20:25 --> Final output sent to browser
DEBUG - 2024-05-07 10:20:25 --> Total execution time: 0.0179
INFO - 2024-05-07 10:20:25 --> Config Class Initialized
INFO - 2024-05-07 10:20:25 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:20:25 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:20:25 --> Utf8 Class Initialized
INFO - 2024-05-07 10:20:25 --> URI Class Initialized
INFO - 2024-05-07 10:20:25 --> Router Class Initialized
INFO - 2024-05-07 10:20:25 --> Output Class Initialized
INFO - 2024-05-07 10:20:25 --> Security Class Initialized
DEBUG - 2024-05-07 10:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:20:25 --> Input Class Initialized
INFO - 2024-05-07 10:20:25 --> Language Class Initialized
INFO - 2024-05-07 10:20:25 --> Loader Class Initialized
INFO - 2024-05-07 10:20:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:20:25 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:20:25 --> Controller Class Initialized
DEBUG - 2024-05-07 10:20:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_tiposprop.php
INFO - 2024-05-07 10:20:25 --> Database Driver Class Initialized
INFO - 2024-05-07 10:20:25 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:20:25 --> Final output sent to browser
DEBUG - 2024-05-07 10:20:25 --> Total execution time: 0.0195
INFO - 2024-05-07 10:20:25 --> Config Class Initialized
INFO - 2024-05-07 10:20:25 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:20:25 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:20:25 --> Utf8 Class Initialized
INFO - 2024-05-07 10:20:25 --> URI Class Initialized
INFO - 2024-05-07 10:20:25 --> Router Class Initialized
INFO - 2024-05-07 10:20:25 --> Output Class Initialized
INFO - 2024-05-07 10:20:25 --> Security Class Initialized
DEBUG - 2024-05-07 10:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:20:25 --> Input Class Initialized
INFO - 2024-05-07 10:20:25 --> Language Class Initialized
INFO - 2024-05-07 10:20:25 --> Loader Class Initialized
INFO - 2024-05-07 10:20:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:20:25 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:20:25 --> Controller Class Initialized
DEBUG - 2024-05-07 10:20:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:20:25 --> Database Driver Class Initialized
INFO - 2024-05-07 10:20:25 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:20:25 --> Final output sent to browser
DEBUG - 2024-05-07 10:20:25 --> Total execution time: 0.0139
INFO - 2024-05-07 10:20:31 --> Config Class Initialized
INFO - 2024-05-07 10:20:31 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:20:31 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:20:31 --> Utf8 Class Initialized
INFO - 2024-05-07 10:20:31 --> URI Class Initialized
INFO - 2024-05-07 10:20:31 --> Router Class Initialized
INFO - 2024-05-07 10:20:31 --> Output Class Initialized
INFO - 2024-05-07 10:20:31 --> Security Class Initialized
DEBUG - 2024-05-07 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:20:31 --> Input Class Initialized
INFO - 2024-05-07 10:20:31 --> Language Class Initialized
INFO - 2024-05-07 10:20:31 --> Loader Class Initialized
INFO - 2024-05-07 10:20:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:20:31 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:20:31 --> Controller Class Initialized
DEBUG - 2024-05-07 10:20:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:20:31 --> Database Driver Class Initialized
INFO - 2024-05-07 10:20:31 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:20:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:20:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:20:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/proyectos.php
INFO - 2024-05-07 10:20:31 --> Final output sent to browser
DEBUG - 2024-05-07 10:20:31 --> Total execution time: 0.0122
INFO - 2024-05-07 10:20:32 --> Config Class Initialized
INFO - 2024-05-07 10:20:32 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:20:32 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:20:32 --> Utf8 Class Initialized
INFO - 2024-05-07 10:20:32 --> URI Class Initialized
INFO - 2024-05-07 10:20:32 --> Router Class Initialized
INFO - 2024-05-07 10:20:32 --> Output Class Initialized
INFO - 2024-05-07 10:20:32 --> Security Class Initialized
DEBUG - 2024-05-07 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:20:32 --> Input Class Initialized
INFO - 2024-05-07 10:20:32 --> Language Class Initialized
INFO - 2024-05-07 10:20:32 --> Loader Class Initialized
INFO - 2024-05-07 10:20:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:20:32 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:20:32 --> Controller Class Initialized
DEBUG - 2024-05-07 10:20:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:20:32 --> Database Driver Class Initialized
INFO - 2024-05-07 10:20:32 --> Config Class Initialized
INFO - 2024-05-07 10:20:32 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:20:32 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:20:32 --> Utf8 Class Initialized
INFO - 2024-05-07 10:20:32 --> URI Class Initialized
INFO - 2024-05-07 10:20:32 --> Router Class Initialized
INFO - 2024-05-07 10:20:32 --> Output Class Initialized
INFO - 2024-05-07 10:20:32 --> Security Class Initialized
DEBUG - 2024-05-07 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:20:32 --> Input Class Initialized
INFO - 2024-05-07 10:20:32 --> Language Class Initialized
INFO - 2024-05-07 10:20:32 --> Loader Class Initialized
INFO - 2024-05-07 10:20:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:20:32 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:20:32 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:20:32 --> Final output sent to browser
DEBUG - 2024-05-07 10:20:32 --> Total execution time: 0.0207
INFO - 2024-05-07 10:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:20:32 --> Controller Class Initialized
DEBUG - 2024-05-07 10:20:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:20:32 --> Database Driver Class Initialized
INFO - 2024-05-07 10:20:32 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:20:32 --> Final output sent to browser
DEBUG - 2024-05-07 10:20:32 --> Total execution time: 0.0394
INFO - 2024-05-07 10:20:33 --> Config Class Initialized
INFO - 2024-05-07 10:20:33 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:20:33 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:20:33 --> Utf8 Class Initialized
INFO - 2024-05-07 10:20:33 --> URI Class Initialized
INFO - 2024-05-07 10:20:33 --> Router Class Initialized
INFO - 2024-05-07 10:20:33 --> Output Class Initialized
INFO - 2024-05-07 10:20:33 --> Security Class Initialized
DEBUG - 2024-05-07 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:20:33 --> Input Class Initialized
INFO - 2024-05-07 10:20:33 --> Language Class Initialized
INFO - 2024-05-07 10:20:33 --> Loader Class Initialized
INFO - 2024-05-07 10:20:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:20:33 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:20:33 --> Controller Class Initialized
DEBUG - 2024-05-07 10:20:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:20:33 --> Database Driver Class Initialized
INFO - 2024-05-07 10:20:33 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:20:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-proyecto.php
INFO - 2024-05-07 10:20:33 --> Final output sent to browser
DEBUG - 2024-05-07 10:20:33 --> Total execution time: 0.0229
INFO - 2024-05-07 10:21:59 --> Config Class Initialized
INFO - 2024-05-07 10:21:59 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:21:59 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:21:59 --> Utf8 Class Initialized
INFO - 2024-05-07 10:21:59 --> URI Class Initialized
INFO - 2024-05-07 10:21:59 --> Router Class Initialized
INFO - 2024-05-07 10:21:59 --> Output Class Initialized
INFO - 2024-05-07 10:21:59 --> Security Class Initialized
DEBUG - 2024-05-07 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:21:59 --> Input Class Initialized
INFO - 2024-05-07 10:21:59 --> Language Class Initialized
INFO - 2024-05-07 10:21:59 --> Loader Class Initialized
INFO - 2024-05-07 10:21:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:21:59 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:21:59 --> Controller Class Initialized
DEBUG - 2024-05-07 10:21:59 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:21:59 --> Database Driver Class Initialized
INFO - 2024-05-07 10:21:59 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:21:59 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:21:59 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:21:59 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-05-07 10:21:59 --> Final output sent to browser
DEBUG - 2024-05-07 10:21:59 --> Total execution time: 0.0147
INFO - 2024-05-07 10:21:59 --> Config Class Initialized
INFO - 2024-05-07 10:21:59 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:21:59 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:21:59 --> Utf8 Class Initialized
INFO - 2024-05-07 10:21:59 --> URI Class Initialized
INFO - 2024-05-07 10:21:59 --> Router Class Initialized
INFO - 2024-05-07 10:21:59 --> Output Class Initialized
INFO - 2024-05-07 10:21:59 --> Security Class Initialized
DEBUG - 2024-05-07 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:21:59 --> Input Class Initialized
INFO - 2024-05-07 10:21:59 --> Language Class Initialized
INFO - 2024-05-07 10:21:59 --> Loader Class Initialized
INFO - 2024-05-07 10:21:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:21:59 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:21:59 --> Controller Class Initialized
DEBUG - 2024-05-07 10:21:59 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:21:59 --> Database Driver Class Initialized
INFO - 2024-05-07 10:21:59 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:21:59 --> Final output sent to browser
DEBUG - 2024-05-07 10:21:59 --> Total execution time: 0.0620
INFO - 2024-05-07 10:21:59 --> Config Class Initialized
INFO - 2024-05-07 10:21:59 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:21:59 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:21:59 --> Utf8 Class Initialized
INFO - 2024-05-07 10:21:59 --> URI Class Initialized
INFO - 2024-05-07 10:21:59 --> Router Class Initialized
INFO - 2024-05-07 10:21:59 --> Output Class Initialized
INFO - 2024-05-07 10:21:59 --> Security Class Initialized
DEBUG - 2024-05-07 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:21:59 --> Input Class Initialized
INFO - 2024-05-07 10:21:59 --> Language Class Initialized
INFO - 2024-05-07 10:21:59 --> Loader Class Initialized
INFO - 2024-05-07 10:21:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:21:59 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:21:59 --> Controller Class Initialized
DEBUG - 2024-05-07 10:21:59 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:21:59 --> Database Driver Class Initialized
INFO - 2024-05-07 10:21:59 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:21:59 --> Final output sent to browser
DEBUG - 2024-05-07 10:21:59 --> Total execution time: 0.0206
INFO - 2024-05-07 10:22:02 --> Config Class Initialized
INFO - 2024-05-07 10:22:02 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:22:02 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:22:02 --> Utf8 Class Initialized
INFO - 2024-05-07 10:22:02 --> URI Class Initialized
INFO - 2024-05-07 10:22:02 --> Router Class Initialized
INFO - 2024-05-07 10:22:02 --> Output Class Initialized
INFO - 2024-05-07 10:22:02 --> Security Class Initialized
DEBUG - 2024-05-07 10:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:22:02 --> Input Class Initialized
INFO - 2024-05-07 10:22:02 --> Language Class Initialized
INFO - 2024-05-07 10:22:02 --> Loader Class Initialized
INFO - 2024-05-07 10:22:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:22:02 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:22:02 --> Controller Class Initialized
DEBUG - 2024-05-07 10:22:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:22:02 --> Database Driver Class Initialized
INFO - 2024-05-07 10:22:02 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:22:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-entidad.php
INFO - 2024-05-07 10:22:02 --> Final output sent to browser
DEBUG - 2024-05-07 10:22:02 --> Total execution time: 0.0219
INFO - 2024-05-07 10:23:11 --> Config Class Initialized
INFO - 2024-05-07 10:23:11 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:11 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:11 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:11 --> URI Class Initialized
INFO - 2024-05-07 10:23:11 --> Router Class Initialized
INFO - 2024-05-07 10:23:11 --> Output Class Initialized
INFO - 2024-05-07 10:23:11 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:11 --> Input Class Initialized
INFO - 2024-05-07 10:23:11 --> Language Class Initialized
INFO - 2024-05-07 10:23:11 --> Loader Class Initialized
INFO - 2024-05-07 10:23:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:11 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:11 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:23:11 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:11 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:11 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:11 --> Total execution time: 0.0125
INFO - 2024-05-07 10:23:19 --> Config Class Initialized
INFO - 2024-05-07 10:23:19 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:19 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:19 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:19 --> URI Class Initialized
INFO - 2024-05-07 10:23:19 --> Router Class Initialized
INFO - 2024-05-07 10:23:19 --> Output Class Initialized
INFO - 2024-05-07 10:23:19 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:19 --> Input Class Initialized
INFO - 2024-05-07 10:23:19 --> Language Class Initialized
INFO - 2024-05-07 10:23:19 --> Loader Class Initialized
INFO - 2024-05-07 10:23:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:19 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:19 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:23:19 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:19 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:19 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:19 --> Total execution time: 0.0233
INFO - 2024-05-07 10:23:19 --> Config Class Initialized
INFO - 2024-05-07 10:23:19 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:19 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:19 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:19 --> URI Class Initialized
INFO - 2024-05-07 10:23:19 --> Router Class Initialized
INFO - 2024-05-07 10:23:19 --> Output Class Initialized
INFO - 2024-05-07 10:23:19 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:19 --> Input Class Initialized
INFO - 2024-05-07 10:23:19 --> Language Class Initialized
INFO - 2024-05-07 10:23:19 --> Loader Class Initialized
INFO - 2024-05-07 10:23:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:19 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:19 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 10:23:19 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:19 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:19 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:19 --> Total execution time: 0.0367
INFO - 2024-05-07 10:23:26 --> Config Class Initialized
INFO - 2024-05-07 10:23:26 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:26 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:26 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:26 --> URI Class Initialized
INFO - 2024-05-07 10:23:26 --> Router Class Initialized
INFO - 2024-05-07 10:23:26 --> Output Class Initialized
INFO - 2024-05-07 10:23:26 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:26 --> Input Class Initialized
INFO - 2024-05-07 10:23:26 --> Language Class Initialized
INFO - 2024-05-07 10:23:26 --> Loader Class Initialized
INFO - 2024-05-07 10:23:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:26 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:26 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:23:26 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:26 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:23:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:23:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-07 10:23:26 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:26 --> Total execution time: 0.0345
INFO - 2024-05-07 10:23:26 --> Config Class Initialized
INFO - 2024-05-07 10:23:26 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:26 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:26 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:26 --> URI Class Initialized
INFO - 2024-05-07 10:23:26 --> Router Class Initialized
INFO - 2024-05-07 10:23:26 --> Output Class Initialized
INFO - 2024-05-07 10:23:26 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:26 --> Input Class Initialized
INFO - 2024-05-07 10:23:26 --> Language Class Initialized
INFO - 2024-05-07 10:23:26 --> Loader Class Initialized
INFO - 2024-05-07 10:23:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:26 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:26 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 10:23:26 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:26 --> Config Class Initialized
INFO - 2024-05-07 10:23:26 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:26 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:26 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:26 --> URI Class Initialized
INFO - 2024-05-07 10:23:26 --> Router Class Initialized
INFO - 2024-05-07 10:23:26 --> Output Class Initialized
INFO - 2024-05-07 10:23:26 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:26 --> Input Class Initialized
INFO - 2024-05-07 10:23:26 --> Language Class Initialized
INFO - 2024-05-07 10:23:26 --> Loader Class Initialized
INFO - 2024-05-07 10:23:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:26 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:26 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:26 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:26 --> Total execution time: 0.0149
INFO - 2024-05-07 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:26 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:23:26 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:26 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:26 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:26 --> Total execution time: 0.0629
INFO - 2024-05-07 10:23:29 --> Config Class Initialized
INFO - 2024-05-07 10:23:29 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:29 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:29 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:29 --> URI Class Initialized
INFO - 2024-05-07 10:23:29 --> Router Class Initialized
INFO - 2024-05-07 10:23:29 --> Output Class Initialized
INFO - 2024-05-07 10:23:29 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:29 --> Input Class Initialized
INFO - 2024-05-07 10:23:29 --> Language Class Initialized
INFO - 2024-05-07 10:23:29 --> Loader Class Initialized
INFO - 2024-05-07 10:23:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:29 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:29 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:29 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:23:29 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:29 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:29 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:29 --> Total execution time: 0.0308
INFO - 2024-05-07 10:23:31 --> Config Class Initialized
INFO - 2024-05-07 10:23:31 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:31 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:31 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:31 --> URI Class Initialized
INFO - 2024-05-07 10:23:31 --> Router Class Initialized
INFO - 2024-05-07 10:23:31 --> Output Class Initialized
INFO - 2024-05-07 10:23:31 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:31 --> Input Class Initialized
INFO - 2024-05-07 10:23:31 --> Language Class Initialized
INFO - 2024-05-07 10:23:31 --> Loader Class Initialized
INFO - 2024-05-07 10:23:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:31 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:31 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:23:31 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:31 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-07 10:23:31 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:31 --> Total execution time: 0.0550
INFO - 2024-05-07 10:23:31 --> Config Class Initialized
INFO - 2024-05-07 10:23:31 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:31 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:31 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:31 --> URI Class Initialized
INFO - 2024-05-07 10:23:31 --> Router Class Initialized
INFO - 2024-05-07 10:23:31 --> Output Class Initialized
INFO - 2024-05-07 10:23:31 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:31 --> Input Class Initialized
INFO - 2024-05-07 10:23:31 --> Language Class Initialized
INFO - 2024-05-07 10:23:31 --> Loader Class Initialized
INFO - 2024-05-07 10:23:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:31 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:31 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:23:31 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:31 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:31 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:31 --> Total execution time: 0.0168
INFO - 2024-05-07 10:23:32 --> Config Class Initialized
INFO - 2024-05-07 10:23:32 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:23:32 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:23:32 --> Utf8 Class Initialized
INFO - 2024-05-07 10:23:32 --> URI Class Initialized
INFO - 2024-05-07 10:23:32 --> Router Class Initialized
INFO - 2024-05-07 10:23:32 --> Output Class Initialized
INFO - 2024-05-07 10:23:32 --> Security Class Initialized
DEBUG - 2024-05-07 10:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:23:32 --> Input Class Initialized
INFO - 2024-05-07 10:23:32 --> Language Class Initialized
INFO - 2024-05-07 10:23:32 --> Loader Class Initialized
INFO - 2024-05-07 10:23:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:23:32 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:23:32 --> Controller Class Initialized
DEBUG - 2024-05-07 10:23:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:23:32 --> Database Driver Class Initialized
INFO - 2024-05-07 10:23:32 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:23:32 --> Final output sent to browser
DEBUG - 2024-05-07 10:23:32 --> Total execution time: 0.0177
INFO - 2024-05-07 10:27:13 --> Config Class Initialized
INFO - 2024-05-07 10:27:13 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:27:13 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:27:13 --> Utf8 Class Initialized
INFO - 2024-05-07 10:27:13 --> URI Class Initialized
DEBUG - 2024-05-07 10:27:13 --> No URI present. Default controller set.
INFO - 2024-05-07 10:27:13 --> Router Class Initialized
INFO - 2024-05-07 10:27:13 --> Output Class Initialized
INFO - 2024-05-07 10:27:13 --> Security Class Initialized
DEBUG - 2024-05-07 10:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:27:13 --> Input Class Initialized
INFO - 2024-05-07 10:27:13 --> Language Class Initialized
INFO - 2024-05-07 10:27:13 --> Loader Class Initialized
INFO - 2024-05-07 10:27:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:27:13 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:27:13 --> Controller Class Initialized
INFO - 2024-05-07 10:27:13 --> Config Class Initialized
INFO - 2024-05-07 10:27:13 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:27:13 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:27:13 --> Utf8 Class Initialized
INFO - 2024-05-07 10:27:13 --> URI Class Initialized
INFO - 2024-05-07 10:27:13 --> Router Class Initialized
INFO - 2024-05-07 10:27:13 --> Output Class Initialized
INFO - 2024-05-07 10:27:13 --> Security Class Initialized
DEBUG - 2024-05-07 10:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:27:13 --> Input Class Initialized
INFO - 2024-05-07 10:27:13 --> Language Class Initialized
INFO - 2024-05-07 10:27:13 --> Loader Class Initialized
INFO - 2024-05-07 10:27:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:27:13 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:27:13 --> Controller Class Initialized
DEBUG - 2024-05-07 10:27:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-07 10:27:13 --> Database Driver Class Initialized
INFO - 2024-05-07 10:27:13 --> Helper loaded: cookie_helper
INFO - 2024-05-07 10:27:13 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 10:27:13 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 10:27:13 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-07 10:27:13 --> Final output sent to browser
DEBUG - 2024-05-07 10:27:13 --> Total execution time: 0.0142
INFO - 2024-05-07 10:27:15 --> Config Class Initialized
INFO - 2024-05-07 10:27:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:27:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:27:15 --> Utf8 Class Initialized
INFO - 2024-05-07 10:27:15 --> URI Class Initialized
INFO - 2024-05-07 10:27:15 --> Router Class Initialized
INFO - 2024-05-07 10:27:15 --> Output Class Initialized
INFO - 2024-05-07 10:27:15 --> Security Class Initialized
DEBUG - 2024-05-07 10:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:27:15 --> Input Class Initialized
INFO - 2024-05-07 10:27:15 --> Language Class Initialized
INFO - 2024-05-07 10:27:15 --> Loader Class Initialized
INFO - 2024-05-07 10:27:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:27:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:27:15 --> Controller Class Initialized
INFO - 2024-05-07 10:30:14 --> Config Class Initialized
INFO - 2024-05-07 10:30:14 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:30:14 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:30:14 --> Utf8 Class Initialized
INFO - 2024-05-07 10:30:14 --> URI Class Initialized
INFO - 2024-05-07 10:30:14 --> Router Class Initialized
INFO - 2024-05-07 10:30:14 --> Output Class Initialized
INFO - 2024-05-07 10:30:14 --> Security Class Initialized
DEBUG - 2024-05-07 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:30:14 --> Input Class Initialized
INFO - 2024-05-07 10:30:14 --> Language Class Initialized
INFO - 2024-05-07 10:30:14 --> Loader Class Initialized
INFO - 2024-05-07 10:30:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:30:14 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:30:14 --> Controller Class Initialized
DEBUG - 2024-05-07 10:30:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:30:14 --> Database Driver Class Initialized
INFO - 2024-05-07 10:30:14 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:30:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-07 10:30:15 --> Final output sent to browser
DEBUG - 2024-05-07 10:30:15 --> Total execution time: 0.3873
INFO - 2024-05-07 10:30:15 --> Config Class Initialized
INFO - 2024-05-07 10:30:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 10:30:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 10:30:15 --> Utf8 Class Initialized
INFO - 2024-05-07 10:30:15 --> URI Class Initialized
INFO - 2024-05-07 10:30:15 --> Router Class Initialized
INFO - 2024-05-07 10:30:15 --> Output Class Initialized
INFO - 2024-05-07 10:30:15 --> Security Class Initialized
DEBUG - 2024-05-07 10:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 10:30:15 --> Input Class Initialized
INFO - 2024-05-07 10:30:15 --> Language Class Initialized
INFO - 2024-05-07 10:30:15 --> Loader Class Initialized
INFO - 2024-05-07 10:30:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 10:30:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 10:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 10:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 10:30:15 --> Controller Class Initialized
DEBUG - 2024-05-07 10:30:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-07 10:30:15 --> Database Driver Class Initialized
INFO - 2024-05-07 10:30:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 10:30:15 --> Final output sent to browser
DEBUG - 2024-05-07 10:30:15 --> Total execution time: 0.0429
INFO - 2024-05-07 17:08:33 --> Config Class Initialized
INFO - 2024-05-07 17:08:33 --> Hooks Class Initialized
DEBUG - 2024-05-07 17:08:33 --> UTF-8 Support Enabled
INFO - 2024-05-07 17:08:33 --> Utf8 Class Initialized
INFO - 2024-05-07 17:08:33 --> URI Class Initialized
DEBUG - 2024-05-07 17:08:33 --> No URI present. Default controller set.
INFO - 2024-05-07 17:08:33 --> Router Class Initialized
INFO - 2024-05-07 17:08:33 --> Output Class Initialized
INFO - 2024-05-07 17:08:33 --> Security Class Initialized
DEBUG - 2024-05-07 17:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 17:08:33 --> Input Class Initialized
INFO - 2024-05-07 17:08:33 --> Language Class Initialized
INFO - 2024-05-07 17:08:33 --> Loader Class Initialized
INFO - 2024-05-07 17:08:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 17:08:33 --> Helper loaded: url_helper
DEBUG - 2024-05-07 17:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 17:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 17:08:33 --> Controller Class Initialized
INFO - 2024-05-07 19:04:54 --> Config Class Initialized
INFO - 2024-05-07 19:04:54 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:04:54 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:04:54 --> Utf8 Class Initialized
INFO - 2024-05-07 19:04:54 --> URI Class Initialized
DEBUG - 2024-05-07 19:04:54 --> No URI present. Default controller set.
INFO - 2024-05-07 19:04:54 --> Router Class Initialized
INFO - 2024-05-07 19:04:54 --> Output Class Initialized
INFO - 2024-05-07 19:04:54 --> Security Class Initialized
DEBUG - 2024-05-07 19:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:04:54 --> Input Class Initialized
INFO - 2024-05-07 19:04:54 --> Language Class Initialized
INFO - 2024-05-07 19:04:54 --> Loader Class Initialized
INFO - 2024-05-07 19:04:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:04:54 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:04:54 --> Controller Class Initialized
INFO - 2024-05-07 19:04:54 --> Config Class Initialized
INFO - 2024-05-07 19:04:54 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:04:54 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:04:54 --> Utf8 Class Initialized
INFO - 2024-05-07 19:04:54 --> URI Class Initialized
INFO - 2024-05-07 19:04:54 --> Router Class Initialized
INFO - 2024-05-07 19:04:54 --> Output Class Initialized
INFO - 2024-05-07 19:04:54 --> Security Class Initialized
DEBUG - 2024-05-07 19:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:04:54 --> Input Class Initialized
INFO - 2024-05-07 19:04:54 --> Language Class Initialized
INFO - 2024-05-07 19:04:54 --> Loader Class Initialized
INFO - 2024-05-07 19:04:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:04:54 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:04:54 --> Controller Class Initialized
DEBUG - 2024-05-07 19:04:54 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-07 19:04:54 --> Database Driver Class Initialized
INFO - 2024-05-07 19:04:54 --> Helper loaded: cookie_helper
INFO - 2024-05-07 19:04:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:04:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:04:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-07 19:04:54 --> Final output sent to browser
DEBUG - 2024-05-07 19:04:54 --> Total execution time: 0.0342
INFO - 2024-05-07 19:04:54 --> Config Class Initialized
INFO - 2024-05-07 19:04:54 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:04:54 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:04:54 --> Utf8 Class Initialized
INFO - 2024-05-07 19:04:54 --> URI Class Initialized
INFO - 2024-05-07 19:04:54 --> Router Class Initialized
INFO - 2024-05-07 19:04:54 --> Output Class Initialized
INFO - 2024-05-07 19:04:54 --> Security Class Initialized
DEBUG - 2024-05-07 19:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:04:54 --> Input Class Initialized
INFO - 2024-05-07 19:04:54 --> Language Class Initialized
INFO - 2024-05-07 19:04:54 --> Loader Class Initialized
INFO - 2024-05-07 19:04:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:04:54 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:04:54 --> Controller Class Initialized
INFO - 2024-05-07 19:04:58 --> Config Class Initialized
INFO - 2024-05-07 19:04:58 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:04:58 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:04:58 --> Utf8 Class Initialized
INFO - 2024-05-07 19:04:58 --> URI Class Initialized
INFO - 2024-05-07 19:04:58 --> Router Class Initialized
INFO - 2024-05-07 19:04:58 --> Output Class Initialized
INFO - 2024-05-07 19:04:58 --> Security Class Initialized
DEBUG - 2024-05-07 19:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:04:58 --> Input Class Initialized
INFO - 2024-05-07 19:04:58 --> Language Class Initialized
INFO - 2024-05-07 19:04:58 --> Loader Class Initialized
INFO - 2024-05-07 19:04:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:04:58 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:04:58 --> Controller Class Initialized
DEBUG - 2024-05-07 19:04:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-07 19:04:58 --> Database Driver Class Initialized
INFO - 2024-05-07 19:04:58 --> Helper loaded: cookie_helper
INFO - 2024-05-07 19:04:58 --> Helper loaded: form_helper
INFO - 2024-05-07 19:04:58 --> Form Validation Class Initialized
INFO - 2024-05-07 19:04:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-07 19:04:58 --> Config Class Initialized
INFO - 2024-05-07 19:04:58 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:04:58 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:04:58 --> Utf8 Class Initialized
INFO - 2024-05-07 19:04:58 --> URI Class Initialized
INFO - 2024-05-07 19:04:58 --> Router Class Initialized
INFO - 2024-05-07 19:04:58 --> Output Class Initialized
INFO - 2024-05-07 19:04:58 --> Security Class Initialized
DEBUG - 2024-05-07 19:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:04:58 --> Input Class Initialized
INFO - 2024-05-07 19:04:58 --> Language Class Initialized
INFO - 2024-05-07 19:04:58 --> Loader Class Initialized
INFO - 2024-05-07 19:04:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:04:58 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:04:58 --> Controller Class Initialized
INFO - 2024-05-07 19:04:58 --> Database Driver Class Initialized
DEBUG - 2024-05-07 19:04:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-07 19:04:58 --> Helper loaded: cookie_helper
INFO - 2024-05-07 19:04:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:04:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:04:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-07 19:04:58 --> Final output sent to browser
DEBUG - 2024-05-07 19:04:58 --> Total execution time: 0.0116
INFO - 2024-05-07 19:04:58 --> Config Class Initialized
INFO - 2024-05-07 19:04:58 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:04:58 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:04:58 --> Utf8 Class Initialized
INFO - 2024-05-07 19:04:58 --> URI Class Initialized
INFO - 2024-05-07 19:04:58 --> Router Class Initialized
INFO - 2024-05-07 19:04:58 --> Output Class Initialized
INFO - 2024-05-07 19:04:58 --> Security Class Initialized
DEBUG - 2024-05-07 19:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:04:58 --> Input Class Initialized
INFO - 2024-05-07 19:04:58 --> Language Class Initialized
INFO - 2024-05-07 19:04:58 --> Loader Class Initialized
INFO - 2024-05-07 19:04:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:04:58 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:04:58 --> Controller Class Initialized
DEBUG - 2024-05-07 19:04:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:04:58 --> Database Driver Class Initialized
INFO - 2024-05-07 19:04:58 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:04:58 --> Final output sent to browser
DEBUG - 2024-05-07 19:04:58 --> Total execution time: 0.0239
INFO - 2024-05-07 19:05:01 --> Config Class Initialized
INFO - 2024-05-07 19:05:01 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:01 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:01 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:01 --> URI Class Initialized
INFO - 2024-05-07 19:05:01 --> Router Class Initialized
INFO - 2024-05-07 19:05:01 --> Output Class Initialized
INFO - 2024-05-07 19:05:01 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:01 --> Input Class Initialized
INFO - 2024-05-07 19:05:01 --> Language Class Initialized
INFO - 2024-05-07 19:05:01 --> Loader Class Initialized
INFO - 2024-05-07 19:05:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:01 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:01 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:05:01 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:01 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:05:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:05:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-07 19:05:01 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:01 --> Total execution time: 0.0175
INFO - 2024-05-07 19:05:02 --> Config Class Initialized
INFO - 2024-05-07 19:05:02 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:02 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:02 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:02 --> URI Class Initialized
INFO - 2024-05-07 19:05:02 --> Router Class Initialized
INFO - 2024-05-07 19:05:02 --> Output Class Initialized
INFO - 2024-05-07 19:05:02 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:02 --> Input Class Initialized
INFO - 2024-05-07 19:05:02 --> Language Class Initialized
INFO - 2024-05-07 19:05:02 --> Loader Class Initialized
INFO - 2024-05-07 19:05:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:02 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:02 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:05:02 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:02 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:02 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:02 --> Total execution time: 0.0209
INFO - 2024-05-07 19:05:04 --> Config Class Initialized
INFO - 2024-05-07 19:05:04 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:04 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:04 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:04 --> URI Class Initialized
INFO - 2024-05-07 19:05:04 --> Router Class Initialized
INFO - 2024-05-07 19:05:04 --> Output Class Initialized
INFO - 2024-05-07 19:05:04 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:04 --> Input Class Initialized
INFO - 2024-05-07 19:05:04 --> Language Class Initialized
INFO - 2024-05-07 19:05:04 --> Loader Class Initialized
INFO - 2024-05-07 19:05:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:04 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:04 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:05:04 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:04 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:05:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:05:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-07 19:05:04 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:04 --> Total execution time: 0.0350
INFO - 2024-05-07 19:05:04 --> Config Class Initialized
INFO - 2024-05-07 19:05:04 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:04 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:04 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:04 --> URI Class Initialized
INFO - 2024-05-07 19:05:04 --> Router Class Initialized
INFO - 2024-05-07 19:05:04 --> Output Class Initialized
INFO - 2024-05-07 19:05:04 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:04 --> Input Class Initialized
INFO - 2024-05-07 19:05:04 --> Language Class Initialized
INFO - 2024-05-07 19:05:04 --> Loader Class Initialized
INFO - 2024-05-07 19:05:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:04 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:04 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:05:04 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:04 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:04 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:04 --> Total execution time: 0.0209
INFO - 2024-05-07 19:05:06 --> Config Class Initialized
INFO - 2024-05-07 19:05:06 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:06 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:06 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:06 --> URI Class Initialized
INFO - 2024-05-07 19:05:06 --> Router Class Initialized
INFO - 2024-05-07 19:05:06 --> Output Class Initialized
INFO - 2024-05-07 19:05:06 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:06 --> Input Class Initialized
INFO - 2024-05-07 19:05:06 --> Language Class Initialized
INFO - 2024-05-07 19:05:06 --> Loader Class Initialized
INFO - 2024-05-07 19:05:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:06 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:06 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:06 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:05:06 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:07 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:07 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:07 --> Total execution time: 0.0206
INFO - 2024-05-07 19:05:22 --> Config Class Initialized
INFO - 2024-05-07 19:05:22 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:22 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:22 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:22 --> URI Class Initialized
INFO - 2024-05-07 19:05:22 --> Router Class Initialized
INFO - 2024-05-07 19:05:22 --> Output Class Initialized
INFO - 2024-05-07 19:05:22 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:22 --> Input Class Initialized
INFO - 2024-05-07 19:05:22 --> Language Class Initialized
INFO - 2024-05-07 19:05:22 --> Loader Class Initialized
INFO - 2024-05-07 19:05:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:22 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:22 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:05:22 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:22 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:22 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:22 --> Total execution time: 0.0188
INFO - 2024-05-07 19:05:25 --> Config Class Initialized
INFO - 2024-05-07 19:05:25 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:25 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:25 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:25 --> URI Class Initialized
INFO - 2024-05-07 19:05:25 --> Router Class Initialized
INFO - 2024-05-07 19:05:25 --> Output Class Initialized
INFO - 2024-05-07 19:05:25 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:25 --> Input Class Initialized
INFO - 2024-05-07 19:05:25 --> Language Class Initialized
INFO - 2024-05-07 19:05:25 --> Loader Class Initialized
INFO - 2024-05-07 19:05:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:25 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:25 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:05:25 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:25 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:25 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:25 --> Total execution time: 0.0183
INFO - 2024-05-07 19:05:27 --> Config Class Initialized
INFO - 2024-05-07 19:05:27 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:05:27 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:05:27 --> Utf8 Class Initialized
INFO - 2024-05-07 19:05:27 --> URI Class Initialized
INFO - 2024-05-07 19:05:27 --> Router Class Initialized
INFO - 2024-05-07 19:05:27 --> Output Class Initialized
INFO - 2024-05-07 19:05:27 --> Security Class Initialized
DEBUG - 2024-05-07 19:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:05:27 --> Input Class Initialized
INFO - 2024-05-07 19:05:27 --> Language Class Initialized
INFO - 2024-05-07 19:05:27 --> Loader Class Initialized
INFO - 2024-05-07 19:05:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:05:27 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:05:27 --> Controller Class Initialized
DEBUG - 2024-05-07 19:05:27 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:05:27 --> Database Driver Class Initialized
INFO - 2024-05-07 19:05:27 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:05:27 --> Final output sent to browser
DEBUG - 2024-05-07 19:05:27 --> Total execution time: 0.0158
INFO - 2024-05-07 19:06:15 --> Config Class Initialized
INFO - 2024-05-07 19:06:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:15 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:15 --> URI Class Initialized
INFO - 2024-05-07 19:06:15 --> Router Class Initialized
INFO - 2024-05-07 19:06:15 --> Output Class Initialized
INFO - 2024-05-07 19:06:15 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:15 --> Input Class Initialized
INFO - 2024-05-07 19:06:15 --> Language Class Initialized
INFO - 2024-05-07 19:06:15 --> Loader Class Initialized
INFO - 2024-05-07 19:06:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:15 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 19:06:15 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:06:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:06:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-05-07 19:06:15 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:15 --> Total execution time: 0.0179
INFO - 2024-05-07 19:06:15 --> Config Class Initialized
INFO - 2024-05-07 19:06:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:15 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:15 --> URI Class Initialized
INFO - 2024-05-07 19:06:15 --> Router Class Initialized
INFO - 2024-05-07 19:06:15 --> Output Class Initialized
INFO - 2024-05-07 19:06:15 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:15 --> Input Class Initialized
INFO - 2024-05-07 19:06:15 --> Language Class Initialized
INFO - 2024-05-07 19:06:15 --> Loader Class Initialized
INFO - 2024-05-07 19:06:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:15 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 19:06:15 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:15 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:15 --> Total execution time: 0.0592
INFO - 2024-05-07 19:06:15 --> Config Class Initialized
INFO - 2024-05-07 19:06:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:15 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:15 --> URI Class Initialized
INFO - 2024-05-07 19:06:15 --> Router Class Initialized
INFO - 2024-05-07 19:06:15 --> Output Class Initialized
INFO - 2024-05-07 19:06:15 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:15 --> Input Class Initialized
INFO - 2024-05-07 19:06:15 --> Language Class Initialized
INFO - 2024-05-07 19:06:15 --> Loader Class Initialized
INFO - 2024-05-07 19:06:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:15 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:06:15 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:15 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:15 --> Total execution time: 0.0202
INFO - 2024-05-07 19:06:18 --> Config Class Initialized
INFO - 2024-05-07 19:06:18 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:18 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:18 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:18 --> URI Class Initialized
INFO - 2024-05-07 19:06:18 --> Router Class Initialized
INFO - 2024-05-07 19:06:18 --> Output Class Initialized
INFO - 2024-05-07 19:06:18 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:18 --> Input Class Initialized
INFO - 2024-05-07 19:06:18 --> Language Class Initialized
INFO - 2024-05-07 19:06:18 --> Loader Class Initialized
INFO - 2024-05-07 19:06:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:18 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:18 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 19:06:18 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:18 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:18 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:18 --> Total execution time: 0.2104
INFO - 2024-05-07 19:06:24 --> Config Class Initialized
INFO - 2024-05-07 19:06:24 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:24 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:24 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:24 --> URI Class Initialized
INFO - 2024-05-07 19:06:24 --> Router Class Initialized
INFO - 2024-05-07 19:06:24 --> Output Class Initialized
INFO - 2024-05-07 19:06:24 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:24 --> Input Class Initialized
INFO - 2024-05-07 19:06:24 --> Language Class Initialized
INFO - 2024-05-07 19:06:24 --> Loader Class Initialized
INFO - 2024-05-07 19:06:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:24 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:24 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 19:06:24 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:24 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:24 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:24 --> Total execution time: 0.3337
INFO - 2024-05-07 19:06:26 --> Config Class Initialized
INFO - 2024-05-07 19:06:26 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:26 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:26 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:26 --> URI Class Initialized
INFO - 2024-05-07 19:06:26 --> Router Class Initialized
INFO - 2024-05-07 19:06:26 --> Output Class Initialized
INFO - 2024-05-07 19:06:26 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:26 --> Input Class Initialized
INFO - 2024-05-07 19:06:26 --> Language Class Initialized
INFO - 2024-05-07 19:06:26 --> Loader Class Initialized
INFO - 2024-05-07 19:06:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:26 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:26 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-07 19:06:26 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:26 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:26 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:26 --> Total execution time: 0.2478
INFO - 2024-05-07 19:06:33 --> Config Class Initialized
INFO - 2024-05-07 19:06:33 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:33 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:33 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:33 --> URI Class Initialized
INFO - 2024-05-07 19:06:33 --> Router Class Initialized
INFO - 2024-05-07 19:06:33 --> Output Class Initialized
INFO - 2024-05-07 19:06:33 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:33 --> Input Class Initialized
INFO - 2024-05-07 19:06:33 --> Language Class Initialized
INFO - 2024-05-07 19:06:33 --> Loader Class Initialized
INFO - 2024-05-07 19:06:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:33 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:33 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:06:33 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:33 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:06:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:06:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-07 19:06:33 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:33 --> Total execution time: 0.0369
INFO - 2024-05-07 19:06:33 --> Config Class Initialized
INFO - 2024-05-07 19:06:33 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:33 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:33 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:33 --> URI Class Initialized
INFO - 2024-05-07 19:06:33 --> Router Class Initialized
INFO - 2024-05-07 19:06:33 --> Output Class Initialized
INFO - 2024-05-07 19:06:33 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:33 --> Input Class Initialized
INFO - 2024-05-07 19:06:33 --> Language Class Initialized
INFO - 2024-05-07 19:06:33 --> Loader Class Initialized
INFO - 2024-05-07 19:06:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:33 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:33 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:06:33 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:33 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:33 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:33 --> Total execution time: 0.0166
INFO - 2024-05-07 19:06:38 --> Config Class Initialized
INFO - 2024-05-07 19:06:38 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:06:38 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:06:38 --> Utf8 Class Initialized
INFO - 2024-05-07 19:06:38 --> URI Class Initialized
INFO - 2024-05-07 19:06:38 --> Router Class Initialized
INFO - 2024-05-07 19:06:38 --> Output Class Initialized
INFO - 2024-05-07 19:06:38 --> Security Class Initialized
DEBUG - 2024-05-07 19:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:06:38 --> Input Class Initialized
INFO - 2024-05-07 19:06:38 --> Language Class Initialized
INFO - 2024-05-07 19:06:38 --> Loader Class Initialized
INFO - 2024-05-07 19:06:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:06:38 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:06:38 --> Controller Class Initialized
DEBUG - 2024-05-07 19:06:38 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:06:38 --> Database Driver Class Initialized
INFO - 2024-05-07 19:06:38 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:06:38 --> Final output sent to browser
DEBUG - 2024-05-07 19:06:38 --> Total execution time: 0.0173
INFO - 2024-05-07 19:07:04 --> Config Class Initialized
INFO - 2024-05-07 19:07:04 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:04 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:04 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:04 --> URI Class Initialized
INFO - 2024-05-07 19:07:04 --> Router Class Initialized
INFO - 2024-05-07 19:07:04 --> Output Class Initialized
INFO - 2024-05-07 19:07:04 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:04 --> Input Class Initialized
INFO - 2024-05-07 19:07:04 --> Language Class Initialized
INFO - 2024-05-07 19:07:04 --> Loader Class Initialized
INFO - 2024-05-07 19:07:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:04 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:04 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-07 19:07:04 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:04 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:07:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:07:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/presupuestos.php
INFO - 2024-05-07 19:07:04 --> Final output sent to browser
DEBUG - 2024-05-07 19:07:04 --> Total execution time: 0.0381
INFO - 2024-05-07 19:07:04 --> Config Class Initialized
INFO - 2024-05-07 19:07:04 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:04 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:04 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:04 --> URI Class Initialized
INFO - 2024-05-07 19:07:04 --> Router Class Initialized
INFO - 2024-05-07 19:07:04 --> Output Class Initialized
INFO - 2024-05-07 19:07:04 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:04 --> Input Class Initialized
INFO - 2024-05-07 19:07:04 --> Language Class Initialized
INFO - 2024-05-07 19:07:04 --> Loader Class Initialized
INFO - 2024-05-07 19:07:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:04 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:04 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-07 19:07:04 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:04 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:04 --> Final output sent to browser
DEBUG - 2024-05-07 19:07:04 --> Total execution time: 0.0232
INFO - 2024-05-07 19:07:04 --> Config Class Initialized
INFO - 2024-05-07 19:07:04 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:04 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:04 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:04 --> URI Class Initialized
INFO - 2024-05-07 19:07:04 --> Router Class Initialized
INFO - 2024-05-07 19:07:04 --> Output Class Initialized
INFO - 2024-05-07 19:07:04 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:04 --> Input Class Initialized
INFO - 2024-05-07 19:07:04 --> Language Class Initialized
INFO - 2024-05-07 19:07:04 --> Loader Class Initialized
INFO - 2024-05-07 19:07:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:04 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:04 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:07:04 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:04 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:04 --> Final output sent to browser
DEBUG - 2024-05-07 19:07:04 --> Total execution time: 0.0195
INFO - 2024-05-07 19:07:08 --> Config Class Initialized
INFO - 2024-05-07 19:07:08 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:08 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:08 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:08 --> URI Class Initialized
INFO - 2024-05-07 19:07:08 --> Router Class Initialized
INFO - 2024-05-07 19:07:08 --> Output Class Initialized
INFO - 2024-05-07 19:07:08 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:08 --> Input Class Initialized
INFO - 2024-05-07 19:07:08 --> Language Class Initialized
INFO - 2024-05-07 19:07:08 --> Loader Class Initialized
INFO - 2024-05-07 19:07:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:08 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:08 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-07 19:07:08 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:08 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-07 19:07:08 --> Final output sent to browser
DEBUG - 2024-05-07 19:07:08 --> Total execution time: 0.0136
INFO - 2024-05-07 19:07:15 --> Config Class Initialized
INFO - 2024-05-07 19:07:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:15 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:15 --> URI Class Initialized
INFO - 2024-05-07 19:07:15 --> Router Class Initialized
INFO - 2024-05-07 19:07:15 --> Output Class Initialized
INFO - 2024-05-07 19:07:15 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:15 --> Input Class Initialized
INFO - 2024-05-07 19:07:15 --> Language Class Initialized
INFO - 2024-05-07 19:07:15 --> Loader Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:15 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-07 19:07:15 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:15 --> Config Class Initialized
INFO - 2024-05-07 19:07:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:15 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:15 --> URI Class Initialized
INFO - 2024-05-07 19:07:15 --> Router Class Initialized
INFO - 2024-05-07 19:07:15 --> Output Class Initialized
INFO - 2024-05-07 19:07:15 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:15 --> Input Class Initialized
INFO - 2024-05-07 19:07:15 --> Language Class Initialized
INFO - 2024-05-07 19:07:15 --> Loader Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:15 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-07 19:07:15 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:07:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:07:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/presupuestos.php
INFO - 2024-05-07 19:07:15 --> Final output sent to browser
DEBUG - 2024-05-07 19:07:15 --> Total execution time: 0.0263
INFO - 2024-05-07 19:07:15 --> Config Class Initialized
INFO - 2024-05-07 19:07:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:15 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:15 --> URI Class Initialized
INFO - 2024-05-07 19:07:15 --> Router Class Initialized
INFO - 2024-05-07 19:07:15 --> Output Class Initialized
INFO - 2024-05-07 19:07:15 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:15 --> Input Class Initialized
INFO - 2024-05-07 19:07:15 --> Language Class Initialized
INFO - 2024-05-07 19:07:15 --> Loader Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:15 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-07 19:07:15 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:15 --> Final output sent to browser
DEBUG - 2024-05-07 19:07:15 --> Total execution time: 0.0177
INFO - 2024-05-07 19:07:15 --> Config Class Initialized
INFO - 2024-05-07 19:07:15 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:07:15 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:07:15 --> Utf8 Class Initialized
INFO - 2024-05-07 19:07:15 --> URI Class Initialized
INFO - 2024-05-07 19:07:15 --> Router Class Initialized
INFO - 2024-05-07 19:07:15 --> Output Class Initialized
INFO - 2024-05-07 19:07:15 --> Security Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:07:15 --> Input Class Initialized
INFO - 2024-05-07 19:07:15 --> Language Class Initialized
INFO - 2024-05-07 19:07:15 --> Loader Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:07:15 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:07:15 --> Controller Class Initialized
DEBUG - 2024-05-07 19:07:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:07:15 --> Database Driver Class Initialized
INFO - 2024-05-07 19:07:15 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:07:15 --> Final output sent to browser
DEBUG - 2024-05-07 19:07:15 --> Total execution time: 0.0229
INFO - 2024-05-07 19:08:12 --> Config Class Initialized
INFO - 2024-05-07 19:08:12 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:08:12 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:08:12 --> Utf8 Class Initialized
INFO - 2024-05-07 19:08:12 --> URI Class Initialized
INFO - 2024-05-07 19:08:12 --> Router Class Initialized
INFO - 2024-05-07 19:08:12 --> Output Class Initialized
INFO - 2024-05-07 19:08:12 --> Security Class Initialized
DEBUG - 2024-05-07 19:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:08:12 --> Input Class Initialized
INFO - 2024-05-07 19:08:12 --> Language Class Initialized
INFO - 2024-05-07 19:08:12 --> Loader Class Initialized
INFO - 2024-05-07 19:08:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:08:12 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:08:12 --> Controller Class Initialized
DEBUG - 2024-05-07 19:08:12 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:08:12 --> Database Driver Class Initialized
INFO - 2024-05-07 19:08:12 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:08:12 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 19:08:12 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 19:08:12 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-07 19:08:12 --> Final output sent to browser
DEBUG - 2024-05-07 19:08:12 --> Total execution time: 0.0335
INFO - 2024-05-07 19:08:13 --> Config Class Initialized
INFO - 2024-05-07 19:08:13 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:08:13 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:08:13 --> Utf8 Class Initialized
INFO - 2024-05-07 19:08:13 --> URI Class Initialized
INFO - 2024-05-07 19:08:13 --> Router Class Initialized
INFO - 2024-05-07 19:08:13 --> Output Class Initialized
INFO - 2024-05-07 19:08:13 --> Security Class Initialized
DEBUG - 2024-05-07 19:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:08:13 --> Input Class Initialized
INFO - 2024-05-07 19:08:13 --> Language Class Initialized
INFO - 2024-05-07 19:08:13 --> Loader Class Initialized
INFO - 2024-05-07 19:08:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:08:13 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:08:13 --> Controller Class Initialized
DEBUG - 2024-05-07 19:08:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 19:08:13 --> Database Driver Class Initialized
INFO - 2024-05-07 19:08:13 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:08:13 --> Final output sent to browser
DEBUG - 2024-05-07 19:08:13 --> Total execution time: 0.0207
INFO - 2024-05-07 19:08:17 --> Config Class Initialized
INFO - 2024-05-07 19:08:17 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:08:17 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:08:17 --> Utf8 Class Initialized
INFO - 2024-05-07 19:08:17 --> URI Class Initialized
INFO - 2024-05-07 19:08:17 --> Router Class Initialized
INFO - 2024-05-07 19:08:17 --> Output Class Initialized
INFO - 2024-05-07 19:08:17 --> Security Class Initialized
DEBUG - 2024-05-07 19:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:08:17 --> Input Class Initialized
INFO - 2024-05-07 19:08:17 --> Language Class Initialized
INFO - 2024-05-07 19:08:17 --> Loader Class Initialized
INFO - 2024-05-07 19:08:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:08:17 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:08:17 --> Controller Class Initialized
DEBUG - 2024-05-07 19:08:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:08:17 --> Database Driver Class Initialized
INFO - 2024-05-07 19:08:17 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:08:17 --> Final output sent to browser
DEBUG - 2024-05-07 19:08:17 --> Total execution time: 0.1230
INFO - 2024-05-07 19:08:30 --> Config Class Initialized
INFO - 2024-05-07 19:08:30 --> Hooks Class Initialized
DEBUG - 2024-05-07 19:08:30 --> UTF-8 Support Enabled
INFO - 2024-05-07 19:08:30 --> Utf8 Class Initialized
INFO - 2024-05-07 19:08:30 --> URI Class Initialized
INFO - 2024-05-07 19:08:30 --> Router Class Initialized
INFO - 2024-05-07 19:08:30 --> Output Class Initialized
INFO - 2024-05-07 19:08:30 --> Security Class Initialized
DEBUG - 2024-05-07 19:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 19:08:30 --> Input Class Initialized
INFO - 2024-05-07 19:08:30 --> Language Class Initialized
INFO - 2024-05-07 19:08:30 --> Loader Class Initialized
INFO - 2024-05-07 19:08:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 19:08:30 --> Helper loaded: url_helper
DEBUG - 2024-05-07 19:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 19:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 19:08:30 --> Controller Class Initialized
DEBUG - 2024-05-07 19:08:30 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 19:08:30 --> Database Driver Class Initialized
INFO - 2024-05-07 19:08:30 --> Helper loaded: funciones_helper
INFO - 2024-05-07 19:08:30 --> Final output sent to browser
DEBUG - 2024-05-07 19:08:30 --> Total execution time: 0.0417
INFO - 2024-05-07 20:35:02 --> Config Class Initialized
INFO - 2024-05-07 20:35:02 --> Hooks Class Initialized
DEBUG - 2024-05-07 20:35:02 --> UTF-8 Support Enabled
INFO - 2024-05-07 20:35:02 --> Utf8 Class Initialized
INFO - 2024-05-07 20:35:02 --> URI Class Initialized
INFO - 2024-05-07 20:35:02 --> Router Class Initialized
INFO - 2024-05-07 20:35:02 --> Output Class Initialized
INFO - 2024-05-07 20:35:02 --> Security Class Initialized
DEBUG - 2024-05-07 20:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 20:35:02 --> Input Class Initialized
INFO - 2024-05-07 20:35:02 --> Language Class Initialized
INFO - 2024-05-07 20:35:02 --> Loader Class Initialized
INFO - 2024-05-07 20:35:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 20:35:02 --> Helper loaded: url_helper
DEBUG - 2024-05-07 20:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 20:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 20:35:02 --> Controller Class Initialized
DEBUG - 2024-05-07 20:35:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-07 20:35:02 --> Database Driver Class Initialized
INFO - 2024-05-07 20:35:02 --> Helper loaded: funciones_helper
INFO - 2024-05-07 20:35:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-07 20:35:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-07 20:35:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-07 20:35:02 --> Final output sent to browser
DEBUG - 2024-05-07 20:35:02 --> Total execution time: 0.0602
INFO - 2024-05-07 20:35:04 --> Config Class Initialized
INFO - 2024-05-07 20:35:04 --> Hooks Class Initialized
DEBUG - 2024-05-07 20:35:04 --> UTF-8 Support Enabled
INFO - 2024-05-07 20:35:04 --> Utf8 Class Initialized
INFO - 2024-05-07 20:35:04 --> URI Class Initialized
INFO - 2024-05-07 20:35:04 --> Router Class Initialized
INFO - 2024-05-07 20:35:04 --> Output Class Initialized
INFO - 2024-05-07 20:35:04 --> Security Class Initialized
DEBUG - 2024-05-07 20:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-07 20:35:04 --> Input Class Initialized
INFO - 2024-05-07 20:35:04 --> Language Class Initialized
INFO - 2024-05-07 20:35:04 --> Loader Class Initialized
INFO - 2024-05-07 20:35:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-07 20:35:04 --> Helper loaded: url_helper
DEBUG - 2024-05-07 20:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-07 20:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-07 20:35:04 --> Controller Class Initialized
DEBUG - 2024-05-07 20:35:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-07 20:35:04 --> Database Driver Class Initialized
INFO - 2024-05-07 20:35:05 --> Helper loaded: funciones_helper
INFO - 2024-05-07 20:35:05 --> Final output sent to browser
DEBUG - 2024-05-07 20:35:05 --> Total execution time: 0.0234
