<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-07 04:19:27 --> Config Class Initialized
INFO - 2024-06-07 04:19:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 04:19:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 04:19:27 --> Utf8 Class Initialized
INFO - 2024-06-07 04:19:27 --> URI Class Initialized
DEBUG - 2024-06-07 04:19:27 --> No URI present. Default controller set.
INFO - 2024-06-07 04:19:27 --> Router Class Initialized
INFO - 2024-06-07 04:19:27 --> Output Class Initialized
INFO - 2024-06-07 04:19:27 --> Security Class Initialized
DEBUG - 2024-06-07 04:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 04:19:27 --> Input Class Initialized
INFO - 2024-06-07 04:19:27 --> Language Class Initialized
INFO - 2024-06-07 04:19:27 --> Loader Class Initialized
INFO - 2024-06-07 04:19:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-07 04:19:27 --> Helper loaded: url_helper
DEBUG - 2024-06-07 04:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-07 04:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 04:19:27 --> Controller Class Initialized
INFO - 2024-06-07 04:19:28 --> Config Class Initialized
INFO - 2024-06-07 04:19:28 --> Hooks Class Initialized
DEBUG - 2024-06-07 04:19:28 --> UTF-8 Support Enabled
INFO - 2024-06-07 04:19:28 --> Utf8 Class Initialized
INFO - 2024-06-07 04:19:28 --> URI Class Initialized
INFO - 2024-06-07 04:19:28 --> Router Class Initialized
INFO - 2024-06-07 04:19:28 --> Output Class Initialized
INFO - 2024-06-07 04:19:28 --> Security Class Initialized
DEBUG - 2024-06-07 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 04:19:28 --> Input Class Initialized
INFO - 2024-06-07 04:19:28 --> Language Class Initialized
INFO - 2024-06-07 04:19:28 --> Loader Class Initialized
INFO - 2024-06-07 04:19:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-07 04:19:28 --> Helper loaded: url_helper
DEBUG - 2024-06-07 04:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-07 04:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 04:19:28 --> Controller Class Initialized
DEBUG - 2024-06-07 04:19:28 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-07 04:19:28 --> Database Driver Class Initialized
INFO - 2024-06-07 04:19:28 --> Helper loaded: cookie_helper
INFO - 2024-06-07 04:19:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-07 04:19:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-07 04:19:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-07 04:19:28 --> Final output sent to browser
DEBUG - 2024-06-07 04:19:28 --> Total execution time: 0.0527
INFO - 2024-06-07 04:46:32 --> Config Class Initialized
INFO - 2024-06-07 04:46:32 --> Hooks Class Initialized
DEBUG - 2024-06-07 04:46:32 --> UTF-8 Support Enabled
INFO - 2024-06-07 04:46:32 --> Utf8 Class Initialized
INFO - 2024-06-07 04:46:32 --> URI Class Initialized
DEBUG - 2024-06-07 04:46:32 --> No URI present. Default controller set.
INFO - 2024-06-07 04:46:32 --> Router Class Initialized
INFO - 2024-06-07 04:46:32 --> Output Class Initialized
INFO - 2024-06-07 04:46:32 --> Security Class Initialized
DEBUG - 2024-06-07 04:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 04:46:32 --> Input Class Initialized
INFO - 2024-06-07 04:46:32 --> Language Class Initialized
INFO - 2024-06-07 04:46:32 --> Loader Class Initialized
INFO - 2024-06-07 04:46:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-07 04:46:32 --> Helper loaded: url_helper
DEBUG - 2024-06-07 04:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-07 04:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 04:46:32 --> Controller Class Initialized
INFO - 2024-06-07 04:46:33 --> Config Class Initialized
INFO - 2024-06-07 04:46:33 --> Hooks Class Initialized
DEBUG - 2024-06-07 04:46:33 --> UTF-8 Support Enabled
INFO - 2024-06-07 04:46:33 --> Utf8 Class Initialized
INFO - 2024-06-07 04:46:33 --> URI Class Initialized
DEBUG - 2024-06-07 04:46:33 --> No URI present. Default controller set.
INFO - 2024-06-07 04:46:33 --> Router Class Initialized
INFO - 2024-06-07 04:46:33 --> Output Class Initialized
INFO - 2024-06-07 04:46:33 --> Security Class Initialized
DEBUG - 2024-06-07 04:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 04:46:33 --> Input Class Initialized
INFO - 2024-06-07 04:46:33 --> Language Class Initialized
INFO - 2024-06-07 04:46:33 --> Loader Class Initialized
INFO - 2024-06-07 04:46:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-07 04:46:33 --> Helper loaded: url_helper
DEBUG - 2024-06-07 04:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-07 04:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 04:46:33 --> Controller Class Initialized
INFO - 2024-06-07 10:00:56 --> Config Class Initialized
INFO - 2024-06-07 10:00:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:00:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:00:56 --> Utf8 Class Initialized
INFO - 2024-06-07 10:00:56 --> URI Class Initialized
DEBUG - 2024-06-07 10:00:56 --> No URI present. Default controller set.
INFO - 2024-06-07 10:00:56 --> Router Class Initialized
INFO - 2024-06-07 10:00:56 --> Output Class Initialized
INFO - 2024-06-07 10:00:56 --> Security Class Initialized
DEBUG - 2024-06-07 10:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:00:56 --> Input Class Initialized
INFO - 2024-06-07 10:00:56 --> Language Class Initialized
INFO - 2024-06-07 10:00:56 --> Loader Class Initialized
INFO - 2024-06-07 10:00:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-07 10:00:56 --> Helper loaded: url_helper
DEBUG - 2024-06-07 10:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-07 10:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:00:56 --> Controller Class Initialized
INFO - 2024-06-07 12:11:49 --> Config Class Initialized
INFO - 2024-06-07 12:11:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 12:11:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 12:11:49 --> Utf8 Class Initialized
INFO - 2024-06-07 12:11:49 --> URI Class Initialized
DEBUG - 2024-06-07 12:11:49 --> No URI present. Default controller set.
INFO - 2024-06-07 12:11:49 --> Router Class Initialized
INFO - 2024-06-07 12:11:49 --> Output Class Initialized
INFO - 2024-06-07 12:11:49 --> Security Class Initialized
DEBUG - 2024-06-07 12:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 12:11:49 --> Input Class Initialized
INFO - 2024-06-07 12:11:49 --> Language Class Initialized
INFO - 2024-06-07 12:11:49 --> Loader Class Initialized
INFO - 2024-06-07 12:11:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-07 12:11:49 --> Helper loaded: url_helper
DEBUG - 2024-06-07 12:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-07 12:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 12:11:49 --> Controller Class Initialized
INFO - 2024-06-07 12:17:19 --> Config Class Initialized
INFO - 2024-06-07 12:17:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 12:17:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 12:17:19 --> Utf8 Class Initialized
INFO - 2024-06-07 12:17:19 --> URI Class Initialized
DEBUG - 2024-06-07 12:17:19 --> No URI present. Default controller set.
INFO - 2024-06-07 12:17:19 --> Router Class Initialized
INFO - 2024-06-07 12:17:19 --> Output Class Initialized
INFO - 2024-06-07 12:17:19 --> Security Class Initialized
DEBUG - 2024-06-07 12:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 12:17:19 --> Input Class Initialized
INFO - 2024-06-07 12:17:19 --> Language Class Initialized
INFO - 2024-06-07 12:17:19 --> Loader Class Initialized
INFO - 2024-06-07 12:17:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-07 12:17:19 --> Helper loaded: url_helper
DEBUG - 2024-06-07 12:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-07 12:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 12:17:19 --> Controller Class Initialized
