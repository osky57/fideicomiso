<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-13 01:53:06 --> Config Class Initialized
INFO - 2024-09-13 01:53:06 --> Hooks Class Initialized
DEBUG - 2024-09-13 01:53:06 --> UTF-8 Support Enabled
INFO - 2024-09-13 01:53:06 --> Utf8 Class Initialized
INFO - 2024-09-13 01:53:06 --> URI Class Initialized
DEBUG - 2024-09-13 01:53:06 --> No URI present. Default controller set.
INFO - 2024-09-13 01:53:06 --> Router Class Initialized
INFO - 2024-09-13 01:53:06 --> Output Class Initialized
INFO - 2024-09-13 01:53:06 --> Security Class Initialized
DEBUG - 2024-09-13 01:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 01:53:06 --> Input Class Initialized
INFO - 2024-09-13 01:53:06 --> Language Class Initialized
INFO - 2024-09-13 01:53:06 --> Loader Class Initialized
INFO - 2024-09-13 01:53:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-13 01:53:06 --> Helper loaded: url_helper
DEBUG - 2024-09-13 01:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 01:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 01:53:06 --> Controller Class Initialized
INFO - 2024-09-13 05:01:21 --> Config Class Initialized
INFO - 2024-09-13 05:01:21 --> Hooks Class Initialized
DEBUG - 2024-09-13 05:01:21 --> UTF-8 Support Enabled
INFO - 2024-09-13 05:01:21 --> Utf8 Class Initialized
INFO - 2024-09-13 05:01:21 --> URI Class Initialized
DEBUG - 2024-09-13 05:01:21 --> No URI present. Default controller set.
INFO - 2024-09-13 05:01:21 --> Router Class Initialized
INFO - 2024-09-13 05:01:21 --> Output Class Initialized
INFO - 2024-09-13 05:01:21 --> Security Class Initialized
DEBUG - 2024-09-13 05:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 05:01:21 --> Input Class Initialized
INFO - 2024-09-13 05:01:21 --> Language Class Initialized
INFO - 2024-09-13 05:01:21 --> Loader Class Initialized
INFO - 2024-09-13 05:01:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-13 05:01:21 --> Helper loaded: url_helper
DEBUG - 2024-09-13 05:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 05:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 05:01:21 --> Controller Class Initialized
