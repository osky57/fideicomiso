<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-24 15:46:03 --> Config Class Initialized
INFO - 2024-07-24 15:46:03 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:46:03 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:46:03 --> Utf8 Class Initialized
INFO - 2024-07-24 15:46:03 --> URI Class Initialized
DEBUG - 2024-07-24 15:46:03 --> No URI present. Default controller set.
INFO - 2024-07-24 15:46:03 --> Router Class Initialized
INFO - 2024-07-24 15:46:03 --> Output Class Initialized
INFO - 2024-07-24 15:46:03 --> Security Class Initialized
DEBUG - 2024-07-24 15:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:46:04 --> Input Class Initialized
INFO - 2024-07-24 15:46:04 --> Language Class Initialized
INFO - 2024-07-24 15:46:04 --> Loader Class Initialized
INFO - 2024-07-24 15:46:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-24 15:46:04 --> Helper loaded: url_helper
DEBUG - 2024-07-24 15:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-24 15:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:46:04 --> Controller Class Initialized
