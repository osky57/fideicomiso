<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-03 00:09:01 --> Config Class Initialized
INFO - 2024-07-03 00:09:01 --> Hooks Class Initialized
DEBUG - 2024-07-03 00:09:01 --> UTF-8 Support Enabled
INFO - 2024-07-03 00:09:01 --> Utf8 Class Initialized
INFO - 2024-07-03 00:09:01 --> URI Class Initialized
DEBUG - 2024-07-03 00:09:01 --> No URI present. Default controller set.
INFO - 2024-07-03 00:09:01 --> Router Class Initialized
INFO - 2024-07-03 00:09:01 --> Output Class Initialized
INFO - 2024-07-03 00:09:01 --> Security Class Initialized
DEBUG - 2024-07-03 00:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 00:09:01 --> Input Class Initialized
INFO - 2024-07-03 00:09:01 --> Language Class Initialized
INFO - 2024-07-03 00:09:01 --> Loader Class Initialized
INFO - 2024-07-03 00:09:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-03 00:09:01 --> Helper loaded: url_helper
DEBUG - 2024-07-03 00:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-03 00:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 00:09:01 --> Controller Class Initialized
INFO - 2024-07-03 01:05:13 --> Config Class Initialized
INFO - 2024-07-03 01:05:13 --> Hooks Class Initialized
DEBUG - 2024-07-03 01:05:13 --> UTF-8 Support Enabled
INFO - 2024-07-03 01:05:13 --> Utf8 Class Initialized
INFO - 2024-07-03 01:05:13 --> URI Class Initialized
DEBUG - 2024-07-03 01:05:13 --> No URI present. Default controller set.
INFO - 2024-07-03 01:05:13 --> Router Class Initialized
INFO - 2024-07-03 01:05:13 --> Output Class Initialized
INFO - 2024-07-03 01:05:13 --> Security Class Initialized
DEBUG - 2024-07-03 01:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 01:05:13 --> Input Class Initialized
INFO - 2024-07-03 01:05:13 --> Language Class Initialized
INFO - 2024-07-03 01:05:13 --> Loader Class Initialized
INFO - 2024-07-03 01:05:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-03 01:05:13 --> Helper loaded: url_helper
DEBUG - 2024-07-03 01:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-03 01:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 01:05:13 --> Controller Class Initialized
INFO - 2024-07-03 17:01:04 --> Config Class Initialized
INFO - 2024-07-03 17:01:04 --> Hooks Class Initialized
DEBUG - 2024-07-03 17:01:04 --> UTF-8 Support Enabled
INFO - 2024-07-03 17:01:04 --> Utf8 Class Initialized
INFO - 2024-07-03 17:01:04 --> URI Class Initialized
DEBUG - 2024-07-03 17:01:04 --> No URI present. Default controller set.
INFO - 2024-07-03 17:01:04 --> Router Class Initialized
INFO - 2024-07-03 17:01:04 --> Output Class Initialized
INFO - 2024-07-03 17:01:04 --> Security Class Initialized
DEBUG - 2024-07-03 17:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 17:01:04 --> Input Class Initialized
INFO - 2024-07-03 17:01:04 --> Language Class Initialized
INFO - 2024-07-03 17:01:04 --> Loader Class Initialized
INFO - 2024-07-03 17:01:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-03 17:01:04 --> Helper loaded: url_helper
DEBUG - 2024-07-03 17:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-03 17:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 17:01:04 --> Controller Class Initialized
