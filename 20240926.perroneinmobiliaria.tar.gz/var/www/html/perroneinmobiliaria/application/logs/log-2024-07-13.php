<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-13 19:16:21 --> Config Class Initialized
INFO - 2024-07-13 19:16:21 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:21 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:21 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:21 --> URI Class Initialized
DEBUG - 2024-07-13 19:16:21 --> No URI present. Default controller set.
INFO - 2024-07-13 19:16:21 --> Router Class Initialized
INFO - 2024-07-13 19:16:21 --> Output Class Initialized
INFO - 2024-07-13 19:16:21 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:21 --> Input Class Initialized
INFO - 2024-07-13 19:16:21 --> Language Class Initialized
INFO - 2024-07-13 19:16:21 --> Loader Class Initialized
INFO - 2024-07-13 19:16:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:22 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:22 --> Controller Class Initialized
INFO - 2024-07-13 19:16:22 --> Config Class Initialized
INFO - 2024-07-13 19:16:22 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:22 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:22 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:22 --> URI Class Initialized
INFO - 2024-07-13 19:16:22 --> Router Class Initialized
INFO - 2024-07-13 19:16:22 --> Output Class Initialized
INFO - 2024-07-13 19:16:22 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:22 --> Input Class Initialized
INFO - 2024-07-13 19:16:22 --> Language Class Initialized
INFO - 2024-07-13 19:16:22 --> Loader Class Initialized
INFO - 2024-07-13 19:16:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:22 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:22 --> Controller Class Initialized
DEBUG - 2024-07-13 19:16:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-13 19:16:22 --> Database Driver Class Initialized
INFO - 2024-07-13 19:16:22 --> Helper loaded: cookie_helper
INFO - 2024-07-13 19:16:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-13 19:16:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-13 19:16:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-07-13 19:16:22 --> Final output sent to browser
DEBUG - 2024-07-13 19:16:22 --> Total execution time: 0.2700
INFO - 2024-07-13 19:16:23 --> Config Class Initialized
INFO - 2024-07-13 19:16:23 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:23 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:23 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:23 --> URI Class Initialized
INFO - 2024-07-13 19:16:23 --> Router Class Initialized
INFO - 2024-07-13 19:16:23 --> Output Class Initialized
INFO - 2024-07-13 19:16:23 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:23 --> Input Class Initialized
INFO - 2024-07-13 19:16:23 --> Language Class Initialized
INFO - 2024-07-13 19:16:23 --> Loader Class Initialized
INFO - 2024-07-13 19:16:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:23 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:23 --> Controller Class Initialized
INFO - 2024-07-13 19:16:28 --> Config Class Initialized
INFO - 2024-07-13 19:16:28 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:28 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:28 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:28 --> URI Class Initialized
INFO - 2024-07-13 19:16:28 --> Router Class Initialized
INFO - 2024-07-13 19:16:28 --> Output Class Initialized
INFO - 2024-07-13 19:16:28 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:28 --> Input Class Initialized
INFO - 2024-07-13 19:16:28 --> Language Class Initialized
INFO - 2024-07-13 19:16:28 --> Loader Class Initialized
INFO - 2024-07-13 19:16:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:28 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:28 --> Controller Class Initialized
DEBUG - 2024-07-13 19:16:28 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-13 19:16:28 --> Database Driver Class Initialized
INFO - 2024-07-13 19:16:28 --> Helper loaded: cookie_helper
INFO - 2024-07-13 19:16:28 --> Helper loaded: form_helper
INFO - 2024-07-13 19:16:28 --> Form Validation Class Initialized
INFO - 2024-07-13 19:16:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-07-13 19:16:29 --> Config Class Initialized
INFO - 2024-07-13 19:16:29 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:29 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:29 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:29 --> URI Class Initialized
INFO - 2024-07-13 19:16:29 --> Router Class Initialized
INFO - 2024-07-13 19:16:29 --> Output Class Initialized
INFO - 2024-07-13 19:16:29 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:29 --> Input Class Initialized
INFO - 2024-07-13 19:16:29 --> Language Class Initialized
INFO - 2024-07-13 19:16:29 --> Loader Class Initialized
INFO - 2024-07-13 19:16:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:29 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:29 --> Controller Class Initialized
INFO - 2024-07-13 19:16:29 --> Database Driver Class Initialized
DEBUG - 2024-07-13 19:16:29 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-13 19:16:29 --> Helper loaded: cookie_helper
INFO - 2024-07-13 19:16:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-13 19:16:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-13 19:16:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-07-13 19:16:29 --> Final output sent to browser
DEBUG - 2024-07-13 19:16:29 --> Total execution time: 0.0195
INFO - 2024-07-13 19:16:29 --> Config Class Initialized
INFO - 2024-07-13 19:16:29 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:29 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:29 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:29 --> URI Class Initialized
INFO - 2024-07-13 19:16:29 --> Router Class Initialized
INFO - 2024-07-13 19:16:29 --> Output Class Initialized
INFO - 2024-07-13 19:16:29 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:29 --> Input Class Initialized
INFO - 2024-07-13 19:16:29 --> Language Class Initialized
INFO - 2024-07-13 19:16:29 --> Loader Class Initialized
INFO - 2024-07-13 19:16:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:29 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:29 --> Controller Class Initialized
DEBUG - 2024-07-13 19:16:29 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-13 19:16:29 --> Database Driver Class Initialized
INFO - 2024-07-13 19:16:29 --> Helper loaded: funciones_helper
INFO - 2024-07-13 19:16:29 --> Final output sent to browser
DEBUG - 2024-07-13 19:16:29 --> Total execution time: 0.0348
INFO - 2024-07-13 19:16:33 --> Config Class Initialized
INFO - 2024-07-13 19:16:33 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:33 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:33 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:33 --> URI Class Initialized
INFO - 2024-07-13 19:16:33 --> Router Class Initialized
INFO - 2024-07-13 19:16:33 --> Output Class Initialized
INFO - 2024-07-13 19:16:33 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:33 --> Input Class Initialized
INFO - 2024-07-13 19:16:33 --> Language Class Initialized
INFO - 2024-07-13 19:16:33 --> Loader Class Initialized
INFO - 2024-07-13 19:16:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:33 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:33 --> Controller Class Initialized
DEBUG - 2024-07-13 19:16:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-13 19:16:33 --> Database Driver Class Initialized
INFO - 2024-07-13 19:16:33 --> Helper loaded: funciones_helper
INFO - 2024-07-13 19:16:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-13 19:16:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-13 19:16:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-07-13 19:16:33 --> Final output sent to browser
DEBUG - 2024-07-13 19:16:33 --> Total execution time: 0.0126
INFO - 2024-07-13 19:16:33 --> Config Class Initialized
INFO - 2024-07-13 19:16:33 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:33 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:33 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:33 --> URI Class Initialized
INFO - 2024-07-13 19:16:33 --> Router Class Initialized
INFO - 2024-07-13 19:16:33 --> Output Class Initialized
INFO - 2024-07-13 19:16:33 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:33 --> Input Class Initialized
INFO - 2024-07-13 19:16:33 --> Language Class Initialized
INFO - 2024-07-13 19:16:33 --> Loader Class Initialized
INFO - 2024-07-13 19:16:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:33 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:33 --> Controller Class Initialized
DEBUG - 2024-07-13 19:16:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-13 19:16:33 --> Database Driver Class Initialized
INFO - 2024-07-13 19:16:33 --> Helper loaded: funciones_helper
INFO - 2024-07-13 19:16:33 --> Final output sent to browser
DEBUG - 2024-07-13 19:16:33 --> Total execution time: 0.0219
INFO - 2024-07-13 19:16:59 --> Config Class Initialized
INFO - 2024-07-13 19:16:59 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:16:59 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:16:59 --> Utf8 Class Initialized
INFO - 2024-07-13 19:16:59 --> URI Class Initialized
INFO - 2024-07-13 19:16:59 --> Router Class Initialized
INFO - 2024-07-13 19:16:59 --> Output Class Initialized
INFO - 2024-07-13 19:16:59 --> Security Class Initialized
DEBUG - 2024-07-13 19:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:16:59 --> Input Class Initialized
INFO - 2024-07-13 19:16:59 --> Language Class Initialized
INFO - 2024-07-13 19:16:59 --> Loader Class Initialized
INFO - 2024-07-13 19:16:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:16:59 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:16:59 --> Controller Class Initialized
DEBUG - 2024-07-13 19:16:59 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-13 19:16:59 --> Database Driver Class Initialized
INFO - 2024-07-13 19:16:59 --> Helper loaded: funciones_helper
INFO - 2024-07-13 19:17:00 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-13 19:17:00 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-13 19:17:00 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-07-13 19:17:00 --> Final output sent to browser
DEBUG - 2024-07-13 19:17:00 --> Total execution time: 0.1127
INFO - 2024-07-13 19:17:00 --> Config Class Initialized
INFO - 2024-07-13 19:17:00 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:17:00 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:17:00 --> Utf8 Class Initialized
INFO - 2024-07-13 19:17:00 --> URI Class Initialized
INFO - 2024-07-13 19:17:00 --> Router Class Initialized
INFO - 2024-07-13 19:17:00 --> Output Class Initialized
INFO - 2024-07-13 19:17:00 --> Security Class Initialized
DEBUG - 2024-07-13 19:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:17:00 --> Input Class Initialized
INFO - 2024-07-13 19:17:00 --> Language Class Initialized
INFO - 2024-07-13 19:17:00 --> Loader Class Initialized
INFO - 2024-07-13 19:17:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:17:00 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:17:00 --> Controller Class Initialized
DEBUG - 2024-07-13 19:17:00 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-13 19:17:00 --> Database Driver Class Initialized
INFO - 2024-07-13 19:17:00 --> Helper loaded: funciones_helper
INFO - 2024-07-13 19:17:00 --> Final output sent to browser
DEBUG - 2024-07-13 19:17:00 --> Total execution time: 0.0935
INFO - 2024-07-13 19:17:01 --> Config Class Initialized
INFO - 2024-07-13 19:17:01 --> Hooks Class Initialized
DEBUG - 2024-07-13 19:17:01 --> UTF-8 Support Enabled
INFO - 2024-07-13 19:17:01 --> Utf8 Class Initialized
INFO - 2024-07-13 19:17:01 --> URI Class Initialized
INFO - 2024-07-13 19:17:01 --> Router Class Initialized
INFO - 2024-07-13 19:17:01 --> Output Class Initialized
INFO - 2024-07-13 19:17:01 --> Security Class Initialized
DEBUG - 2024-07-13 19:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 19:17:01 --> Input Class Initialized
INFO - 2024-07-13 19:17:01 --> Language Class Initialized
INFO - 2024-07-13 19:17:01 --> Loader Class Initialized
INFO - 2024-07-13 19:17:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-13 19:17:01 --> Helper loaded: url_helper
DEBUG - 2024-07-13 19:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-13 19:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 19:17:01 --> Controller Class Initialized
DEBUG - 2024-07-13 19:17:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-13 19:17:01 --> Database Driver Class Initialized
INFO - 2024-07-13 19:17:01 --> Helper loaded: funciones_helper
INFO - 2024-07-13 19:17:01 --> Final output sent to browser
DEBUG - 2024-07-13 19:17:01 --> Total execution time: 0.0197
