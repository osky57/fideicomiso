<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-22 12:30:20 --> Config Class Initialized
INFO - 2024-05-22 12:30:20 --> Hooks Class Initialized
DEBUG - 2024-05-22 12:30:20 --> UTF-8 Support Enabled
INFO - 2024-05-22 12:30:20 --> Utf8 Class Initialized
INFO - 2024-05-22 12:30:20 --> URI Class Initialized
DEBUG - 2024-05-22 12:30:20 --> No URI present. Default controller set.
INFO - 2024-05-22 12:30:20 --> Router Class Initialized
INFO - 2024-05-22 12:30:20 --> Output Class Initialized
INFO - 2024-05-22 12:30:20 --> Security Class Initialized
DEBUG - 2024-05-22 12:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 12:30:20 --> Input Class Initialized
INFO - 2024-05-22 12:30:20 --> Language Class Initialized
INFO - 2024-05-22 12:30:20 --> Loader Class Initialized
INFO - 2024-05-22 12:30:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-22 12:30:20 --> Helper loaded: url_helper
DEBUG - 2024-05-22 12:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-22 12:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 12:30:20 --> Controller Class Initialized
INFO - 2024-05-22 16:52:07 --> Config Class Initialized
INFO - 2024-05-22 16:52:07 --> Hooks Class Initialized
DEBUG - 2024-05-22 16:52:07 --> UTF-8 Support Enabled
INFO - 2024-05-22 16:52:07 --> Utf8 Class Initialized
INFO - 2024-05-22 16:52:07 --> URI Class Initialized
DEBUG - 2024-05-22 16:52:07 --> No URI present. Default controller set.
INFO - 2024-05-22 16:52:07 --> Router Class Initialized
INFO - 2024-05-22 16:52:07 --> Output Class Initialized
INFO - 2024-05-22 16:52:07 --> Security Class Initialized
DEBUG - 2024-05-22 16:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 16:52:07 --> Input Class Initialized
INFO - 2024-05-22 16:52:07 --> Language Class Initialized
INFO - 2024-05-22 16:52:07 --> Loader Class Initialized
INFO - 2024-05-22 16:52:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-22 16:52:07 --> Helper loaded: url_helper
DEBUG - 2024-05-22 16:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-22 16:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 16:52:07 --> Controller Class Initialized
INFO - 2024-05-22 16:52:08 --> Config Class Initialized
INFO - 2024-05-22 16:52:08 --> Hooks Class Initialized
DEBUG - 2024-05-22 16:52:08 --> UTF-8 Support Enabled
INFO - 2024-05-22 16:52:08 --> Utf8 Class Initialized
INFO - 2024-05-22 16:52:08 --> URI Class Initialized
DEBUG - 2024-05-22 16:52:08 --> No URI present. Default controller set.
INFO - 2024-05-22 16:52:08 --> Router Class Initialized
INFO - 2024-05-22 16:52:08 --> Output Class Initialized
INFO - 2024-05-22 16:52:08 --> Security Class Initialized
DEBUG - 2024-05-22 16:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 16:52:08 --> Input Class Initialized
INFO - 2024-05-22 16:52:08 --> Language Class Initialized
INFO - 2024-05-22 16:52:08 --> Loader Class Initialized
INFO - 2024-05-22 16:52:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-22 16:52:08 --> Helper loaded: url_helper
DEBUG - 2024-05-22 16:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-22 16:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 16:52:08 --> Controller Class Initialized
