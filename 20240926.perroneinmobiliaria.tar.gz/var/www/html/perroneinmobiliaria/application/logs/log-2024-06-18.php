<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-18 04:53:20 --> Config Class Initialized
INFO - 2024-06-18 04:53:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 04:53:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 04:53:20 --> Utf8 Class Initialized
INFO - 2024-06-18 04:53:20 --> URI Class Initialized
DEBUG - 2024-06-18 04:53:20 --> No URI present. Default controller set.
INFO - 2024-06-18 04:53:20 --> Router Class Initialized
INFO - 2024-06-18 04:53:20 --> Output Class Initialized
INFO - 2024-06-18 04:53:20 --> Security Class Initialized
DEBUG - 2024-06-18 04:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 04:53:20 --> Input Class Initialized
INFO - 2024-06-18 04:53:20 --> Language Class Initialized
INFO - 2024-06-18 04:53:20 --> Loader Class Initialized
INFO - 2024-06-18 04:53:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 04:53:20 --> Helper loaded: url_helper
DEBUG - 2024-06-18 04:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 04:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 04:53:20 --> Controller Class Initialized
INFO - 2024-06-18 10:37:14 --> Config Class Initialized
INFO - 2024-06-18 10:37:14 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:37:14 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:37:14 --> Utf8 Class Initialized
INFO - 2024-06-18 10:37:14 --> URI Class Initialized
DEBUG - 2024-06-18 10:37:14 --> No URI present. Default controller set.
INFO - 2024-06-18 10:37:14 --> Router Class Initialized
INFO - 2024-06-18 10:37:14 --> Output Class Initialized
INFO - 2024-06-18 10:37:14 --> Security Class Initialized
DEBUG - 2024-06-18 10:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:37:14 --> Input Class Initialized
INFO - 2024-06-18 10:37:14 --> Language Class Initialized
INFO - 2024-06-18 10:37:14 --> Loader Class Initialized
INFO - 2024-06-18 10:37:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 10:37:14 --> Helper loaded: url_helper
DEBUG - 2024-06-18 10:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 10:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:37:14 --> Controller Class Initialized
INFO - 2024-06-18 12:03:16 --> Config Class Initialized
INFO - 2024-06-18 12:03:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:16 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:16 --> URI Class Initialized
DEBUG - 2024-06-18 12:03:16 --> No URI present. Default controller set.
INFO - 2024-06-18 12:03:16 --> Router Class Initialized
INFO - 2024-06-18 12:03:16 --> Output Class Initialized
INFO - 2024-06-18 12:03:16 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:16 --> Input Class Initialized
INFO - 2024-06-18 12:03:16 --> Language Class Initialized
INFO - 2024-06-18 12:03:16 --> Loader Class Initialized
INFO - 2024-06-18 12:03:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:16 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:16 --> Controller Class Initialized
INFO - 2024-06-18 12:03:16 --> Config Class Initialized
INFO - 2024-06-18 12:03:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:16 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:16 --> URI Class Initialized
INFO - 2024-06-18 12:03:16 --> Router Class Initialized
INFO - 2024-06-18 12:03:16 --> Output Class Initialized
INFO - 2024-06-18 12:03:16 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:16 --> Input Class Initialized
INFO - 2024-06-18 12:03:16 --> Language Class Initialized
INFO - 2024-06-18 12:03:16 --> Loader Class Initialized
INFO - 2024-06-18 12:03:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:16 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:16 --> Controller Class Initialized
DEBUG - 2024-06-18 12:03:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-18 12:03:16 --> Database Driver Class Initialized
INFO - 2024-06-18 12:03:16 --> Helper loaded: cookie_helper
INFO - 2024-06-18 12:03:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-18 12:03:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-18 12:03:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-18 12:03:16 --> Final output sent to browser
DEBUG - 2024-06-18 12:03:16 --> Total execution time: 0.0475
INFO - 2024-06-18 12:03:18 --> Config Class Initialized
INFO - 2024-06-18 12:03:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:18 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:18 --> URI Class Initialized
INFO - 2024-06-18 12:03:18 --> Router Class Initialized
INFO - 2024-06-18 12:03:18 --> Output Class Initialized
INFO - 2024-06-18 12:03:18 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:18 --> Input Class Initialized
INFO - 2024-06-18 12:03:18 --> Language Class Initialized
INFO - 2024-06-18 12:03:18 --> Loader Class Initialized
INFO - 2024-06-18 12:03:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:18 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:18 --> Controller Class Initialized
INFO - 2024-06-18 12:03:32 --> Config Class Initialized
INFO - 2024-06-18 12:03:32 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:32 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:32 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:32 --> URI Class Initialized
INFO - 2024-06-18 12:03:32 --> Router Class Initialized
INFO - 2024-06-18 12:03:32 --> Output Class Initialized
INFO - 2024-06-18 12:03:32 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:32 --> Input Class Initialized
INFO - 2024-06-18 12:03:32 --> Language Class Initialized
INFO - 2024-06-18 12:03:32 --> Loader Class Initialized
INFO - 2024-06-18 12:03:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:32 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:32 --> Controller Class Initialized
DEBUG - 2024-06-18 12:03:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-18 12:03:32 --> Database Driver Class Initialized
INFO - 2024-06-18 12:03:32 --> Helper loaded: cookie_helper
INFO - 2024-06-18 12:03:32 --> Helper loaded: form_helper
INFO - 2024-06-18 12:03:32 --> Form Validation Class Initialized
INFO - 2024-06-18 12:03:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-18 12:03:32 --> Config Class Initialized
INFO - 2024-06-18 12:03:32 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:32 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:32 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:32 --> URI Class Initialized
INFO - 2024-06-18 12:03:32 --> Router Class Initialized
INFO - 2024-06-18 12:03:32 --> Output Class Initialized
INFO - 2024-06-18 12:03:32 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:32 --> Input Class Initialized
INFO - 2024-06-18 12:03:32 --> Language Class Initialized
INFO - 2024-06-18 12:03:32 --> Loader Class Initialized
INFO - 2024-06-18 12:03:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:32 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:32 --> Controller Class Initialized
INFO - 2024-06-18 12:03:32 --> Database Driver Class Initialized
DEBUG - 2024-06-18 12:03:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-18 12:03:32 --> Helper loaded: cookie_helper
INFO - 2024-06-18 12:03:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-18 12:03:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-18 12:03:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-06-18 12:03:32 --> Final output sent to browser
DEBUG - 2024-06-18 12:03:32 --> Total execution time: 0.0145
INFO - 2024-06-18 12:03:32 --> Config Class Initialized
INFO - 2024-06-18 12:03:32 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:32 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:32 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:32 --> URI Class Initialized
INFO - 2024-06-18 12:03:32 --> Router Class Initialized
INFO - 2024-06-18 12:03:32 --> Output Class Initialized
INFO - 2024-06-18 12:03:32 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:32 --> Input Class Initialized
INFO - 2024-06-18 12:03:32 --> Language Class Initialized
INFO - 2024-06-18 12:03:32 --> Loader Class Initialized
INFO - 2024-06-18 12:03:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:32 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:32 --> Controller Class Initialized
DEBUG - 2024-06-18 12:03:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-18 12:03:32 --> Database Driver Class Initialized
INFO - 2024-06-18 12:03:32 --> Helper loaded: funciones_helper
INFO - 2024-06-18 12:03:32 --> Final output sent to browser
DEBUG - 2024-06-18 12:03:32 --> Total execution time: 0.0325
INFO - 2024-06-18 12:03:37 --> Config Class Initialized
INFO - 2024-06-18 12:03:37 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:37 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:37 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:37 --> URI Class Initialized
INFO - 2024-06-18 12:03:37 --> Router Class Initialized
INFO - 2024-06-18 12:03:37 --> Output Class Initialized
INFO - 2024-06-18 12:03:37 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:37 --> Input Class Initialized
INFO - 2024-06-18 12:03:37 --> Language Class Initialized
INFO - 2024-06-18 12:03:37 --> Loader Class Initialized
INFO - 2024-06-18 12:03:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:37 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:37 --> Controller Class Initialized
DEBUG - 2024-06-18 12:03:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-18 12:03:37 --> Database Driver Class Initialized
INFO - 2024-06-18 12:03:37 --> Helper loaded: funciones_helper
INFO - 2024-06-18 12:03:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-18 12:03:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-18 12:03:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-06-18 12:03:37 --> Final output sent to browser
DEBUG - 2024-06-18 12:03:37 --> Total execution time: 0.0250
INFO - 2024-06-18 12:03:38 --> Config Class Initialized
INFO - 2024-06-18 12:03:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 12:03:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 12:03:38 --> Utf8 Class Initialized
INFO - 2024-06-18 12:03:38 --> URI Class Initialized
INFO - 2024-06-18 12:03:38 --> Router Class Initialized
INFO - 2024-06-18 12:03:38 --> Output Class Initialized
INFO - 2024-06-18 12:03:38 --> Security Class Initialized
DEBUG - 2024-06-18 12:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 12:03:38 --> Input Class Initialized
INFO - 2024-06-18 12:03:38 --> Language Class Initialized
INFO - 2024-06-18 12:03:38 --> Loader Class Initialized
INFO - 2024-06-18 12:03:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 12:03:38 --> Helper loaded: url_helper
DEBUG - 2024-06-18 12:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 12:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 12:03:38 --> Controller Class Initialized
DEBUG - 2024-06-18 12:03:38 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-18 12:03:38 --> Database Driver Class Initialized
INFO - 2024-06-18 12:03:38 --> Helper loaded: funciones_helper
INFO - 2024-06-18 12:03:38 --> Final output sent to browser
DEBUG - 2024-06-18 12:03:38 --> Total execution time: 0.0282
INFO - 2024-06-18 16:08:59 --> Config Class Initialized
INFO - 2024-06-18 16:08:59 --> Hooks Class Initialized
DEBUG - 2024-06-18 16:08:59 --> UTF-8 Support Enabled
INFO - 2024-06-18 16:08:59 --> Utf8 Class Initialized
INFO - 2024-06-18 16:08:59 --> URI Class Initialized
DEBUG - 2024-06-18 16:08:59 --> No URI present. Default controller set.
INFO - 2024-06-18 16:08:59 --> Router Class Initialized
INFO - 2024-06-18 16:08:59 --> Output Class Initialized
INFO - 2024-06-18 16:08:59 --> Security Class Initialized
DEBUG - 2024-06-18 16:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 16:08:59 --> Input Class Initialized
INFO - 2024-06-18 16:08:59 --> Language Class Initialized
INFO - 2024-06-18 16:08:59 --> Loader Class Initialized
INFO - 2024-06-18 16:08:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-18 16:08:59 --> Helper loaded: url_helper
DEBUG - 2024-06-18 16:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-18 16:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 16:08:59 --> Controller Class Initialized
