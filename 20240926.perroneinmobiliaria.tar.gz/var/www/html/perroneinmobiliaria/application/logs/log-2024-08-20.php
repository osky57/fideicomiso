<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-20 02:06:30 --> Config Class Initialized
INFO - 2024-08-20 02:06:30 --> Hooks Class Initialized
DEBUG - 2024-08-20 02:06:30 --> UTF-8 Support Enabled
INFO - 2024-08-20 02:06:30 --> Utf8 Class Initialized
INFO - 2024-08-20 02:06:30 --> URI Class Initialized
DEBUG - 2024-08-20 02:06:30 --> No URI present. Default controller set.
INFO - 2024-08-20 02:06:30 --> Router Class Initialized
INFO - 2024-08-20 02:06:30 --> Output Class Initialized
INFO - 2024-08-20 02:06:30 --> Security Class Initialized
DEBUG - 2024-08-20 02:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-20 02:06:30 --> Input Class Initialized
INFO - 2024-08-20 02:06:30 --> Language Class Initialized
INFO - 2024-08-20 02:06:30 --> Loader Class Initialized
INFO - 2024-08-20 02:06:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-20 02:06:30 --> Helper loaded: url_helper
DEBUG - 2024-08-20 02:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-20 02:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-20 02:06:30 --> Controller Class Initialized
INFO - 2024-08-20 05:55:18 --> Config Class Initialized
INFO - 2024-08-20 05:55:18 --> Hooks Class Initialized
DEBUG - 2024-08-20 05:55:18 --> UTF-8 Support Enabled
INFO - 2024-08-20 05:55:18 --> Utf8 Class Initialized
INFO - 2024-08-20 05:55:18 --> URI Class Initialized
DEBUG - 2024-08-20 05:55:18 --> No URI present. Default controller set.
INFO - 2024-08-20 05:55:18 --> Router Class Initialized
INFO - 2024-08-20 05:55:18 --> Output Class Initialized
INFO - 2024-08-20 05:55:18 --> Security Class Initialized
DEBUG - 2024-08-20 05:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-20 05:55:18 --> Input Class Initialized
INFO - 2024-08-20 05:55:18 --> Language Class Initialized
INFO - 2024-08-20 05:55:18 --> Loader Class Initialized
INFO - 2024-08-20 05:55:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-20 05:55:18 --> Helper loaded: url_helper
DEBUG - 2024-08-20 05:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-20 05:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-20 05:55:18 --> Controller Class Initialized
INFO - 2024-08-20 05:55:28 --> Config Class Initialized
INFO - 2024-08-20 05:55:28 --> Hooks Class Initialized
DEBUG - 2024-08-20 05:55:28 --> UTF-8 Support Enabled
INFO - 2024-08-20 05:55:28 --> Utf8 Class Initialized
INFO - 2024-08-20 05:55:28 --> URI Class Initialized
DEBUG - 2024-08-20 05:55:28 --> No URI present. Default controller set.
INFO - 2024-08-20 05:55:28 --> Router Class Initialized
INFO - 2024-08-20 05:55:28 --> Output Class Initialized
INFO - 2024-08-20 05:55:28 --> Security Class Initialized
DEBUG - 2024-08-20 05:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-20 05:55:28 --> Input Class Initialized
INFO - 2024-08-20 05:55:28 --> Language Class Initialized
INFO - 2024-08-20 05:55:28 --> Loader Class Initialized
INFO - 2024-08-20 05:55:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-20 05:55:28 --> Helper loaded: url_helper
DEBUG - 2024-08-20 05:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-20 05:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-20 05:55:28 --> Controller Class Initialized
INFO - 2024-08-20 23:32:18 --> Config Class Initialized
INFO - 2024-08-20 23:32:18 --> Hooks Class Initialized
DEBUG - 2024-08-20 23:32:18 --> UTF-8 Support Enabled
INFO - 2024-08-20 23:32:18 --> Utf8 Class Initialized
INFO - 2024-08-20 23:32:18 --> URI Class Initialized
DEBUG - 2024-08-20 23:32:18 --> No URI present. Default controller set.
INFO - 2024-08-20 23:32:18 --> Router Class Initialized
INFO - 2024-08-20 23:32:18 --> Output Class Initialized
INFO - 2024-08-20 23:32:18 --> Security Class Initialized
DEBUG - 2024-08-20 23:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-20 23:32:18 --> Input Class Initialized
INFO - 2024-08-20 23:32:18 --> Language Class Initialized
INFO - 2024-08-20 23:32:18 --> Loader Class Initialized
INFO - 2024-08-20 23:32:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-20 23:32:18 --> Helper loaded: url_helper
DEBUG - 2024-08-20 23:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-20 23:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-20 23:32:18 --> Controller Class Initialized
