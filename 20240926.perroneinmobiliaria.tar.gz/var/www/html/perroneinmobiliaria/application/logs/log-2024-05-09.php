<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-09 00:04:53 --> Config Class Initialized
INFO - 2024-05-09 00:04:53 --> Hooks Class Initialized
DEBUG - 2024-05-09 00:04:53 --> UTF-8 Support Enabled
INFO - 2024-05-09 00:04:53 --> Utf8 Class Initialized
INFO - 2024-05-09 00:04:53 --> URI Class Initialized
DEBUG - 2024-05-09 00:04:53 --> No URI present. Default controller set.
INFO - 2024-05-09 00:04:53 --> Router Class Initialized
INFO - 2024-05-09 00:04:53 --> Output Class Initialized
INFO - 2024-05-09 00:04:53 --> Security Class Initialized
DEBUG - 2024-05-09 00:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-09 00:04:53 --> Input Class Initialized
INFO - 2024-05-09 00:04:53 --> Language Class Initialized
INFO - 2024-05-09 00:04:53 --> Loader Class Initialized
INFO - 2024-05-09 00:04:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-09 00:04:53 --> Helper loaded: url_helper
DEBUG - 2024-05-09 00:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-09 00:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-09 00:04:53 --> Controller Class Initialized
INFO - 2024-05-09 17:48:21 --> Config Class Initialized
INFO - 2024-05-09 17:48:21 --> Hooks Class Initialized
DEBUG - 2024-05-09 17:48:21 --> UTF-8 Support Enabled
INFO - 2024-05-09 17:48:21 --> Utf8 Class Initialized
INFO - 2024-05-09 17:48:21 --> URI Class Initialized
DEBUG - 2024-05-09 17:48:21 --> No URI present. Default controller set.
INFO - 2024-05-09 17:48:21 --> Router Class Initialized
INFO - 2024-05-09 17:48:21 --> Output Class Initialized
INFO - 2024-05-09 17:48:21 --> Security Class Initialized
DEBUG - 2024-05-09 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-09 17:48:21 --> Input Class Initialized
INFO - 2024-05-09 17:48:21 --> Language Class Initialized
INFO - 2024-05-09 17:48:21 --> Loader Class Initialized
INFO - 2024-05-09 17:48:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-09 17:48:21 --> Helper loaded: url_helper
DEBUG - 2024-05-09 17:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-09 17:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-09 17:48:21 --> Controller Class Initialized
INFO - 2024-05-09 21:25:21 --> Config Class Initialized
INFO - 2024-05-09 21:25:21 --> Hooks Class Initialized
DEBUG - 2024-05-09 21:25:21 --> UTF-8 Support Enabled
INFO - 2024-05-09 21:25:21 --> Utf8 Class Initialized
INFO - 2024-05-09 21:25:21 --> URI Class Initialized
DEBUG - 2024-05-09 21:25:21 --> No URI present. Default controller set.
INFO - 2024-05-09 21:25:21 --> Router Class Initialized
INFO - 2024-05-09 21:25:21 --> Output Class Initialized
INFO - 2024-05-09 21:25:21 --> Security Class Initialized
DEBUG - 2024-05-09 21:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-09 21:25:21 --> Input Class Initialized
INFO - 2024-05-09 21:25:21 --> Language Class Initialized
INFO - 2024-05-09 21:25:21 --> Loader Class Initialized
INFO - 2024-05-09 21:25:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-09 21:25:21 --> Helper loaded: url_helper
DEBUG - 2024-05-09 21:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-09 21:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-09 21:25:21 --> Controller Class Initialized
INFO - 2024-05-09 21:31:31 --> Config Class Initialized
INFO - 2024-05-09 21:31:31 --> Hooks Class Initialized
DEBUG - 2024-05-09 21:31:31 --> UTF-8 Support Enabled
INFO - 2024-05-09 21:31:31 --> Utf8 Class Initialized
INFO - 2024-05-09 21:31:31 --> URI Class Initialized
DEBUG - 2024-05-09 21:31:31 --> No URI present. Default controller set.
INFO - 2024-05-09 21:31:31 --> Router Class Initialized
INFO - 2024-05-09 21:31:31 --> Output Class Initialized
INFO - 2024-05-09 21:31:31 --> Security Class Initialized
DEBUG - 2024-05-09 21:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-09 21:31:31 --> Input Class Initialized
INFO - 2024-05-09 21:31:31 --> Language Class Initialized
INFO - 2024-05-09 21:31:31 --> Loader Class Initialized
INFO - 2024-05-09 21:31:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-09 21:31:31 --> Helper loaded: url_helper
DEBUG - 2024-05-09 21:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-09 21:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-09 21:31:31 --> Controller Class Initialized
