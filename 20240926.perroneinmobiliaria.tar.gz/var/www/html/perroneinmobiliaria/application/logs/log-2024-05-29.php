<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-29 09:04:01 --> Config Class Initialized
INFO - 2024-05-29 09:04:01 --> Hooks Class Initialized
DEBUG - 2024-05-29 09:04:01 --> UTF-8 Support Enabled
INFO - 2024-05-29 09:04:01 --> Utf8 Class Initialized
INFO - 2024-05-29 09:04:01 --> URI Class Initialized
INFO - 2024-05-29 09:04:01 --> Router Class Initialized
INFO - 2024-05-29 09:04:01 --> Output Class Initialized
INFO - 2024-05-29 09:04:01 --> Security Class Initialized
DEBUG - 2024-05-29 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-29 09:04:01 --> Input Class Initialized
INFO - 2024-05-29 09:04:01 --> Language Class Initialized
INFO - 2024-05-29 09:04:01 --> Loader Class Initialized
INFO - 2024-05-29 09:04:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-29 09:04:01 --> Helper loaded: url_helper
DEBUG - 2024-05-29 09:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-29 09:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-29 09:04:01 --> Controller Class Initialized
DEBUG - 2024-05-29 09:04:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-29 09:04:01 --> Database Driver Class Initialized
INFO - 2024-05-29 09:04:01 --> Helper loaded: cookie_helper
INFO - 2024-05-29 09:04:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-29 09:04:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-29 09:04:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-29 09:04:01 --> Final output sent to browser
DEBUG - 2024-05-29 09:04:01 --> Total execution time: 0.1011
INFO - 2024-05-29 09:04:03 --> Config Class Initialized
INFO - 2024-05-29 09:04:03 --> Hooks Class Initialized
DEBUG - 2024-05-29 09:04:03 --> UTF-8 Support Enabled
INFO - 2024-05-29 09:04:03 --> Utf8 Class Initialized
INFO - 2024-05-29 09:04:03 --> URI Class Initialized
INFO - 2024-05-29 09:04:03 --> Router Class Initialized
INFO - 2024-05-29 09:04:03 --> Output Class Initialized
INFO - 2024-05-29 09:04:03 --> Security Class Initialized
DEBUG - 2024-05-29 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-29 09:04:03 --> Input Class Initialized
INFO - 2024-05-29 09:04:03 --> Language Class Initialized
INFO - 2024-05-29 09:04:03 --> Loader Class Initialized
INFO - 2024-05-29 09:04:03 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-29 09:04:03 --> Helper loaded: url_helper
DEBUG - 2024-05-29 09:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-29 09:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-29 09:04:03 --> Controller Class Initialized
INFO - 2024-05-29 10:36:07 --> Config Class Initialized
INFO - 2024-05-29 10:36:07 --> Hooks Class Initialized
DEBUG - 2024-05-29 10:36:07 --> UTF-8 Support Enabled
INFO - 2024-05-29 10:36:07 --> Utf8 Class Initialized
INFO - 2024-05-29 10:36:07 --> URI Class Initialized
DEBUG - 2024-05-29 10:36:07 --> No URI present. Default controller set.
INFO - 2024-05-29 10:36:07 --> Router Class Initialized
INFO - 2024-05-29 10:36:07 --> Output Class Initialized
INFO - 2024-05-29 10:36:07 --> Security Class Initialized
DEBUG - 2024-05-29 10:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-29 10:36:07 --> Input Class Initialized
INFO - 2024-05-29 10:36:07 --> Language Class Initialized
INFO - 2024-05-29 10:36:07 --> Loader Class Initialized
INFO - 2024-05-29 10:36:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-29 10:36:07 --> Helper loaded: url_helper
DEBUG - 2024-05-29 10:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-29 10:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-29 10:36:07 --> Controller Class Initialized
INFO - 2024-05-29 16:40:45 --> Config Class Initialized
INFO - 2024-05-29 16:40:45 --> Hooks Class Initialized
DEBUG - 2024-05-29 16:40:45 --> UTF-8 Support Enabled
INFO - 2024-05-29 16:40:45 --> Utf8 Class Initialized
INFO - 2024-05-29 16:40:45 --> URI Class Initialized
DEBUG - 2024-05-29 16:40:45 --> No URI present. Default controller set.
INFO - 2024-05-29 16:40:45 --> Router Class Initialized
INFO - 2024-05-29 16:40:45 --> Output Class Initialized
INFO - 2024-05-29 16:40:45 --> Security Class Initialized
DEBUG - 2024-05-29 16:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-29 16:40:45 --> Input Class Initialized
INFO - 2024-05-29 16:40:45 --> Language Class Initialized
INFO - 2024-05-29 16:40:45 --> Loader Class Initialized
INFO - 2024-05-29 16:40:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-29 16:40:45 --> Helper loaded: url_helper
DEBUG - 2024-05-29 16:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-29 16:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-29 16:40:45 --> Controller Class Initialized
