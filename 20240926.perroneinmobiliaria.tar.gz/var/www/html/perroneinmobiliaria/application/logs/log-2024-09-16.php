<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-16 05:48:58 --> Config Class Initialized
INFO - 2024-09-16 05:48:58 --> Hooks Class Initialized
DEBUG - 2024-09-16 05:48:58 --> UTF-8 Support Enabled
INFO - 2024-09-16 05:48:58 --> Utf8 Class Initialized
INFO - 2024-09-16 05:48:58 --> URI Class Initialized
DEBUG - 2024-09-16 05:48:58 --> No URI present. Default controller set.
INFO - 2024-09-16 05:48:58 --> Router Class Initialized
INFO - 2024-09-16 05:48:58 --> Output Class Initialized
INFO - 2024-09-16 05:48:58 --> Security Class Initialized
DEBUG - 2024-09-16 05:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 05:48:58 --> Input Class Initialized
INFO - 2024-09-16 05:48:58 --> Language Class Initialized
INFO - 2024-09-16 05:48:58 --> Loader Class Initialized
INFO - 2024-09-16 05:48:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-16 05:48:58 --> Helper loaded: url_helper
DEBUG - 2024-09-16 05:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-16 05:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 05:48:58 --> Controller Class Initialized
INFO - 2024-09-16 11:47:51 --> Config Class Initialized
INFO - 2024-09-16 11:47:51 --> Hooks Class Initialized
DEBUG - 2024-09-16 11:47:51 --> UTF-8 Support Enabled
INFO - 2024-09-16 11:47:51 --> Utf8 Class Initialized
INFO - 2024-09-16 11:47:51 --> URI Class Initialized
DEBUG - 2024-09-16 11:47:51 --> No URI present. Default controller set.
INFO - 2024-09-16 11:47:51 --> Router Class Initialized
INFO - 2024-09-16 11:47:51 --> Output Class Initialized
INFO - 2024-09-16 11:47:51 --> Security Class Initialized
DEBUG - 2024-09-16 11:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 11:47:51 --> Input Class Initialized
INFO - 2024-09-16 11:47:51 --> Language Class Initialized
INFO - 2024-09-16 11:47:51 --> Loader Class Initialized
INFO - 2024-09-16 11:47:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-16 11:47:51 --> Helper loaded: url_helper
DEBUG - 2024-09-16 11:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-16 11:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 11:47:51 --> Controller Class Initialized
INFO - 2024-09-16 11:55:56 --> Config Class Initialized
INFO - 2024-09-16 11:55:56 --> Hooks Class Initialized
DEBUG - 2024-09-16 11:55:56 --> UTF-8 Support Enabled
INFO - 2024-09-16 11:55:56 --> Utf8 Class Initialized
INFO - 2024-09-16 11:55:56 --> URI Class Initialized
DEBUG - 2024-09-16 11:55:56 --> No URI present. Default controller set.
INFO - 2024-09-16 11:55:56 --> Router Class Initialized
INFO - 2024-09-16 11:55:56 --> Output Class Initialized
INFO - 2024-09-16 11:55:56 --> Security Class Initialized
DEBUG - 2024-09-16 11:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 11:55:56 --> Input Class Initialized
INFO - 2024-09-16 11:55:56 --> Language Class Initialized
INFO - 2024-09-16 11:55:56 --> Loader Class Initialized
INFO - 2024-09-16 11:55:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-16 11:55:56 --> Helper loaded: url_helper
DEBUG - 2024-09-16 11:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-16 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 11:55:56 --> Controller Class Initialized
