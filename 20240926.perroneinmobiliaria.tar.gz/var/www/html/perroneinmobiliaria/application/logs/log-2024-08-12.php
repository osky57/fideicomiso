<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-12 01:13:31 --> Config Class Initialized
INFO - 2024-08-12 01:13:31 --> Hooks Class Initialized
DEBUG - 2024-08-12 01:13:31 --> UTF-8 Support Enabled
INFO - 2024-08-12 01:13:31 --> Utf8 Class Initialized
INFO - 2024-08-12 01:13:31 --> URI Class Initialized
DEBUG - 2024-08-12 01:13:31 --> No URI present. Default controller set.
INFO - 2024-08-12 01:13:31 --> Router Class Initialized
INFO - 2024-08-12 01:13:31 --> Output Class Initialized
INFO - 2024-08-12 01:13:31 --> Security Class Initialized
DEBUG - 2024-08-12 01:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 01:13:31 --> Input Class Initialized
INFO - 2024-08-12 01:13:31 --> Language Class Initialized
INFO - 2024-08-12 01:13:31 --> Loader Class Initialized
INFO - 2024-08-12 01:13:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-12 01:13:31 --> Helper loaded: url_helper
DEBUG - 2024-08-12 01:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-12 01:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 01:13:31 --> Controller Class Initialized
INFO - 2024-08-12 03:07:52 --> Config Class Initialized
INFO - 2024-08-12 03:07:52 --> Hooks Class Initialized
DEBUG - 2024-08-12 03:07:52 --> UTF-8 Support Enabled
INFO - 2024-08-12 03:07:52 --> Utf8 Class Initialized
INFO - 2024-08-12 03:07:52 --> URI Class Initialized
DEBUG - 2024-08-12 03:07:52 --> No URI present. Default controller set.
INFO - 2024-08-12 03:07:52 --> Router Class Initialized
INFO - 2024-08-12 03:07:52 --> Output Class Initialized
INFO - 2024-08-12 03:07:52 --> Security Class Initialized
DEBUG - 2024-08-12 03:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 03:07:52 --> Input Class Initialized
INFO - 2024-08-12 03:07:52 --> Language Class Initialized
INFO - 2024-08-12 03:07:52 --> Loader Class Initialized
INFO - 2024-08-12 03:07:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-12 03:07:52 --> Helper loaded: url_helper
DEBUG - 2024-08-12 03:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-12 03:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 03:07:52 --> Controller Class Initialized
INFO - 2024-08-12 03:15:12 --> Config Class Initialized
INFO - 2024-08-12 03:15:12 --> Hooks Class Initialized
DEBUG - 2024-08-12 03:15:12 --> UTF-8 Support Enabled
INFO - 2024-08-12 03:15:12 --> Utf8 Class Initialized
INFO - 2024-08-12 03:15:12 --> URI Class Initialized
DEBUG - 2024-08-12 03:15:12 --> No URI present. Default controller set.
INFO - 2024-08-12 03:15:12 --> Router Class Initialized
INFO - 2024-08-12 03:15:12 --> Output Class Initialized
INFO - 2024-08-12 03:15:12 --> Security Class Initialized
DEBUG - 2024-08-12 03:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 03:15:12 --> Input Class Initialized
INFO - 2024-08-12 03:15:12 --> Language Class Initialized
INFO - 2024-08-12 03:15:12 --> Loader Class Initialized
INFO - 2024-08-12 03:15:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-12 03:15:12 --> Helper loaded: url_helper
DEBUG - 2024-08-12 03:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-12 03:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 03:15:12 --> Controller Class Initialized
