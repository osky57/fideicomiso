<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-26 01:47:12 --> Config Class Initialized
INFO - 2024-07-26 01:47:12 --> Hooks Class Initialized
DEBUG - 2024-07-26 01:47:12 --> UTF-8 Support Enabled
INFO - 2024-07-26 01:47:12 --> Utf8 Class Initialized
INFO - 2024-07-26 01:47:12 --> URI Class Initialized
DEBUG - 2024-07-26 01:47:12 --> No URI present. Default controller set.
INFO - 2024-07-26 01:47:12 --> Router Class Initialized
INFO - 2024-07-26 01:47:12 --> Output Class Initialized
INFO - 2024-07-26 01:47:12 --> Security Class Initialized
DEBUG - 2024-07-26 01:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 01:47:12 --> Input Class Initialized
INFO - 2024-07-26 01:47:12 --> Language Class Initialized
INFO - 2024-07-26 01:47:12 --> Loader Class Initialized
INFO - 2024-07-26 01:47:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-26 01:47:12 --> Helper loaded: url_helper
DEBUG - 2024-07-26 01:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-26 01:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 01:47:12 --> Controller Class Initialized
INFO - 2024-07-26 07:22:05 --> Config Class Initialized
INFO - 2024-07-26 07:22:05 --> Hooks Class Initialized
DEBUG - 2024-07-26 07:22:05 --> UTF-8 Support Enabled
INFO - 2024-07-26 07:22:05 --> Utf8 Class Initialized
INFO - 2024-07-26 07:22:05 --> URI Class Initialized
INFO - 2024-07-26 07:22:05 --> Router Class Initialized
INFO - 2024-07-26 07:22:05 --> Output Class Initialized
INFO - 2024-07-26 07:22:05 --> Security Class Initialized
DEBUG - 2024-07-26 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 07:22:05 --> Input Class Initialized
INFO - 2024-07-26 07:22:05 --> Language Class Initialized
INFO - 2024-07-26 07:22:05 --> Loader Class Initialized
INFO - 2024-07-26 07:22:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-26 07:22:05 --> Helper loaded: url_helper
DEBUG - 2024-07-26 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-26 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 07:22:05 --> Controller Class Initialized
DEBUG - 2024-07-26 07:22:05 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-26 07:22:05 --> Database Driver Class Initialized
INFO - 2024-07-26 07:22:05 --> Helper loaded: cookie_helper
INFO - 2024-07-26 07:22:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-26 07:22:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-26 07:22:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-07-26 07:22:05 --> Final output sent to browser
DEBUG - 2024-07-26 07:22:05 --> Total execution time: 0.0979
INFO - 2024-07-26 09:13:04 --> Config Class Initialized
INFO - 2024-07-26 09:13:04 --> Hooks Class Initialized
DEBUG - 2024-07-26 09:13:04 --> UTF-8 Support Enabled
INFO - 2024-07-26 09:13:04 --> Utf8 Class Initialized
INFO - 2024-07-26 09:13:04 --> URI Class Initialized
DEBUG - 2024-07-26 09:13:04 --> No URI present. Default controller set.
INFO - 2024-07-26 09:13:04 --> Router Class Initialized
INFO - 2024-07-26 09:13:04 --> Output Class Initialized
INFO - 2024-07-26 09:13:04 --> Security Class Initialized
DEBUG - 2024-07-26 09:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 09:13:04 --> Input Class Initialized
INFO - 2024-07-26 09:13:04 --> Language Class Initialized
INFO - 2024-07-26 09:13:04 --> Loader Class Initialized
INFO - 2024-07-26 09:13:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-26 09:13:04 --> Helper loaded: url_helper
DEBUG - 2024-07-26 09:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-26 09:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 09:13:04 --> Controller Class Initialized
