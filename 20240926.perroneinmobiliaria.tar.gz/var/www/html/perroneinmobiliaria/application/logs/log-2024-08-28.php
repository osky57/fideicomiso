<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-28 06:04:10 --> Config Class Initialized
INFO - 2024-08-28 06:04:10 --> Hooks Class Initialized
DEBUG - 2024-08-28 06:04:10 --> UTF-8 Support Enabled
INFO - 2024-08-28 06:04:10 --> Utf8 Class Initialized
INFO - 2024-08-28 06:04:10 --> URI Class Initialized
DEBUG - 2024-08-28 06:04:10 --> No URI present. Default controller set.
INFO - 2024-08-28 06:04:10 --> Router Class Initialized
INFO - 2024-08-28 06:04:10 --> Output Class Initialized
INFO - 2024-08-28 06:04:10 --> Security Class Initialized
DEBUG - 2024-08-28 06:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 06:04:10 --> Input Class Initialized
INFO - 2024-08-28 06:04:10 --> Language Class Initialized
INFO - 2024-08-28 06:04:10 --> Loader Class Initialized
INFO - 2024-08-28 06:04:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-28 06:04:10 --> Helper loaded: url_helper
DEBUG - 2024-08-28 06:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-28 06:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 06:04:10 --> Controller Class Initialized
INFO - 2024-08-28 07:19:15 --> Config Class Initialized
INFO - 2024-08-28 07:19:15 --> Hooks Class Initialized
DEBUG - 2024-08-28 07:19:15 --> UTF-8 Support Enabled
INFO - 2024-08-28 07:19:15 --> Utf8 Class Initialized
INFO - 2024-08-28 07:19:15 --> URI Class Initialized
DEBUG - 2024-08-28 07:19:15 --> No URI present. Default controller set.
INFO - 2024-08-28 07:19:15 --> Router Class Initialized
INFO - 2024-08-28 07:19:15 --> Output Class Initialized
INFO - 2024-08-28 07:19:15 --> Security Class Initialized
DEBUG - 2024-08-28 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 07:19:15 --> Input Class Initialized
INFO - 2024-08-28 07:19:15 --> Language Class Initialized
INFO - 2024-08-28 07:19:15 --> Loader Class Initialized
INFO - 2024-08-28 07:19:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-28 07:19:15 --> Helper loaded: url_helper
DEBUG - 2024-08-28 07:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-28 07:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 07:19:15 --> Controller Class Initialized
