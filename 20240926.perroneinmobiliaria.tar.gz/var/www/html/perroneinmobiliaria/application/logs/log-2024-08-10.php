<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-10 00:39:55 --> Config Class Initialized
INFO - 2024-08-10 00:39:55 --> Hooks Class Initialized
DEBUG - 2024-08-10 00:39:55 --> UTF-8 Support Enabled
INFO - 2024-08-10 00:39:55 --> Utf8 Class Initialized
INFO - 2024-08-10 00:39:55 --> URI Class Initialized
DEBUG - 2024-08-10 00:39:55 --> No URI present. Default controller set.
INFO - 2024-08-10 00:39:55 --> Router Class Initialized
INFO - 2024-08-10 00:39:55 --> Output Class Initialized
INFO - 2024-08-10 00:39:55 --> Security Class Initialized
DEBUG - 2024-08-10 00:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-10 00:39:55 --> Input Class Initialized
INFO - 2024-08-10 00:39:55 --> Language Class Initialized
INFO - 2024-08-10 00:39:55 --> Loader Class Initialized
INFO - 2024-08-10 00:39:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-10 00:39:55 --> Helper loaded: url_helper
DEBUG - 2024-08-10 00:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-10 00:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-10 00:39:55 --> Controller Class Initialized
INFO - 2024-08-10 10:07:19 --> Config Class Initialized
INFO - 2024-08-10 10:07:19 --> Hooks Class Initialized
DEBUG - 2024-08-10 10:07:19 --> UTF-8 Support Enabled
INFO - 2024-08-10 10:07:19 --> Utf8 Class Initialized
INFO - 2024-08-10 10:07:19 --> URI Class Initialized
DEBUG - 2024-08-10 10:07:19 --> No URI present. Default controller set.
INFO - 2024-08-10 10:07:19 --> Router Class Initialized
INFO - 2024-08-10 10:07:19 --> Output Class Initialized
INFO - 2024-08-10 10:07:19 --> Security Class Initialized
DEBUG - 2024-08-10 10:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-10 10:07:19 --> Input Class Initialized
INFO - 2024-08-10 10:07:19 --> Language Class Initialized
INFO - 2024-08-10 10:07:19 --> Loader Class Initialized
INFO - 2024-08-10 10:07:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-10 10:07:19 --> Helper loaded: url_helper
DEBUG - 2024-08-10 10:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-10 10:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-10 10:07:19 --> Controller Class Initialized
INFO - 2024-08-10 14:49:27 --> Config Class Initialized
INFO - 2024-08-10 14:49:27 --> Hooks Class Initialized
DEBUG - 2024-08-10 14:49:27 --> UTF-8 Support Enabled
INFO - 2024-08-10 14:49:27 --> Utf8 Class Initialized
INFO - 2024-08-10 14:49:27 --> URI Class Initialized
DEBUG - 2024-08-10 14:49:27 --> No URI present. Default controller set.
INFO - 2024-08-10 14:49:27 --> Router Class Initialized
INFO - 2024-08-10 14:49:27 --> Output Class Initialized
INFO - 2024-08-10 14:49:27 --> Security Class Initialized
DEBUG - 2024-08-10 14:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-10 14:49:27 --> Input Class Initialized
INFO - 2024-08-10 14:49:27 --> Language Class Initialized
INFO - 2024-08-10 14:49:27 --> Loader Class Initialized
INFO - 2024-08-10 14:49:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-10 14:49:27 --> Helper loaded: url_helper
DEBUG - 2024-08-10 14:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-10 14:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-10 14:49:27 --> Controller Class Initialized
INFO - 2024-08-10 22:29:09 --> Config Class Initialized
INFO - 2024-08-10 22:29:09 --> Hooks Class Initialized
DEBUG - 2024-08-10 22:29:09 --> UTF-8 Support Enabled
INFO - 2024-08-10 22:29:09 --> Utf8 Class Initialized
INFO - 2024-08-10 22:29:09 --> URI Class Initialized
DEBUG - 2024-08-10 22:29:09 --> No URI present. Default controller set.
INFO - 2024-08-10 22:29:09 --> Router Class Initialized
INFO - 2024-08-10 22:29:09 --> Output Class Initialized
INFO - 2024-08-10 22:29:09 --> Security Class Initialized
DEBUG - 2024-08-10 22:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-10 22:29:09 --> Input Class Initialized
INFO - 2024-08-10 22:29:09 --> Language Class Initialized
INFO - 2024-08-10 22:29:09 --> Loader Class Initialized
INFO - 2024-08-10 22:29:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-10 22:29:09 --> Helper loaded: url_helper
DEBUG - 2024-08-10 22:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-10 22:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-10 22:29:09 --> Controller Class Initialized
