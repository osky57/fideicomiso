<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-17 05:31:21 --> Config Class Initialized
INFO - 2024-05-17 05:31:21 --> Hooks Class Initialized
DEBUG - 2024-05-17 05:31:21 --> UTF-8 Support Enabled
INFO - 2024-05-17 05:31:21 --> Utf8 Class Initialized
INFO - 2024-05-17 05:31:21 --> URI Class Initialized
DEBUG - 2024-05-17 05:31:21 --> No URI present. Default controller set.
INFO - 2024-05-17 05:31:21 --> Router Class Initialized
INFO - 2024-05-17 05:31:21 --> Output Class Initialized
INFO - 2024-05-17 05:31:21 --> Security Class Initialized
DEBUG - 2024-05-17 05:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-17 05:31:21 --> Input Class Initialized
INFO - 2024-05-17 05:31:21 --> Language Class Initialized
INFO - 2024-05-17 05:31:21 --> Loader Class Initialized
INFO - 2024-05-17 05:31:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-17 05:31:21 --> Helper loaded: url_helper
DEBUG - 2024-05-17 05:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-17 05:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-17 05:31:21 --> Controller Class Initialized
INFO - 2024-05-17 05:31:28 --> Config Class Initialized
INFO - 2024-05-17 05:31:28 --> Hooks Class Initialized
DEBUG - 2024-05-17 05:31:28 --> UTF-8 Support Enabled
INFO - 2024-05-17 05:31:28 --> Utf8 Class Initialized
INFO - 2024-05-17 05:31:28 --> URI Class Initialized
DEBUG - 2024-05-17 05:31:28 --> No URI present. Default controller set.
INFO - 2024-05-17 05:31:28 --> Router Class Initialized
INFO - 2024-05-17 05:31:28 --> Output Class Initialized
INFO - 2024-05-17 05:31:28 --> Security Class Initialized
DEBUG - 2024-05-17 05:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-17 05:31:28 --> Input Class Initialized
INFO - 2024-05-17 05:31:28 --> Language Class Initialized
INFO - 2024-05-17 05:31:28 --> Loader Class Initialized
INFO - 2024-05-17 05:31:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-17 05:31:28 --> Helper loaded: url_helper
DEBUG - 2024-05-17 05:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-17 05:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-17 05:31:28 --> Controller Class Initialized
INFO - 2024-05-17 06:10:37 --> Config Class Initialized
INFO - 2024-05-17 06:10:37 --> Hooks Class Initialized
DEBUG - 2024-05-17 06:10:37 --> UTF-8 Support Enabled
INFO - 2024-05-17 06:10:37 --> Utf8 Class Initialized
INFO - 2024-05-17 06:10:37 --> URI Class Initialized
DEBUG - 2024-05-17 06:10:37 --> No URI present. Default controller set.
INFO - 2024-05-17 06:10:37 --> Router Class Initialized
INFO - 2024-05-17 06:10:37 --> Output Class Initialized
INFO - 2024-05-17 06:10:37 --> Security Class Initialized
DEBUG - 2024-05-17 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-17 06:10:37 --> Input Class Initialized
INFO - 2024-05-17 06:10:37 --> Language Class Initialized
INFO - 2024-05-17 06:10:37 --> Loader Class Initialized
INFO - 2024-05-17 06:10:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-17 06:10:37 --> Helper loaded: url_helper
DEBUG - 2024-05-17 06:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-17 06:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-17 06:10:37 --> Controller Class Initialized
INFO - 2024-05-17 15:48:32 --> Config Class Initialized
INFO - 2024-05-17 15:48:32 --> Hooks Class Initialized
DEBUG - 2024-05-17 15:48:32 --> UTF-8 Support Enabled
INFO - 2024-05-17 15:48:32 --> Utf8 Class Initialized
INFO - 2024-05-17 15:48:32 --> URI Class Initialized
DEBUG - 2024-05-17 15:48:32 --> No URI present. Default controller set.
INFO - 2024-05-17 15:48:32 --> Router Class Initialized
INFO - 2024-05-17 15:48:32 --> Output Class Initialized
INFO - 2024-05-17 15:48:32 --> Security Class Initialized
DEBUG - 2024-05-17 15:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-17 15:48:32 --> Input Class Initialized
INFO - 2024-05-17 15:48:32 --> Language Class Initialized
INFO - 2024-05-17 15:48:32 --> Loader Class Initialized
INFO - 2024-05-17 15:48:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-17 15:48:32 --> Helper loaded: url_helper
DEBUG - 2024-05-17 15:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-17 15:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-17 15:48:32 --> Controller Class Initialized
