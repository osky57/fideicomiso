<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-28 04:45:00 --> Config Class Initialized
INFO - 2024-05-28 04:45:00 --> Hooks Class Initialized
DEBUG - 2024-05-28 04:45:00 --> UTF-8 Support Enabled
INFO - 2024-05-28 04:45:00 --> Utf8 Class Initialized
INFO - 2024-05-28 04:45:00 --> URI Class Initialized
DEBUG - 2024-05-28 04:45:00 --> No URI present. Default controller set.
INFO - 2024-05-28 04:45:00 --> Router Class Initialized
INFO - 2024-05-28 04:45:00 --> Output Class Initialized
INFO - 2024-05-28 04:45:00 --> Security Class Initialized
DEBUG - 2024-05-28 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 04:45:00 --> Input Class Initialized
INFO - 2024-05-28 04:45:00 --> Language Class Initialized
INFO - 2024-05-28 04:45:00 --> Loader Class Initialized
INFO - 2024-05-28 04:45:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 04:45:00 --> Helper loaded: url_helper
DEBUG - 2024-05-28 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 04:45:00 --> Controller Class Initialized
INFO - 2024-05-28 08:56:57 --> Config Class Initialized
INFO - 2024-05-28 08:56:57 --> Hooks Class Initialized
DEBUG - 2024-05-28 08:56:57 --> UTF-8 Support Enabled
INFO - 2024-05-28 08:56:57 --> Utf8 Class Initialized
INFO - 2024-05-28 08:56:57 --> URI Class Initialized
INFO - 2024-05-28 08:56:57 --> Router Class Initialized
INFO - 2024-05-28 08:56:57 --> Output Class Initialized
INFO - 2024-05-28 08:56:57 --> Security Class Initialized
DEBUG - 2024-05-28 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 08:56:57 --> Input Class Initialized
INFO - 2024-05-28 08:56:57 --> Language Class Initialized
INFO - 2024-05-28 08:56:57 --> Loader Class Initialized
INFO - 2024-05-28 08:56:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 08:56:57 --> Helper loaded: url_helper
DEBUG - 2024-05-28 08:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 08:56:57 --> Controller Class Initialized
INFO - 2024-05-28 08:56:57 --> Config Class Initialized
INFO - 2024-05-28 08:56:57 --> Hooks Class Initialized
DEBUG - 2024-05-28 08:56:57 --> UTF-8 Support Enabled
INFO - 2024-05-28 08:56:57 --> Utf8 Class Initialized
INFO - 2024-05-28 08:56:57 --> URI Class Initialized
INFO - 2024-05-28 08:56:57 --> Router Class Initialized
INFO - 2024-05-28 08:56:57 --> Output Class Initialized
INFO - 2024-05-28 08:56:57 --> Security Class Initialized
DEBUG - 2024-05-28 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 08:56:57 --> Input Class Initialized
INFO - 2024-05-28 08:56:57 --> Language Class Initialized
INFO - 2024-05-28 08:56:57 --> Loader Class Initialized
INFO - 2024-05-28 08:56:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 08:56:57 --> Helper loaded: url_helper
DEBUG - 2024-05-28 08:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 08:56:57 --> Controller Class Initialized
DEBUG - 2024-05-28 08:56:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-28 08:56:57 --> Database Driver Class Initialized
INFO - 2024-05-28 08:56:57 --> Helper loaded: cookie_helper
INFO - 2024-05-28 08:56:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-28 08:56:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-28 08:56:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-28 08:56:57 --> Final output sent to browser
DEBUG - 2024-05-28 08:56:57 --> Total execution time: 0.0302
INFO - 2024-05-28 08:57:01 --> Config Class Initialized
INFO - 2024-05-28 08:57:01 --> Hooks Class Initialized
DEBUG - 2024-05-28 08:57:01 --> UTF-8 Support Enabled
INFO - 2024-05-28 08:57:01 --> Utf8 Class Initialized
INFO - 2024-05-28 08:57:01 --> URI Class Initialized
INFO - 2024-05-28 08:57:01 --> Router Class Initialized
INFO - 2024-05-28 08:57:01 --> Output Class Initialized
INFO - 2024-05-28 08:57:01 --> Security Class Initialized
DEBUG - 2024-05-28 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 08:57:01 --> Input Class Initialized
INFO - 2024-05-28 08:57:01 --> Language Class Initialized
INFO - 2024-05-28 08:57:01 --> Loader Class Initialized
INFO - 2024-05-28 08:57:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 08:57:01 --> Helper loaded: url_helper
DEBUG - 2024-05-28 08:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 08:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 08:57:01 --> Controller Class Initialized
INFO - 2024-05-28 09:57:28 --> Config Class Initialized
INFO - 2024-05-28 09:57:28 --> Hooks Class Initialized
DEBUG - 2024-05-28 09:57:28 --> UTF-8 Support Enabled
INFO - 2024-05-28 09:57:28 --> Utf8 Class Initialized
INFO - 2024-05-28 09:57:28 --> URI Class Initialized
DEBUG - 2024-05-28 09:57:28 --> No URI present. Default controller set.
INFO - 2024-05-28 09:57:28 --> Router Class Initialized
INFO - 2024-05-28 09:57:28 --> Output Class Initialized
INFO - 2024-05-28 09:57:28 --> Security Class Initialized
DEBUG - 2024-05-28 09:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 09:57:28 --> Input Class Initialized
INFO - 2024-05-28 09:57:28 --> Language Class Initialized
INFO - 2024-05-28 09:57:28 --> Loader Class Initialized
INFO - 2024-05-28 09:57:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 09:57:28 --> Helper loaded: url_helper
DEBUG - 2024-05-28 09:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 09:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 09:57:28 --> Controller Class Initialized
INFO - 2024-05-28 14:55:28 --> Config Class Initialized
INFO - 2024-05-28 14:55:28 --> Hooks Class Initialized
DEBUG - 2024-05-28 14:55:28 --> UTF-8 Support Enabled
INFO - 2024-05-28 14:55:28 --> Utf8 Class Initialized
INFO - 2024-05-28 14:55:28 --> URI Class Initialized
DEBUG - 2024-05-28 14:55:28 --> No URI present. Default controller set.
INFO - 2024-05-28 14:55:28 --> Router Class Initialized
INFO - 2024-05-28 14:55:28 --> Output Class Initialized
INFO - 2024-05-28 14:55:28 --> Security Class Initialized
DEBUG - 2024-05-28 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 14:55:28 --> Input Class Initialized
INFO - 2024-05-28 14:55:28 --> Language Class Initialized
INFO - 2024-05-28 14:55:28 --> Loader Class Initialized
INFO - 2024-05-28 14:55:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 14:55:28 --> Helper loaded: url_helper
DEBUG - 2024-05-28 14:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 14:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 14:55:28 --> Controller Class Initialized
INFO - 2024-05-28 22:11:04 --> Config Class Initialized
INFO - 2024-05-28 22:11:04 --> Hooks Class Initialized
DEBUG - 2024-05-28 22:11:04 --> UTF-8 Support Enabled
INFO - 2024-05-28 22:11:04 --> Utf8 Class Initialized
INFO - 2024-05-28 22:11:04 --> URI Class Initialized
DEBUG - 2024-05-28 22:11:04 --> No URI present. Default controller set.
INFO - 2024-05-28 22:11:04 --> Router Class Initialized
INFO - 2024-05-28 22:11:04 --> Output Class Initialized
INFO - 2024-05-28 22:11:04 --> Security Class Initialized
DEBUG - 2024-05-28 22:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 22:11:04 --> Input Class Initialized
INFO - 2024-05-28 22:11:04 --> Language Class Initialized
INFO - 2024-05-28 22:11:04 --> Loader Class Initialized
INFO - 2024-05-28 22:11:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 22:11:04 --> Helper loaded: url_helper
DEBUG - 2024-05-28 22:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 22:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 22:11:04 --> Controller Class Initialized
INFO - 2024-05-28 22:11:06 --> Config Class Initialized
INFO - 2024-05-28 22:11:06 --> Hooks Class Initialized
DEBUG - 2024-05-28 22:11:06 --> UTF-8 Support Enabled
INFO - 2024-05-28 22:11:06 --> Utf8 Class Initialized
INFO - 2024-05-28 22:11:06 --> URI Class Initialized
DEBUG - 2024-05-28 22:11:06 --> No URI present. Default controller set.
INFO - 2024-05-28 22:11:06 --> Router Class Initialized
INFO - 2024-05-28 22:11:06 --> Output Class Initialized
INFO - 2024-05-28 22:11:06 --> Security Class Initialized
DEBUG - 2024-05-28 22:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-28 22:11:06 --> Input Class Initialized
INFO - 2024-05-28 22:11:06 --> Language Class Initialized
INFO - 2024-05-28 22:11:06 --> Loader Class Initialized
INFO - 2024-05-28 22:11:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-28 22:11:06 --> Helper loaded: url_helper
DEBUG - 2024-05-28 22:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-28 22:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-28 22:11:06 --> Controller Class Initialized
