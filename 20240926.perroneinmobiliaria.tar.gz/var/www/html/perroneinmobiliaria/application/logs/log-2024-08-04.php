<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-04 09:19:22 --> Config Class Initialized
INFO - 2024-08-04 09:19:22 --> Hooks Class Initialized
DEBUG - 2024-08-04 09:19:22 --> UTF-8 Support Enabled
INFO - 2024-08-04 09:19:22 --> Utf8 Class Initialized
INFO - 2024-08-04 09:19:22 --> URI Class Initialized
DEBUG - 2024-08-04 09:19:22 --> No URI present. Default controller set.
INFO - 2024-08-04 09:19:22 --> Router Class Initialized
INFO - 2024-08-04 09:19:22 --> Output Class Initialized
INFO - 2024-08-04 09:19:22 --> Security Class Initialized
DEBUG - 2024-08-04 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 09:19:22 --> Input Class Initialized
INFO - 2024-08-04 09:19:22 --> Language Class Initialized
INFO - 2024-08-04 09:19:22 --> Loader Class Initialized
INFO - 2024-08-04 09:19:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-04 09:19:22 --> Helper loaded: url_helper
DEBUG - 2024-08-04 09:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-04 09:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 09:19:22 --> Controller Class Initialized
INFO - 2024-08-04 22:43:39 --> Config Class Initialized
INFO - 2024-08-04 22:43:39 --> Hooks Class Initialized
DEBUG - 2024-08-04 22:43:39 --> UTF-8 Support Enabled
INFO - 2024-08-04 22:43:39 --> Utf8 Class Initialized
INFO - 2024-08-04 22:43:39 --> URI Class Initialized
DEBUG - 2024-08-04 22:43:39 --> No URI present. Default controller set.
INFO - 2024-08-04 22:43:39 --> Router Class Initialized
INFO - 2024-08-04 22:43:39 --> Output Class Initialized
INFO - 2024-08-04 22:43:39 --> Security Class Initialized
DEBUG - 2024-08-04 22:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 22:43:39 --> Input Class Initialized
INFO - 2024-08-04 22:43:39 --> Language Class Initialized
INFO - 2024-08-04 22:43:39 --> Loader Class Initialized
INFO - 2024-08-04 22:43:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-04 22:43:39 --> Helper loaded: url_helper
DEBUG - 2024-08-04 22:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-04 22:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 22:43:39 --> Controller Class Initialized
INFO - 2024-08-04 22:43:42 --> Config Class Initialized
INFO - 2024-08-04 22:43:42 --> Hooks Class Initialized
DEBUG - 2024-08-04 22:43:42 --> UTF-8 Support Enabled
INFO - 2024-08-04 22:43:42 --> Utf8 Class Initialized
INFO - 2024-08-04 22:43:42 --> URI Class Initialized
INFO - 2024-08-04 22:43:42 --> Router Class Initialized
INFO - 2024-08-04 22:43:42 --> Output Class Initialized
INFO - 2024-08-04 22:43:42 --> Security Class Initialized
DEBUG - 2024-08-04 22:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 22:43:42 --> Input Class Initialized
INFO - 2024-08-04 22:43:42 --> Language Class Initialized
INFO - 2024-08-04 22:43:42 --> Loader Class Initialized
INFO - 2024-08-04 22:43:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-04 22:43:42 --> Helper loaded: url_helper
DEBUG - 2024-08-04 22:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-04 22:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 22:43:42 --> Controller Class Initialized
DEBUG - 2024-08-04 22:43:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-04 22:43:42 --> Database Driver Class Initialized
INFO - 2024-08-04 22:43:42 --> Helper loaded: cookie_helper
INFO - 2024-08-04 22:43:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-04 22:43:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-04 22:43:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-04 22:43:42 --> Final output sent to browser
DEBUG - 2024-08-04 22:43:42 --> Total execution time: 0.0422
