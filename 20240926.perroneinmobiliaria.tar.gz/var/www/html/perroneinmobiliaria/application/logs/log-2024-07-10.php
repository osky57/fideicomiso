<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-10 23:56:10 --> Config Class Initialized
INFO - 2024-07-10 23:56:10 --> Hooks Class Initialized
DEBUG - 2024-07-10 23:56:11 --> UTF-8 Support Enabled
INFO - 2024-07-10 23:56:11 --> Utf8 Class Initialized
INFO - 2024-07-10 23:56:11 --> URI Class Initialized
DEBUG - 2024-07-10 23:56:11 --> No URI present. Default controller set.
INFO - 2024-07-10 23:56:11 --> Router Class Initialized
INFO - 2024-07-10 23:56:12 --> Output Class Initialized
INFO - 2024-07-10 23:56:12 --> Security Class Initialized
DEBUG - 2024-07-10 23:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-10 23:56:12 --> Input Class Initialized
INFO - 2024-07-10 23:56:12 --> Language Class Initialized
INFO - 2024-07-10 23:56:13 --> Loader Class Initialized
INFO - 2024-07-10 23:56:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-10 23:56:13 --> Helper loaded: url_helper
DEBUG - 2024-07-10 23:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-10 23:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-10 23:56:14 --> Controller Class Initialized
