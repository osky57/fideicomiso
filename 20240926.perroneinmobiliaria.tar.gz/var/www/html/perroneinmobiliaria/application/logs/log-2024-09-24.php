<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-24 00:14:57 --> Config Class Initialized
INFO - 2024-09-24 00:14:57 --> Hooks Class Initialized
DEBUG - 2024-09-24 00:14:57 --> UTF-8 Support Enabled
INFO - 2024-09-24 00:14:57 --> Utf8 Class Initialized
INFO - 2024-09-24 00:14:57 --> URI Class Initialized
DEBUG - 2024-09-24 00:14:57 --> No URI present. Default controller set.
INFO - 2024-09-24 00:14:57 --> Router Class Initialized
INFO - 2024-09-24 00:14:57 --> Output Class Initialized
INFO - 2024-09-24 00:14:57 --> Security Class Initialized
DEBUG - 2024-09-24 00:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 00:14:57 --> Input Class Initialized
INFO - 2024-09-24 00:14:57 --> Language Class Initialized
INFO - 2024-09-24 00:14:57 --> Loader Class Initialized
INFO - 2024-09-24 00:14:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-24 00:14:57 --> Helper loaded: url_helper
DEBUG - 2024-09-24 00:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-24 00:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 00:14:57 --> Controller Class Initialized
INFO - 2024-09-24 00:21:33 --> Config Class Initialized
INFO - 2024-09-24 00:21:33 --> Hooks Class Initialized
DEBUG - 2024-09-24 00:21:33 --> UTF-8 Support Enabled
INFO - 2024-09-24 00:21:33 --> Utf8 Class Initialized
INFO - 2024-09-24 00:21:33 --> URI Class Initialized
DEBUG - 2024-09-24 00:21:33 --> No URI present. Default controller set.
INFO - 2024-09-24 00:21:33 --> Router Class Initialized
INFO - 2024-09-24 00:21:33 --> Output Class Initialized
INFO - 2024-09-24 00:21:33 --> Security Class Initialized
DEBUG - 2024-09-24 00:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 00:21:33 --> Input Class Initialized
INFO - 2024-09-24 00:21:33 --> Language Class Initialized
INFO - 2024-09-24 00:21:33 --> Loader Class Initialized
INFO - 2024-09-24 00:21:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-24 00:21:33 --> Helper loaded: url_helper
DEBUG - 2024-09-24 00:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-24 00:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 00:21:33 --> Controller Class Initialized
