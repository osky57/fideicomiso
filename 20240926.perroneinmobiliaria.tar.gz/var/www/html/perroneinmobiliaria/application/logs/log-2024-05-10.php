<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-10 07:58:43 --> Config Class Initialized
INFO - 2024-05-10 07:58:43 --> Hooks Class Initialized
DEBUG - 2024-05-10 07:58:43 --> UTF-8 Support Enabled
INFO - 2024-05-10 07:58:43 --> Utf8 Class Initialized
INFO - 2024-05-10 07:58:43 --> URI Class Initialized
DEBUG - 2024-05-10 07:58:43 --> No URI present. Default controller set.
INFO - 2024-05-10 07:58:43 --> Router Class Initialized
INFO - 2024-05-10 07:58:43 --> Output Class Initialized
INFO - 2024-05-10 07:58:43 --> Security Class Initialized
DEBUG - 2024-05-10 07:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 07:58:43 --> Input Class Initialized
INFO - 2024-05-10 07:58:43 --> Language Class Initialized
INFO - 2024-05-10 07:58:43 --> Loader Class Initialized
INFO - 2024-05-10 07:58:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 07:58:43 --> Helper loaded: url_helper
DEBUG - 2024-05-10 07:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 07:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 07:58:43 --> Controller Class Initialized
INFO - 2024-05-10 09:29:23 --> Config Class Initialized
INFO - 2024-05-10 09:29:23 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:23 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:23 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:23 --> URI Class Initialized
INFO - 2024-05-10 09:29:23 --> Router Class Initialized
INFO - 2024-05-10 09:29:23 --> Output Class Initialized
INFO - 2024-05-10 09:29:23 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:23 --> Input Class Initialized
INFO - 2024-05-10 09:29:23 --> Language Class Initialized
INFO - 2024-05-10 09:29:23 --> Loader Class Initialized
INFO - 2024-05-10 09:29:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:23 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:23 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-10 09:29:23 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:23 --> Helper loaded: cookie_helper
INFO - 2024-05-10 09:29:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-10 09:29:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-10 09:29:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-10 09:29:23 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:23 --> Total execution time: 0.0470
INFO - 2024-05-10 09:29:23 --> Config Class Initialized
INFO - 2024-05-10 09:29:23 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:23 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:23 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:23 --> URI Class Initialized
INFO - 2024-05-10 09:29:23 --> Router Class Initialized
INFO - 2024-05-10 09:29:23 --> Output Class Initialized
INFO - 2024-05-10 09:29:23 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:23 --> Input Class Initialized
INFO - 2024-05-10 09:29:23 --> Language Class Initialized
INFO - 2024-05-10 09:29:23 --> Loader Class Initialized
INFO - 2024-05-10 09:29:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:23 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:23 --> Controller Class Initialized
INFO - 2024-05-10 09:29:24 --> Config Class Initialized
INFO - 2024-05-10 09:29:24 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:24 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:24 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:24 --> URI Class Initialized
INFO - 2024-05-10 09:29:24 --> Router Class Initialized
INFO - 2024-05-10 09:29:24 --> Output Class Initialized
INFO - 2024-05-10 09:29:24 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:24 --> Input Class Initialized
INFO - 2024-05-10 09:29:24 --> Language Class Initialized
INFO - 2024-05-10 09:29:24 --> Loader Class Initialized
INFO - 2024-05-10 09:29:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:24 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:24 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-10 09:29:24 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:24 --> Helper loaded: cookie_helper
INFO - 2024-05-10 09:29:24 --> Helper loaded: form_helper
INFO - 2024-05-10 09:29:24 --> Form Validation Class Initialized
INFO - 2024-05-10 09:29:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-10 09:29:25 --> Config Class Initialized
INFO - 2024-05-10 09:29:25 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:25 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:25 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:25 --> URI Class Initialized
INFO - 2024-05-10 09:29:25 --> Router Class Initialized
INFO - 2024-05-10 09:29:25 --> Output Class Initialized
INFO - 2024-05-10 09:29:25 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:25 --> Input Class Initialized
INFO - 2024-05-10 09:29:25 --> Language Class Initialized
INFO - 2024-05-10 09:29:25 --> Loader Class Initialized
INFO - 2024-05-10 09:29:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:25 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:25 --> Controller Class Initialized
INFO - 2024-05-10 09:29:25 --> Database Driver Class Initialized
DEBUG - 2024-05-10 09:29:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-10 09:29:25 --> Helper loaded: cookie_helper
INFO - 2024-05-10 09:29:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-10 09:29:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-10 09:29:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-10 09:29:25 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:25 --> Total execution time: 0.0102
INFO - 2024-05-10 09:29:25 --> Config Class Initialized
INFO - 2024-05-10 09:29:25 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:25 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:25 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:25 --> URI Class Initialized
INFO - 2024-05-10 09:29:25 --> Router Class Initialized
INFO - 2024-05-10 09:29:25 --> Output Class Initialized
INFO - 2024-05-10 09:29:25 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:25 --> Input Class Initialized
INFO - 2024-05-10 09:29:25 --> Language Class Initialized
INFO - 2024-05-10 09:29:25 --> Loader Class Initialized
INFO - 2024-05-10 09:29:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:25 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:25 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:29:25 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:25 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:29:25 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:25 --> Total execution time: 0.0260
INFO - 2024-05-10 09:29:31 --> Config Class Initialized
INFO - 2024-05-10 09:29:31 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:31 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:31 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:31 --> URI Class Initialized
INFO - 2024-05-10 09:29:31 --> Router Class Initialized
INFO - 2024-05-10 09:29:31 --> Output Class Initialized
INFO - 2024-05-10 09:29:31 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:31 --> Input Class Initialized
INFO - 2024-05-10 09:29:31 --> Language Class Initialized
INFO - 2024-05-10 09:29:31 --> Loader Class Initialized
INFO - 2024-05-10 09:29:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:31 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:31 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:29:31 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:31 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:29:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-10 09:29:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-10 09:29:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-10 09:29:31 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:31 --> Total execution time: 0.0166
INFO - 2024-05-10 09:29:32 --> Config Class Initialized
INFO - 2024-05-10 09:29:32 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:32 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:32 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:32 --> URI Class Initialized
INFO - 2024-05-10 09:29:32 --> Router Class Initialized
INFO - 2024-05-10 09:29:32 --> Output Class Initialized
INFO - 2024-05-10 09:29:32 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:32 --> Input Class Initialized
INFO - 2024-05-10 09:29:32 --> Language Class Initialized
INFO - 2024-05-10 09:29:32 --> Loader Class Initialized
INFO - 2024-05-10 09:29:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:32 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:32 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:29:32 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:32 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:29:32 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:32 --> Total execution time: 0.0212
INFO - 2024-05-10 09:29:36 --> Config Class Initialized
INFO - 2024-05-10 09:29:36 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:36 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:36 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:36 --> URI Class Initialized
INFO - 2024-05-10 09:29:36 --> Router Class Initialized
INFO - 2024-05-10 09:29:36 --> Output Class Initialized
INFO - 2024-05-10 09:29:36 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:36 --> Input Class Initialized
INFO - 2024-05-10 09:29:36 --> Language Class Initialized
INFO - 2024-05-10 09:29:36 --> Loader Class Initialized
INFO - 2024-05-10 09:29:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:36 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:36 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:29:36 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:36 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:29:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-10 09:29:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-10 09:29:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-10 09:29:36 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:36 --> Total execution time: 0.0365
INFO - 2024-05-10 09:29:36 --> Config Class Initialized
INFO - 2024-05-10 09:29:36 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:36 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:36 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:36 --> URI Class Initialized
INFO - 2024-05-10 09:29:36 --> Router Class Initialized
INFO - 2024-05-10 09:29:36 --> Output Class Initialized
INFO - 2024-05-10 09:29:36 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:36 --> Input Class Initialized
INFO - 2024-05-10 09:29:36 --> Language Class Initialized
INFO - 2024-05-10 09:29:36 --> Loader Class Initialized
INFO - 2024-05-10 09:29:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:36 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:36 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:29:36 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:36 --> Config Class Initialized
INFO - 2024-05-10 09:29:36 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:36 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:36 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:36 --> URI Class Initialized
INFO - 2024-05-10 09:29:36 --> Router Class Initialized
INFO - 2024-05-10 09:29:36 --> Output Class Initialized
INFO - 2024-05-10 09:29:36 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:36 --> Input Class Initialized
INFO - 2024-05-10 09:29:36 --> Language Class Initialized
INFO - 2024-05-10 09:29:36 --> Loader Class Initialized
INFO - 2024-05-10 09:29:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:36 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:36 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:29:37 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:37 --> Total execution time: 0.0557
INFO - 2024-05-10 09:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:37 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:29:37 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:37 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:29:37 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:37 --> Total execution time: 0.0707
INFO - 2024-05-10 09:29:57 --> Config Class Initialized
INFO - 2024-05-10 09:29:57 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:29:57 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:29:57 --> Utf8 Class Initialized
INFO - 2024-05-10 09:29:57 --> URI Class Initialized
INFO - 2024-05-10 09:29:57 --> Router Class Initialized
INFO - 2024-05-10 09:29:57 --> Output Class Initialized
INFO - 2024-05-10 09:29:57 --> Security Class Initialized
DEBUG - 2024-05-10 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:29:57 --> Input Class Initialized
INFO - 2024-05-10 09:29:57 --> Language Class Initialized
INFO - 2024-05-10 09:29:57 --> Loader Class Initialized
INFO - 2024-05-10 09:29:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:29:57 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:29:57 --> Controller Class Initialized
DEBUG - 2024-05-10 09:29:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:29:57 --> Database Driver Class Initialized
INFO - 2024-05-10 09:29:57 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:29:57 --> Final output sent to browser
DEBUG - 2024-05-10 09:29:57 --> Total execution time: 0.0390
INFO - 2024-05-10 09:30:00 --> Config Class Initialized
INFO - 2024-05-10 09:30:00 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:00 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:00 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:00 --> URI Class Initialized
INFO - 2024-05-10 09:30:00 --> Router Class Initialized
INFO - 2024-05-10 09:30:00 --> Output Class Initialized
INFO - 2024-05-10 09:30:00 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:00 --> Input Class Initialized
INFO - 2024-05-10 09:30:00 --> Language Class Initialized
INFO - 2024-05-10 09:30:00 --> Loader Class Initialized
INFO - 2024-05-10 09:30:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:00 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:00 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:00 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:00 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:00 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:00 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-10 09:30:00 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:00 --> Total execution time: 0.0638
INFO - 2024-05-10 09:30:01 --> Config Class Initialized
INFO - 2024-05-10 09:30:01 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:01 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:01 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:01 --> URI Class Initialized
INFO - 2024-05-10 09:30:01 --> Router Class Initialized
INFO - 2024-05-10 09:30:01 --> Output Class Initialized
INFO - 2024-05-10 09:30:01 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:01 --> Input Class Initialized
INFO - 2024-05-10 09:30:01 --> Language Class Initialized
INFO - 2024-05-10 09:30:01 --> Loader Class Initialized
INFO - 2024-05-10 09:30:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:01 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:01 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:01 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:01 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:01 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:01 --> Total execution time: 0.0274
INFO - 2024-05-10 09:30:01 --> Config Class Initialized
INFO - 2024-05-10 09:30:01 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:01 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:01 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:01 --> URI Class Initialized
INFO - 2024-05-10 09:30:01 --> Router Class Initialized
INFO - 2024-05-10 09:30:01 --> Output Class Initialized
INFO - 2024-05-10 09:30:01 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:01 --> Input Class Initialized
INFO - 2024-05-10 09:30:01 --> Language Class Initialized
INFO - 2024-05-10 09:30:01 --> Loader Class Initialized
INFO - 2024-05-10 09:30:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:01 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:01 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:01 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:01 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:01 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:01 --> Total execution time: 0.0308
INFO - 2024-05-10 09:30:01 --> Config Class Initialized
INFO - 2024-05-10 09:30:01 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:01 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:01 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:01 --> URI Class Initialized
INFO - 2024-05-10 09:30:01 --> Router Class Initialized
INFO - 2024-05-10 09:30:01 --> Output Class Initialized
INFO - 2024-05-10 09:30:01 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:01 --> Input Class Initialized
INFO - 2024-05-10 09:30:01 --> Language Class Initialized
INFO - 2024-05-10 09:30:01 --> Loader Class Initialized
INFO - 2024-05-10 09:30:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:01 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:01 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:01 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:01 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:01 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:01 --> Total execution time: 0.0417
INFO - 2024-05-10 09:30:02 --> Config Class Initialized
INFO - 2024-05-10 09:30:02 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:02 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:02 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:02 --> URI Class Initialized
INFO - 2024-05-10 09:30:02 --> Router Class Initialized
INFO - 2024-05-10 09:30:02 --> Output Class Initialized
INFO - 2024-05-10 09:30:02 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:02 --> Input Class Initialized
INFO - 2024-05-10 09:30:02 --> Language Class Initialized
INFO - 2024-05-10 09:30:02 --> Loader Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:02 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:02 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:02 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:02 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:02 --> Total execution time: 0.0271
INFO - 2024-05-10 09:30:02 --> Config Class Initialized
INFO - 2024-05-10 09:30:02 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:02 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:02 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:02 --> URI Class Initialized
INFO - 2024-05-10 09:30:02 --> Router Class Initialized
INFO - 2024-05-10 09:30:02 --> Output Class Initialized
INFO - 2024-05-10 09:30:02 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:02 --> Input Class Initialized
INFO - 2024-05-10 09:30:02 --> Language Class Initialized
INFO - 2024-05-10 09:30:02 --> Loader Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:02 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:02 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:02 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:02 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:02 --> Total execution time: 0.0267
INFO - 2024-05-10 09:30:02 --> Config Class Initialized
INFO - 2024-05-10 09:30:02 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:02 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:02 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:02 --> URI Class Initialized
INFO - 2024-05-10 09:30:02 --> Router Class Initialized
INFO - 2024-05-10 09:30:02 --> Output Class Initialized
INFO - 2024-05-10 09:30:02 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:02 --> Input Class Initialized
INFO - 2024-05-10 09:30:02 --> Language Class Initialized
INFO - 2024-05-10 09:30:02 --> Loader Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:02 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:02 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:02 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:02 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:02 --> Total execution time: 0.0304
INFO - 2024-05-10 09:30:02 --> Config Class Initialized
INFO - 2024-05-10 09:30:02 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:02 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:02 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:02 --> URI Class Initialized
INFO - 2024-05-10 09:30:02 --> Router Class Initialized
INFO - 2024-05-10 09:30:02 --> Output Class Initialized
INFO - 2024-05-10 09:30:02 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:02 --> Input Class Initialized
INFO - 2024-05-10 09:30:02 --> Language Class Initialized
INFO - 2024-05-10 09:30:02 --> Loader Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:02 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:02 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:02 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:02 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:02 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:02 --> Total execution time: 0.0309
INFO - 2024-05-10 09:30:06 --> Config Class Initialized
INFO - 2024-05-10 09:30:06 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:06 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:06 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:06 --> URI Class Initialized
INFO - 2024-05-10 09:30:06 --> Router Class Initialized
INFO - 2024-05-10 09:30:06 --> Output Class Initialized
INFO - 2024-05-10 09:30:06 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:06 --> Input Class Initialized
INFO - 2024-05-10 09:30:06 --> Language Class Initialized
INFO - 2024-05-10 09:30:06 --> Loader Class Initialized
INFO - 2024-05-10 09:30:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:06 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:06 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:06 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:06 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:06 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:06 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:06 --> Total execution time: 0.0330
INFO - 2024-05-10 09:30:32 --> Config Class Initialized
INFO - 2024-05-10 09:30:32 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:32 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:32 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:32 --> URI Class Initialized
INFO - 2024-05-10 09:30:32 --> Router Class Initialized
INFO - 2024-05-10 09:30:32 --> Output Class Initialized
INFO - 2024-05-10 09:30:32 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:32 --> Input Class Initialized
INFO - 2024-05-10 09:30:32 --> Language Class Initialized
INFO - 2024-05-10 09:30:32 --> Loader Class Initialized
INFO - 2024-05-10 09:30:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:32 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:32 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:32 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:32 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-10 09:30:32 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:32 --> Total execution time: 0.4109
INFO - 2024-05-10 09:30:33 --> Config Class Initialized
INFO - 2024-05-10 09:30:33 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:33 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:33 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:33 --> URI Class Initialized
INFO - 2024-05-10 09:30:33 --> Router Class Initialized
INFO - 2024-05-10 09:30:33 --> Output Class Initialized
INFO - 2024-05-10 09:30:33 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:33 --> Input Class Initialized
INFO - 2024-05-10 09:30:33 --> Language Class Initialized
INFO - 2024-05-10 09:30:33 --> Loader Class Initialized
INFO - 2024-05-10 09:30:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:33 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:33 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:33 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:33 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:33 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:33 --> Total execution time: 0.0552
INFO - 2024-05-10 09:30:37 --> Config Class Initialized
INFO - 2024-05-10 09:30:37 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:37 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:37 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:37 --> URI Class Initialized
INFO - 2024-05-10 09:30:37 --> Router Class Initialized
INFO - 2024-05-10 09:30:37 --> Output Class Initialized
INFO - 2024-05-10 09:30:37 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:37 --> Input Class Initialized
INFO - 2024-05-10 09:30:37 --> Language Class Initialized
INFO - 2024-05-10 09:30:37 --> Loader Class Initialized
INFO - 2024-05-10 09:30:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:37 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:37 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:37 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:37 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:38 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:38 --> Total execution time: 0.0447
INFO - 2024-05-10 09:30:39 --> Config Class Initialized
INFO - 2024-05-10 09:30:39 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:39 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:39 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:39 --> URI Class Initialized
INFO - 2024-05-10 09:30:39 --> Router Class Initialized
INFO - 2024-05-10 09:30:39 --> Output Class Initialized
INFO - 2024-05-10 09:30:39 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:39 --> Input Class Initialized
INFO - 2024-05-10 09:30:39 --> Language Class Initialized
INFO - 2024-05-10 09:30:39 --> Loader Class Initialized
INFO - 2024-05-10 09:30:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:39 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:39 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:39 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:39 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-10 09:30:39 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:39 --> Total execution time: 0.0650
INFO - 2024-05-10 09:30:39 --> Config Class Initialized
INFO - 2024-05-10 09:30:39 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:39 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:39 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:39 --> URI Class Initialized
INFO - 2024-05-10 09:30:39 --> Router Class Initialized
INFO - 2024-05-10 09:30:39 --> Output Class Initialized
INFO - 2024-05-10 09:30:39 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:39 --> Input Class Initialized
INFO - 2024-05-10 09:30:39 --> Language Class Initialized
INFO - 2024-05-10 09:30:39 --> Loader Class Initialized
INFO - 2024-05-10 09:30:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:39 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:39 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:39 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:39 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:39 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:39 --> Total execution time: 0.0166
INFO - 2024-05-10 09:30:40 --> Config Class Initialized
INFO - 2024-05-10 09:30:40 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:40 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:40 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:40 --> URI Class Initialized
INFO - 2024-05-10 09:30:40 --> Router Class Initialized
INFO - 2024-05-10 09:30:40 --> Output Class Initialized
INFO - 2024-05-10 09:30:40 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:40 --> Input Class Initialized
INFO - 2024-05-10 09:30:40 --> Language Class Initialized
INFO - 2024-05-10 09:30:40 --> Loader Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:40 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:40 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:40 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:40 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:40 --> Total execution time: 0.0170
INFO - 2024-05-10 09:30:40 --> Config Class Initialized
INFO - 2024-05-10 09:30:40 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:40 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:40 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:40 --> URI Class Initialized
INFO - 2024-05-10 09:30:40 --> Router Class Initialized
INFO - 2024-05-10 09:30:40 --> Output Class Initialized
INFO - 2024-05-10 09:30:40 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:40 --> Input Class Initialized
INFO - 2024-05-10 09:30:40 --> Language Class Initialized
INFO - 2024-05-10 09:30:40 --> Loader Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:40 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:40 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:40 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:40 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:40 --> Total execution time: 0.0246
INFO - 2024-05-10 09:30:40 --> Config Class Initialized
INFO - 2024-05-10 09:30:40 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:40 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:40 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:40 --> URI Class Initialized
INFO - 2024-05-10 09:30:40 --> Router Class Initialized
INFO - 2024-05-10 09:30:40 --> Output Class Initialized
INFO - 2024-05-10 09:30:40 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:40 --> Input Class Initialized
INFO - 2024-05-10 09:30:40 --> Language Class Initialized
INFO - 2024-05-10 09:30:40 --> Loader Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:40 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:40 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:40 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:40 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:40 --> Total execution time: 0.0169
INFO - 2024-05-10 09:30:40 --> Config Class Initialized
INFO - 2024-05-10 09:30:40 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:40 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:40 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:40 --> URI Class Initialized
INFO - 2024-05-10 09:30:40 --> Router Class Initialized
INFO - 2024-05-10 09:30:40 --> Output Class Initialized
INFO - 2024-05-10 09:30:40 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:40 --> Input Class Initialized
INFO - 2024-05-10 09:30:40 --> Language Class Initialized
INFO - 2024-05-10 09:30:40 --> Loader Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:40 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:40 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:40 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:40 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:40 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:40 --> Total execution time: 0.0224
INFO - 2024-05-10 09:30:41 --> Config Class Initialized
INFO - 2024-05-10 09:30:41 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:41 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:41 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:41 --> URI Class Initialized
INFO - 2024-05-10 09:30:41 --> Router Class Initialized
INFO - 2024-05-10 09:30:41 --> Output Class Initialized
INFO - 2024-05-10 09:30:41 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:41 --> Input Class Initialized
INFO - 2024-05-10 09:30:41 --> Language Class Initialized
INFO - 2024-05-10 09:30:41 --> Loader Class Initialized
INFO - 2024-05-10 09:30:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:41 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:41 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:41 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:41 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:41 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:41 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:41 --> Total execution time: 0.0193
INFO - 2024-05-10 09:30:41 --> Config Class Initialized
INFO - 2024-05-10 09:30:41 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:41 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:41 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:41 --> URI Class Initialized
INFO - 2024-05-10 09:30:41 --> Router Class Initialized
INFO - 2024-05-10 09:30:41 --> Output Class Initialized
INFO - 2024-05-10 09:30:41 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:41 --> Input Class Initialized
INFO - 2024-05-10 09:30:41 --> Language Class Initialized
INFO - 2024-05-10 09:30:41 --> Loader Class Initialized
INFO - 2024-05-10 09:30:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:41 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:41 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:41 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:41 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:41 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:41 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:41 --> Total execution time: 0.0172
INFO - 2024-05-10 09:30:43 --> Config Class Initialized
INFO - 2024-05-10 09:30:43 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:30:43 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:30:43 --> Utf8 Class Initialized
INFO - 2024-05-10 09:30:43 --> URI Class Initialized
INFO - 2024-05-10 09:30:43 --> Router Class Initialized
INFO - 2024-05-10 09:30:43 --> Output Class Initialized
INFO - 2024-05-10 09:30:43 --> Security Class Initialized
DEBUG - 2024-05-10 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:30:43 --> Input Class Initialized
INFO - 2024-05-10 09:30:43 --> Language Class Initialized
INFO - 2024-05-10 09:30:43 --> Loader Class Initialized
INFO - 2024-05-10 09:30:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:30:43 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:30:43 --> Controller Class Initialized
DEBUG - 2024-05-10 09:30:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:30:43 --> Database Driver Class Initialized
INFO - 2024-05-10 09:30:43 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:30:43 --> Final output sent to browser
DEBUG - 2024-05-10 09:30:43 --> Total execution time: 0.0186
INFO - 2024-05-10 09:31:10 --> Config Class Initialized
INFO - 2024-05-10 09:31:10 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:31:10 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:31:10 --> Utf8 Class Initialized
INFO - 2024-05-10 09:31:10 --> URI Class Initialized
INFO - 2024-05-10 09:31:10 --> Router Class Initialized
INFO - 2024-05-10 09:31:10 --> Output Class Initialized
INFO - 2024-05-10 09:31:10 --> Security Class Initialized
DEBUG - 2024-05-10 09:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:31:10 --> Input Class Initialized
INFO - 2024-05-10 09:31:10 --> Language Class Initialized
INFO - 2024-05-10 09:31:10 --> Loader Class Initialized
INFO - 2024-05-10 09:31:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:31:10 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:31:10 --> Controller Class Initialized
DEBUG - 2024-05-10 09:31:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:31:10 --> Database Driver Class Initialized
INFO - 2024-05-10 09:31:10 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:31:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-10 09:31:10 --> Final output sent to browser
DEBUG - 2024-05-10 09:31:10 --> Total execution time: 0.2323
INFO - 2024-05-10 09:31:10 --> Config Class Initialized
INFO - 2024-05-10 09:31:10 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:31:10 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:31:10 --> Utf8 Class Initialized
INFO - 2024-05-10 09:31:10 --> URI Class Initialized
INFO - 2024-05-10 09:31:10 --> Router Class Initialized
INFO - 2024-05-10 09:31:10 --> Output Class Initialized
INFO - 2024-05-10 09:31:10 --> Security Class Initialized
DEBUG - 2024-05-10 09:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:31:10 --> Input Class Initialized
INFO - 2024-05-10 09:31:10 --> Language Class Initialized
INFO - 2024-05-10 09:31:10 --> Loader Class Initialized
INFO - 2024-05-10 09:31:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:31:10 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:31:10 --> Controller Class Initialized
DEBUG - 2024-05-10 09:31:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:31:10 --> Database Driver Class Initialized
INFO - 2024-05-10 09:31:10 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:31:10 --> Final output sent to browser
DEBUG - 2024-05-10 09:31:10 --> Total execution time: 0.0506
INFO - 2024-05-10 09:53:23 --> Config Class Initialized
INFO - 2024-05-10 09:53:23 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:23 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:23 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:23 --> URI Class Initialized
INFO - 2024-05-10 09:53:23 --> Router Class Initialized
INFO - 2024-05-10 09:53:23 --> Output Class Initialized
INFO - 2024-05-10 09:53:23 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:23 --> Input Class Initialized
INFO - 2024-05-10 09:53:23 --> Language Class Initialized
INFO - 2024-05-10 09:53:23 --> Loader Class Initialized
INFO - 2024-05-10 09:53:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:23 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:23 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:53:23 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:23 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-10 09:53:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-10 09:53:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-10 09:53:23 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:23 --> Total execution time: 0.0177
INFO - 2024-05-10 09:53:23 --> Config Class Initialized
INFO - 2024-05-10 09:53:23 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:23 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:23 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:23 --> URI Class Initialized
INFO - 2024-05-10 09:53:23 --> Router Class Initialized
INFO - 2024-05-10 09:53:23 --> Output Class Initialized
INFO - 2024-05-10 09:53:23 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:23 --> Input Class Initialized
INFO - 2024-05-10 09:53:23 --> Language Class Initialized
INFO - 2024-05-10 09:53:23 --> Loader Class Initialized
INFO - 2024-05-10 09:53:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:23 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:23 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:53:23 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:23 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:23 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:23 --> Total execution time: 0.0206
INFO - 2024-05-10 09:53:26 --> Config Class Initialized
INFO - 2024-05-10 09:53:26 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:26 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:26 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:26 --> URI Class Initialized
INFO - 2024-05-10 09:53:26 --> Router Class Initialized
INFO - 2024-05-10 09:53:26 --> Output Class Initialized
INFO - 2024-05-10 09:53:26 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:26 --> Input Class Initialized
INFO - 2024-05-10 09:53:26 --> Language Class Initialized
INFO - 2024-05-10 09:53:26 --> Loader Class Initialized
INFO - 2024-05-10 09:53:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:26 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:26 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:53:26 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:26 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-10 09:53:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-10 09:53:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-10 09:53:26 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:26 --> Total execution time: 0.0131
INFO - 2024-05-10 09:53:27 --> Config Class Initialized
INFO - 2024-05-10 09:53:27 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:27 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:27 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:27 --> URI Class Initialized
INFO - 2024-05-10 09:53:27 --> Router Class Initialized
INFO - 2024-05-10 09:53:27 --> Output Class Initialized
INFO - 2024-05-10 09:53:27 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:27 --> Input Class Initialized
INFO - 2024-05-10 09:53:27 --> Language Class Initialized
INFO - 2024-05-10 09:53:27 --> Loader Class Initialized
INFO - 2024-05-10 09:53:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:27 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:27 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:27 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:53:27 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:27 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:27 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:27 --> Total execution time: 0.0260
INFO - 2024-05-10 09:53:30 --> Config Class Initialized
INFO - 2024-05-10 09:53:30 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:30 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:30 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:30 --> URI Class Initialized
INFO - 2024-05-10 09:53:30 --> Router Class Initialized
INFO - 2024-05-10 09:53:30 --> Output Class Initialized
INFO - 2024-05-10 09:53:30 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:30 --> Input Class Initialized
INFO - 2024-05-10 09:53:30 --> Language Class Initialized
INFO - 2024-05-10 09:53:30 --> Loader Class Initialized
INFO - 2024-05-10 09:53:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:30 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:30 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:30 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:53:30 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:30 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:30 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-10 09:53:30 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-10 09:53:30 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-10 09:53:30 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:30 --> Total execution time: 0.0496
INFO - 2024-05-10 09:53:30 --> Config Class Initialized
INFO - 2024-05-10 09:53:30 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:30 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:30 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:30 --> URI Class Initialized
INFO - 2024-05-10 09:53:30 --> Router Class Initialized
INFO - 2024-05-10 09:53:30 --> Output Class Initialized
INFO - 2024-05-10 09:53:30 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:30 --> Input Class Initialized
INFO - 2024-05-10 09:53:30 --> Language Class Initialized
INFO - 2024-05-10 09:53:30 --> Loader Class Initialized
INFO - 2024-05-10 09:53:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:30 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:30 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:30 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:53:30 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:30 --> Config Class Initialized
INFO - 2024-05-10 09:53:30 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:30 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:30 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:30 --> URI Class Initialized
INFO - 2024-05-10 09:53:30 --> Router Class Initialized
INFO - 2024-05-10 09:53:30 --> Output Class Initialized
INFO - 2024-05-10 09:53:30 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:30 --> Input Class Initialized
INFO - 2024-05-10 09:53:30 --> Language Class Initialized
INFO - 2024-05-10 09:53:30 --> Loader Class Initialized
INFO - 2024-05-10 09:53:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:30 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:30 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:30 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:30 --> Total execution time: 0.0996
INFO - 2024-05-10 09:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:30 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:30 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-10 09:53:30 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:30 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:30 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:30 --> Total execution time: 0.1254
INFO - 2024-05-10 09:53:40 --> Config Class Initialized
INFO - 2024-05-10 09:53:40 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:40 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:40 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:40 --> URI Class Initialized
INFO - 2024-05-10 09:53:40 --> Router Class Initialized
INFO - 2024-05-10 09:53:40 --> Output Class Initialized
INFO - 2024-05-10 09:53:40 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:40 --> Input Class Initialized
INFO - 2024-05-10 09:53:40 --> Language Class Initialized
INFO - 2024-05-10 09:53:40 --> Loader Class Initialized
INFO - 2024-05-10 09:53:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:40 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:40 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:53:40 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:40 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:40 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:40 --> Total execution time: 0.0668
INFO - 2024-05-10 09:53:42 --> Config Class Initialized
INFO - 2024-05-10 09:53:42 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:42 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:42 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:42 --> URI Class Initialized
INFO - 2024-05-10 09:53:42 --> Router Class Initialized
INFO - 2024-05-10 09:53:42 --> Output Class Initialized
INFO - 2024-05-10 09:53:42 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:42 --> Input Class Initialized
INFO - 2024-05-10 09:53:42 --> Language Class Initialized
INFO - 2024-05-10 09:53:42 --> Loader Class Initialized
INFO - 2024-05-10 09:53:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:42 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:42 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:53:42 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:42 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-10 09:53:42 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:42 --> Total execution time: 0.0795
INFO - 2024-05-10 09:53:42 --> Config Class Initialized
INFO - 2024-05-10 09:53:42 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:42 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:42 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:42 --> URI Class Initialized
INFO - 2024-05-10 09:53:42 --> Router Class Initialized
INFO - 2024-05-10 09:53:42 --> Output Class Initialized
INFO - 2024-05-10 09:53:42 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:42 --> Input Class Initialized
INFO - 2024-05-10 09:53:42 --> Language Class Initialized
INFO - 2024-05-10 09:53:42 --> Loader Class Initialized
INFO - 2024-05-10 09:53:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:42 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:42 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:53:42 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:42 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:42 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:42 --> Total execution time: 0.0226
INFO - 2024-05-10 09:53:42 --> Config Class Initialized
INFO - 2024-05-10 09:53:42 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:53:42 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:53:42 --> Utf8 Class Initialized
INFO - 2024-05-10 09:53:42 --> URI Class Initialized
INFO - 2024-05-10 09:53:42 --> Router Class Initialized
INFO - 2024-05-10 09:53:42 --> Output Class Initialized
INFO - 2024-05-10 09:53:42 --> Security Class Initialized
DEBUG - 2024-05-10 09:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:53:42 --> Input Class Initialized
INFO - 2024-05-10 09:53:42 --> Language Class Initialized
INFO - 2024-05-10 09:53:42 --> Loader Class Initialized
INFO - 2024-05-10 09:53:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:53:42 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:53:42 --> Controller Class Initialized
DEBUG - 2024-05-10 09:53:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:53:42 --> Database Driver Class Initialized
INFO - 2024-05-10 09:53:42 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:53:42 --> Final output sent to browser
DEBUG - 2024-05-10 09:53:42 --> Total execution time: 0.0235
INFO - 2024-05-10 09:55:00 --> Config Class Initialized
INFO - 2024-05-10 09:55:00 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:00 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:00 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:00 --> URI Class Initialized
INFO - 2024-05-10 09:55:00 --> Router Class Initialized
INFO - 2024-05-10 09:55:00 --> Output Class Initialized
INFO - 2024-05-10 09:55:00 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:00 --> Input Class Initialized
INFO - 2024-05-10 09:55:00 --> Language Class Initialized
INFO - 2024-05-10 09:55:00 --> Loader Class Initialized
INFO - 2024-05-10 09:55:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:00 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:00 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:00 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:00 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:00 --> Helper loaded: funciones_helper
ERROR - 2024-05-10 09:55:00 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;c&quot;
LINE 6:     AND docu_sucu  = 1c
                              ^ /var/www/html/perroneinmobiliaria/system/database/drivers/postgre/postgre_driver.php 242
ERROR - 2024-05-10 09:55:00 --> Query error: ERROR:  syntax error at or near "c"
LINE 6:     AND docu_sucu  = 1c
                              ^ - Invalid query: SELECT COUNT(*) AS nreg FROM cuentas_corrientes
		WHERE estado = 0
		  AND tipo_comprobante_id = 1
		  AND entidad_id = 89
		  AND docu_letra = 'c'
		  AND docu_sucu  = 1c
		  AND docu_nume  = 410
ERROR - 2024-05-10 09:55:00 --> Severity: error --> Exception: Call to a member function result() on bool /var/www/html/perroneinmobiliaria/application/models/Cuentascorrientes_model.php 903
INFO - 2024-05-10 09:55:08 --> Config Class Initialized
INFO - 2024-05-10 09:55:08 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:08 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:08 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:08 --> URI Class Initialized
INFO - 2024-05-10 09:55:08 --> Router Class Initialized
INFO - 2024-05-10 09:55:08 --> Output Class Initialized
INFO - 2024-05-10 09:55:08 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:08 --> Input Class Initialized
INFO - 2024-05-10 09:55:08 --> Language Class Initialized
INFO - 2024-05-10 09:55:08 --> Loader Class Initialized
INFO - 2024-05-10 09:55:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:08 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:08 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:08 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:08 --> Helper loaded: funciones_helper
ERROR - 2024-05-10 09:55:08 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;c&quot;
LINE 6:     AND docu_sucu  = 1c
                              ^ /var/www/html/perroneinmobiliaria/system/database/drivers/postgre/postgre_driver.php 242
ERROR - 2024-05-10 09:55:08 --> Query error: ERROR:  syntax error at or near "c"
LINE 6:     AND docu_sucu  = 1c
                              ^ - Invalid query: SELECT COUNT(*) AS nreg FROM cuentas_corrientes
		WHERE estado = 0
		  AND tipo_comprobante_id = 1
		  AND entidad_id = 89
		  AND docu_letra = 'c'
		  AND docu_sucu  = 1c
		  AND docu_nume  = 410
ERROR - 2024-05-10 09:55:08 --> Severity: error --> Exception: Call to a member function result() on bool /var/www/html/perroneinmobiliaria/application/models/Cuentascorrientes_model.php 903
INFO - 2024-05-10 09:55:08 --> Config Class Initialized
INFO - 2024-05-10 09:55:08 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:08 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:08 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:08 --> URI Class Initialized
INFO - 2024-05-10 09:55:08 --> Router Class Initialized
INFO - 2024-05-10 09:55:08 --> Output Class Initialized
INFO - 2024-05-10 09:55:08 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:08 --> Input Class Initialized
INFO - 2024-05-10 09:55:08 --> Language Class Initialized
INFO - 2024-05-10 09:55:08 --> Loader Class Initialized
INFO - 2024-05-10 09:55:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:08 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:08 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:08 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:08 --> Helper loaded: funciones_helper
ERROR - 2024-05-10 09:55:08 --> Severity: Warning --> pg_query(): Query failed: ERROR:  invalid input syntax for type integer: &quot;1c&quot;
LINE 1: ..., '1', 0, '1040', 'fc honorarios', '3', '2', 'c', '1c', '410...
                                                             ^ /var/www/html/perroneinmobiliaria/system/database/drivers/postgre/postgre_driver.php 242
ERROR - 2024-05-10 09:55:08 --> Query error: ERROR:  invalid input syntax for type integer: "1c"
LINE 1: ..., '1', 0, '1040', 'fc honorarios', '3', '2', 'c', '1c', '410...
                                                             ^ - Invalid query: INSERT INTO "cuentas_corrientes" ("tipo_comprobante_id", "fecha", "entidad_id", "detalle_proyecto_tipo_propiedad_id", "importe", "moneda_id", "cotizacion_divisa", "importe_divisa", "comentario", "proyecto_id", "usuario_id", "docu_letra", "docu_sucu", "docu_nume", "proyecto_origen_id", "numero", "id") VALUES ('1', '2024-05-10', '89', NULL, '500000', '1', 0, '1040', 'fc honorarios', '3', '2', 'c', '1c', '410', '3', '83', '808')
INFO - 2024-05-10 09:55:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-10 09:55:08 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:08 --> Total execution time: 0.0835
INFO - 2024-05-10 09:55:09 --> Config Class Initialized
INFO - 2024-05-10 09:55:09 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:09 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:09 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:09 --> URI Class Initialized
INFO - 2024-05-10 09:55:09 --> Router Class Initialized
INFO - 2024-05-10 09:55:09 --> Output Class Initialized
INFO - 2024-05-10 09:55:09 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:09 --> Input Class Initialized
INFO - 2024-05-10 09:55:09 --> Language Class Initialized
INFO - 2024-05-10 09:55:09 --> Loader Class Initialized
INFO - 2024-05-10 09:55:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:09 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:09 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:09 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:09 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:09 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:09 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:09 --> Total execution time: 0.0555
INFO - 2024-05-10 09:55:12 --> Config Class Initialized
INFO - 2024-05-10 09:55:12 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:12 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:12 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:12 --> URI Class Initialized
INFO - 2024-05-10 09:55:12 --> Router Class Initialized
INFO - 2024-05-10 09:55:12 --> Output Class Initialized
INFO - 2024-05-10 09:55:12 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:12 --> Input Class Initialized
INFO - 2024-05-10 09:55:12 --> Language Class Initialized
INFO - 2024-05-10 09:55:12 --> Loader Class Initialized
INFO - 2024-05-10 09:55:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:12 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:12 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:12 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:12 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:12 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:12 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-10 09:55:12 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:12 --> Total execution time: 0.0650
INFO - 2024-05-10 09:55:12 --> Config Class Initialized
INFO - 2024-05-10 09:55:12 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:12 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:12 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:12 --> URI Class Initialized
INFO - 2024-05-10 09:55:12 --> Router Class Initialized
INFO - 2024-05-10 09:55:12 --> Output Class Initialized
INFO - 2024-05-10 09:55:12 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:12 --> Input Class Initialized
INFO - 2024-05-10 09:55:12 --> Language Class Initialized
INFO - 2024-05-10 09:55:12 --> Loader Class Initialized
INFO - 2024-05-10 09:55:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:12 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:12 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:12 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:12 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:12 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:12 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:12 --> Total execution time: 0.0210
INFO - 2024-05-10 09:55:12 --> Config Class Initialized
INFO - 2024-05-10 09:55:12 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:12 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:12 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:12 --> URI Class Initialized
INFO - 2024-05-10 09:55:12 --> Router Class Initialized
INFO - 2024-05-10 09:55:12 --> Output Class Initialized
INFO - 2024-05-10 09:55:12 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:12 --> Input Class Initialized
INFO - 2024-05-10 09:55:12 --> Language Class Initialized
INFO - 2024-05-10 09:55:12 --> Loader Class Initialized
INFO - 2024-05-10 09:55:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:12 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:12 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:12 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:12 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:12 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:12 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:12 --> Total execution time: 0.0210
INFO - 2024-05-10 09:55:23 --> Config Class Initialized
INFO - 2024-05-10 09:55:23 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:23 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:23 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:23 --> URI Class Initialized
INFO - 2024-05-10 09:55:23 --> Router Class Initialized
INFO - 2024-05-10 09:55:23 --> Output Class Initialized
INFO - 2024-05-10 09:55:23 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:23 --> Input Class Initialized
INFO - 2024-05-10 09:55:23 --> Language Class Initialized
INFO - 2024-05-10 09:55:23 --> Loader Class Initialized
INFO - 2024-05-10 09:55:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:23 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:23 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:23 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:23 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:23 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:23 --> Total execution time: 0.0375
INFO - 2024-05-10 09:55:57 --> Config Class Initialized
INFO - 2024-05-10 09:55:57 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:57 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:57 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:57 --> URI Class Initialized
INFO - 2024-05-10 09:55:57 --> Router Class Initialized
INFO - 2024-05-10 09:55:57 --> Output Class Initialized
INFO - 2024-05-10 09:55:57 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:57 --> Input Class Initialized
INFO - 2024-05-10 09:55:57 --> Language Class Initialized
INFO - 2024-05-10 09:55:57 --> Loader Class Initialized
INFO - 2024-05-10 09:55:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:57 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:57 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:57 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:57 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-10 09:55:57 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:57 --> Total execution time: 0.0660
INFO - 2024-05-10 09:55:57 --> Config Class Initialized
INFO - 2024-05-10 09:55:57 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:57 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:57 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:57 --> URI Class Initialized
INFO - 2024-05-10 09:55:57 --> Router Class Initialized
INFO - 2024-05-10 09:55:57 --> Output Class Initialized
INFO - 2024-05-10 09:55:57 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:57 --> Input Class Initialized
INFO - 2024-05-10 09:55:57 --> Language Class Initialized
INFO - 2024-05-10 09:55:57 --> Loader Class Initialized
INFO - 2024-05-10 09:55:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:57 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:57 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:57 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:57 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:57 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:57 --> Total execution time: 0.0151
INFO - 2024-05-10 09:55:57 --> Config Class Initialized
INFO - 2024-05-10 09:55:57 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:55:57 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:55:57 --> Utf8 Class Initialized
INFO - 2024-05-10 09:55:57 --> URI Class Initialized
INFO - 2024-05-10 09:55:57 --> Router Class Initialized
INFO - 2024-05-10 09:55:57 --> Output Class Initialized
INFO - 2024-05-10 09:55:57 --> Security Class Initialized
DEBUG - 2024-05-10 09:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:55:57 --> Input Class Initialized
INFO - 2024-05-10 09:55:57 --> Language Class Initialized
INFO - 2024-05-10 09:55:57 --> Loader Class Initialized
INFO - 2024-05-10 09:55:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:55:57 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:55:57 --> Controller Class Initialized
DEBUG - 2024-05-10 09:55:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:55:57 --> Database Driver Class Initialized
INFO - 2024-05-10 09:55:57 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:55:57 --> Final output sent to browser
DEBUG - 2024-05-10 09:55:57 --> Total execution time: 0.0150
INFO - 2024-05-10 09:56:00 --> Config Class Initialized
INFO - 2024-05-10 09:56:00 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:56:00 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:56:00 --> Utf8 Class Initialized
INFO - 2024-05-10 09:56:00 --> URI Class Initialized
INFO - 2024-05-10 09:56:00 --> Router Class Initialized
INFO - 2024-05-10 09:56:00 --> Output Class Initialized
INFO - 2024-05-10 09:56:00 --> Security Class Initialized
DEBUG - 2024-05-10 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:56:00 --> Input Class Initialized
INFO - 2024-05-10 09:56:00 --> Language Class Initialized
INFO - 2024-05-10 09:56:00 --> Loader Class Initialized
INFO - 2024-05-10 09:56:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:56:00 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:56:00 --> Controller Class Initialized
DEBUG - 2024-05-10 09:56:00 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:56:00 --> Database Driver Class Initialized
INFO - 2024-05-10 09:56:00 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:56:00 --> Final output sent to browser
DEBUG - 2024-05-10 09:56:00 --> Total execution time: 0.0354
INFO - 2024-05-10 09:56:14 --> Config Class Initialized
INFO - 2024-05-10 09:56:14 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:56:14 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:56:14 --> Utf8 Class Initialized
INFO - 2024-05-10 09:56:14 --> URI Class Initialized
INFO - 2024-05-10 09:56:14 --> Router Class Initialized
INFO - 2024-05-10 09:56:14 --> Output Class Initialized
INFO - 2024-05-10 09:56:14 --> Security Class Initialized
DEBUG - 2024-05-10 09:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:56:14 --> Input Class Initialized
INFO - 2024-05-10 09:56:14 --> Language Class Initialized
INFO - 2024-05-10 09:56:14 --> Loader Class Initialized
INFO - 2024-05-10 09:56:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:56:14 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:56:14 --> Controller Class Initialized
DEBUG - 2024-05-10 09:56:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:56:14 --> Database Driver Class Initialized
INFO - 2024-05-10 09:56:14 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:56:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-10 09:56:14 --> Final output sent to browser
DEBUG - 2024-05-10 09:56:14 --> Total execution time: 0.0684
INFO - 2024-05-10 09:56:14 --> Config Class Initialized
INFO - 2024-05-10 09:56:14 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:56:14 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:56:14 --> Utf8 Class Initialized
INFO - 2024-05-10 09:56:14 --> URI Class Initialized
INFO - 2024-05-10 09:56:14 --> Router Class Initialized
INFO - 2024-05-10 09:56:14 --> Output Class Initialized
INFO - 2024-05-10 09:56:14 --> Security Class Initialized
DEBUG - 2024-05-10 09:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:56:14 --> Input Class Initialized
INFO - 2024-05-10 09:56:14 --> Language Class Initialized
INFO - 2024-05-10 09:56:14 --> Loader Class Initialized
INFO - 2024-05-10 09:56:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:56:14 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:56:14 --> Controller Class Initialized
DEBUG - 2024-05-10 09:56:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:56:14 --> Database Driver Class Initialized
INFO - 2024-05-10 09:56:14 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:56:14 --> Final output sent to browser
DEBUG - 2024-05-10 09:56:14 --> Total execution time: 0.0147
INFO - 2024-05-10 09:56:14 --> Config Class Initialized
INFO - 2024-05-10 09:56:14 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:56:14 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:56:14 --> Utf8 Class Initialized
INFO - 2024-05-10 09:56:14 --> URI Class Initialized
INFO - 2024-05-10 09:56:14 --> Router Class Initialized
INFO - 2024-05-10 09:56:14 --> Output Class Initialized
INFO - 2024-05-10 09:56:14 --> Security Class Initialized
DEBUG - 2024-05-10 09:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:56:14 --> Input Class Initialized
INFO - 2024-05-10 09:56:14 --> Language Class Initialized
INFO - 2024-05-10 09:56:14 --> Loader Class Initialized
INFO - 2024-05-10 09:56:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:56:14 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:56:14 --> Controller Class Initialized
DEBUG - 2024-05-10 09:56:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:56:14 --> Database Driver Class Initialized
INFO - 2024-05-10 09:56:14 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:56:14 --> Final output sent to browser
DEBUG - 2024-05-10 09:56:14 --> Total execution time: 0.0151
INFO - 2024-05-10 09:56:58 --> Config Class Initialized
INFO - 2024-05-10 09:56:58 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:56:58 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:56:58 --> Utf8 Class Initialized
INFO - 2024-05-10 09:56:58 --> URI Class Initialized
INFO - 2024-05-10 09:56:58 --> Router Class Initialized
INFO - 2024-05-10 09:56:58 --> Output Class Initialized
INFO - 2024-05-10 09:56:58 --> Security Class Initialized
DEBUG - 2024-05-10 09:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:56:58 --> Input Class Initialized
INFO - 2024-05-10 09:56:58 --> Language Class Initialized
INFO - 2024-05-10 09:56:58 --> Loader Class Initialized
INFO - 2024-05-10 09:56:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:56:58 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:56:58 --> Controller Class Initialized
DEBUG - 2024-05-10 09:56:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:56:58 --> Database Driver Class Initialized
INFO - 2024-05-10 09:56:58 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:56:58 --> Final output sent to browser
DEBUG - 2024-05-10 09:56:58 --> Total execution time: 0.0114
INFO - 2024-05-10 09:57:05 --> Config Class Initialized
INFO - 2024-05-10 09:57:05 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:57:05 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:57:05 --> Utf8 Class Initialized
INFO - 2024-05-10 09:57:05 --> URI Class Initialized
INFO - 2024-05-10 09:57:05 --> Router Class Initialized
INFO - 2024-05-10 09:57:05 --> Output Class Initialized
INFO - 2024-05-10 09:57:05 --> Security Class Initialized
DEBUG - 2024-05-10 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:57:05 --> Input Class Initialized
INFO - 2024-05-10 09:57:05 --> Language Class Initialized
INFO - 2024-05-10 09:57:05 --> Loader Class Initialized
INFO - 2024-05-10 09:57:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:57:05 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:57:05 --> Controller Class Initialized
DEBUG - 2024-05-10 09:57:05 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:57:05 --> Database Driver Class Initialized
INFO - 2024-05-10 09:57:05 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:57:05 --> Final output sent to browser
DEBUG - 2024-05-10 09:57:05 --> Total execution time: 0.0186
INFO - 2024-05-10 09:57:05 --> Config Class Initialized
INFO - 2024-05-10 09:57:05 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:57:05 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:57:05 --> Utf8 Class Initialized
INFO - 2024-05-10 09:57:05 --> URI Class Initialized
INFO - 2024-05-10 09:57:05 --> Router Class Initialized
INFO - 2024-05-10 09:57:05 --> Output Class Initialized
INFO - 2024-05-10 09:57:05 --> Security Class Initialized
DEBUG - 2024-05-10 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:57:05 --> Input Class Initialized
INFO - 2024-05-10 09:57:05 --> Language Class Initialized
INFO - 2024-05-10 09:57:05 --> Loader Class Initialized
INFO - 2024-05-10 09:57:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:57:05 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:57:05 --> Controller Class Initialized
DEBUG - 2024-05-10 09:57:05 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:57:05 --> Database Driver Class Initialized
INFO - 2024-05-10 09:57:05 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:57:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-10 09:57:05 --> Final output sent to browser
DEBUG - 2024-05-10 09:57:05 --> Total execution time: 0.0794
INFO - 2024-05-10 09:57:05 --> Config Class Initialized
INFO - 2024-05-10 09:57:05 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:57:05 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:57:05 --> Utf8 Class Initialized
INFO - 2024-05-10 09:57:05 --> URI Class Initialized
INFO - 2024-05-10 09:57:05 --> Router Class Initialized
INFO - 2024-05-10 09:57:05 --> Output Class Initialized
INFO - 2024-05-10 09:57:05 --> Security Class Initialized
DEBUG - 2024-05-10 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:57:05 --> Input Class Initialized
INFO - 2024-05-10 09:57:05 --> Language Class Initialized
INFO - 2024-05-10 09:57:05 --> Loader Class Initialized
INFO - 2024-05-10 09:57:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:57:05 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:57:05 --> Controller Class Initialized
DEBUG - 2024-05-10 09:57:05 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:57:05 --> Database Driver Class Initialized
INFO - 2024-05-10 09:57:05 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:57:05 --> Final output sent to browser
DEBUG - 2024-05-10 09:57:05 --> Total execution time: 0.0580
INFO - 2024-05-10 09:57:08 --> Config Class Initialized
INFO - 2024-05-10 09:57:08 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:57:08 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:57:08 --> Utf8 Class Initialized
INFO - 2024-05-10 09:57:08 --> URI Class Initialized
INFO - 2024-05-10 09:57:08 --> Router Class Initialized
INFO - 2024-05-10 09:57:08 --> Output Class Initialized
INFO - 2024-05-10 09:57:08 --> Security Class Initialized
DEBUG - 2024-05-10 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:57:08 --> Input Class Initialized
INFO - 2024-05-10 09:57:08 --> Language Class Initialized
INFO - 2024-05-10 09:57:08 --> Loader Class Initialized
INFO - 2024-05-10 09:57:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:57:08 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:57:08 --> Controller Class Initialized
DEBUG - 2024-05-10 09:57:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:57:08 --> Database Driver Class Initialized
INFO - 2024-05-10 09:57:08 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:57:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-10 09:57:08 --> Final output sent to browser
DEBUG - 2024-05-10 09:57:08 --> Total execution time: 0.0480
INFO - 2024-05-10 09:57:08 --> Config Class Initialized
INFO - 2024-05-10 09:57:08 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:57:08 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:57:08 --> Utf8 Class Initialized
INFO - 2024-05-10 09:57:08 --> URI Class Initialized
INFO - 2024-05-10 09:57:08 --> Config Class Initialized
INFO - 2024-05-10 09:57:08 --> Router Class Initialized
INFO - 2024-05-10 09:57:08 --> Hooks Class Initialized
INFO - 2024-05-10 09:57:08 --> Output Class Initialized
DEBUG - 2024-05-10 09:57:08 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:57:08 --> Security Class Initialized
INFO - 2024-05-10 09:57:08 --> Utf8 Class Initialized
DEBUG - 2024-05-10 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:57:08 --> Input Class Initialized
INFO - 2024-05-10 09:57:08 --> URI Class Initialized
INFO - 2024-05-10 09:57:08 --> Language Class Initialized
INFO - 2024-05-10 09:57:08 --> Router Class Initialized
INFO - 2024-05-10 09:57:08 --> Loader Class Initialized
INFO - 2024-05-10 09:57:08 --> Output Class Initialized
INFO - 2024-05-10 09:57:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:57:08 --> Helper loaded: url_helper
INFO - 2024-05-10 09:57:08 --> Security Class Initialized
DEBUG - 2024-05-10 09:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-10 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:57:08 --> Input Class Initialized
INFO - 2024-05-10 09:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:57:08 --> Controller Class Initialized
INFO - 2024-05-10 09:57:08 --> Language Class Initialized
DEBUG - 2024-05-10 09:57:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:57:08 --> Loader Class Initialized
INFO - 2024-05-10 09:57:08 --> Database Driver Class Initialized
INFO - 2024-05-10 09:57:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:57:08 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:57:08 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:57:08 --> Final output sent to browser
DEBUG - 2024-05-10 09:57:08 --> Total execution time: 0.0178
INFO - 2024-05-10 09:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:57:08 --> Controller Class Initialized
DEBUG - 2024-05-10 09:57:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:57:08 --> Database Driver Class Initialized
INFO - 2024-05-10 09:57:08 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:57:08 --> Final output sent to browser
DEBUG - 2024-05-10 09:57:08 --> Total execution time: 0.0425
INFO - 2024-05-10 09:57:12 --> Config Class Initialized
INFO - 2024-05-10 09:57:12 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:57:12 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:57:12 --> Utf8 Class Initialized
INFO - 2024-05-10 09:57:12 --> URI Class Initialized
INFO - 2024-05-10 09:57:12 --> Router Class Initialized
INFO - 2024-05-10 09:57:12 --> Output Class Initialized
INFO - 2024-05-10 09:57:12 --> Security Class Initialized
DEBUG - 2024-05-10 09:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:57:12 --> Input Class Initialized
INFO - 2024-05-10 09:57:12 --> Language Class Initialized
INFO - 2024-05-10 09:57:12 --> Loader Class Initialized
INFO - 2024-05-10 09:57:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:57:12 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:57:12 --> Controller Class Initialized
DEBUG - 2024-05-10 09:57:12 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:57:12 --> Database Driver Class Initialized
INFO - 2024-05-10 09:57:12 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:57:12 --> Final output sent to browser
DEBUG - 2024-05-10 09:57:12 --> Total execution time: 0.0272
INFO - 2024-05-10 09:58:01 --> Config Class Initialized
INFO - 2024-05-10 09:58:01 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:58:01 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:58:01 --> Utf8 Class Initialized
INFO - 2024-05-10 09:58:01 --> URI Class Initialized
INFO - 2024-05-10 09:58:01 --> Router Class Initialized
INFO - 2024-05-10 09:58:01 --> Output Class Initialized
INFO - 2024-05-10 09:58:01 --> Security Class Initialized
DEBUG - 2024-05-10 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:58:01 --> Input Class Initialized
INFO - 2024-05-10 09:58:01 --> Language Class Initialized
INFO - 2024-05-10 09:58:01 --> Loader Class Initialized
INFO - 2024-05-10 09:58:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:58:01 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:58:01 --> Controller Class Initialized
DEBUG - 2024-05-10 09:58:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:58:01 --> Database Driver Class Initialized
INFO - 2024-05-10 09:58:01 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:58:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-10 09:58:01 --> Final output sent to browser
DEBUG - 2024-05-10 09:58:01 --> Total execution time: 0.2545
INFO - 2024-05-10 09:58:02 --> Config Class Initialized
INFO - 2024-05-10 09:58:02 --> Hooks Class Initialized
DEBUG - 2024-05-10 09:58:02 --> UTF-8 Support Enabled
INFO - 2024-05-10 09:58:02 --> Utf8 Class Initialized
INFO - 2024-05-10 09:58:02 --> URI Class Initialized
INFO - 2024-05-10 09:58:02 --> Router Class Initialized
INFO - 2024-05-10 09:58:02 --> Output Class Initialized
INFO - 2024-05-10 09:58:02 --> Security Class Initialized
DEBUG - 2024-05-10 09:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 09:58:02 --> Input Class Initialized
INFO - 2024-05-10 09:58:02 --> Language Class Initialized
INFO - 2024-05-10 09:58:02 --> Loader Class Initialized
INFO - 2024-05-10 09:58:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-10 09:58:02 --> Helper loaded: url_helper
DEBUG - 2024-05-10 09:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-10 09:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-10 09:58:02 --> Controller Class Initialized
DEBUG - 2024-05-10 09:58:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-10 09:58:02 --> Database Driver Class Initialized
INFO - 2024-05-10 09:58:02 --> Helper loaded: funciones_helper
INFO - 2024-05-10 09:58:02 --> Final output sent to browser
DEBUG - 2024-05-10 09:58:02 --> Total execution time: 0.0543
