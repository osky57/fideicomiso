<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-30 07:04:46 --> Config Class Initialized
INFO - 2024-05-30 07:04:46 --> Hooks Class Initialized
DEBUG - 2024-05-30 07:04:46 --> UTF-8 Support Enabled
INFO - 2024-05-30 07:04:46 --> Utf8 Class Initialized
INFO - 2024-05-30 07:04:46 --> URI Class Initialized
DEBUG - 2024-05-30 07:04:46 --> No URI present. Default controller set.
INFO - 2024-05-30 07:04:46 --> Router Class Initialized
INFO - 2024-05-30 07:04:46 --> Output Class Initialized
INFO - 2024-05-30 07:04:46 --> Security Class Initialized
DEBUG - 2024-05-30 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 07:04:46 --> Input Class Initialized
INFO - 2024-05-30 07:04:46 --> Language Class Initialized
INFO - 2024-05-30 07:04:46 --> Loader Class Initialized
INFO - 2024-05-30 07:04:46 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-30 07:04:46 --> Helper loaded: url_helper
DEBUG - 2024-05-30 07:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-30 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 07:04:46 --> Controller Class Initialized
INFO - 2024-05-30 07:04:51 --> Config Class Initialized
INFO - 2024-05-30 07:04:51 --> Hooks Class Initialized
DEBUG - 2024-05-30 07:04:51 --> UTF-8 Support Enabled
INFO - 2024-05-30 07:04:51 --> Utf8 Class Initialized
INFO - 2024-05-30 07:04:51 --> URI Class Initialized
DEBUG - 2024-05-30 07:04:51 --> No URI present. Default controller set.
INFO - 2024-05-30 07:04:51 --> Router Class Initialized
INFO - 2024-05-30 07:04:51 --> Output Class Initialized
INFO - 2024-05-30 07:04:51 --> Security Class Initialized
DEBUG - 2024-05-30 07:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 07:04:51 --> Input Class Initialized
INFO - 2024-05-30 07:04:51 --> Language Class Initialized
INFO - 2024-05-30 07:04:51 --> Loader Class Initialized
INFO - 2024-05-30 07:04:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-30 07:04:51 --> Helper loaded: url_helper
DEBUG - 2024-05-30 07:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-30 07:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 07:04:51 --> Controller Class Initialized
INFO - 2024-05-30 07:48:39 --> Config Class Initialized
INFO - 2024-05-30 07:48:39 --> Hooks Class Initialized
DEBUG - 2024-05-30 07:48:39 --> UTF-8 Support Enabled
INFO - 2024-05-30 07:48:39 --> Utf8 Class Initialized
INFO - 2024-05-30 07:48:39 --> URI Class Initialized
DEBUG - 2024-05-30 07:48:39 --> No URI present. Default controller set.
INFO - 2024-05-30 07:48:39 --> Router Class Initialized
INFO - 2024-05-30 07:48:39 --> Output Class Initialized
INFO - 2024-05-30 07:48:39 --> Security Class Initialized
DEBUG - 2024-05-30 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 07:48:39 --> Input Class Initialized
INFO - 2024-05-30 07:48:39 --> Language Class Initialized
INFO - 2024-05-30 07:48:39 --> Loader Class Initialized
INFO - 2024-05-30 07:48:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-30 07:48:39 --> Helper loaded: url_helper
DEBUG - 2024-05-30 07:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-30 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 07:48:39 --> Controller Class Initialized
