<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-11 16:26:51 --> Config Class Initialized
INFO - 2024-05-11 16:26:51 --> Hooks Class Initialized
DEBUG - 2024-05-11 16:26:51 --> UTF-8 Support Enabled
INFO - 2024-05-11 16:26:51 --> Utf8 Class Initialized
INFO - 2024-05-11 16:26:51 --> URI Class Initialized
DEBUG - 2024-05-11 16:26:51 --> No URI present. Default controller set.
INFO - 2024-05-11 16:26:51 --> Router Class Initialized
INFO - 2024-05-11 16:26:51 --> Output Class Initialized
INFO - 2024-05-11 16:26:51 --> Security Class Initialized
DEBUG - 2024-05-11 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-11 16:26:51 --> Input Class Initialized
INFO - 2024-05-11 16:26:51 --> Language Class Initialized
INFO - 2024-05-11 16:26:51 --> Loader Class Initialized
INFO - 2024-05-11 16:26:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-11 16:26:51 --> Helper loaded: url_helper
DEBUG - 2024-05-11 16:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-11 16:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-11 16:26:51 --> Controller Class Initialized
INFO - 2024-05-11 17:05:42 --> Config Class Initialized
INFO - 2024-05-11 17:05:42 --> Hooks Class Initialized
DEBUG - 2024-05-11 17:05:42 --> UTF-8 Support Enabled
INFO - 2024-05-11 17:05:42 --> Utf8 Class Initialized
INFO - 2024-05-11 17:05:42 --> URI Class Initialized
DEBUG - 2024-05-11 17:05:42 --> No URI present. Default controller set.
INFO - 2024-05-11 17:05:42 --> Router Class Initialized
INFO - 2024-05-11 17:05:42 --> Output Class Initialized
INFO - 2024-05-11 17:05:42 --> Security Class Initialized
DEBUG - 2024-05-11 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-11 17:05:42 --> Input Class Initialized
INFO - 2024-05-11 17:05:42 --> Language Class Initialized
INFO - 2024-05-11 17:05:42 --> Loader Class Initialized
INFO - 2024-05-11 17:05:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-11 17:05:42 --> Helper loaded: url_helper
DEBUG - 2024-05-11 17:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-11 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-11 17:05:42 --> Controller Class Initialized
