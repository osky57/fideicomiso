<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-31 12:18:09 --> Config Class Initialized
INFO - 2024-05-31 12:18:09 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:09 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:09 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:09 --> URI Class Initialized
DEBUG - 2024-05-31 12:18:09 --> No URI present. Default controller set.
INFO - 2024-05-31 12:18:09 --> Router Class Initialized
INFO - 2024-05-31 12:18:09 --> Output Class Initialized
INFO - 2024-05-31 12:18:09 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:09 --> Input Class Initialized
INFO - 2024-05-31 12:18:09 --> Language Class Initialized
INFO - 2024-05-31 12:18:09 --> Loader Class Initialized
INFO - 2024-05-31 12:18:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:09 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:09 --> Controller Class Initialized
INFO - 2024-05-31 12:18:10 --> Config Class Initialized
INFO - 2024-05-31 12:18:10 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:10 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:10 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:10 --> URI Class Initialized
INFO - 2024-05-31 12:18:10 --> Router Class Initialized
INFO - 2024-05-31 12:18:10 --> Output Class Initialized
INFO - 2024-05-31 12:18:10 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:10 --> Input Class Initialized
INFO - 2024-05-31 12:18:10 --> Language Class Initialized
INFO - 2024-05-31 12:18:10 --> Loader Class Initialized
INFO - 2024-05-31 12:18:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:10 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:10 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-31 12:18:10 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:10 --> Helper loaded: cookie_helper
INFO - 2024-05-31 12:18:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 12:18:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 12:18:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-31 12:18:10 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:10 --> Total execution time: 0.0519
INFO - 2024-05-31 12:18:10 --> Config Class Initialized
INFO - 2024-05-31 12:18:10 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:10 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:10 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:10 --> URI Class Initialized
INFO - 2024-05-31 12:18:10 --> Router Class Initialized
INFO - 2024-05-31 12:18:10 --> Output Class Initialized
INFO - 2024-05-31 12:18:10 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:10 --> Input Class Initialized
INFO - 2024-05-31 12:18:10 --> Language Class Initialized
INFO - 2024-05-31 12:18:10 --> Loader Class Initialized
INFO - 2024-05-31 12:18:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:10 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:10 --> Controller Class Initialized
INFO - 2024-05-31 12:18:14 --> Config Class Initialized
INFO - 2024-05-31 12:18:14 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:14 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:14 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:14 --> URI Class Initialized
INFO - 2024-05-31 12:18:14 --> Router Class Initialized
INFO - 2024-05-31 12:18:14 --> Output Class Initialized
INFO - 2024-05-31 12:18:14 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:14 --> Input Class Initialized
INFO - 2024-05-31 12:18:14 --> Language Class Initialized
INFO - 2024-05-31 12:18:14 --> Loader Class Initialized
INFO - 2024-05-31 12:18:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:14 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:14 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-31 12:18:14 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:14 --> Helper loaded: cookie_helper
INFO - 2024-05-31 12:18:14 --> Helper loaded: form_helper
INFO - 2024-05-31 12:18:14 --> Form Validation Class Initialized
INFO - 2024-05-31 12:18:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-31 12:18:14 --> Config Class Initialized
INFO - 2024-05-31 12:18:14 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:14 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:14 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:14 --> URI Class Initialized
INFO - 2024-05-31 12:18:14 --> Router Class Initialized
INFO - 2024-05-31 12:18:14 --> Output Class Initialized
INFO - 2024-05-31 12:18:14 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:14 --> Input Class Initialized
INFO - 2024-05-31 12:18:14 --> Language Class Initialized
INFO - 2024-05-31 12:18:14 --> Loader Class Initialized
INFO - 2024-05-31 12:18:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:14 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:14 --> Controller Class Initialized
INFO - 2024-05-31 12:18:14 --> Database Driver Class Initialized
DEBUG - 2024-05-31 12:18:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-31 12:18:14 --> Helper loaded: cookie_helper
INFO - 2024-05-31 12:18:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 12:18:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 12:18:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-31 12:18:14 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:14 --> Total execution time: 0.0152
INFO - 2024-05-31 12:18:15 --> Config Class Initialized
INFO - 2024-05-31 12:18:15 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:15 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:15 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:15 --> URI Class Initialized
INFO - 2024-05-31 12:18:15 --> Router Class Initialized
INFO - 2024-05-31 12:18:15 --> Output Class Initialized
INFO - 2024-05-31 12:18:15 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:15 --> Input Class Initialized
INFO - 2024-05-31 12:18:15 --> Language Class Initialized
INFO - 2024-05-31 12:18:15 --> Loader Class Initialized
INFO - 2024-05-31 12:18:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:15 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:15 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-31 12:18:15 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:15 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:15 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:15 --> Total execution time: 0.0432
INFO - 2024-05-31 12:18:17 --> Config Class Initialized
INFO - 2024-05-31 12:18:17 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:17 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:17 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:17 --> URI Class Initialized
INFO - 2024-05-31 12:18:17 --> Router Class Initialized
INFO - 2024-05-31 12:18:17 --> Output Class Initialized
INFO - 2024-05-31 12:18:17 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:17 --> Input Class Initialized
INFO - 2024-05-31 12:18:17 --> Language Class Initialized
INFO - 2024-05-31 12:18:17 --> Loader Class Initialized
INFO - 2024-05-31 12:18:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:17 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:17 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-31 12:18:17 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:17 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 12:18:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 12:18:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-31 12:18:17 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:17 --> Total execution time: 0.0210
INFO - 2024-05-31 12:18:18 --> Config Class Initialized
INFO - 2024-05-31 12:18:18 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:18 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:18 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:18 --> URI Class Initialized
INFO - 2024-05-31 12:18:18 --> Router Class Initialized
INFO - 2024-05-31 12:18:18 --> Output Class Initialized
INFO - 2024-05-31 12:18:18 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:18 --> Input Class Initialized
INFO - 2024-05-31 12:18:18 --> Language Class Initialized
INFO - 2024-05-31 12:18:18 --> Loader Class Initialized
INFO - 2024-05-31 12:18:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:18 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:18 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-31 12:18:18 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:18 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:18 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:18 --> Total execution time: 0.0215
INFO - 2024-05-31 12:18:19 --> Config Class Initialized
INFO - 2024-05-31 12:18:19 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:19 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:19 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:19 --> URI Class Initialized
INFO - 2024-05-31 12:18:19 --> Router Class Initialized
INFO - 2024-05-31 12:18:19 --> Output Class Initialized
INFO - 2024-05-31 12:18:19 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:19 --> Input Class Initialized
INFO - 2024-05-31 12:18:19 --> Language Class Initialized
INFO - 2024-05-31 12:18:19 --> Loader Class Initialized
INFO - 2024-05-31 12:18:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:19 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:19 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-31 12:18:19 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:19 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 12:18:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 12:18:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-31 12:18:19 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:19 --> Total execution time: 0.0424
INFO - 2024-05-31 12:18:20 --> Config Class Initialized
INFO - 2024-05-31 12:18:20 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:20 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:20 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:20 --> URI Class Initialized
INFO - 2024-05-31 12:18:20 --> Router Class Initialized
INFO - 2024-05-31 12:18:20 --> Output Class Initialized
INFO - 2024-05-31 12:18:20 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:20 --> Input Class Initialized
INFO - 2024-05-31 12:18:20 --> Language Class Initialized
INFO - 2024-05-31 12:18:20 --> Loader Class Initialized
INFO - 2024-05-31 12:18:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:20 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:20 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-31 12:18:20 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:20 --> Config Class Initialized
INFO - 2024-05-31 12:18:20 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:20 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:20 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:20 --> URI Class Initialized
INFO - 2024-05-31 12:18:20 --> Router Class Initialized
INFO - 2024-05-31 12:18:20 --> Output Class Initialized
INFO - 2024-05-31 12:18:20 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:20 --> Input Class Initialized
INFO - 2024-05-31 12:18:20 --> Language Class Initialized
INFO - 2024-05-31 12:18:20 --> Loader Class Initialized
INFO - 2024-05-31 12:18:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:20 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:20 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:20 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:20 --> Total execution time: 0.0815
INFO - 2024-05-31 12:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:20 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-31 12:18:20 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:20 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:20 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:20 --> Total execution time: 0.1045
INFO - 2024-05-31 12:18:34 --> Config Class Initialized
INFO - 2024-05-31 12:18:34 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:34 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:34 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:34 --> URI Class Initialized
INFO - 2024-05-31 12:18:34 --> Router Class Initialized
INFO - 2024-05-31 12:18:34 --> Output Class Initialized
INFO - 2024-05-31 12:18:34 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:34 --> Input Class Initialized
INFO - 2024-05-31 12:18:34 --> Language Class Initialized
INFO - 2024-05-31 12:18:34 --> Loader Class Initialized
INFO - 2024-05-31 12:18:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:34 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:34 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-31 12:18:34 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:34 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 12:18:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 12:18:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-31 12:18:34 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:34 --> Total execution time: 0.0374
INFO - 2024-05-31 12:18:34 --> Config Class Initialized
INFO - 2024-05-31 12:18:34 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:34 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:34 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:34 --> URI Class Initialized
INFO - 2024-05-31 12:18:34 --> Router Class Initialized
INFO - 2024-05-31 12:18:34 --> Output Class Initialized
INFO - 2024-05-31 12:18:34 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:34 --> Input Class Initialized
INFO - 2024-05-31 12:18:34 --> Language Class Initialized
INFO - 2024-05-31 12:18:34 --> Loader Class Initialized
INFO - 2024-05-31 12:18:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:34 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:34 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-31 12:18:34 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:34 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:34 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:34 --> Total execution time: 0.1037
INFO - 2024-05-31 12:18:34 --> Config Class Initialized
INFO - 2024-05-31 12:18:34 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:18:34 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:18:34 --> Utf8 Class Initialized
INFO - 2024-05-31 12:18:34 --> URI Class Initialized
INFO - 2024-05-31 12:18:34 --> Router Class Initialized
INFO - 2024-05-31 12:18:34 --> Output Class Initialized
INFO - 2024-05-31 12:18:34 --> Security Class Initialized
DEBUG - 2024-05-31 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:18:34 --> Input Class Initialized
INFO - 2024-05-31 12:18:34 --> Language Class Initialized
INFO - 2024-05-31 12:18:34 --> Loader Class Initialized
INFO - 2024-05-31 12:18:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:18:34 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:18:34 --> Controller Class Initialized
DEBUG - 2024-05-31 12:18:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-31 12:18:34 --> Database Driver Class Initialized
INFO - 2024-05-31 12:18:34 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:18:34 --> Final output sent to browser
DEBUG - 2024-05-31 12:18:34 --> Total execution time: 0.0202
INFO - 2024-05-31 12:19:19 --> Config Class Initialized
INFO - 2024-05-31 12:19:19 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:19:19 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:19:19 --> Utf8 Class Initialized
INFO - 2024-05-31 12:19:19 --> URI Class Initialized
INFO - 2024-05-31 12:19:19 --> Router Class Initialized
INFO - 2024-05-31 12:19:19 --> Output Class Initialized
INFO - 2024-05-31 12:19:19 --> Security Class Initialized
DEBUG - 2024-05-31 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:19:19 --> Input Class Initialized
INFO - 2024-05-31 12:19:19 --> Language Class Initialized
INFO - 2024-05-31 12:19:19 --> Loader Class Initialized
INFO - 2024-05-31 12:19:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:19:19 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:19:19 --> Controller Class Initialized
DEBUG - 2024-05-31 12:19:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-31 12:19:19 --> Database Driver Class Initialized
INFO - 2024-05-31 12:19:19 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:19:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 12:19:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 12:19:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-31 12:19:19 --> Final output sent to browser
DEBUG - 2024-05-31 12:19:19 --> Total execution time: 0.0285
INFO - 2024-05-31 12:19:19 --> Config Class Initialized
INFO - 2024-05-31 12:19:19 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:19:19 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:19:19 --> Utf8 Class Initialized
INFO - 2024-05-31 12:19:19 --> URI Class Initialized
INFO - 2024-05-31 12:19:19 --> Router Class Initialized
INFO - 2024-05-31 12:19:19 --> Output Class Initialized
INFO - 2024-05-31 12:19:19 --> Security Class Initialized
DEBUG - 2024-05-31 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:19:19 --> Input Class Initialized
INFO - 2024-05-31 12:19:19 --> Language Class Initialized
INFO - 2024-05-31 12:19:19 --> Loader Class Initialized
INFO - 2024-05-31 12:19:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:19:19 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:19:19 --> Controller Class Initialized
DEBUG - 2024-05-31 12:19:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-31 12:19:19 --> Database Driver Class Initialized
INFO - 2024-05-31 12:19:19 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:19:19 --> Final output sent to browser
DEBUG - 2024-05-31 12:19:19 --> Total execution time: 0.0831
INFO - 2024-05-31 12:19:19 --> Config Class Initialized
INFO - 2024-05-31 12:19:19 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:19:19 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:19:19 --> Utf8 Class Initialized
INFO - 2024-05-31 12:19:19 --> URI Class Initialized
INFO - 2024-05-31 12:19:19 --> Router Class Initialized
INFO - 2024-05-31 12:19:19 --> Output Class Initialized
INFO - 2024-05-31 12:19:19 --> Security Class Initialized
DEBUG - 2024-05-31 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:19:19 --> Input Class Initialized
INFO - 2024-05-31 12:19:19 --> Language Class Initialized
INFO - 2024-05-31 12:19:19 --> Loader Class Initialized
INFO - 2024-05-31 12:19:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:19:19 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:19:19 --> Controller Class Initialized
DEBUG - 2024-05-31 12:19:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-31 12:19:19 --> Database Driver Class Initialized
INFO - 2024-05-31 12:19:19 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:19:19 --> Final output sent to browser
DEBUG - 2024-05-31 12:19:19 --> Total execution time: 0.0236
INFO - 2024-05-31 12:19:26 --> Config Class Initialized
INFO - 2024-05-31 12:19:26 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:19:26 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:19:26 --> Utf8 Class Initialized
INFO - 2024-05-31 12:19:26 --> URI Class Initialized
INFO - 2024-05-31 12:19:26 --> Router Class Initialized
INFO - 2024-05-31 12:19:26 --> Output Class Initialized
INFO - 2024-05-31 12:19:26 --> Security Class Initialized
DEBUG - 2024-05-31 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:19:26 --> Input Class Initialized
INFO - 2024-05-31 12:19:26 --> Language Class Initialized
INFO - 2024-05-31 12:19:26 --> Loader Class Initialized
INFO - 2024-05-31 12:19:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:19:26 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:19:26 --> Controller Class Initialized
DEBUG - 2024-05-31 12:19:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-31 12:19:26 --> Database Driver Class Initialized
INFO - 2024-05-31 12:19:26 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:19:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 12:19:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 12:19:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/presupuestos.php
INFO - 2024-05-31 12:19:26 --> Final output sent to browser
DEBUG - 2024-05-31 12:19:26 --> Total execution time: 0.0680
INFO - 2024-05-31 12:19:26 --> Config Class Initialized
INFO - 2024-05-31 12:19:26 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:19:26 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:19:26 --> Utf8 Class Initialized
INFO - 2024-05-31 12:19:26 --> URI Class Initialized
INFO - 2024-05-31 12:19:26 --> Router Class Initialized
INFO - 2024-05-31 12:19:26 --> Output Class Initialized
INFO - 2024-05-31 12:19:26 --> Security Class Initialized
DEBUG - 2024-05-31 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:19:26 --> Input Class Initialized
INFO - 2024-05-31 12:19:26 --> Language Class Initialized
INFO - 2024-05-31 12:19:26 --> Loader Class Initialized
INFO - 2024-05-31 12:19:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:19:26 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:19:26 --> Controller Class Initialized
DEBUG - 2024-05-31 12:19:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-31 12:19:26 --> Database Driver Class Initialized
INFO - 2024-05-31 12:19:26 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:19:26 --> Final output sent to browser
DEBUG - 2024-05-31 12:19:26 --> Total execution time: 0.0175
INFO - 2024-05-31 12:19:26 --> Config Class Initialized
INFO - 2024-05-31 12:19:26 --> Hooks Class Initialized
DEBUG - 2024-05-31 12:19:26 --> UTF-8 Support Enabled
INFO - 2024-05-31 12:19:26 --> Utf8 Class Initialized
INFO - 2024-05-31 12:19:26 --> URI Class Initialized
INFO - 2024-05-31 12:19:26 --> Router Class Initialized
INFO - 2024-05-31 12:19:26 --> Output Class Initialized
INFO - 2024-05-31 12:19:26 --> Security Class Initialized
DEBUG - 2024-05-31 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 12:19:26 --> Input Class Initialized
INFO - 2024-05-31 12:19:26 --> Language Class Initialized
INFO - 2024-05-31 12:19:26 --> Loader Class Initialized
INFO - 2024-05-31 12:19:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 12:19:26 --> Helper loaded: url_helper
DEBUG - 2024-05-31 12:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 12:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 12:19:26 --> Controller Class Initialized
DEBUG - 2024-05-31 12:19:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-31 12:19:26 --> Database Driver Class Initialized
INFO - 2024-05-31 12:19:26 --> Helper loaded: funciones_helper
INFO - 2024-05-31 12:19:26 --> Final output sent to browser
DEBUG - 2024-05-31 12:19:26 --> Total execution time: 0.0215
INFO - 2024-05-31 15:25:06 --> Config Class Initialized
INFO - 2024-05-31 15:25:06 --> Hooks Class Initialized
DEBUG - 2024-05-31 15:25:06 --> UTF-8 Support Enabled
INFO - 2024-05-31 15:25:06 --> Utf8 Class Initialized
INFO - 2024-05-31 15:25:06 --> URI Class Initialized
DEBUG - 2024-05-31 15:25:06 --> No URI present. Default controller set.
INFO - 2024-05-31 15:25:06 --> Router Class Initialized
INFO - 2024-05-31 15:25:06 --> Output Class Initialized
INFO - 2024-05-31 15:25:06 --> Security Class Initialized
DEBUG - 2024-05-31 15:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 15:25:06 --> Input Class Initialized
INFO - 2024-05-31 15:25:06 --> Language Class Initialized
INFO - 2024-05-31 15:25:06 --> Loader Class Initialized
INFO - 2024-05-31 15:25:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 15:25:06 --> Helper loaded: url_helper
DEBUG - 2024-05-31 15:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 15:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 15:25:06 --> Controller Class Initialized
INFO - 2024-05-31 16:13:02 --> Config Class Initialized
INFO - 2024-05-31 16:13:02 --> Hooks Class Initialized
DEBUG - 2024-05-31 16:13:02 --> UTF-8 Support Enabled
INFO - 2024-05-31 16:13:02 --> Utf8 Class Initialized
INFO - 2024-05-31 16:13:02 --> URI Class Initialized
DEBUG - 2024-05-31 16:13:02 --> No URI present. Default controller set.
INFO - 2024-05-31 16:13:02 --> Router Class Initialized
INFO - 2024-05-31 16:13:02 --> Output Class Initialized
INFO - 2024-05-31 16:13:02 --> Security Class Initialized
DEBUG - 2024-05-31 16:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 16:13:02 --> Input Class Initialized
INFO - 2024-05-31 16:13:02 --> Language Class Initialized
INFO - 2024-05-31 16:13:02 --> Loader Class Initialized
INFO - 2024-05-31 16:13:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 16:13:02 --> Helper loaded: url_helper
DEBUG - 2024-05-31 16:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 16:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 16:13:02 --> Controller Class Initialized
INFO - 2024-05-31 16:13:06 --> Config Class Initialized
INFO - 2024-05-31 16:13:06 --> Hooks Class Initialized
DEBUG - 2024-05-31 16:13:06 --> UTF-8 Support Enabled
INFO - 2024-05-31 16:13:06 --> Utf8 Class Initialized
INFO - 2024-05-31 16:13:06 --> URI Class Initialized
INFO - 2024-05-31 16:13:06 --> Router Class Initialized
INFO - 2024-05-31 16:13:06 --> Output Class Initialized
INFO - 2024-05-31 16:13:06 --> Security Class Initialized
DEBUG - 2024-05-31 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 16:13:06 --> Input Class Initialized
INFO - 2024-05-31 16:13:06 --> Language Class Initialized
INFO - 2024-05-31 16:13:06 --> Loader Class Initialized
INFO - 2024-05-31 16:13:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-31 16:13:06 --> Helper loaded: url_helper
DEBUG - 2024-05-31 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-31 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 16:13:06 --> Controller Class Initialized
DEBUG - 2024-05-31 16:13:06 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-31 16:13:06 --> Database Driver Class Initialized
INFO - 2024-05-31 16:13:06 --> Helper loaded: cookie_helper
INFO - 2024-05-31 16:13:06 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-31 16:13:06 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-31 16:13:06 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-31 16:13:06 --> Final output sent to browser
DEBUG - 2024-05-31 16:13:06 --> Total execution time: 0.0180
