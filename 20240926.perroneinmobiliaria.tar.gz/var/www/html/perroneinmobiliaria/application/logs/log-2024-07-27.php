<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-27 02:52:48 --> Config Class Initialized
INFO - 2024-07-27 02:52:48 --> Hooks Class Initialized
DEBUG - 2024-07-27 02:52:48 --> UTF-8 Support Enabled
INFO - 2024-07-27 02:52:48 --> Utf8 Class Initialized
INFO - 2024-07-27 02:52:48 --> URI Class Initialized
DEBUG - 2024-07-27 02:52:48 --> No URI present. Default controller set.
INFO - 2024-07-27 02:52:48 --> Router Class Initialized
INFO - 2024-07-27 02:52:48 --> Output Class Initialized
INFO - 2024-07-27 02:52:48 --> Security Class Initialized
DEBUG - 2024-07-27 02:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-27 02:52:48 --> Input Class Initialized
INFO - 2024-07-27 02:52:48 --> Language Class Initialized
INFO - 2024-07-27 02:52:48 --> Loader Class Initialized
INFO - 2024-07-27 02:52:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-27 02:52:48 --> Helper loaded: url_helper
DEBUG - 2024-07-27 02:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-27 02:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-27 02:52:48 --> Controller Class Initialized
