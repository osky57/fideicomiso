<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-01 12:52:15 --> Config Class Initialized
INFO - 2024-07-01 12:52:15 --> Hooks Class Initialized
DEBUG - 2024-07-01 12:52:15 --> UTF-8 Support Enabled
INFO - 2024-07-01 12:52:15 --> Utf8 Class Initialized
INFO - 2024-07-01 12:52:15 --> URI Class Initialized
DEBUG - 2024-07-01 12:52:15 --> No URI present. Default controller set.
INFO - 2024-07-01 12:52:15 --> Router Class Initialized
INFO - 2024-07-01 12:52:15 --> Output Class Initialized
INFO - 2024-07-01 12:52:15 --> Security Class Initialized
DEBUG - 2024-07-01 12:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 12:52:15 --> Input Class Initialized
INFO - 2024-07-01 12:52:15 --> Language Class Initialized
INFO - 2024-07-01 12:52:15 --> Loader Class Initialized
INFO - 2024-07-01 12:52:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-01 12:52:15 --> Helper loaded: url_helper
DEBUG - 2024-07-01 12:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-01 12:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 12:52:15 --> Controller Class Initialized
INFO - 2024-07-01 12:52:18 --> Config Class Initialized
INFO - 2024-07-01 12:52:18 --> Hooks Class Initialized
DEBUG - 2024-07-01 12:52:18 --> UTF-8 Support Enabled
INFO - 2024-07-01 12:52:18 --> Utf8 Class Initialized
INFO - 2024-07-01 12:52:18 --> URI Class Initialized
INFO - 2024-07-01 12:52:18 --> Router Class Initialized
INFO - 2024-07-01 12:52:18 --> Output Class Initialized
INFO - 2024-07-01 12:52:18 --> Security Class Initialized
DEBUG - 2024-07-01 12:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 12:52:18 --> Input Class Initialized
INFO - 2024-07-01 12:52:18 --> Language Class Initialized
INFO - 2024-07-01 12:52:18 --> Loader Class Initialized
INFO - 2024-07-01 12:52:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-01 12:52:18 --> Helper loaded: url_helper
DEBUG - 2024-07-01 12:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-01 12:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 12:52:18 --> Controller Class Initialized
DEBUG - 2024-07-01 12:52:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-01 12:52:18 --> Database Driver Class Initialized
INFO - 2024-07-01 12:52:18 --> Helper loaded: cookie_helper
INFO - 2024-07-01 12:52:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-01 12:52:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-01 12:52:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-07-01 12:52:18 --> Final output sent to browser
DEBUG - 2024-07-01 12:52:18 --> Total execution time: 0.0415
INFO - 2024-07-01 19:58:56 --> Config Class Initialized
INFO - 2024-07-01 19:58:56 --> Hooks Class Initialized
DEBUG - 2024-07-01 19:58:56 --> UTF-8 Support Enabled
INFO - 2024-07-01 19:58:56 --> Utf8 Class Initialized
INFO - 2024-07-01 19:58:56 --> URI Class Initialized
DEBUG - 2024-07-01 19:58:56 --> No URI present. Default controller set.
INFO - 2024-07-01 19:58:56 --> Router Class Initialized
INFO - 2024-07-01 19:58:56 --> Output Class Initialized
INFO - 2024-07-01 19:58:56 --> Security Class Initialized
DEBUG - 2024-07-01 19:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 19:58:56 --> Input Class Initialized
INFO - 2024-07-01 19:58:56 --> Language Class Initialized
INFO - 2024-07-01 19:58:56 --> Loader Class Initialized
INFO - 2024-07-01 19:58:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-01 19:58:56 --> Helper loaded: url_helper
DEBUG - 2024-07-01 19:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-01 19:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 19:58:56 --> Controller Class Initialized
