<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-05 12:41:58 --> Config Class Initialized
INFO - 2024-09-05 12:41:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 12:41:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 12:41:58 --> Utf8 Class Initialized
INFO - 2024-09-05 12:41:58 --> URI Class Initialized
DEBUG - 2024-09-05 12:41:58 --> No URI present. Default controller set.
INFO - 2024-09-05 12:41:58 --> Router Class Initialized
INFO - 2024-09-05 12:41:58 --> Output Class Initialized
INFO - 2024-09-05 12:41:58 --> Security Class Initialized
DEBUG - 2024-09-05 12:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 12:41:58 --> Input Class Initialized
INFO - 2024-09-05 12:41:58 --> Language Class Initialized
INFO - 2024-09-05 12:41:58 --> Loader Class Initialized
INFO - 2024-09-05 12:41:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-05 12:41:58 --> Helper loaded: url_helper
DEBUG - 2024-09-05 12:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 12:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 12:41:58 --> Controller Class Initialized
INFO - 2024-09-05 12:41:58 --> Config Class Initialized
INFO - 2024-09-05 12:41:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 12:41:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 12:41:58 --> Utf8 Class Initialized
INFO - 2024-09-05 12:41:58 --> URI Class Initialized
INFO - 2024-09-05 12:41:58 --> Router Class Initialized
INFO - 2024-09-05 12:41:58 --> Output Class Initialized
INFO - 2024-09-05 12:41:58 --> Security Class Initialized
DEBUG - 2024-09-05 12:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 12:41:58 --> Input Class Initialized
INFO - 2024-09-05 12:41:58 --> Language Class Initialized
INFO - 2024-09-05 12:41:58 --> Loader Class Initialized
INFO - 2024-09-05 12:41:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-05 12:41:58 --> Helper loaded: url_helper
DEBUG - 2024-09-05 12:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 12:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 12:41:58 --> Controller Class Initialized
DEBUG - 2024-09-05 12:41:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-05 12:41:58 --> Database Driver Class Initialized
INFO - 2024-09-05 12:41:58 --> Helper loaded: cookie_helper
INFO - 2024-09-05 12:41:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-05 12:41:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-05 12:41:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-05 12:41:58 --> Final output sent to browser
DEBUG - 2024-09-05 12:41:58 --> Total execution time: 0.0557
INFO - 2024-09-05 12:42:00 --> Config Class Initialized
INFO - 2024-09-05 12:42:00 --> Hooks Class Initialized
DEBUG - 2024-09-05 12:42:00 --> UTF-8 Support Enabled
INFO - 2024-09-05 12:42:00 --> Utf8 Class Initialized
INFO - 2024-09-05 12:42:00 --> URI Class Initialized
INFO - 2024-09-05 12:42:00 --> Router Class Initialized
INFO - 2024-09-05 12:42:00 --> Output Class Initialized
INFO - 2024-09-05 12:42:00 --> Security Class Initialized
DEBUG - 2024-09-05 12:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 12:42:00 --> Input Class Initialized
INFO - 2024-09-05 12:42:00 --> Language Class Initialized
INFO - 2024-09-05 12:42:00 --> Loader Class Initialized
INFO - 2024-09-05 12:42:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-05 12:42:00 --> Helper loaded: url_helper
DEBUG - 2024-09-05 12:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 12:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 12:42:00 --> Controller Class Initialized
