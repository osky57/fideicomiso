<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-26 10:13:20 --> Config Class Initialized
INFO - 2024-05-26 10:13:20 --> Hooks Class Initialized
DEBUG - 2024-05-26 10:13:20 --> UTF-8 Support Enabled
INFO - 2024-05-26 10:13:20 --> Utf8 Class Initialized
INFO - 2024-05-26 10:13:20 --> URI Class Initialized
DEBUG - 2024-05-26 10:13:20 --> No URI present. Default controller set.
INFO - 2024-05-26 10:13:20 --> Router Class Initialized
INFO - 2024-05-26 10:13:20 --> Output Class Initialized
INFO - 2024-05-26 10:13:20 --> Security Class Initialized
DEBUG - 2024-05-26 10:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 10:13:20 --> Input Class Initialized
INFO - 2024-05-26 10:13:20 --> Language Class Initialized
INFO - 2024-05-26 10:13:20 --> Loader Class Initialized
INFO - 2024-05-26 10:13:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 10:13:20 --> Helper loaded: url_helper
DEBUG - 2024-05-26 10:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 10:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 10:13:20 --> Controller Class Initialized
INFO - 2024-05-26 18:27:02 --> Config Class Initialized
INFO - 2024-05-26 18:27:02 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:02 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:02 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:02 --> URI Class Initialized
DEBUG - 2024-05-26 18:27:02 --> No URI present. Default controller set.
INFO - 2024-05-26 18:27:02 --> Router Class Initialized
INFO - 2024-05-26 18:27:02 --> Output Class Initialized
INFO - 2024-05-26 18:27:02 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:02 --> Input Class Initialized
INFO - 2024-05-26 18:27:02 --> Language Class Initialized
INFO - 2024-05-26 18:27:02 --> Loader Class Initialized
INFO - 2024-05-26 18:27:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:02 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:02 --> Controller Class Initialized
INFO - 2024-05-26 18:27:02 --> Config Class Initialized
INFO - 2024-05-26 18:27:02 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:02 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:02 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:02 --> URI Class Initialized
INFO - 2024-05-26 18:27:02 --> Router Class Initialized
INFO - 2024-05-26 18:27:02 --> Output Class Initialized
INFO - 2024-05-26 18:27:02 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:02 --> Input Class Initialized
INFO - 2024-05-26 18:27:02 --> Language Class Initialized
INFO - 2024-05-26 18:27:02 --> Loader Class Initialized
INFO - 2024-05-26 18:27:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:02 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:02 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-26 18:27:02 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:02 --> Helper loaded: cookie_helper
INFO - 2024-05-26 18:27:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-26 18:27:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-26 18:27:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-26 18:27:02 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:02 --> Total execution time: 0.0449
INFO - 2024-05-26 18:27:03 --> Config Class Initialized
INFO - 2024-05-26 18:27:03 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:03 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:03 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:03 --> URI Class Initialized
INFO - 2024-05-26 18:27:03 --> Router Class Initialized
INFO - 2024-05-26 18:27:03 --> Output Class Initialized
INFO - 2024-05-26 18:27:03 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:03 --> Input Class Initialized
INFO - 2024-05-26 18:27:03 --> Language Class Initialized
INFO - 2024-05-26 18:27:03 --> Loader Class Initialized
INFO - 2024-05-26 18:27:03 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:03 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:03 --> Controller Class Initialized
INFO - 2024-05-26 18:27:05 --> Config Class Initialized
INFO - 2024-05-26 18:27:05 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:05 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:05 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:05 --> URI Class Initialized
INFO - 2024-05-26 18:27:05 --> Router Class Initialized
INFO - 2024-05-26 18:27:05 --> Output Class Initialized
INFO - 2024-05-26 18:27:05 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:05 --> Input Class Initialized
INFO - 2024-05-26 18:27:05 --> Language Class Initialized
INFO - 2024-05-26 18:27:05 --> Loader Class Initialized
INFO - 2024-05-26 18:27:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:05 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:05 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:05 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-26 18:27:05 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:05 --> Helper loaded: cookie_helper
INFO - 2024-05-26 18:27:05 --> Helper loaded: form_helper
INFO - 2024-05-26 18:27:05 --> Form Validation Class Initialized
INFO - 2024-05-26 18:27:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-26 18:27:05 --> Config Class Initialized
INFO - 2024-05-26 18:27:05 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:05 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:05 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:05 --> URI Class Initialized
INFO - 2024-05-26 18:27:05 --> Router Class Initialized
INFO - 2024-05-26 18:27:05 --> Output Class Initialized
INFO - 2024-05-26 18:27:05 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:05 --> Input Class Initialized
INFO - 2024-05-26 18:27:05 --> Language Class Initialized
INFO - 2024-05-26 18:27:05 --> Loader Class Initialized
INFO - 2024-05-26 18:27:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:05 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:05 --> Controller Class Initialized
INFO - 2024-05-26 18:27:05 --> Database Driver Class Initialized
DEBUG - 2024-05-26 18:27:05 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-26 18:27:05 --> Helper loaded: cookie_helper
INFO - 2024-05-26 18:27:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-26 18:27:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-26 18:27:05 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-26 18:27:05 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:05 --> Total execution time: 0.0148
INFO - 2024-05-26 18:27:06 --> Config Class Initialized
INFO - 2024-05-26 18:27:06 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:06 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:06 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:06 --> URI Class Initialized
INFO - 2024-05-26 18:27:06 --> Router Class Initialized
INFO - 2024-05-26 18:27:06 --> Output Class Initialized
INFO - 2024-05-26 18:27:06 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:06 --> Input Class Initialized
INFO - 2024-05-26 18:27:06 --> Language Class Initialized
INFO - 2024-05-26 18:27:06 --> Loader Class Initialized
INFO - 2024-05-26 18:27:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:06 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:06 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:06 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-26 18:27:06 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:06 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:06 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:06 --> Total execution time: 0.0394
INFO - 2024-05-26 18:27:08 --> Config Class Initialized
INFO - 2024-05-26 18:27:08 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:08 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:08 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:08 --> URI Class Initialized
INFO - 2024-05-26 18:27:08 --> Router Class Initialized
INFO - 2024-05-26 18:27:08 --> Output Class Initialized
INFO - 2024-05-26 18:27:08 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:08 --> Input Class Initialized
INFO - 2024-05-26 18:27:08 --> Language Class Initialized
INFO - 2024-05-26 18:27:08 --> Loader Class Initialized
INFO - 2024-05-26 18:27:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:08 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:08 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-26 18:27:08 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:08 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-26 18:27:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-26 18:27:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-26 18:27:08 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:08 --> Total execution time: 0.0191
INFO - 2024-05-26 18:27:09 --> Config Class Initialized
INFO - 2024-05-26 18:27:09 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:09 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:09 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:09 --> URI Class Initialized
INFO - 2024-05-26 18:27:09 --> Router Class Initialized
INFO - 2024-05-26 18:27:09 --> Output Class Initialized
INFO - 2024-05-26 18:27:09 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:09 --> Input Class Initialized
INFO - 2024-05-26 18:27:09 --> Language Class Initialized
INFO - 2024-05-26 18:27:09 --> Loader Class Initialized
INFO - 2024-05-26 18:27:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:09 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:09 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:09 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-26 18:27:09 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:09 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:09 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:09 --> Total execution time: 0.0202
INFO - 2024-05-26 18:27:11 --> Config Class Initialized
INFO - 2024-05-26 18:27:11 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:11 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:11 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:11 --> URI Class Initialized
INFO - 2024-05-26 18:27:11 --> Router Class Initialized
INFO - 2024-05-26 18:27:11 --> Output Class Initialized
INFO - 2024-05-26 18:27:11 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:11 --> Input Class Initialized
INFO - 2024-05-26 18:27:11 --> Language Class Initialized
INFO - 2024-05-26 18:27:11 --> Loader Class Initialized
INFO - 2024-05-26 18:27:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:11 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:11 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-26 18:27:11 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:11 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-26 18:27:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-26 18:27:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresta.php
INFO - 2024-05-26 18:27:11 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:11 --> Total execution time: 0.0531
INFO - 2024-05-26 18:27:11 --> Config Class Initialized
INFO - 2024-05-26 18:27:11 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:11 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:11 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:11 --> URI Class Initialized
INFO - 2024-05-26 18:27:11 --> Router Class Initialized
INFO - 2024-05-26 18:27:11 --> Output Class Initialized
INFO - 2024-05-26 18:27:11 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:11 --> Input Class Initialized
INFO - 2024-05-26 18:27:11 --> Language Class Initialized
INFO - 2024-05-26 18:27:11 --> Loader Class Initialized
INFO - 2024-05-26 18:27:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:11 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:11 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-26 18:27:11 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:11 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:11 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:11 --> Total execution time: 0.0212
INFO - 2024-05-26 18:27:14 --> Config Class Initialized
INFO - 2024-05-26 18:27:14 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:14 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:14 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:14 --> URI Class Initialized
INFO - 2024-05-26 18:27:14 --> Router Class Initialized
INFO - 2024-05-26 18:27:14 --> Output Class Initialized
INFO - 2024-05-26 18:27:14 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:14 --> Input Class Initialized
INFO - 2024-05-26 18:27:14 --> Language Class Initialized
INFO - 2024-05-26 18:27:14 --> Loader Class Initialized
INFO - 2024-05-26 18:27:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:14 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:14 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-26 18:27:14 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:14 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:15 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:15 --> Total execution time: 0.0511
INFO - 2024-05-26 18:27:19 --> Config Class Initialized
INFO - 2024-05-26 18:27:19 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:19 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:19 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:19 --> URI Class Initialized
INFO - 2024-05-26 18:27:19 --> Router Class Initialized
INFO - 2024-05-26 18:27:19 --> Output Class Initialized
INFO - 2024-05-26 18:27:19 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:19 --> Input Class Initialized
INFO - 2024-05-26 18:27:19 --> Language Class Initialized
INFO - 2024-05-26 18:27:19 --> Loader Class Initialized
INFO - 2024-05-26 18:27:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:19 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:19 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-26 18:27:19 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:19 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:19 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:19 --> Total execution time: 0.0465
INFO - 2024-05-26 18:27:24 --> Config Class Initialized
INFO - 2024-05-26 18:27:24 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:24 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:24 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:24 --> URI Class Initialized
INFO - 2024-05-26 18:27:24 --> Router Class Initialized
INFO - 2024-05-26 18:27:24 --> Output Class Initialized
INFO - 2024-05-26 18:27:24 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:24 --> Input Class Initialized
INFO - 2024-05-26 18:27:24 --> Language Class Initialized
INFO - 2024-05-26 18:27:24 --> Loader Class Initialized
INFO - 2024-05-26 18:27:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:24 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:24 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_prestamistas.php
INFO - 2024-05-26 18:27:24 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:24 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:24 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:24 --> Total execution time: 0.0340
INFO - 2024-05-26 18:27:30 --> Config Class Initialized
INFO - 2024-05-26 18:27:30 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:30 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:30 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:30 --> URI Class Initialized
INFO - 2024-05-26 18:27:30 --> Router Class Initialized
INFO - 2024-05-26 18:27:30 --> Output Class Initialized
INFO - 2024-05-26 18:27:30 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:30 --> Input Class Initialized
INFO - 2024-05-26 18:27:30 --> Language Class Initialized
INFO - 2024-05-26 18:27:30 --> Loader Class Initialized
INFO - 2024-05-26 18:27:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:30 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:30 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:30 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-26 18:27:30 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:30 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:30 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-26 18:27:30 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-26 18:27:30 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-26 18:27:30 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:30 --> Total execution time: 0.0561
INFO - 2024-05-26 18:27:31 --> Config Class Initialized
INFO - 2024-05-26 18:27:31 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:31 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:31 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:31 --> URI Class Initialized
INFO - 2024-05-26 18:27:31 --> Router Class Initialized
INFO - 2024-05-26 18:27:31 --> Output Class Initialized
INFO - 2024-05-26 18:27:31 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:31 --> Input Class Initialized
INFO - 2024-05-26 18:27:31 --> Language Class Initialized
INFO - 2024-05-26 18:27:31 --> Loader Class Initialized
INFO - 2024-05-26 18:27:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:31 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:31 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-26 18:27:31 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:31 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:31 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:31 --> Total execution time: 0.0796
INFO - 2024-05-26 18:27:31 --> Config Class Initialized
INFO - 2024-05-26 18:27:31 --> Hooks Class Initialized
DEBUG - 2024-05-26 18:27:31 --> UTF-8 Support Enabled
INFO - 2024-05-26 18:27:31 --> Utf8 Class Initialized
INFO - 2024-05-26 18:27:31 --> URI Class Initialized
INFO - 2024-05-26 18:27:31 --> Router Class Initialized
INFO - 2024-05-26 18:27:31 --> Output Class Initialized
INFO - 2024-05-26 18:27:31 --> Security Class Initialized
DEBUG - 2024-05-26 18:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 18:27:31 --> Input Class Initialized
INFO - 2024-05-26 18:27:31 --> Language Class Initialized
INFO - 2024-05-26 18:27:31 --> Loader Class Initialized
INFO - 2024-05-26 18:27:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 18:27:31 --> Helper loaded: url_helper
DEBUG - 2024-05-26 18:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 18:27:31 --> Controller Class Initialized
DEBUG - 2024-05-26 18:27:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-26 18:27:31 --> Database Driver Class Initialized
INFO - 2024-05-26 18:27:31 --> Helper loaded: funciones_helper
INFO - 2024-05-26 18:27:31 --> Final output sent to browser
DEBUG - 2024-05-26 18:27:31 --> Total execution time: 0.0265
INFO - 2024-05-26 22:58:44 --> Config Class Initialized
INFO - 2024-05-26 22:58:44 --> Hooks Class Initialized
DEBUG - 2024-05-26 22:58:44 --> UTF-8 Support Enabled
INFO - 2024-05-26 22:58:44 --> Utf8 Class Initialized
INFO - 2024-05-26 22:58:44 --> URI Class Initialized
DEBUG - 2024-05-26 22:58:44 --> No URI present. Default controller set.
INFO - 2024-05-26 22:58:44 --> Router Class Initialized
INFO - 2024-05-26 22:58:44 --> Output Class Initialized
INFO - 2024-05-26 22:58:44 --> Security Class Initialized
DEBUG - 2024-05-26 22:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 22:58:44 --> Input Class Initialized
INFO - 2024-05-26 22:58:44 --> Language Class Initialized
INFO - 2024-05-26 22:58:44 --> Loader Class Initialized
INFO - 2024-05-26 22:58:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 22:58:44 --> Helper loaded: url_helper
DEBUG - 2024-05-26 22:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 22:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 22:58:44 --> Controller Class Initialized
INFO - 2024-05-26 23:32:30 --> Config Class Initialized
INFO - 2024-05-26 23:32:30 --> Hooks Class Initialized
DEBUG - 2024-05-26 23:32:30 --> UTF-8 Support Enabled
INFO - 2024-05-26 23:32:30 --> Utf8 Class Initialized
INFO - 2024-05-26 23:32:30 --> URI Class Initialized
DEBUG - 2024-05-26 23:32:30 --> No URI present. Default controller set.
INFO - 2024-05-26 23:32:30 --> Router Class Initialized
INFO - 2024-05-26 23:32:30 --> Output Class Initialized
INFO - 2024-05-26 23:32:30 --> Security Class Initialized
DEBUG - 2024-05-26 23:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-26 23:32:30 --> Input Class Initialized
INFO - 2024-05-26 23:32:30 --> Language Class Initialized
INFO - 2024-05-26 23:32:30 --> Loader Class Initialized
INFO - 2024-05-26 23:32:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-26 23:32:30 --> Helper loaded: url_helper
DEBUG - 2024-05-26 23:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-26 23:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-26 23:32:30 --> Controller Class Initialized
