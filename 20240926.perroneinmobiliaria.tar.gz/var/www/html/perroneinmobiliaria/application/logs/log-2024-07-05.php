<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-05 06:32:14 --> Config Class Initialized
INFO - 2024-07-05 06:32:14 --> Hooks Class Initialized
DEBUG - 2024-07-05 06:32:14 --> UTF-8 Support Enabled
INFO - 2024-07-05 06:32:14 --> Utf8 Class Initialized
INFO - 2024-07-05 06:32:14 --> URI Class Initialized
DEBUG - 2024-07-05 06:32:14 --> No URI present. Default controller set.
INFO - 2024-07-05 06:32:14 --> Router Class Initialized
INFO - 2024-07-05 06:32:14 --> Output Class Initialized
INFO - 2024-07-05 06:32:14 --> Security Class Initialized
DEBUG - 2024-07-05 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-05 06:32:14 --> Input Class Initialized
INFO - 2024-07-05 06:32:14 --> Language Class Initialized
INFO - 2024-07-05 06:32:14 --> Loader Class Initialized
INFO - 2024-07-05 06:32:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-05 06:32:14 --> Helper loaded: url_helper
DEBUG - 2024-07-05 06:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-05 06:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-05 06:32:14 --> Controller Class Initialized
INFO - 2024-07-05 09:19:54 --> Config Class Initialized
INFO - 2024-07-05 09:19:54 --> Hooks Class Initialized
DEBUG - 2024-07-05 09:19:54 --> UTF-8 Support Enabled
INFO - 2024-07-05 09:19:54 --> Utf8 Class Initialized
INFO - 2024-07-05 09:19:54 --> URI Class Initialized
INFO - 2024-07-05 09:19:54 --> Router Class Initialized
INFO - 2024-07-05 09:19:54 --> Output Class Initialized
INFO - 2024-07-05 09:19:54 --> Security Class Initialized
DEBUG - 2024-07-05 09:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-05 09:19:54 --> Input Class Initialized
INFO - 2024-07-05 09:19:54 --> Language Class Initialized
INFO - 2024-07-05 09:19:54 --> Loader Class Initialized
INFO - 2024-07-05 09:19:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-05 09:19:54 --> Helper loaded: url_helper
DEBUG - 2024-07-05 09:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-05 09:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-05 09:19:54 --> Controller Class Initialized
DEBUG - 2024-07-05 09:19:54 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-05 09:19:54 --> Database Driver Class Initialized
INFO - 2024-07-05 09:19:54 --> Helper loaded: cookie_helper
INFO - 2024-07-05 09:19:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-05 09:19:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-05 09:19:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-07-05 09:19:54 --> Final output sent to browser
DEBUG - 2024-07-05 09:19:54 --> Total execution time: 0.0549
INFO - 2024-07-05 09:19:55 --> Config Class Initialized
INFO - 2024-07-05 09:19:55 --> Hooks Class Initialized
DEBUG - 2024-07-05 09:19:55 --> UTF-8 Support Enabled
INFO - 2024-07-05 09:19:55 --> Utf8 Class Initialized
INFO - 2024-07-05 09:19:55 --> URI Class Initialized
INFO - 2024-07-05 09:19:55 --> Router Class Initialized
INFO - 2024-07-05 09:19:55 --> Output Class Initialized
INFO - 2024-07-05 09:19:55 --> Security Class Initialized
DEBUG - 2024-07-05 09:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-05 09:19:55 --> Input Class Initialized
INFO - 2024-07-05 09:19:55 --> Language Class Initialized
INFO - 2024-07-05 09:19:55 --> Loader Class Initialized
INFO - 2024-07-05 09:19:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-05 09:19:55 --> Helper loaded: url_helper
DEBUG - 2024-07-05 09:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-05 09:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-05 09:19:55 --> Controller Class Initialized
INFO - 2024-07-05 17:23:25 --> Config Class Initialized
INFO - 2024-07-05 17:23:25 --> Hooks Class Initialized
DEBUG - 2024-07-05 17:23:25 --> UTF-8 Support Enabled
INFO - 2024-07-05 17:23:25 --> Utf8 Class Initialized
INFO - 2024-07-05 17:23:25 --> URI Class Initialized
DEBUG - 2024-07-05 17:23:25 --> No URI present. Default controller set.
INFO - 2024-07-05 17:23:25 --> Router Class Initialized
INFO - 2024-07-05 17:23:25 --> Output Class Initialized
INFO - 2024-07-05 17:23:25 --> Security Class Initialized
DEBUG - 2024-07-05 17:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-05 17:23:25 --> Input Class Initialized
INFO - 2024-07-05 17:23:25 --> Language Class Initialized
INFO - 2024-07-05 17:23:25 --> Loader Class Initialized
INFO - 2024-07-05 17:23:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-05 17:23:25 --> Helper loaded: url_helper
DEBUG - 2024-07-05 17:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-05 17:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-05 17:23:25 --> Controller Class Initialized
