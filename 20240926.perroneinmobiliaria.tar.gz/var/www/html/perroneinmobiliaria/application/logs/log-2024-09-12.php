<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-12 14:11:24 --> Config Class Initialized
INFO - 2024-09-12 14:11:24 --> Hooks Class Initialized
DEBUG - 2024-09-12 14:11:24 --> UTF-8 Support Enabled
INFO - 2024-09-12 14:11:24 --> Utf8 Class Initialized
INFO - 2024-09-12 14:11:24 --> URI Class Initialized
DEBUG - 2024-09-12 14:11:24 --> No URI present. Default controller set.
INFO - 2024-09-12 14:11:24 --> Router Class Initialized
INFO - 2024-09-12 14:11:24 --> Output Class Initialized
INFO - 2024-09-12 14:11:24 --> Security Class Initialized
DEBUG - 2024-09-12 14:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 14:11:24 --> Input Class Initialized
INFO - 2024-09-12 14:11:24 --> Language Class Initialized
INFO - 2024-09-12 14:11:24 --> Loader Class Initialized
INFO - 2024-09-12 14:11:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-12 14:11:24 --> Helper loaded: url_helper
DEBUG - 2024-09-12 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 14:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 14:11:24 --> Controller Class Initialized
INFO - 2024-09-12 16:14:04 --> Config Class Initialized
INFO - 2024-09-12 16:14:04 --> Hooks Class Initialized
DEBUG - 2024-09-12 16:14:04 --> UTF-8 Support Enabled
INFO - 2024-09-12 16:14:04 --> Utf8 Class Initialized
INFO - 2024-09-12 16:14:04 --> URI Class Initialized
DEBUG - 2024-09-12 16:14:04 --> No URI present. Default controller set.
INFO - 2024-09-12 16:14:04 --> Router Class Initialized
INFO - 2024-09-12 16:14:04 --> Output Class Initialized
INFO - 2024-09-12 16:14:04 --> Security Class Initialized
DEBUG - 2024-09-12 16:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 16:14:04 --> Input Class Initialized
INFO - 2024-09-12 16:14:04 --> Language Class Initialized
INFO - 2024-09-12 16:14:04 --> Loader Class Initialized
INFO - 2024-09-12 16:14:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-12 16:14:04 --> Helper loaded: url_helper
DEBUG - 2024-09-12 16:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 16:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 16:14:04 --> Controller Class Initialized
