<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-31 01:40:24 --> Config Class Initialized
INFO - 2024-07-31 01:40:24 --> Hooks Class Initialized
DEBUG - 2024-07-31 01:40:24 --> UTF-8 Support Enabled
INFO - 2024-07-31 01:40:24 --> Utf8 Class Initialized
INFO - 2024-07-31 01:40:24 --> URI Class Initialized
DEBUG - 2024-07-31 01:40:24 --> No URI present. Default controller set.
INFO - 2024-07-31 01:40:24 --> Router Class Initialized
INFO - 2024-07-31 01:40:24 --> Output Class Initialized
INFO - 2024-07-31 01:40:24 --> Security Class Initialized
DEBUG - 2024-07-31 01:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 01:40:24 --> Input Class Initialized
INFO - 2024-07-31 01:40:24 --> Language Class Initialized
INFO - 2024-07-31 01:40:24 --> Loader Class Initialized
INFO - 2024-07-31 01:40:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-31 01:40:24 --> Helper loaded: url_helper
DEBUG - 2024-07-31 01:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-31 01:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 01:40:24 --> Controller Class Initialized
INFO - 2024-07-31 01:40:29 --> Config Class Initialized
INFO - 2024-07-31 01:40:29 --> Hooks Class Initialized
DEBUG - 2024-07-31 01:40:29 --> UTF-8 Support Enabled
INFO - 2024-07-31 01:40:29 --> Utf8 Class Initialized
INFO - 2024-07-31 01:40:29 --> URI Class Initialized
DEBUG - 2024-07-31 01:40:29 --> No URI present. Default controller set.
INFO - 2024-07-31 01:40:29 --> Router Class Initialized
INFO - 2024-07-31 01:40:29 --> Output Class Initialized
INFO - 2024-07-31 01:40:29 --> Security Class Initialized
DEBUG - 2024-07-31 01:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 01:40:29 --> Input Class Initialized
INFO - 2024-07-31 01:40:29 --> Language Class Initialized
INFO - 2024-07-31 01:40:29 --> Loader Class Initialized
INFO - 2024-07-31 01:40:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-31 01:40:29 --> Helper loaded: url_helper
DEBUG - 2024-07-31 01:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-31 01:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 01:40:29 --> Controller Class Initialized
INFO - 2024-07-31 21:09:46 --> Config Class Initialized
INFO - 2024-07-31 21:09:46 --> Hooks Class Initialized
DEBUG - 2024-07-31 21:09:46 --> UTF-8 Support Enabled
INFO - 2024-07-31 21:09:46 --> Utf8 Class Initialized
INFO - 2024-07-31 21:09:46 --> URI Class Initialized
DEBUG - 2024-07-31 21:09:46 --> No URI present. Default controller set.
INFO - 2024-07-31 21:09:46 --> Router Class Initialized
INFO - 2024-07-31 21:09:46 --> Output Class Initialized
INFO - 2024-07-31 21:09:46 --> Security Class Initialized
DEBUG - 2024-07-31 21:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 21:09:46 --> Input Class Initialized
INFO - 2024-07-31 21:09:46 --> Language Class Initialized
INFO - 2024-07-31 21:09:46 --> Loader Class Initialized
INFO - 2024-07-31 21:09:46 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-31 21:09:46 --> Helper loaded: url_helper
DEBUG - 2024-07-31 21:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-31 21:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 21:09:46 --> Controller Class Initialized
INFO - 2024-07-31 21:09:47 --> Config Class Initialized
INFO - 2024-07-31 21:09:47 --> Hooks Class Initialized
DEBUG - 2024-07-31 21:09:47 --> UTF-8 Support Enabled
INFO - 2024-07-31 21:09:47 --> Utf8 Class Initialized
INFO - 2024-07-31 21:09:47 --> URI Class Initialized
DEBUG - 2024-07-31 21:09:47 --> No URI present. Default controller set.
INFO - 2024-07-31 21:09:47 --> Router Class Initialized
INFO - 2024-07-31 21:09:47 --> Output Class Initialized
INFO - 2024-07-31 21:09:47 --> Security Class Initialized
DEBUG - 2024-07-31 21:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 21:09:47 --> Input Class Initialized
INFO - 2024-07-31 21:09:47 --> Language Class Initialized
INFO - 2024-07-31 21:09:47 --> Loader Class Initialized
INFO - 2024-07-31 21:09:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-31 21:09:47 --> Helper loaded: url_helper
DEBUG - 2024-07-31 21:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-31 21:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 21:09:47 --> Controller Class Initialized
