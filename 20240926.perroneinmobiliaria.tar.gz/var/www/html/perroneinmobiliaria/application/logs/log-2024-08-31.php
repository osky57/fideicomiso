<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-31 08:46:19 --> Config Class Initialized
INFO - 2024-08-31 08:46:19 --> Hooks Class Initialized
DEBUG - 2024-08-31 08:46:20 --> UTF-8 Support Enabled
INFO - 2024-08-31 08:46:20 --> Utf8 Class Initialized
INFO - 2024-08-31 08:46:20 --> URI Class Initialized
DEBUG - 2024-08-31 08:46:20 --> No URI present. Default controller set.
INFO - 2024-08-31 08:46:20 --> Router Class Initialized
INFO - 2024-08-31 08:46:20 --> Output Class Initialized
INFO - 2024-08-31 08:46:20 --> Security Class Initialized
DEBUG - 2024-08-31 08:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-31 08:46:20 --> Input Class Initialized
INFO - 2024-08-31 08:46:21 --> Language Class Initialized
INFO - 2024-08-31 08:46:21 --> Loader Class Initialized
INFO - 2024-08-31 08:46:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-31 08:46:21 --> Helper loaded: url_helper
DEBUG - 2024-08-31 08:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-31 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-31 08:46:21 --> Controller Class Initialized
