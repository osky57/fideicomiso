<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-01 05:22:42 --> Config Class Initialized
INFO - 2024-08-01 05:22:42 --> Hooks Class Initialized
DEBUG - 2024-08-01 05:22:42 --> UTF-8 Support Enabled
INFO - 2024-08-01 05:22:42 --> Utf8 Class Initialized
INFO - 2024-08-01 05:22:42 --> URI Class Initialized
DEBUG - 2024-08-01 05:22:42 --> No URI present. Default controller set.
INFO - 2024-08-01 05:22:42 --> Router Class Initialized
INFO - 2024-08-01 05:22:42 --> Output Class Initialized
INFO - 2024-08-01 05:22:42 --> Security Class Initialized
DEBUG - 2024-08-01 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 05:22:42 --> Input Class Initialized
INFO - 2024-08-01 05:22:42 --> Language Class Initialized
INFO - 2024-08-01 05:22:42 --> Loader Class Initialized
INFO - 2024-08-01 05:22:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-01 05:22:42 --> Helper loaded: url_helper
DEBUG - 2024-08-01 05:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-01 05:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 05:22:42 --> Controller Class Initialized
INFO - 2024-08-01 07:59:38 --> Config Class Initialized
INFO - 2024-08-01 07:59:38 --> Hooks Class Initialized
DEBUG - 2024-08-01 07:59:38 --> UTF-8 Support Enabled
INFO - 2024-08-01 07:59:38 --> Utf8 Class Initialized
INFO - 2024-08-01 07:59:38 --> URI Class Initialized
DEBUG - 2024-08-01 07:59:38 --> No URI present. Default controller set.
INFO - 2024-08-01 07:59:38 --> Router Class Initialized
INFO - 2024-08-01 07:59:38 --> Output Class Initialized
INFO - 2024-08-01 07:59:38 --> Security Class Initialized
DEBUG - 2024-08-01 07:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 07:59:38 --> Input Class Initialized
INFO - 2024-08-01 07:59:38 --> Language Class Initialized
INFO - 2024-08-01 07:59:38 --> Loader Class Initialized
INFO - 2024-08-01 07:59:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-01 07:59:38 --> Helper loaded: url_helper
DEBUG - 2024-08-01 07:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-01 07:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 07:59:38 --> Controller Class Initialized
INFO - 2024-08-01 07:59:42 --> Config Class Initialized
INFO - 2024-08-01 07:59:42 --> Hooks Class Initialized
DEBUG - 2024-08-01 07:59:42 --> UTF-8 Support Enabled
INFO - 2024-08-01 07:59:42 --> Utf8 Class Initialized
INFO - 2024-08-01 07:59:42 --> URI Class Initialized
DEBUG - 2024-08-01 07:59:42 --> No URI present. Default controller set.
INFO - 2024-08-01 07:59:42 --> Router Class Initialized
INFO - 2024-08-01 07:59:42 --> Output Class Initialized
INFO - 2024-08-01 07:59:42 --> Security Class Initialized
DEBUG - 2024-08-01 07:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 07:59:42 --> Input Class Initialized
INFO - 2024-08-01 07:59:42 --> Language Class Initialized
INFO - 2024-08-01 07:59:42 --> Loader Class Initialized
INFO - 2024-08-01 07:59:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-01 07:59:42 --> Helper loaded: url_helper
DEBUG - 2024-08-01 07:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-01 07:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 07:59:42 --> Controller Class Initialized
INFO - 2024-08-01 07:59:44 --> Config Class Initialized
INFO - 2024-08-01 07:59:44 --> Hooks Class Initialized
DEBUG - 2024-08-01 07:59:44 --> UTF-8 Support Enabled
INFO - 2024-08-01 07:59:44 --> Utf8 Class Initialized
INFO - 2024-08-01 07:59:44 --> URI Class Initialized
DEBUG - 2024-08-01 07:59:44 --> No URI present. Default controller set.
INFO - 2024-08-01 07:59:44 --> Router Class Initialized
INFO - 2024-08-01 07:59:44 --> Output Class Initialized
INFO - 2024-08-01 07:59:44 --> Security Class Initialized
DEBUG - 2024-08-01 07:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 07:59:44 --> Input Class Initialized
INFO - 2024-08-01 07:59:44 --> Language Class Initialized
INFO - 2024-08-01 07:59:44 --> Loader Class Initialized
INFO - 2024-08-01 07:59:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-01 07:59:44 --> Helper loaded: url_helper
DEBUG - 2024-08-01 07:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-01 07:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 07:59:44 --> Controller Class Initialized
INFO - 2024-08-01 11:36:29 --> Config Class Initialized
INFO - 2024-08-01 11:36:29 --> Hooks Class Initialized
DEBUG - 2024-08-01 11:36:29 --> UTF-8 Support Enabled
INFO - 2024-08-01 11:36:29 --> Utf8 Class Initialized
INFO - 2024-08-01 11:36:29 --> URI Class Initialized
DEBUG - 2024-08-01 11:36:29 --> No URI present. Default controller set.
INFO - 2024-08-01 11:36:29 --> Router Class Initialized
INFO - 2024-08-01 11:36:29 --> Output Class Initialized
INFO - 2024-08-01 11:36:29 --> Security Class Initialized
DEBUG - 2024-08-01 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 11:36:29 --> Input Class Initialized
INFO - 2024-08-01 11:36:29 --> Language Class Initialized
INFO - 2024-08-01 11:36:29 --> Loader Class Initialized
INFO - 2024-08-01 11:36:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-01 11:36:29 --> Helper loaded: url_helper
DEBUG - 2024-08-01 11:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-01 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 11:36:29 --> Controller Class Initialized
