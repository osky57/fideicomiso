<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-09 21:14:09 --> Config Class Initialized
INFO - 2024-06-09 21:14:09 --> Hooks Class Initialized
DEBUG - 2024-06-09 21:14:09 --> UTF-8 Support Enabled
INFO - 2024-06-09 21:14:09 --> Utf8 Class Initialized
INFO - 2024-06-09 21:14:09 --> URI Class Initialized
DEBUG - 2024-06-09 21:14:09 --> No URI present. Default controller set.
INFO - 2024-06-09 21:14:09 --> Router Class Initialized
INFO - 2024-06-09 21:14:09 --> Output Class Initialized
INFO - 2024-06-09 21:14:09 --> Security Class Initialized
DEBUG - 2024-06-09 21:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-09 21:14:09 --> Input Class Initialized
INFO - 2024-06-09 21:14:09 --> Language Class Initialized
INFO - 2024-06-09 21:14:09 --> Loader Class Initialized
INFO - 2024-06-09 21:14:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-09 21:14:09 --> Helper loaded: url_helper
DEBUG - 2024-06-09 21:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-09 21:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-09 21:14:09 --> Controller Class Initialized
