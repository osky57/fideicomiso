<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-07 04:06:54 --> Config Class Initialized
INFO - 2024-09-07 04:06:54 --> Hooks Class Initialized
DEBUG - 2024-09-07 04:06:54 --> UTF-8 Support Enabled
INFO - 2024-09-07 04:06:54 --> Utf8 Class Initialized
INFO - 2024-09-07 04:06:54 --> URI Class Initialized
DEBUG - 2024-09-07 04:06:54 --> No URI present. Default controller set.
INFO - 2024-09-07 04:06:54 --> Router Class Initialized
INFO - 2024-09-07 04:06:54 --> Output Class Initialized
INFO - 2024-09-07 04:06:54 --> Security Class Initialized
DEBUG - 2024-09-07 04:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 04:06:54 --> Input Class Initialized
INFO - 2024-09-07 04:06:54 --> Language Class Initialized
INFO - 2024-09-07 04:06:54 --> Loader Class Initialized
INFO - 2024-09-07 04:06:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-07 04:06:54 --> Helper loaded: url_helper
DEBUG - 2024-09-07 04:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 04:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 04:06:54 --> Controller Class Initialized
INFO - 2024-09-07 06:20:14 --> Config Class Initialized
INFO - 2024-09-07 06:20:14 --> Hooks Class Initialized
DEBUG - 2024-09-07 06:20:14 --> UTF-8 Support Enabled
INFO - 2024-09-07 06:20:14 --> Utf8 Class Initialized
INFO - 2024-09-07 06:20:14 --> URI Class Initialized
DEBUG - 2024-09-07 06:20:14 --> No URI present. Default controller set.
INFO - 2024-09-07 06:20:14 --> Router Class Initialized
INFO - 2024-09-07 06:20:14 --> Output Class Initialized
INFO - 2024-09-07 06:20:14 --> Security Class Initialized
DEBUG - 2024-09-07 06:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 06:20:14 --> Input Class Initialized
INFO - 2024-09-07 06:20:14 --> Language Class Initialized
INFO - 2024-09-07 06:20:14 --> Loader Class Initialized
INFO - 2024-09-07 06:20:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-07 06:20:14 --> Helper loaded: url_helper
DEBUG - 2024-09-07 06:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 06:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 06:20:14 --> Controller Class Initialized
INFO - 2024-09-07 06:20:14 --> Config Class Initialized
INFO - 2024-09-07 06:20:14 --> Hooks Class Initialized
DEBUG - 2024-09-07 06:20:14 --> UTF-8 Support Enabled
INFO - 2024-09-07 06:20:14 --> Utf8 Class Initialized
INFO - 2024-09-07 06:20:14 --> URI Class Initialized
DEBUG - 2024-09-07 06:20:14 --> No URI present. Default controller set.
INFO - 2024-09-07 06:20:14 --> Router Class Initialized
INFO - 2024-09-07 06:20:14 --> Output Class Initialized
INFO - 2024-09-07 06:20:14 --> Security Class Initialized
DEBUG - 2024-09-07 06:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 06:20:14 --> Input Class Initialized
INFO - 2024-09-07 06:20:14 --> Language Class Initialized
INFO - 2024-09-07 06:20:14 --> Loader Class Initialized
INFO - 2024-09-07 06:20:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-07 06:20:14 --> Helper loaded: url_helper
DEBUG - 2024-09-07 06:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 06:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 06:20:14 --> Controller Class Initialized
INFO - 2024-09-07 07:44:53 --> Config Class Initialized
INFO - 2024-09-07 07:44:53 --> Hooks Class Initialized
DEBUG - 2024-09-07 07:44:53 --> UTF-8 Support Enabled
INFO - 2024-09-07 07:44:53 --> Utf8 Class Initialized
INFO - 2024-09-07 07:44:53 --> URI Class Initialized
DEBUG - 2024-09-07 07:44:53 --> No URI present. Default controller set.
INFO - 2024-09-07 07:44:53 --> Router Class Initialized
INFO - 2024-09-07 07:44:53 --> Output Class Initialized
INFO - 2024-09-07 07:44:53 --> Security Class Initialized
DEBUG - 2024-09-07 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 07:44:53 --> Input Class Initialized
INFO - 2024-09-07 07:44:53 --> Language Class Initialized
INFO - 2024-09-07 07:44:53 --> Loader Class Initialized
INFO - 2024-09-07 07:44:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-07 07:44:53 --> Helper loaded: url_helper
DEBUG - 2024-09-07 07:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 07:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 07:44:53 --> Controller Class Initialized
INFO - 2024-09-07 19:12:33 --> Config Class Initialized
INFO - 2024-09-07 19:12:33 --> Hooks Class Initialized
DEBUG - 2024-09-07 19:12:33 --> UTF-8 Support Enabled
INFO - 2024-09-07 19:12:33 --> Utf8 Class Initialized
INFO - 2024-09-07 19:12:33 --> URI Class Initialized
DEBUG - 2024-09-07 19:12:33 --> No URI present. Default controller set.
INFO - 2024-09-07 19:12:33 --> Router Class Initialized
INFO - 2024-09-07 19:12:33 --> Output Class Initialized
INFO - 2024-09-07 19:12:33 --> Security Class Initialized
DEBUG - 2024-09-07 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 19:12:33 --> Input Class Initialized
INFO - 2024-09-07 19:12:33 --> Language Class Initialized
INFO - 2024-09-07 19:12:33 --> Loader Class Initialized
INFO - 2024-09-07 19:12:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-07 19:12:33 --> Helper loaded: url_helper
DEBUG - 2024-09-07 19:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 19:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 19:12:33 --> Controller Class Initialized
INFO - 2024-09-07 19:12:33 --> Config Class Initialized
INFO - 2024-09-07 19:12:33 --> Hooks Class Initialized
DEBUG - 2024-09-07 19:12:33 --> UTF-8 Support Enabled
INFO - 2024-09-07 19:12:33 --> Utf8 Class Initialized
INFO - 2024-09-07 19:12:33 --> URI Class Initialized
DEBUG - 2024-09-07 19:12:33 --> No URI present. Default controller set.
INFO - 2024-09-07 19:12:33 --> Router Class Initialized
INFO - 2024-09-07 19:12:33 --> Output Class Initialized
INFO - 2024-09-07 19:12:33 --> Security Class Initialized
DEBUG - 2024-09-07 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 19:12:33 --> Input Class Initialized
INFO - 2024-09-07 19:12:33 --> Language Class Initialized
INFO - 2024-09-07 19:12:33 --> Loader Class Initialized
INFO - 2024-09-07 19:12:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-07 19:12:33 --> Helper loaded: url_helper
DEBUG - 2024-09-07 19:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 19:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 19:12:33 --> Controller Class Initialized
