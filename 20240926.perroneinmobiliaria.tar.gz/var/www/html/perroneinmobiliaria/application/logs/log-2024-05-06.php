<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-06 04:41:10 --> Config Class Initialized
INFO - 2024-05-06 04:41:10 --> Hooks Class Initialized
DEBUG - 2024-05-06 04:41:10 --> UTF-8 Support Enabled
INFO - 2024-05-06 04:41:10 --> Utf8 Class Initialized
INFO - 2024-05-06 04:41:10 --> URI Class Initialized
DEBUG - 2024-05-06 04:41:10 --> No URI present. Default controller set.
INFO - 2024-05-06 04:41:10 --> Router Class Initialized
INFO - 2024-05-06 04:41:10 --> Output Class Initialized
INFO - 2024-05-06 04:41:10 --> Security Class Initialized
DEBUG - 2024-05-06 04:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 04:41:10 --> Input Class Initialized
INFO - 2024-05-06 04:41:10 --> Language Class Initialized
INFO - 2024-05-06 04:41:10 --> Loader Class Initialized
INFO - 2024-05-06 04:41:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 04:41:10 --> Helper loaded: url_helper
DEBUG - 2024-05-06 04:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 04:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 04:41:10 --> Controller Class Initialized
INFO - 2024-05-06 09:49:33 --> Config Class Initialized
INFO - 2024-05-06 09:49:33 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:33 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:33 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:33 --> URI Class Initialized
DEBUG - 2024-05-06 09:49:33 --> No URI present. Default controller set.
INFO - 2024-05-06 09:49:33 --> Router Class Initialized
INFO - 2024-05-06 09:49:33 --> Output Class Initialized
INFO - 2024-05-06 09:49:33 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:33 --> Input Class Initialized
INFO - 2024-05-06 09:49:33 --> Language Class Initialized
INFO - 2024-05-06 09:49:33 --> Loader Class Initialized
INFO - 2024-05-06 09:49:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:33 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:33 --> Controller Class Initialized
INFO - 2024-05-06 09:49:33 --> Config Class Initialized
INFO - 2024-05-06 09:49:33 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:33 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:33 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:33 --> URI Class Initialized
INFO - 2024-05-06 09:49:33 --> Router Class Initialized
INFO - 2024-05-06 09:49:33 --> Output Class Initialized
INFO - 2024-05-06 09:49:33 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:33 --> Input Class Initialized
INFO - 2024-05-06 09:49:33 --> Language Class Initialized
INFO - 2024-05-06 09:49:33 --> Loader Class Initialized
INFO - 2024-05-06 09:49:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:33 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:33 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-06 09:49:33 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:33 --> Helper loaded: cookie_helper
INFO - 2024-05-06 09:49:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:49:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:49:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-06 09:49:33 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:33 --> Total execution time: 0.0471
INFO - 2024-05-06 09:49:34 --> Config Class Initialized
INFO - 2024-05-06 09:49:34 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:34 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:34 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:34 --> URI Class Initialized
INFO - 2024-05-06 09:49:34 --> Router Class Initialized
INFO - 2024-05-06 09:49:34 --> Output Class Initialized
INFO - 2024-05-06 09:49:34 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:34 --> Input Class Initialized
INFO - 2024-05-06 09:49:34 --> Language Class Initialized
INFO - 2024-05-06 09:49:34 --> Loader Class Initialized
INFO - 2024-05-06 09:49:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:34 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:34 --> Controller Class Initialized
INFO - 2024-05-06 09:49:35 --> Config Class Initialized
INFO - 2024-05-06 09:49:35 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:35 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:35 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:35 --> URI Class Initialized
INFO - 2024-05-06 09:49:35 --> Router Class Initialized
INFO - 2024-05-06 09:49:35 --> Output Class Initialized
INFO - 2024-05-06 09:49:35 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:35 --> Input Class Initialized
INFO - 2024-05-06 09:49:35 --> Language Class Initialized
INFO - 2024-05-06 09:49:35 --> Loader Class Initialized
INFO - 2024-05-06 09:49:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:35 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:35 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-06 09:49:35 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:35 --> Helper loaded: cookie_helper
INFO - 2024-05-06 09:49:35 --> Helper loaded: form_helper
INFO - 2024-05-06 09:49:35 --> Form Validation Class Initialized
INFO - 2024-05-06 09:49:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-06 09:49:35 --> Config Class Initialized
INFO - 2024-05-06 09:49:35 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:35 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:35 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:35 --> URI Class Initialized
INFO - 2024-05-06 09:49:35 --> Router Class Initialized
INFO - 2024-05-06 09:49:35 --> Output Class Initialized
INFO - 2024-05-06 09:49:35 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:35 --> Input Class Initialized
INFO - 2024-05-06 09:49:35 --> Language Class Initialized
INFO - 2024-05-06 09:49:35 --> Loader Class Initialized
INFO - 2024-05-06 09:49:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:35 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:35 --> Controller Class Initialized
INFO - 2024-05-06 09:49:35 --> Database Driver Class Initialized
DEBUG - 2024-05-06 09:49:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-06 09:49:35 --> Helper loaded: cookie_helper
INFO - 2024-05-06 09:49:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:49:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:49:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-06 09:49:35 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:35 --> Total execution time: 0.0137
INFO - 2024-05-06 09:49:36 --> Config Class Initialized
INFO - 2024-05-06 09:49:36 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:36 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:36 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:36 --> URI Class Initialized
INFO - 2024-05-06 09:49:36 --> Router Class Initialized
INFO - 2024-05-06 09:49:36 --> Output Class Initialized
INFO - 2024-05-06 09:49:36 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:36 --> Input Class Initialized
INFO - 2024-05-06 09:49:36 --> Language Class Initialized
INFO - 2024-05-06 09:49:36 --> Loader Class Initialized
INFO - 2024-05-06 09:49:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:36 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:36 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:49:36 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:36 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:49:36 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:36 --> Total execution time: 0.0419
INFO - 2024-05-06 09:49:39 --> Config Class Initialized
INFO - 2024-05-06 09:49:39 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:39 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:39 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:39 --> URI Class Initialized
INFO - 2024-05-06 09:49:39 --> Router Class Initialized
INFO - 2024-05-06 09:49:39 --> Output Class Initialized
INFO - 2024-05-06 09:49:39 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:39 --> Input Class Initialized
INFO - 2024-05-06 09:49:39 --> Language Class Initialized
INFO - 2024-05-06 09:49:39 --> Loader Class Initialized
INFO - 2024-05-06 09:49:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:39 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:39 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:49:39 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:39 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:49:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:49:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:49:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-06 09:49:39 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:39 --> Total execution time: 0.0199
INFO - 2024-05-06 09:49:40 --> Config Class Initialized
INFO - 2024-05-06 09:49:40 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:40 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:40 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:40 --> URI Class Initialized
INFO - 2024-05-06 09:49:40 --> Router Class Initialized
INFO - 2024-05-06 09:49:40 --> Output Class Initialized
INFO - 2024-05-06 09:49:40 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:40 --> Input Class Initialized
INFO - 2024-05-06 09:49:40 --> Language Class Initialized
INFO - 2024-05-06 09:49:40 --> Loader Class Initialized
INFO - 2024-05-06 09:49:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:40 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:40 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:49:40 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:40 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:49:40 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:40 --> Total execution time: 0.0211
INFO - 2024-05-06 09:49:58 --> Config Class Initialized
INFO - 2024-05-06 09:49:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:58 --> URI Class Initialized
INFO - 2024-05-06 09:49:58 --> Router Class Initialized
INFO - 2024-05-06 09:49:58 --> Output Class Initialized
INFO - 2024-05-06 09:49:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:58 --> Input Class Initialized
INFO - 2024-05-06 09:49:58 --> Language Class Initialized
INFO - 2024-05-06 09:49:58 --> Loader Class Initialized
INFO - 2024-05-06 09:49:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:49:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:49:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:49:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:49:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/presupuestos.php
INFO - 2024-05-06 09:49:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:58 --> Total execution time: 0.0509
INFO - 2024-05-06 09:49:58 --> Config Class Initialized
INFO - 2024-05-06 09:49:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:58 --> URI Class Initialized
INFO - 2024-05-06 09:49:58 --> Router Class Initialized
INFO - 2024-05-06 09:49:58 --> Output Class Initialized
INFO - 2024-05-06 09:49:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:58 --> Input Class Initialized
INFO - 2024-05-06 09:49:58 --> Language Class Initialized
INFO - 2024-05-06 09:49:58 --> Loader Class Initialized
INFO - 2024-05-06 09:49:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:49:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:49:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:58 --> Total execution time: 0.0242
INFO - 2024-05-06 09:49:58 --> Config Class Initialized
INFO - 2024-05-06 09:49:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:49:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:49:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:49:58 --> URI Class Initialized
INFO - 2024-05-06 09:49:58 --> Router Class Initialized
INFO - 2024-05-06 09:49:58 --> Output Class Initialized
INFO - 2024-05-06 09:49:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:49:58 --> Input Class Initialized
INFO - 2024-05-06 09:49:58 --> Language Class Initialized
INFO - 2024-05-06 09:49:58 --> Loader Class Initialized
INFO - 2024-05-06 09:49:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:49:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:49:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:49:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:49:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:49:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:49:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:49:58 --> Total execution time: 0.0212
INFO - 2024-05-06 09:50:04 --> Config Class Initialized
INFO - 2024-05-06 09:50:04 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:04 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:04 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:04 --> URI Class Initialized
INFO - 2024-05-06 09:50:04 --> Router Class Initialized
INFO - 2024-05-06 09:50:04 --> Output Class Initialized
INFO - 2024-05-06 09:50:04 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:04 --> Input Class Initialized
INFO - 2024-05-06 09:50:04 --> Language Class Initialized
INFO - 2024-05-06 09:50:04 --> Loader Class Initialized
INFO - 2024-05-06 09:50:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:04 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:04 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:50:04 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:04 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:50:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:50:04 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-06 09:50:04 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:04 --> Total execution time: 0.0263
INFO - 2024-05-06 09:50:04 --> Config Class Initialized
INFO - 2024-05-06 09:50:04 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:04 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:04 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:04 --> URI Class Initialized
INFO - 2024-05-06 09:50:04 --> Router Class Initialized
INFO - 2024-05-06 09:50:04 --> Output Class Initialized
INFO - 2024-05-06 09:50:04 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:04 --> Input Class Initialized
INFO - 2024-05-06 09:50:04 --> Language Class Initialized
INFO - 2024-05-06 09:50:04 --> Loader Class Initialized
INFO - 2024-05-06 09:50:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:04 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:04 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:50:04 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:04 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:04 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:04 --> Total execution time: 0.0253
INFO - 2024-05-06 09:50:08 --> Config Class Initialized
INFO - 2024-05-06 09:50:08 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:08 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:08 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:08 --> URI Class Initialized
INFO - 2024-05-06 09:50:08 --> Router Class Initialized
INFO - 2024-05-06 09:50:08 --> Output Class Initialized
INFO - 2024-05-06 09:50:08 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:08 --> Input Class Initialized
INFO - 2024-05-06 09:50:08 --> Language Class Initialized
INFO - 2024-05-06 09:50:08 --> Loader Class Initialized
INFO - 2024-05-06 09:50:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:08 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:08 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:50:08 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:08 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:50:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:50:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-06 09:50:08 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:08 --> Total execution time: 0.0237
INFO - 2024-05-06 09:50:08 --> Config Class Initialized
INFO - 2024-05-06 09:50:08 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:08 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:08 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:08 --> URI Class Initialized
INFO - 2024-05-06 09:50:08 --> Router Class Initialized
INFO - 2024-05-06 09:50:08 --> Output Class Initialized
INFO - 2024-05-06 09:50:08 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:08 --> Input Class Initialized
INFO - 2024-05-06 09:50:08 --> Language Class Initialized
INFO - 2024-05-06 09:50:08 --> Loader Class Initialized
INFO - 2024-05-06 09:50:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:08 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:08 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:50:08 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:08 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:08 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:08 --> Total execution time: 0.0230
INFO - 2024-05-06 09:50:10 --> Config Class Initialized
INFO - 2024-05-06 09:50:10 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:10 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:10 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:10 --> URI Class Initialized
INFO - 2024-05-06 09:50:10 --> Router Class Initialized
INFO - 2024-05-06 09:50:10 --> Output Class Initialized
INFO - 2024-05-06 09:50:10 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:10 --> Input Class Initialized
INFO - 2024-05-06 09:50:10 --> Language Class Initialized
INFO - 2024-05-06 09:50:10 --> Loader Class Initialized
INFO - 2024-05-06 09:50:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:10 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:10 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:50:10 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:10 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:50:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:50:10 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/presupuestos.php
INFO - 2024-05-06 09:50:10 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:10 --> Total execution time: 0.0486
INFO - 2024-05-06 09:50:10 --> Config Class Initialized
INFO - 2024-05-06 09:50:10 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:10 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:10 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:10 --> URI Class Initialized
INFO - 2024-05-06 09:50:10 --> Router Class Initialized
INFO - 2024-05-06 09:50:10 --> Output Class Initialized
INFO - 2024-05-06 09:50:10 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:10 --> Input Class Initialized
INFO - 2024-05-06 09:50:10 --> Language Class Initialized
INFO - 2024-05-06 09:50:10 --> Loader Class Initialized
INFO - 2024-05-06 09:50:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:10 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:10 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:50:10 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:10 --> Config Class Initialized
INFO - 2024-05-06 09:50:10 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:10 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:10 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:10 --> URI Class Initialized
INFO - 2024-05-06 09:50:10 --> Router Class Initialized
INFO - 2024-05-06 09:50:10 --> Output Class Initialized
INFO - 2024-05-06 09:50:10 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:10 --> Input Class Initialized
INFO - 2024-05-06 09:50:10 --> Language Class Initialized
INFO - 2024-05-06 09:50:10 --> Loader Class Initialized
INFO - 2024-05-06 09:50:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:10 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:10 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:10 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:10 --> Total execution time: 0.0240
INFO - 2024-05-06 09:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:10 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:50:10 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:10 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:10 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:10 --> Total execution time: 0.0500
INFO - 2024-05-06 09:50:13 --> Config Class Initialized
INFO - 2024-05-06 09:50:13 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:13 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:13 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:13 --> URI Class Initialized
INFO - 2024-05-06 09:50:13 --> Router Class Initialized
INFO - 2024-05-06 09:50:13 --> Output Class Initialized
INFO - 2024-05-06 09:50:13 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:13 --> Input Class Initialized
INFO - 2024-05-06 09:50:13 --> Language Class Initialized
INFO - 2024-05-06 09:50:13 --> Loader Class Initialized
INFO - 2024-05-06 09:50:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:13 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:13 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:50:13 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:13 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:13 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:13 --> Total execution time: 0.0256
INFO - 2024-05-06 09:50:14 --> Config Class Initialized
INFO - 2024-05-06 09:50:14 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:14 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:14 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:14 --> URI Class Initialized
INFO - 2024-05-06 09:50:14 --> Router Class Initialized
INFO - 2024-05-06 09:50:14 --> Output Class Initialized
INFO - 2024-05-06 09:50:14 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:14 --> Input Class Initialized
INFO - 2024-05-06 09:50:14 --> Language Class Initialized
INFO - 2024-05-06 09:50:14 --> Loader Class Initialized
INFO - 2024-05-06 09:50:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:14 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:14 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:50:14 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:14 --> Helper loaded: funciones_helper
ERROR - 2024-05-06 09:50:14 --> Severity: Warning --> Creating default object from empty value /var/www/html/perroneinmobiliaria/application/controllers/Presupuestos.php 98
INFO - 2024-05-06 09:50:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-06 09:50:14 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:14 --> Total execution time: 0.0250
INFO - 2024-05-06 09:50:35 --> Config Class Initialized
INFO - 2024-05-06 09:50:35 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:35 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:35 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:35 --> URI Class Initialized
INFO - 2024-05-06 09:50:35 --> Router Class Initialized
INFO - 2024-05-06 09:50:35 --> Output Class Initialized
INFO - 2024-05-06 09:50:35 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:35 --> Input Class Initialized
INFO - 2024-05-06 09:50:35 --> Language Class Initialized
INFO - 2024-05-06 09:50:35 --> Loader Class Initialized
INFO - 2024-05-06 09:50:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:35 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:35 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:50:35 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:35 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:35 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:35 --> Total execution time: 0.0378
INFO - 2024-05-06 09:50:35 --> Config Class Initialized
INFO - 2024-05-06 09:50:35 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:35 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:35 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:35 --> URI Class Initialized
INFO - 2024-05-06 09:50:35 --> Router Class Initialized
INFO - 2024-05-06 09:50:35 --> Output Class Initialized
INFO - 2024-05-06 09:50:35 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:35 --> Input Class Initialized
INFO - 2024-05-06 09:50:35 --> Language Class Initialized
INFO - 2024-05-06 09:50:35 --> Loader Class Initialized
INFO - 2024-05-06 09:50:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:35 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:35 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-06 09:50:35 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:35 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:35 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:35 --> Total execution time: 0.0266
INFO - 2024-05-06 09:50:49 --> Config Class Initialized
INFO - 2024-05-06 09:50:49 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:49 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:49 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:49 --> URI Class Initialized
INFO - 2024-05-06 09:50:49 --> Router Class Initialized
INFO - 2024-05-06 09:50:49 --> Output Class Initialized
INFO - 2024-05-06 09:50:49 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:49 --> Input Class Initialized
INFO - 2024-05-06 09:50:49 --> Language Class Initialized
INFO - 2024-05-06 09:50:49 --> Loader Class Initialized
INFO - 2024-05-06 09:50:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:49 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:49 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:50:49 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:49 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:49 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:50:49 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:50:49 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-06 09:50:49 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:49 --> Total execution time: 0.0688
INFO - 2024-05-06 09:50:49 --> Config Class Initialized
INFO - 2024-05-06 09:50:49 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:49 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:49 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:49 --> URI Class Initialized
INFO - 2024-05-06 09:50:49 --> Router Class Initialized
INFO - 2024-05-06 09:50:49 --> Output Class Initialized
INFO - 2024-05-06 09:50:49 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:49 --> Input Class Initialized
INFO - 2024-05-06 09:50:49 --> Language Class Initialized
INFO - 2024-05-06 09:50:49 --> Loader Class Initialized
INFO - 2024-05-06 09:50:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:49 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:49 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:50:49 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:49 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:49 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:49 --> Total execution time: 0.0909
INFO - 2024-05-06 09:50:49 --> Config Class Initialized
INFO - 2024-05-06 09:50:49 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:49 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:49 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:49 --> URI Class Initialized
INFO - 2024-05-06 09:50:49 --> Router Class Initialized
INFO - 2024-05-06 09:50:49 --> Output Class Initialized
INFO - 2024-05-06 09:50:49 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:49 --> Input Class Initialized
INFO - 2024-05-06 09:50:49 --> Language Class Initialized
INFO - 2024-05-06 09:50:49 --> Loader Class Initialized
INFO - 2024-05-06 09:50:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:49 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:49 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:50:49 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:49 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:49 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:49 --> Total execution time: 0.0214
INFO - 2024-05-06 09:50:55 --> Config Class Initialized
INFO - 2024-05-06 09:50:55 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:55 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:55 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:55 --> URI Class Initialized
INFO - 2024-05-06 09:50:55 --> Router Class Initialized
INFO - 2024-05-06 09:50:55 --> Output Class Initialized
INFO - 2024-05-06 09:50:55 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:55 --> Input Class Initialized
INFO - 2024-05-06 09:50:55 --> Language Class Initialized
INFO - 2024-05-06 09:50:55 --> Loader Class Initialized
INFO - 2024-05-06 09:50:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:55 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:55 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:55 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:50:55 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:55 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:55 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:55 --> Total execution time: 0.0473
INFO - 2024-05-06 09:50:57 --> Config Class Initialized
INFO - 2024-05-06 09:50:57 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:57 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:57 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:57 --> URI Class Initialized
INFO - 2024-05-06 09:50:57 --> Router Class Initialized
INFO - 2024-05-06 09:50:57 --> Output Class Initialized
INFO - 2024-05-06 09:50:57 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:57 --> Input Class Initialized
INFO - 2024-05-06 09:50:57 --> Language Class Initialized
INFO - 2024-05-06 09:50:57 --> Loader Class Initialized
INFO - 2024-05-06 09:50:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:57 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:57 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:50:57 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:57 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-06 09:50:57 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:57 --> Total execution time: 0.0718
INFO - 2024-05-06 09:50:58 --> Config Class Initialized
INFO - 2024-05-06 09:50:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:58 --> URI Class Initialized
INFO - 2024-05-06 09:50:58 --> Router Class Initialized
INFO - 2024-05-06 09:50:58 --> Output Class Initialized
INFO - 2024-05-06 09:50:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:58 --> Input Class Initialized
INFO - 2024-05-06 09:50:58 --> Language Class Initialized
INFO - 2024-05-06 09:50:58 --> Loader Class Initialized
INFO - 2024-05-06 09:50:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:50:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:58 --> Total execution time: 0.0237
INFO - 2024-05-06 09:50:58 --> Config Class Initialized
INFO - 2024-05-06 09:50:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:50:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:50:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:50:58 --> URI Class Initialized
INFO - 2024-05-06 09:50:58 --> Router Class Initialized
INFO - 2024-05-06 09:50:58 --> Output Class Initialized
INFO - 2024-05-06 09:50:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:50:58 --> Input Class Initialized
INFO - 2024-05-06 09:50:58 --> Language Class Initialized
INFO - 2024-05-06 09:50:58 --> Loader Class Initialized
INFO - 2024-05-06 09:50:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:50:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:50:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:50:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:50:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:50:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:50:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:50:58 --> Total execution time: 0.0225
INFO - 2024-05-06 09:51:13 --> Config Class Initialized
INFO - 2024-05-06 09:51:13 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:51:13 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:51:13 --> Utf8 Class Initialized
INFO - 2024-05-06 09:51:13 --> URI Class Initialized
INFO - 2024-05-06 09:51:13 --> Router Class Initialized
INFO - 2024-05-06 09:51:13 --> Output Class Initialized
INFO - 2024-05-06 09:51:13 --> Security Class Initialized
DEBUG - 2024-05-06 09:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:51:13 --> Input Class Initialized
INFO - 2024-05-06 09:51:13 --> Language Class Initialized
INFO - 2024-05-06 09:51:13 --> Loader Class Initialized
INFO - 2024-05-06 09:51:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:51:13 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:51:13 --> Controller Class Initialized
DEBUG - 2024-05-06 09:51:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:51:13 --> Database Driver Class Initialized
INFO - 2024-05-06 09:51:13 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:51:13 --> Final output sent to browser
DEBUG - 2024-05-06 09:51:13 --> Total execution time: 0.0201
INFO - 2024-05-06 09:52:25 --> Config Class Initialized
INFO - 2024-05-06 09:52:25 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:25 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:25 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:25 --> URI Class Initialized
INFO - 2024-05-06 09:52:25 --> Router Class Initialized
INFO - 2024-05-06 09:52:25 --> Output Class Initialized
INFO - 2024-05-06 09:52:25 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:25 --> Input Class Initialized
INFO - 2024-05-06 09:52:25 --> Language Class Initialized
INFO - 2024-05-06 09:52:25 --> Loader Class Initialized
INFO - 2024-05-06 09:52:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:25 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:25 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:52:25 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:25 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:25 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:25 --> Total execution time: 0.1106
INFO - 2024-05-06 09:52:25 --> Config Class Initialized
INFO - 2024-05-06 09:52:25 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:25 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:25 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:25 --> URI Class Initialized
INFO - 2024-05-06 09:52:25 --> Router Class Initialized
INFO - 2024-05-06 09:52:25 --> Output Class Initialized
INFO - 2024-05-06 09:52:25 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:25 --> Input Class Initialized
INFO - 2024-05-06 09:52:25 --> Language Class Initialized
INFO - 2024-05-06 09:52:25 --> Loader Class Initialized
INFO - 2024-05-06 09:52:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:25 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:25 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:52:25 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:25 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-06 09:52:26 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:26 --> Total execution time: 0.2925
INFO - 2024-05-06 09:52:26 --> Config Class Initialized
INFO - 2024-05-06 09:52:26 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:26 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:26 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:26 --> URI Class Initialized
INFO - 2024-05-06 09:52:26 --> Router Class Initialized
INFO - 2024-05-06 09:52:26 --> Output Class Initialized
INFO - 2024-05-06 09:52:26 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:26 --> Input Class Initialized
INFO - 2024-05-06 09:52:26 --> Language Class Initialized
INFO - 2024-05-06 09:52:26 --> Loader Class Initialized
INFO - 2024-05-06 09:52:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:26 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:26 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:52:26 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:26 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:26 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:26 --> Total execution time: 0.2587
INFO - 2024-05-06 09:52:31 --> Config Class Initialized
INFO - 2024-05-06 09:52:31 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:31 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:31 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:31 --> URI Class Initialized
INFO - 2024-05-06 09:52:31 --> Router Class Initialized
INFO - 2024-05-06 09:52:31 --> Output Class Initialized
INFO - 2024-05-06 09:52:31 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:31 --> Input Class Initialized
INFO - 2024-05-06 09:52:31 --> Language Class Initialized
INFO - 2024-05-06 09:52:31 --> Loader Class Initialized
INFO - 2024-05-06 09:52:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:31 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:31 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-06 09:52:31 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:31 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:52:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:52:31 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-06 09:52:31 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:31 --> Total execution time: 0.0439
INFO - 2024-05-06 09:52:31 --> Config Class Initialized
INFO - 2024-05-06 09:52:31 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:31 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:31 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:31 --> URI Class Initialized
INFO - 2024-05-06 09:52:31 --> Router Class Initialized
INFO - 2024-05-06 09:52:31 --> Output Class Initialized
INFO - 2024-05-06 09:52:31 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:31 --> Input Class Initialized
INFO - 2024-05-06 09:52:31 --> Language Class Initialized
INFO - 2024-05-06 09:52:31 --> Loader Class Initialized
INFO - 2024-05-06 09:52:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:31 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:31 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:52:31 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:31 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:31 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:31 --> Total execution time: 0.0186
INFO - 2024-05-06 09:52:36 --> Config Class Initialized
INFO - 2024-05-06 09:52:36 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:36 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:36 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:36 --> URI Class Initialized
INFO - 2024-05-06 09:52:36 --> Router Class Initialized
INFO - 2024-05-06 09:52:36 --> Output Class Initialized
INFO - 2024-05-06 09:52:36 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:36 --> Input Class Initialized
INFO - 2024-05-06 09:52:36 --> Language Class Initialized
INFO - 2024-05-06 09:52:36 --> Loader Class Initialized
INFO - 2024-05-06 09:52:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:36 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:36 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-06 09:52:36 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:36 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:36 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:36 --> Total execution time: 0.0356
INFO - 2024-05-06 09:52:58 --> Config Class Initialized
INFO - 2024-05-06 09:52:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:58 --> URI Class Initialized
INFO - 2024-05-06 09:52:58 --> Router Class Initialized
INFO - 2024-05-06 09:52:58 --> Output Class Initialized
INFO - 2024-05-06 09:52:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:58 --> Input Class Initialized
INFO - 2024-05-06 09:52:58 --> Language Class Initialized
INFO - 2024-05-06 09:52:58 --> Loader Class Initialized
INFO - 2024-05-06 09:52:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:52:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:52:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:52:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-06 09:52:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:58 --> Total execution time: 0.0482
INFO - 2024-05-06 09:52:58 --> Config Class Initialized
INFO - 2024-05-06 09:52:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:58 --> URI Class Initialized
INFO - 2024-05-06 09:52:58 --> Router Class Initialized
INFO - 2024-05-06 09:52:58 --> Output Class Initialized
INFO - 2024-05-06 09:52:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:58 --> Input Class Initialized
INFO - 2024-05-06 09:52:58 --> Language Class Initialized
INFO - 2024-05-06 09:52:58 --> Loader Class Initialized
INFO - 2024-05-06 09:52:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:52:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:58 --> Total execution time: 0.0873
INFO - 2024-05-06 09:52:58 --> Config Class Initialized
INFO - 2024-05-06 09:52:58 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:52:58 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:52:58 --> Utf8 Class Initialized
INFO - 2024-05-06 09:52:58 --> URI Class Initialized
INFO - 2024-05-06 09:52:58 --> Router Class Initialized
INFO - 2024-05-06 09:52:58 --> Output Class Initialized
INFO - 2024-05-06 09:52:58 --> Security Class Initialized
DEBUG - 2024-05-06 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:52:58 --> Input Class Initialized
INFO - 2024-05-06 09:52:58 --> Language Class Initialized
INFO - 2024-05-06 09:52:58 --> Loader Class Initialized
INFO - 2024-05-06 09:52:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:52:58 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:52:58 --> Controller Class Initialized
DEBUG - 2024-05-06 09:52:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:52:58 --> Database Driver Class Initialized
INFO - 2024-05-06 09:52:58 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:52:58 --> Final output sent to browser
DEBUG - 2024-05-06 09:52:58 --> Total execution time: 0.0216
INFO - 2024-05-06 09:53:05 --> Config Class Initialized
INFO - 2024-05-06 09:53:06 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:06 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:06 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:06 --> URI Class Initialized
INFO - 2024-05-06 09:53:06 --> Router Class Initialized
INFO - 2024-05-06 09:53:06 --> Output Class Initialized
INFO - 2024-05-06 09:53:06 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:06 --> Input Class Initialized
INFO - 2024-05-06 09:53:06 --> Language Class Initialized
INFO - 2024-05-06 09:53:06 --> Loader Class Initialized
INFO - 2024-05-06 09:53:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:06 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:06 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:06 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:06 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:06 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:06 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:06 --> Total execution time: 0.1442
INFO - 2024-05-06 09:53:13 --> Config Class Initialized
INFO - 2024-05-06 09:53:13 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:13 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:13 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:13 --> URI Class Initialized
INFO - 2024-05-06 09:53:13 --> Router Class Initialized
INFO - 2024-05-06 09:53:13 --> Output Class Initialized
INFO - 2024-05-06 09:53:13 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:13 --> Input Class Initialized
INFO - 2024-05-06 09:53:13 --> Language Class Initialized
INFO - 2024-05-06 09:53:13 --> Loader Class Initialized
INFO - 2024-05-06 09:53:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:13 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:13 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:13 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:13 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:14 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:14 --> Total execution time: 0.0739
INFO - 2024-05-06 09:53:14 --> Config Class Initialized
INFO - 2024-05-06 09:53:14 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:14 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:14 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:14 --> URI Class Initialized
INFO - 2024-05-06 09:53:14 --> Router Class Initialized
INFO - 2024-05-06 09:53:14 --> Output Class Initialized
INFO - 2024-05-06 09:53:14 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:14 --> Input Class Initialized
INFO - 2024-05-06 09:53:14 --> Language Class Initialized
INFO - 2024-05-06 09:53:14 --> Loader Class Initialized
INFO - 2024-05-06 09:53:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:14 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:14 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:14 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:14 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:14 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:14 --> Total execution time: 0.0718
INFO - 2024-05-06 09:53:20 --> Config Class Initialized
INFO - 2024-05-06 09:53:20 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:20 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:20 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:20 --> URI Class Initialized
INFO - 2024-05-06 09:53:20 --> Router Class Initialized
INFO - 2024-05-06 09:53:20 --> Output Class Initialized
INFO - 2024-05-06 09:53:20 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:20 --> Input Class Initialized
INFO - 2024-05-06 09:53:20 --> Language Class Initialized
INFO - 2024-05-06 09:53:20 --> Loader Class Initialized
INFO - 2024-05-06 09:53:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:20 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:20 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:20 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:20 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:20 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-05-06 09:53:20 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:20 --> Total execution time: 0.0784
INFO - 2024-05-06 09:53:20 --> Config Class Initialized
INFO - 2024-05-06 09:53:20 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:20 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:20 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:20 --> URI Class Initialized
INFO - 2024-05-06 09:53:20 --> Router Class Initialized
INFO - 2024-05-06 09:53:20 --> Output Class Initialized
INFO - 2024-05-06 09:53:20 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:20 --> Input Class Initialized
INFO - 2024-05-06 09:53:20 --> Language Class Initialized
INFO - 2024-05-06 09:53:20 --> Loader Class Initialized
INFO - 2024-05-06 09:53:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:20 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:20 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:20 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:20 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:20 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:20 --> Total execution time: 0.0263
INFO - 2024-05-06 09:53:20 --> Config Class Initialized
INFO - 2024-05-06 09:53:20 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:20 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:20 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:20 --> URI Class Initialized
INFO - 2024-05-06 09:53:20 --> Router Class Initialized
INFO - 2024-05-06 09:53:20 --> Output Class Initialized
INFO - 2024-05-06 09:53:20 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:20 --> Input Class Initialized
INFO - 2024-05-06 09:53:20 --> Language Class Initialized
INFO - 2024-05-06 09:53:20 --> Loader Class Initialized
INFO - 2024-05-06 09:53:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:20 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:20 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:20 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:20 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:20 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:20 --> Total execution time: 0.0195
INFO - 2024-05-06 09:53:21 --> Config Class Initialized
INFO - 2024-05-06 09:53:21 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:21 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:21 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:21 --> URI Class Initialized
INFO - 2024-05-06 09:53:21 --> Router Class Initialized
INFO - 2024-05-06 09:53:21 --> Output Class Initialized
INFO - 2024-05-06 09:53:21 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:21 --> Input Class Initialized
INFO - 2024-05-06 09:53:21 --> Language Class Initialized
INFO - 2024-05-06 09:53:21 --> Loader Class Initialized
INFO - 2024-05-06 09:53:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:21 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:21 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:21 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:22 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:22 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:22 --> Total execution time: 0.0367
INFO - 2024-05-06 09:53:36 --> Config Class Initialized
INFO - 2024-05-06 09:53:36 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:36 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:36 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:36 --> URI Class Initialized
INFO - 2024-05-06 09:53:36 --> Router Class Initialized
INFO - 2024-05-06 09:53:36 --> Output Class Initialized
INFO - 2024-05-06 09:53:36 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:36 --> Input Class Initialized
INFO - 2024-05-06 09:53:36 --> Language Class Initialized
INFO - 2024-05-06 09:53:36 --> Loader Class Initialized
INFO - 2024-05-06 09:53:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:36 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:36 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:36 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:36 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/comprobantes/ordendepago.php
INFO - 2024-05-06 09:53:37 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:37 --> Total execution time: 0.4316
INFO - 2024-05-06 09:53:37 --> Config Class Initialized
INFO - 2024-05-06 09:53:37 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:37 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:37 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:37 --> URI Class Initialized
INFO - 2024-05-06 09:53:37 --> Router Class Initialized
INFO - 2024-05-06 09:53:37 --> Output Class Initialized
INFO - 2024-05-06 09:53:37 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:37 --> Input Class Initialized
INFO - 2024-05-06 09:53:37 --> Language Class Initialized
INFO - 2024-05-06 09:53:37 --> Loader Class Initialized
INFO - 2024-05-06 09:53:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:37 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:37 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-06 09:53:37 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:37 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:37 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:37 --> Total execution time: 0.0602
INFO - 2024-05-06 09:53:43 --> Config Class Initialized
INFO - 2024-05-06 09:53:43 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:43 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:43 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:43 --> URI Class Initialized
INFO - 2024-05-06 09:53:43 --> Router Class Initialized
INFO - 2024-05-06 09:53:43 --> Output Class Initialized
INFO - 2024-05-06 09:53:43 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:43 --> Input Class Initialized
INFO - 2024-05-06 09:53:43 --> Language Class Initialized
INFO - 2024-05-06 09:53:43 --> Loader Class Initialized
INFO - 2024-05-06 09:53:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:43 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:43 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-06 09:53:43 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:43 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-06 09:53:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-06 09:53:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-06 09:53:43 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:43 --> Total execution time: 0.0535
INFO - 2024-05-06 09:53:43 --> Config Class Initialized
INFO - 2024-05-06 09:53:43 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:43 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:43 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:43 --> URI Class Initialized
INFO - 2024-05-06 09:53:43 --> Router Class Initialized
INFO - 2024-05-06 09:53:43 --> Output Class Initialized
INFO - 2024-05-06 09:53:43 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:43 --> Input Class Initialized
INFO - 2024-05-06 09:53:43 --> Language Class Initialized
INFO - 2024-05-06 09:53:43 --> Loader Class Initialized
INFO - 2024-05-06 09:53:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:43 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:43 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-06 09:53:43 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:43 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:43 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:43 --> Total execution time: 0.0239
INFO - 2024-05-06 09:53:47 --> Config Class Initialized
INFO - 2024-05-06 09:53:47 --> Hooks Class Initialized
DEBUG - 2024-05-06 09:53:47 --> UTF-8 Support Enabled
INFO - 2024-05-06 09:53:47 --> Utf8 Class Initialized
INFO - 2024-05-06 09:53:47 --> URI Class Initialized
INFO - 2024-05-06 09:53:47 --> Router Class Initialized
INFO - 2024-05-06 09:53:47 --> Output Class Initialized
INFO - 2024-05-06 09:53:47 --> Security Class Initialized
DEBUG - 2024-05-06 09:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 09:53:47 --> Input Class Initialized
INFO - 2024-05-06 09:53:47 --> Language Class Initialized
INFO - 2024-05-06 09:53:47 --> Loader Class Initialized
INFO - 2024-05-06 09:53:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 09:53:47 --> Helper loaded: url_helper
DEBUG - 2024-05-06 09:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 09:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 09:53:47 --> Controller Class Initialized
DEBUG - 2024-05-06 09:53:47 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-06 09:53:47 --> Database Driver Class Initialized
INFO - 2024-05-06 09:53:47 --> Helper loaded: funciones_helper
INFO - 2024-05-06 09:53:47 --> Final output sent to browser
DEBUG - 2024-05-06 09:53:47 --> Total execution time: 0.0240
INFO - 2024-05-06 12:16:01 --> Config Class Initialized
INFO - 2024-05-06 12:16:01 --> Hooks Class Initialized
DEBUG - 2024-05-06 12:16:01 --> UTF-8 Support Enabled
INFO - 2024-05-06 12:16:01 --> Utf8 Class Initialized
INFO - 2024-05-06 12:16:01 --> URI Class Initialized
DEBUG - 2024-05-06 12:16:01 --> No URI present. Default controller set.
INFO - 2024-05-06 12:16:01 --> Router Class Initialized
INFO - 2024-05-06 12:16:01 --> Output Class Initialized
INFO - 2024-05-06 12:16:01 --> Security Class Initialized
DEBUG - 2024-05-06 12:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 12:16:01 --> Input Class Initialized
INFO - 2024-05-06 12:16:01 --> Language Class Initialized
INFO - 2024-05-06 12:16:01 --> Loader Class Initialized
INFO - 2024-05-06 12:16:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 12:16:01 --> Helper loaded: url_helper
DEBUG - 2024-05-06 12:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 12:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 12:16:01 --> Controller Class Initialized
INFO - 2024-05-06 15:32:35 --> Config Class Initialized
INFO - 2024-05-06 15:32:35 --> Hooks Class Initialized
DEBUG - 2024-05-06 15:32:35 --> UTF-8 Support Enabled
INFO - 2024-05-06 15:32:35 --> Utf8 Class Initialized
INFO - 2024-05-06 15:32:35 --> URI Class Initialized
DEBUG - 2024-05-06 15:32:35 --> No URI present. Default controller set.
INFO - 2024-05-06 15:32:35 --> Router Class Initialized
INFO - 2024-05-06 15:32:35 --> Output Class Initialized
INFO - 2024-05-06 15:32:35 --> Security Class Initialized
DEBUG - 2024-05-06 15:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-06 15:32:35 --> Input Class Initialized
INFO - 2024-05-06 15:32:35 --> Language Class Initialized
INFO - 2024-05-06 15:32:35 --> Loader Class Initialized
INFO - 2024-05-06 15:32:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-06 15:32:35 --> Helper loaded: url_helper
DEBUG - 2024-05-06 15:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-06 15:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-06 15:32:35 --> Controller Class Initialized
