<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-07 16:21:01 --> Config Class Initialized
INFO - 2024-08-07 16:21:01 --> Hooks Class Initialized
DEBUG - 2024-08-07 16:21:01 --> UTF-8 Support Enabled
INFO - 2024-08-07 16:21:01 --> Utf8 Class Initialized
INFO - 2024-08-07 16:21:01 --> URI Class Initialized
DEBUG - 2024-08-07 16:21:01 --> No URI present. Default controller set.
INFO - 2024-08-07 16:21:01 --> Router Class Initialized
INFO - 2024-08-07 16:21:01 --> Output Class Initialized
INFO - 2024-08-07 16:21:01 --> Security Class Initialized
DEBUG - 2024-08-07 16:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 16:21:01 --> Input Class Initialized
INFO - 2024-08-07 16:21:01 --> Language Class Initialized
INFO - 2024-08-07 16:21:01 --> Loader Class Initialized
INFO - 2024-08-07 16:21:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-07 16:21:01 --> Helper loaded: url_helper
DEBUG - 2024-08-07 16:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-07 16:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 16:21:01 --> Controller Class Initialized
INFO - 2024-08-07 20:59:34 --> Config Class Initialized
INFO - 2024-08-07 20:59:34 --> Hooks Class Initialized
DEBUG - 2024-08-07 20:59:34 --> UTF-8 Support Enabled
INFO - 2024-08-07 20:59:34 --> Utf8 Class Initialized
INFO - 2024-08-07 20:59:34 --> URI Class Initialized
DEBUG - 2024-08-07 20:59:34 --> No URI present. Default controller set.
INFO - 2024-08-07 20:59:34 --> Router Class Initialized
INFO - 2024-08-07 20:59:34 --> Output Class Initialized
INFO - 2024-08-07 20:59:34 --> Security Class Initialized
DEBUG - 2024-08-07 20:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 20:59:34 --> Input Class Initialized
INFO - 2024-08-07 20:59:34 --> Language Class Initialized
INFO - 2024-08-07 20:59:34 --> Loader Class Initialized
INFO - 2024-08-07 20:59:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-07 20:59:34 --> Helper loaded: url_helper
DEBUG - 2024-08-07 20:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-07 20:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 20:59:34 --> Controller Class Initialized
