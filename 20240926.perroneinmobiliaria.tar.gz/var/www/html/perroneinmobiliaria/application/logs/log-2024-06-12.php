<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-12 17:04:43 --> Config Class Initialized
INFO - 2024-06-12 17:04:43 --> Hooks Class Initialized
DEBUG - 2024-06-12 17:04:43 --> UTF-8 Support Enabled
INFO - 2024-06-12 17:04:43 --> Utf8 Class Initialized
INFO - 2024-06-12 17:04:43 --> URI Class Initialized
DEBUG - 2024-06-12 17:04:43 --> No URI present. Default controller set.
INFO - 2024-06-12 17:04:43 --> Router Class Initialized
INFO - 2024-06-12 17:04:43 --> Output Class Initialized
INFO - 2024-06-12 17:04:43 --> Security Class Initialized
DEBUG - 2024-06-12 17:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 17:04:43 --> Input Class Initialized
INFO - 2024-06-12 17:04:43 --> Language Class Initialized
INFO - 2024-06-12 17:04:43 --> Loader Class Initialized
INFO - 2024-06-12 17:04:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-12 17:04:43 --> Helper loaded: url_helper
DEBUG - 2024-06-12 17:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-12 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 17:04:44 --> Controller Class Initialized
