<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-06 05:32:01 --> Config Class Initialized
INFO - 2024-06-06 05:32:01 --> Hooks Class Initialized
DEBUG - 2024-06-06 05:32:01 --> UTF-8 Support Enabled
INFO - 2024-06-06 05:32:01 --> Utf8 Class Initialized
INFO - 2024-06-06 05:32:01 --> URI Class Initialized
DEBUG - 2024-06-06 05:32:01 --> No URI present. Default controller set.
INFO - 2024-06-06 05:32:01 --> Router Class Initialized
INFO - 2024-06-06 05:32:01 --> Output Class Initialized
INFO - 2024-06-06 05:32:01 --> Security Class Initialized
DEBUG - 2024-06-06 05:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 05:32:01 --> Input Class Initialized
INFO - 2024-06-06 05:32:01 --> Language Class Initialized
INFO - 2024-06-06 05:32:01 --> Loader Class Initialized
INFO - 2024-06-06 05:32:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 05:32:01 --> Helper loaded: url_helper
DEBUG - 2024-06-06 05:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 05:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 05:32:01 --> Controller Class Initialized
INFO - 2024-06-06 05:34:30 --> Config Class Initialized
INFO - 2024-06-06 05:34:30 --> Hooks Class Initialized
DEBUG - 2024-06-06 05:34:30 --> UTF-8 Support Enabled
INFO - 2024-06-06 05:34:30 --> Utf8 Class Initialized
INFO - 2024-06-06 05:34:30 --> URI Class Initialized
DEBUG - 2024-06-06 05:34:30 --> No URI present. Default controller set.
INFO - 2024-06-06 05:34:30 --> Router Class Initialized
INFO - 2024-06-06 05:34:30 --> Output Class Initialized
INFO - 2024-06-06 05:34:30 --> Security Class Initialized
DEBUG - 2024-06-06 05:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 05:34:30 --> Input Class Initialized
INFO - 2024-06-06 05:34:30 --> Language Class Initialized
INFO - 2024-06-06 05:34:30 --> Loader Class Initialized
INFO - 2024-06-06 05:34:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 05:34:30 --> Helper loaded: url_helper
DEBUG - 2024-06-06 05:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 05:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 05:34:30 --> Controller Class Initialized
INFO - 2024-06-06 05:58:08 --> Config Class Initialized
INFO - 2024-06-06 05:58:08 --> Hooks Class Initialized
DEBUG - 2024-06-06 05:58:08 --> UTF-8 Support Enabled
INFO - 2024-06-06 05:58:08 --> Utf8 Class Initialized
INFO - 2024-06-06 05:58:08 --> URI Class Initialized
DEBUG - 2024-06-06 05:58:08 --> No URI present. Default controller set.
INFO - 2024-06-06 05:58:08 --> Router Class Initialized
INFO - 2024-06-06 05:58:08 --> Output Class Initialized
INFO - 2024-06-06 05:58:08 --> Security Class Initialized
DEBUG - 2024-06-06 05:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 05:58:08 --> Input Class Initialized
INFO - 2024-06-06 05:58:08 --> Language Class Initialized
INFO - 2024-06-06 05:58:08 --> Loader Class Initialized
INFO - 2024-06-06 05:58:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 05:58:08 --> Helper loaded: url_helper
DEBUG - 2024-06-06 05:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 05:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 05:58:08 --> Controller Class Initialized
INFO - 2024-06-06 05:58:08 --> Config Class Initialized
INFO - 2024-06-06 05:58:08 --> Hooks Class Initialized
DEBUG - 2024-06-06 05:58:08 --> UTF-8 Support Enabled
INFO - 2024-06-06 05:58:08 --> Utf8 Class Initialized
INFO - 2024-06-06 05:58:08 --> URI Class Initialized
INFO - 2024-06-06 05:58:08 --> Router Class Initialized
INFO - 2024-06-06 05:58:08 --> Output Class Initialized
INFO - 2024-06-06 05:58:08 --> Security Class Initialized
DEBUG - 2024-06-06 05:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 05:58:08 --> Input Class Initialized
INFO - 2024-06-06 05:58:08 --> Language Class Initialized
INFO - 2024-06-06 05:58:08 --> Loader Class Initialized
INFO - 2024-06-06 05:58:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 05:58:08 --> Helper loaded: url_helper
DEBUG - 2024-06-06 05:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 05:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 05:58:08 --> Controller Class Initialized
DEBUG - 2024-06-06 05:58:08 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-06 05:58:08 --> Database Driver Class Initialized
INFO - 2024-06-06 05:58:08 --> Helper loaded: cookie_helper
INFO - 2024-06-06 05:58:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-06 05:58:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-06 05:58:08 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-06 05:58:08 --> Final output sent to browser
DEBUG - 2024-06-06 05:58:08 --> Total execution time: 0.0538
INFO - 2024-06-06 06:14:42 --> Config Class Initialized
INFO - 2024-06-06 06:14:42 --> Hooks Class Initialized
DEBUG - 2024-06-06 06:14:42 --> UTF-8 Support Enabled
INFO - 2024-06-06 06:14:42 --> Utf8 Class Initialized
INFO - 2024-06-06 06:14:42 --> URI Class Initialized
DEBUG - 2024-06-06 06:14:42 --> No URI present. Default controller set.
INFO - 2024-06-06 06:14:42 --> Router Class Initialized
INFO - 2024-06-06 06:14:42 --> Output Class Initialized
INFO - 2024-06-06 06:14:42 --> Security Class Initialized
DEBUG - 2024-06-06 06:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 06:14:42 --> Input Class Initialized
INFO - 2024-06-06 06:14:42 --> Language Class Initialized
INFO - 2024-06-06 06:14:42 --> Loader Class Initialized
INFO - 2024-06-06 06:14:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 06:14:42 --> Helper loaded: url_helper
DEBUG - 2024-06-06 06:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 06:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 06:14:42 --> Controller Class Initialized
INFO - 2024-06-06 16:12:45 --> Config Class Initialized
INFO - 2024-06-06 16:12:45 --> Hooks Class Initialized
DEBUG - 2024-06-06 16:12:45 --> UTF-8 Support Enabled
INFO - 2024-06-06 16:12:45 --> Utf8 Class Initialized
INFO - 2024-06-06 16:12:45 --> URI Class Initialized
DEBUG - 2024-06-06 16:12:45 --> No URI present. Default controller set.
INFO - 2024-06-06 16:12:45 --> Router Class Initialized
INFO - 2024-06-06 16:12:45 --> Output Class Initialized
INFO - 2024-06-06 16:12:45 --> Security Class Initialized
DEBUG - 2024-06-06 16:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 16:12:45 --> Input Class Initialized
INFO - 2024-06-06 16:12:45 --> Language Class Initialized
INFO - 2024-06-06 16:12:45 --> Loader Class Initialized
INFO - 2024-06-06 16:12:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 16:12:45 --> Helper loaded: url_helper
DEBUG - 2024-06-06 16:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 16:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 16:12:45 --> Controller Class Initialized
INFO - 2024-06-06 18:24:39 --> Config Class Initialized
INFO - 2024-06-06 18:24:39 --> Hooks Class Initialized
DEBUG - 2024-06-06 18:24:39 --> UTF-8 Support Enabled
INFO - 2024-06-06 18:24:39 --> Utf8 Class Initialized
INFO - 2024-06-06 18:24:39 --> URI Class Initialized
DEBUG - 2024-06-06 18:24:39 --> No URI present. Default controller set.
INFO - 2024-06-06 18:24:39 --> Router Class Initialized
INFO - 2024-06-06 18:24:39 --> Output Class Initialized
INFO - 2024-06-06 18:24:39 --> Security Class Initialized
DEBUG - 2024-06-06 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 18:24:39 --> Input Class Initialized
INFO - 2024-06-06 18:24:39 --> Language Class Initialized
INFO - 2024-06-06 18:24:39 --> Loader Class Initialized
INFO - 2024-06-06 18:24:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 18:24:39 --> Helper loaded: url_helper
DEBUG - 2024-06-06 18:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 18:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 18:24:39 --> Controller Class Initialized
INFO - 2024-06-06 19:09:20 --> Config Class Initialized
INFO - 2024-06-06 19:09:20 --> Hooks Class Initialized
DEBUG - 2024-06-06 19:09:20 --> UTF-8 Support Enabled
INFO - 2024-06-06 19:09:20 --> Utf8 Class Initialized
INFO - 2024-06-06 19:09:20 --> URI Class Initialized
DEBUG - 2024-06-06 19:09:20 --> No URI present. Default controller set.
INFO - 2024-06-06 19:09:20 --> Router Class Initialized
INFO - 2024-06-06 19:09:20 --> Output Class Initialized
INFO - 2024-06-06 19:09:20 --> Security Class Initialized
DEBUG - 2024-06-06 19:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 19:09:20 --> Input Class Initialized
INFO - 2024-06-06 19:09:20 --> Language Class Initialized
INFO - 2024-06-06 19:09:20 --> Loader Class Initialized
INFO - 2024-06-06 19:09:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 19:09:20 --> Helper loaded: url_helper
DEBUG - 2024-06-06 19:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 19:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 19:09:20 --> Controller Class Initialized
INFO - 2024-06-06 19:14:45 --> Config Class Initialized
INFO - 2024-06-06 19:14:45 --> Hooks Class Initialized
DEBUG - 2024-06-06 19:14:45 --> UTF-8 Support Enabled
INFO - 2024-06-06 19:14:45 --> Utf8 Class Initialized
INFO - 2024-06-06 19:14:45 --> URI Class Initialized
DEBUG - 2024-06-06 19:14:45 --> No URI present. Default controller set.
INFO - 2024-06-06 19:14:45 --> Router Class Initialized
INFO - 2024-06-06 19:14:45 --> Output Class Initialized
INFO - 2024-06-06 19:14:45 --> Security Class Initialized
DEBUG - 2024-06-06 19:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 19:14:45 --> Input Class Initialized
INFO - 2024-06-06 19:14:45 --> Language Class Initialized
INFO - 2024-06-06 19:14:45 --> Loader Class Initialized
INFO - 2024-06-06 19:14:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 19:14:45 --> Helper loaded: url_helper
DEBUG - 2024-06-06 19:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 19:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 19:14:45 --> Controller Class Initialized
INFO - 2024-06-06 19:25:26 --> Config Class Initialized
INFO - 2024-06-06 19:25:26 --> Hooks Class Initialized
DEBUG - 2024-06-06 19:25:26 --> UTF-8 Support Enabled
INFO - 2024-06-06 19:25:26 --> Utf8 Class Initialized
INFO - 2024-06-06 19:25:26 --> URI Class Initialized
DEBUG - 2024-06-06 19:25:26 --> No URI present. Default controller set.
INFO - 2024-06-06 19:25:26 --> Router Class Initialized
INFO - 2024-06-06 19:25:26 --> Output Class Initialized
INFO - 2024-06-06 19:25:26 --> Security Class Initialized
DEBUG - 2024-06-06 19:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 19:25:26 --> Input Class Initialized
INFO - 2024-06-06 19:25:26 --> Language Class Initialized
INFO - 2024-06-06 19:25:26 --> Loader Class Initialized
INFO - 2024-06-06 19:25:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 19:25:26 --> Helper loaded: url_helper
DEBUG - 2024-06-06 19:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 19:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 19:25:26 --> Controller Class Initialized
INFO - 2024-06-06 21:58:34 --> Config Class Initialized
INFO - 2024-06-06 21:58:34 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:58:34 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:58:34 --> Utf8 Class Initialized
INFO - 2024-06-06 21:58:34 --> URI Class Initialized
DEBUG - 2024-06-06 21:58:34 --> No URI present. Default controller set.
INFO - 2024-06-06 21:58:34 --> Router Class Initialized
INFO - 2024-06-06 21:58:34 --> Output Class Initialized
INFO - 2024-06-06 21:58:34 --> Security Class Initialized
DEBUG - 2024-06-06 21:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:58:34 --> Input Class Initialized
INFO - 2024-06-06 21:58:34 --> Language Class Initialized
INFO - 2024-06-06 21:58:34 --> Loader Class Initialized
INFO - 2024-06-06 21:58:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-06 21:58:34 --> Helper loaded: url_helper
DEBUG - 2024-06-06 21:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-06 21:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:58:34 --> Controller Class Initialized
