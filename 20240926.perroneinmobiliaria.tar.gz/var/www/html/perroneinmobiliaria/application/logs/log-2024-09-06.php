<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-06 14:18:00 --> Config Class Initialized
INFO - 2024-09-06 14:18:00 --> Hooks Class Initialized
DEBUG - 2024-09-06 14:18:00 --> UTF-8 Support Enabled
INFO - 2024-09-06 14:18:00 --> Utf8 Class Initialized
INFO - 2024-09-06 14:18:00 --> URI Class Initialized
DEBUG - 2024-09-06 14:18:00 --> No URI present. Default controller set.
INFO - 2024-09-06 14:18:00 --> Router Class Initialized
INFO - 2024-09-06 14:18:00 --> Output Class Initialized
INFO - 2024-09-06 14:18:00 --> Security Class Initialized
DEBUG - 2024-09-06 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 14:18:00 --> Input Class Initialized
INFO - 2024-09-06 14:18:00 --> Language Class Initialized
INFO - 2024-09-06 14:18:00 --> Loader Class Initialized
INFO - 2024-09-06 14:18:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-06 14:18:00 --> Helper loaded: url_helper
DEBUG - 2024-09-06 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 14:18:00 --> Controller Class Initialized
INFO - 2024-09-06 22:21:33 --> Config Class Initialized
INFO - 2024-09-06 22:21:33 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:21:33 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:21:33 --> Utf8 Class Initialized
INFO - 2024-09-06 22:21:33 --> URI Class Initialized
DEBUG - 2024-09-06 22:21:33 --> No URI present. Default controller set.
INFO - 2024-09-06 22:21:33 --> Router Class Initialized
INFO - 2024-09-06 22:21:33 --> Output Class Initialized
INFO - 2024-09-06 22:21:33 --> Security Class Initialized
DEBUG - 2024-09-06 22:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:21:33 --> Input Class Initialized
INFO - 2024-09-06 22:21:33 --> Language Class Initialized
INFO - 2024-09-06 22:21:33 --> Loader Class Initialized
INFO - 2024-09-06 22:21:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-06 22:21:33 --> Helper loaded: url_helper
DEBUG - 2024-09-06 22:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 22:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 22:21:33 --> Controller Class Initialized
INFO - 2024-09-06 22:21:35 --> Config Class Initialized
INFO - 2024-09-06 22:21:35 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:21:35 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:21:35 --> Utf8 Class Initialized
INFO - 2024-09-06 22:21:35 --> URI Class Initialized
DEBUG - 2024-09-06 22:21:35 --> No URI present. Default controller set.
INFO - 2024-09-06 22:21:35 --> Router Class Initialized
INFO - 2024-09-06 22:21:35 --> Output Class Initialized
INFO - 2024-09-06 22:21:35 --> Security Class Initialized
DEBUG - 2024-09-06 22:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:21:35 --> Input Class Initialized
INFO - 2024-09-06 22:21:35 --> Language Class Initialized
INFO - 2024-09-06 22:21:35 --> Loader Class Initialized
INFO - 2024-09-06 22:21:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-06 22:21:35 --> Helper loaded: url_helper
DEBUG - 2024-09-06 22:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 22:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 22:21:35 --> Controller Class Initialized
INFO - 2024-09-06 23:27:20 --> Config Class Initialized
INFO - 2024-09-06 23:27:20 --> Hooks Class Initialized
DEBUG - 2024-09-06 23:27:20 --> UTF-8 Support Enabled
INFO - 2024-09-06 23:27:20 --> Utf8 Class Initialized
INFO - 2024-09-06 23:27:20 --> URI Class Initialized
DEBUG - 2024-09-06 23:27:20 --> No URI present. Default controller set.
INFO - 2024-09-06 23:27:20 --> Router Class Initialized
INFO - 2024-09-06 23:27:20 --> Output Class Initialized
INFO - 2024-09-06 23:27:20 --> Security Class Initialized
DEBUG - 2024-09-06 23:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 23:27:20 --> Input Class Initialized
INFO - 2024-09-06 23:27:20 --> Language Class Initialized
INFO - 2024-09-06 23:27:20 --> Loader Class Initialized
INFO - 2024-09-06 23:27:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-06 23:27:20 --> Helper loaded: url_helper
DEBUG - 2024-09-06 23:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 23:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 23:27:20 --> Controller Class Initialized
