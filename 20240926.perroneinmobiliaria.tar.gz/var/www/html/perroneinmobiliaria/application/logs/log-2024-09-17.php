<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-17 05:54:46 --> Config Class Initialized
INFO - 2024-09-17 05:54:46 --> Hooks Class Initialized
DEBUG - 2024-09-17 05:54:46 --> UTF-8 Support Enabled
INFO - 2024-09-17 05:54:46 --> Utf8 Class Initialized
INFO - 2024-09-17 05:54:46 --> URI Class Initialized
DEBUG - 2024-09-17 05:54:46 --> No URI present. Default controller set.
INFO - 2024-09-17 05:54:46 --> Router Class Initialized
INFO - 2024-09-17 05:54:46 --> Output Class Initialized
INFO - 2024-09-17 05:54:46 --> Security Class Initialized
DEBUG - 2024-09-17 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 05:54:46 --> Input Class Initialized
INFO - 2024-09-17 05:54:46 --> Language Class Initialized
INFO - 2024-09-17 05:54:46 --> Loader Class Initialized
INFO - 2024-09-17 05:54:46 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-17 05:54:46 --> Helper loaded: url_helper
DEBUG - 2024-09-17 05:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-17 05:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 05:54:46 --> Controller Class Initialized
INFO - 2024-09-17 11:31:18 --> Config Class Initialized
INFO - 2024-09-17 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-09-17 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-09-17 11:31:18 --> Utf8 Class Initialized
INFO - 2024-09-17 11:31:18 --> URI Class Initialized
DEBUG - 2024-09-17 11:31:18 --> No URI present. Default controller set.
INFO - 2024-09-17 11:31:18 --> Router Class Initialized
INFO - 2024-09-17 11:31:18 --> Output Class Initialized
INFO - 2024-09-17 11:31:18 --> Security Class Initialized
DEBUG - 2024-09-17 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 11:31:18 --> Input Class Initialized
INFO - 2024-09-17 11:31:18 --> Language Class Initialized
INFO - 2024-09-17 11:31:18 --> Loader Class Initialized
INFO - 2024-09-17 11:31:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-17 11:31:18 --> Helper loaded: url_helper
DEBUG - 2024-09-17 11:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-17 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 11:31:18 --> Controller Class Initialized
INFO - 2024-09-17 11:41:28 --> Config Class Initialized
INFO - 2024-09-17 11:41:28 --> Hooks Class Initialized
DEBUG - 2024-09-17 11:41:28 --> UTF-8 Support Enabled
INFO - 2024-09-17 11:41:28 --> Utf8 Class Initialized
INFO - 2024-09-17 11:41:28 --> URI Class Initialized
DEBUG - 2024-09-17 11:41:28 --> No URI present. Default controller set.
INFO - 2024-09-17 11:41:28 --> Router Class Initialized
INFO - 2024-09-17 11:41:28 --> Output Class Initialized
INFO - 2024-09-17 11:41:28 --> Security Class Initialized
DEBUG - 2024-09-17 11:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 11:41:28 --> Input Class Initialized
INFO - 2024-09-17 11:41:28 --> Language Class Initialized
INFO - 2024-09-17 11:41:28 --> Loader Class Initialized
INFO - 2024-09-17 11:41:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-17 11:41:28 --> Helper loaded: url_helper
DEBUG - 2024-09-17 11:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-17 11:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 11:41:28 --> Controller Class Initialized
INFO - 2024-09-17 23:11:50 --> Config Class Initialized
INFO - 2024-09-17 23:11:50 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:11:50 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:11:50 --> Utf8 Class Initialized
INFO - 2024-09-17 23:11:50 --> URI Class Initialized
DEBUG - 2024-09-17 23:11:50 --> No URI present. Default controller set.
INFO - 2024-09-17 23:11:50 --> Router Class Initialized
INFO - 2024-09-17 23:11:50 --> Output Class Initialized
INFO - 2024-09-17 23:11:50 --> Security Class Initialized
DEBUG - 2024-09-17 23:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:11:50 --> Input Class Initialized
INFO - 2024-09-17 23:11:50 --> Language Class Initialized
INFO - 2024-09-17 23:11:50 --> Loader Class Initialized
INFO - 2024-09-17 23:11:50 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-17 23:11:50 --> Helper loaded: url_helper
DEBUG - 2024-09-17 23:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-17 23:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:11:50 --> Controller Class Initialized
INFO - 2024-09-17 23:11:50 --> Config Class Initialized
INFO - 2024-09-17 23:11:50 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:11:50 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:11:50 --> Utf8 Class Initialized
INFO - 2024-09-17 23:11:50 --> URI Class Initialized
INFO - 2024-09-17 23:11:50 --> Router Class Initialized
INFO - 2024-09-17 23:11:50 --> Output Class Initialized
INFO - 2024-09-17 23:11:50 --> Security Class Initialized
DEBUG - 2024-09-17 23:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:11:50 --> Input Class Initialized
INFO - 2024-09-17 23:11:50 --> Language Class Initialized
INFO - 2024-09-17 23:11:50 --> Loader Class Initialized
INFO - 2024-09-17 23:11:50 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-17 23:11:50 --> Helper loaded: url_helper
DEBUG - 2024-09-17 23:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-17 23:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:11:50 --> Controller Class Initialized
DEBUG - 2024-09-17 23:11:50 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-17 23:11:50 --> Database Driver Class Initialized
INFO - 2024-09-17 23:11:50 --> Helper loaded: cookie_helper
INFO - 2024-09-17 23:11:50 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-17 23:11:50 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-17 23:11:50 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-17 23:11:50 --> Final output sent to browser
DEBUG - 2024-09-17 23:11:50 --> Total execution time: 0.0422
