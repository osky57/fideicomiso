<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-22 12:45:48 --> Config Class Initialized
INFO - 2024-09-22 12:45:48 --> Hooks Class Initialized
DEBUG - 2024-09-22 12:45:48 --> UTF-8 Support Enabled
INFO - 2024-09-22 12:45:48 --> Utf8 Class Initialized
INFO - 2024-09-22 12:45:48 --> URI Class Initialized
DEBUG - 2024-09-22 12:45:48 --> No URI present. Default controller set.
INFO - 2024-09-22 12:45:48 --> Router Class Initialized
INFO - 2024-09-22 12:45:48 --> Output Class Initialized
INFO - 2024-09-22 12:45:48 --> Security Class Initialized
DEBUG - 2024-09-22 12:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 12:45:48 --> Input Class Initialized
INFO - 2024-09-22 12:45:48 --> Language Class Initialized
INFO - 2024-09-22 12:45:48 --> Loader Class Initialized
INFO - 2024-09-22 12:45:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-22 12:45:48 --> Helper loaded: url_helper
DEBUG - 2024-09-22 12:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 12:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 12:45:48 --> Controller Class Initialized
INFO - 2024-09-22 13:23:25 --> Config Class Initialized
INFO - 2024-09-22 13:23:25 --> Hooks Class Initialized
DEBUG - 2024-09-22 13:23:25 --> UTF-8 Support Enabled
INFO - 2024-09-22 13:23:25 --> Utf8 Class Initialized
INFO - 2024-09-22 13:23:25 --> URI Class Initialized
DEBUG - 2024-09-22 13:23:25 --> No URI present. Default controller set.
INFO - 2024-09-22 13:23:25 --> Router Class Initialized
INFO - 2024-09-22 13:23:25 --> Output Class Initialized
INFO - 2024-09-22 13:23:25 --> Security Class Initialized
DEBUG - 2024-09-22 13:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 13:23:25 --> Input Class Initialized
INFO - 2024-09-22 13:23:25 --> Language Class Initialized
INFO - 2024-09-22 13:23:25 --> Loader Class Initialized
INFO - 2024-09-22 13:23:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-22 13:23:25 --> Helper loaded: url_helper
DEBUG - 2024-09-22 13:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 13:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 13:23:25 --> Controller Class Initialized
