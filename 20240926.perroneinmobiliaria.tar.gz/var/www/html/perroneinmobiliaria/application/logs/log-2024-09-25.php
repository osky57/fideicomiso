<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-25 11:01:07 --> Config Class Initialized
INFO - 2024-09-25 11:01:07 --> Hooks Class Initialized
DEBUG - 2024-09-25 11:01:07 --> UTF-8 Support Enabled
INFO - 2024-09-25 11:01:07 --> Utf8 Class Initialized
INFO - 2024-09-25 11:01:07 --> URI Class Initialized
DEBUG - 2024-09-25 11:01:07 --> No URI present. Default controller set.
INFO - 2024-09-25 11:01:07 --> Router Class Initialized
INFO - 2024-09-25 11:01:07 --> Output Class Initialized
INFO - 2024-09-25 11:01:07 --> Security Class Initialized
DEBUG - 2024-09-25 11:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 11:01:07 --> Input Class Initialized
INFO - 2024-09-25 11:01:07 --> Language Class Initialized
INFO - 2024-09-25 11:01:07 --> Loader Class Initialized
INFO - 2024-09-25 11:01:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 11:01:07 --> Helper loaded: url_helper
DEBUG - 2024-09-25 11:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 11:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 11:01:07 --> Controller Class Initialized
INFO - 2024-09-25 11:30:25 --> Config Class Initialized
INFO - 2024-09-25 11:30:25 --> Hooks Class Initialized
DEBUG - 2024-09-25 11:30:25 --> UTF-8 Support Enabled
INFO - 2024-09-25 11:30:25 --> Utf8 Class Initialized
INFO - 2024-09-25 11:30:25 --> URI Class Initialized
DEBUG - 2024-09-25 11:30:25 --> No URI present. Default controller set.
INFO - 2024-09-25 11:30:25 --> Router Class Initialized
INFO - 2024-09-25 11:30:25 --> Output Class Initialized
INFO - 2024-09-25 11:30:25 --> Security Class Initialized
DEBUG - 2024-09-25 11:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 11:30:25 --> Input Class Initialized
INFO - 2024-09-25 11:30:25 --> Language Class Initialized
INFO - 2024-09-25 11:30:25 --> Loader Class Initialized
INFO - 2024-09-25 11:30:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 11:30:25 --> Helper loaded: url_helper
DEBUG - 2024-09-25 11:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 11:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 11:30:25 --> Controller Class Initialized
INFO - 2024-09-25 11:30:25 --> Config Class Initialized
INFO - 2024-09-25 11:30:25 --> Hooks Class Initialized
DEBUG - 2024-09-25 11:30:25 --> UTF-8 Support Enabled
INFO - 2024-09-25 11:30:25 --> Utf8 Class Initialized
INFO - 2024-09-25 11:30:25 --> URI Class Initialized
INFO - 2024-09-25 11:30:25 --> Router Class Initialized
INFO - 2024-09-25 11:30:25 --> Output Class Initialized
INFO - 2024-09-25 11:30:25 --> Security Class Initialized
DEBUG - 2024-09-25 11:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 11:30:25 --> Input Class Initialized
INFO - 2024-09-25 11:30:25 --> Language Class Initialized
INFO - 2024-09-25 11:30:25 --> Loader Class Initialized
INFO - 2024-09-25 11:30:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 11:30:25 --> Helper loaded: url_helper
DEBUG - 2024-09-25 11:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 11:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 11:30:25 --> Controller Class Initialized
DEBUG - 2024-09-25 11:30:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 11:30:25 --> Database Driver Class Initialized
INFO - 2024-09-25 11:30:25 --> Helper loaded: cookie_helper
INFO - 2024-09-25 11:30:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 11:30:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 11:30:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-25 11:30:25 --> Final output sent to browser
DEBUG - 2024-09-25 11:30:25 --> Total execution time: 0.0283
INFO - 2024-09-25 16:19:21 --> Config Class Initialized
INFO - 2024-09-25 16:19:21 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:19:21 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:19:21 --> Utf8 Class Initialized
INFO - 2024-09-25 16:19:21 --> URI Class Initialized
DEBUG - 2024-09-25 16:19:21 --> No URI present. Default controller set.
INFO - 2024-09-25 16:19:21 --> Router Class Initialized
INFO - 2024-09-25 16:19:21 --> Output Class Initialized
INFO - 2024-09-25 16:19:21 --> Security Class Initialized
DEBUG - 2024-09-25 16:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:19:21 --> Input Class Initialized
INFO - 2024-09-25 16:19:21 --> Language Class Initialized
INFO - 2024-09-25 16:19:21 --> Loader Class Initialized
INFO - 2024-09-25 16:19:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:19:21 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:19:21 --> Controller Class Initialized
INFO - 2024-09-25 16:19:22 --> Config Class Initialized
INFO - 2024-09-25 16:19:22 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:19:22 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:19:22 --> Utf8 Class Initialized
INFO - 2024-09-25 16:19:22 --> URI Class Initialized
INFO - 2024-09-25 16:19:22 --> Router Class Initialized
INFO - 2024-09-25 16:19:22 --> Output Class Initialized
INFO - 2024-09-25 16:19:22 --> Security Class Initialized
DEBUG - 2024-09-25 16:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:19:22 --> Input Class Initialized
INFO - 2024-09-25 16:19:22 --> Language Class Initialized
INFO - 2024-09-25 16:19:22 --> Loader Class Initialized
INFO - 2024-09-25 16:19:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:19:22 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:19:22 --> Controller Class Initialized
DEBUG - 2024-09-25 16:19:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:19:22 --> Database Driver Class Initialized
INFO - 2024-09-25 16:19:22 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:19:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:19:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:19:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-25 16:19:22 --> Final output sent to browser
DEBUG - 2024-09-25 16:19:22 --> Total execution time: 0.0112
INFO - 2024-09-25 16:19:23 --> Config Class Initialized
INFO - 2024-09-25 16:19:23 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:19:23 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:19:23 --> Utf8 Class Initialized
INFO - 2024-09-25 16:19:23 --> URI Class Initialized
INFO - 2024-09-25 16:19:23 --> Router Class Initialized
INFO - 2024-09-25 16:19:23 --> Output Class Initialized
INFO - 2024-09-25 16:19:23 --> Security Class Initialized
DEBUG - 2024-09-25 16:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:19:23 --> Input Class Initialized
INFO - 2024-09-25 16:19:23 --> Language Class Initialized
INFO - 2024-09-25 16:19:23 --> Loader Class Initialized
INFO - 2024-09-25 16:19:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:19:23 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:19:23 --> Controller Class Initialized
INFO - 2024-09-25 16:19:33 --> Config Class Initialized
INFO - 2024-09-25 16:19:33 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:19:33 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:19:33 --> Utf8 Class Initialized
INFO - 2024-09-25 16:19:33 --> URI Class Initialized
INFO - 2024-09-25 16:19:33 --> Router Class Initialized
INFO - 2024-09-25 16:19:33 --> Output Class Initialized
INFO - 2024-09-25 16:19:33 --> Security Class Initialized
DEBUG - 2024-09-25 16:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:19:33 --> Input Class Initialized
INFO - 2024-09-25 16:19:33 --> Language Class Initialized
INFO - 2024-09-25 16:19:33 --> Loader Class Initialized
INFO - 2024-09-25 16:19:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:19:33 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:19:33 --> Controller Class Initialized
DEBUG - 2024-09-25 16:19:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:19:33 --> Database Driver Class Initialized
INFO - 2024-09-25 16:19:33 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:19:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:19:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:19:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-25 16:19:33 --> Final output sent to browser
DEBUG - 2024-09-25 16:19:33 --> Total execution time: 0.0112
INFO - 2024-09-25 16:20:14 --> Config Class Initialized
INFO - 2024-09-25 16:20:14 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:14 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:14 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:14 --> URI Class Initialized
INFO - 2024-09-25 16:20:14 --> Router Class Initialized
INFO - 2024-09-25 16:20:14 --> Output Class Initialized
INFO - 2024-09-25 16:20:14 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:14 --> Input Class Initialized
INFO - 2024-09-25 16:20:14 --> Language Class Initialized
INFO - 2024-09-25 16:20:14 --> Loader Class Initialized
INFO - 2024-09-25 16:20:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:14 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:14 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:14 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:20:14 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:14 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:20:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:14 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-25 16:20:14 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:14 --> Total execution time: 0.0102
INFO - 2024-09-25 16:20:15 --> Config Class Initialized
INFO - 2024-09-25 16:20:15 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:15 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:15 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:15 --> URI Class Initialized
INFO - 2024-09-25 16:20:15 --> Router Class Initialized
INFO - 2024-09-25 16:20:15 --> Output Class Initialized
INFO - 2024-09-25 16:20:15 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:15 --> Input Class Initialized
INFO - 2024-09-25 16:20:15 --> Language Class Initialized
INFO - 2024-09-25 16:20:15 --> Loader Class Initialized
INFO - 2024-09-25 16:20:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:15 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:15 --> Controller Class Initialized
INFO - 2024-09-25 16:20:18 --> Config Class Initialized
INFO - 2024-09-25 16:20:18 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:18 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:18 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:18 --> URI Class Initialized
INFO - 2024-09-25 16:20:18 --> Router Class Initialized
INFO - 2024-09-25 16:20:18 --> Output Class Initialized
INFO - 2024-09-25 16:20:18 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:18 --> Input Class Initialized
INFO - 2024-09-25 16:20:18 --> Language Class Initialized
INFO - 2024-09-25 16:20:18 --> Loader Class Initialized
INFO - 2024-09-25 16:20:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:18 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:18 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:20:18 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:18 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:20:18 --> Helper loaded: form_helper
INFO - 2024-09-25 16:20:18 --> Form Validation Class Initialized
INFO - 2024-09-25 16:20:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-25 16:20:18 --> Config Class Initialized
INFO - 2024-09-25 16:20:18 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:18 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:18 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:18 --> URI Class Initialized
INFO - 2024-09-25 16:20:18 --> Router Class Initialized
INFO - 2024-09-25 16:20:18 --> Output Class Initialized
INFO - 2024-09-25 16:20:18 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:18 --> Input Class Initialized
INFO - 2024-09-25 16:20:18 --> Language Class Initialized
INFO - 2024-09-25 16:20:18 --> Loader Class Initialized
INFO - 2024-09-25 16:20:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:18 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:18 --> Controller Class Initialized
INFO - 2024-09-25 16:20:18 --> Database Driver Class Initialized
DEBUG - 2024-09-25 16:20:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:20:18 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:20:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-09-25 16:20:18 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:18 --> Total execution time: 0.0092
INFO - 2024-09-25 16:20:18 --> Config Class Initialized
INFO - 2024-09-25 16:20:18 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:18 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:18 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:18 --> URI Class Initialized
INFO - 2024-09-25 16:20:18 --> Router Class Initialized
INFO - 2024-09-25 16:20:18 --> Output Class Initialized
INFO - 2024-09-25 16:20:18 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:18 --> Input Class Initialized
INFO - 2024-09-25 16:20:18 --> Language Class Initialized
INFO - 2024-09-25 16:20:18 --> Loader Class Initialized
INFO - 2024-09-25 16:20:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:18 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:18 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:18 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:18 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:18 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:18 --> Total execution time: 0.0300
INFO - 2024-09-25 16:20:24 --> Config Class Initialized
INFO - 2024-09-25 16:20:24 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:24 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:24 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:24 --> URI Class Initialized
INFO - 2024-09-25 16:20:24 --> Router Class Initialized
INFO - 2024-09-25 16:20:24 --> Output Class Initialized
INFO - 2024-09-25 16:20:24 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:24 --> Input Class Initialized
INFO - 2024-09-25 16:20:24 --> Language Class Initialized
INFO - 2024-09-25 16:20:24 --> Loader Class Initialized
INFO - 2024-09-25 16:20:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:24 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:24 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:24 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:24 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:24 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:24 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:24 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/proyectos.php
INFO - 2024-09-25 16:20:24 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:24 --> Total execution time: 0.0107
INFO - 2024-09-25 16:20:24 --> Config Class Initialized
INFO - 2024-09-25 16:20:24 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:24 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:24 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:24 --> URI Class Initialized
INFO - 2024-09-25 16:20:24 --> Router Class Initialized
INFO - 2024-09-25 16:20:24 --> Output Class Initialized
INFO - 2024-09-25 16:20:24 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:24 --> Input Class Initialized
INFO - 2024-09-25 16:20:24 --> Language Class Initialized
INFO - 2024-09-25 16:20:24 --> Loader Class Initialized
INFO - 2024-09-25 16:20:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:24 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:24 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:24 --> Config Class Initialized
INFO - 2024-09-25 16:20:24 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:24 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:24 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:24 --> URI Class Initialized
INFO - 2024-09-25 16:20:24 --> Router Class Initialized
INFO - 2024-09-25 16:20:24 --> Output Class Initialized
INFO - 2024-09-25 16:20:24 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:24 --> Input Class Initialized
INFO - 2024-09-25 16:20:24 --> Language Class Initialized
INFO - 2024-09-25 16:20:24 --> Loader Class Initialized
INFO - 2024-09-25 16:20:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:24 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:24 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:24 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:24 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:24 --> Total execution time: 0.0244
INFO - 2024-09-25 16:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:24 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:24 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:24 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:24 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:24 --> Total execution time: 0.0381
INFO - 2024-09-25 16:20:27 --> Config Class Initialized
INFO - 2024-09-25 16:20:27 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:27 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:27 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:27 --> URI Class Initialized
INFO - 2024-09-25 16:20:27 --> Router Class Initialized
INFO - 2024-09-25 16:20:27 --> Output Class Initialized
INFO - 2024-09-25 16:20:27 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:27 --> Input Class Initialized
INFO - 2024-09-25 16:20:27 --> Language Class Initialized
INFO - 2024-09-25 16:20:27 --> Loader Class Initialized
INFO - 2024-09-25 16:20:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:27 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:27 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:27 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-09-25 16:20:27 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:27 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:27 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:27 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:27 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-09-25 16:20:27 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:27 --> Total execution time: 0.0139
INFO - 2024-09-25 16:20:27 --> Config Class Initialized
INFO - 2024-09-25 16:20:27 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:27 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:27 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:27 --> URI Class Initialized
INFO - 2024-09-25 16:20:27 --> Router Class Initialized
INFO - 2024-09-25 16:20:27 --> Output Class Initialized
INFO - 2024-09-25 16:20:27 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:27 --> Input Class Initialized
INFO - 2024-09-25 16:20:27 --> Language Class Initialized
INFO - 2024-09-25 16:20:27 --> Loader Class Initialized
INFO - 2024-09-25 16:20:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:27 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:27 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:27 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:27 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:27 --> Config Class Initialized
INFO - 2024-09-25 16:20:27 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:27 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:27 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:27 --> URI Class Initialized
INFO - 2024-09-25 16:20:27 --> Router Class Initialized
INFO - 2024-09-25 16:20:27 --> Output Class Initialized
INFO - 2024-09-25 16:20:27 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:27 --> Input Class Initialized
INFO - 2024-09-25 16:20:27 --> Language Class Initialized
INFO - 2024-09-25 16:20:27 --> Loader Class Initialized
INFO - 2024-09-25 16:20:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:27 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:27 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:27 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:27 --> Total execution time: 0.0140
INFO - 2024-09-25 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:27 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:27 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-09-25 16:20:27 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:27 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:27 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:27 --> Total execution time: 0.0591
INFO - 2024-09-25 16:20:31 --> Config Class Initialized
INFO - 2024-09-25 16:20:31 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:31 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:31 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:31 --> URI Class Initialized
INFO - 2024-09-25 16:20:31 --> Router Class Initialized
INFO - 2024-09-25 16:20:31 --> Output Class Initialized
INFO - 2024-09-25 16:20:31 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:31 --> Input Class Initialized
INFO - 2024-09-25 16:20:31 --> Language Class Initialized
INFO - 2024-09-25 16:20:31 --> Loader Class Initialized
INFO - 2024-09-25 16:20:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:31 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:31 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cotizaciones.php
INFO - 2024-09-25 16:20:31 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:31 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cotizaciones.php
INFO - 2024-09-25 16:20:32 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:32 --> Total execution time: 0.0115
INFO - 2024-09-25 16:20:32 --> Config Class Initialized
INFO - 2024-09-25 16:20:32 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:32 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:32 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:32 --> URI Class Initialized
INFO - 2024-09-25 16:20:32 --> Router Class Initialized
INFO - 2024-09-25 16:20:32 --> Output Class Initialized
INFO - 2024-09-25 16:20:32 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:32 --> Input Class Initialized
INFO - 2024-09-25 16:20:32 --> Language Class Initialized
INFO - 2024-09-25 16:20:32 --> Loader Class Initialized
INFO - 2024-09-25 16:20:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:32 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:32 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cotizaciones.php
INFO - 2024-09-25 16:20:32 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:32 --> Config Class Initialized
INFO - 2024-09-25 16:20:32 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:32 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:32 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:32 --> URI Class Initialized
INFO - 2024-09-25 16:20:32 --> Router Class Initialized
INFO - 2024-09-25 16:20:32 --> Output Class Initialized
INFO - 2024-09-25 16:20:32 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:32 --> Input Class Initialized
INFO - 2024-09-25 16:20:32 --> Language Class Initialized
INFO - 2024-09-25 16:20:32 --> Loader Class Initialized
INFO - 2024-09-25 16:20:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:32 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:32 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:32 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:32 --> Total execution time: 0.0160
INFO - 2024-09-25 16:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:32 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:32 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:32 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:32 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:32 --> Total execution time: 0.0326
INFO - 2024-09-25 16:20:33 --> Config Class Initialized
INFO - 2024-09-25 16:20:33 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:33 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:33 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:33 --> URI Class Initialized
INFO - 2024-09-25 16:20:33 --> Router Class Initialized
INFO - 2024-09-25 16:20:33 --> Output Class Initialized
INFO - 2024-09-25 16:20:33 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:33 --> Input Class Initialized
INFO - 2024-09-25 16:20:33 --> Language Class Initialized
INFO - 2024-09-25 16:20:33 --> Loader Class Initialized
INFO - 2024-09-25 16:20:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:33 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:33 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_caja.php
INFO - 2024-09-25 16:20:33 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:33 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informescaja.php
INFO - 2024-09-25 16:20:33 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:33 --> Total execution time: 0.0135
INFO - 2024-09-25 16:20:34 --> Config Class Initialized
INFO - 2024-09-25 16:20:34 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:34 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:34 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:34 --> URI Class Initialized
INFO - 2024-09-25 16:20:34 --> Router Class Initialized
INFO - 2024-09-25 16:20:34 --> Output Class Initialized
INFO - 2024-09-25 16:20:34 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:34 --> Input Class Initialized
INFO - 2024-09-25 16:20:34 --> Language Class Initialized
INFO - 2024-09-25 16:20:34 --> Loader Class Initialized
INFO - 2024-09-25 16:20:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:34 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:34 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:34 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:34 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:34 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:34 --> Total execution time: 0.0211
INFO - 2024-09-25 16:20:35 --> Config Class Initialized
INFO - 2024-09-25 16:20:35 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:35 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:35 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:35 --> URI Class Initialized
INFO - 2024-09-25 16:20:35 --> Router Class Initialized
INFO - 2024-09-25 16:20:35 --> Output Class Initialized
INFO - 2024-09-25 16:20:35 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:35 --> Input Class Initialized
INFO - 2024-09-25 16:20:35 --> Language Class Initialized
INFO - 2024-09-25 16:20:35 --> Loader Class Initialized
INFO - 2024-09-25 16:20:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:35 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:35 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:20:35 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:35 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informeschq.php
INFO - 2024-09-25 16:20:35 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:35 --> Total execution time: 0.0181
INFO - 2024-09-25 16:20:35 --> Config Class Initialized
INFO - 2024-09-25 16:20:35 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:35 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:35 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:35 --> URI Class Initialized
INFO - 2024-09-25 16:20:35 --> Router Class Initialized
INFO - 2024-09-25 16:20:35 --> Output Class Initialized
INFO - 2024-09-25 16:20:35 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:35 --> Input Class Initialized
INFO - 2024-09-25 16:20:35 --> Language Class Initialized
INFO - 2024-09-25 16:20:35 --> Loader Class Initialized
INFO - 2024-09-25 16:20:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:35 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:35 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:35 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:35 --> Config Class Initialized
INFO - 2024-09-25 16:20:35 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:35 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:35 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:35 --> URI Class Initialized
INFO - 2024-09-25 16:20:35 --> Router Class Initialized
INFO - 2024-09-25 16:20:35 --> Output Class Initialized
INFO - 2024-09-25 16:20:35 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:35 --> Input Class Initialized
INFO - 2024-09-25 16:20:35 --> Language Class Initialized
INFO - 2024-09-25 16:20:35 --> Loader Class Initialized
INFO - 2024-09-25 16:20:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:35 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:35 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:35 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:35 --> Total execution time: 0.0138
INFO - 2024-09-25 16:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:35 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:20:35 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:35 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:35 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:35 --> Total execution time: 0.0378
INFO - 2024-09-25 16:20:39 --> Config Class Initialized
INFO - 2024-09-25 16:20:39 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:39 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:39 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:39 --> URI Class Initialized
INFO - 2024-09-25 16:20:39 --> Router Class Initialized
INFO - 2024-09-25 16:20:39 --> Output Class Initialized
INFO - 2024-09-25 16:20:39 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:39 --> Input Class Initialized
INFO - 2024-09-25 16:20:39 --> Language Class Initialized
INFO - 2024-09-25 16:20:39 --> Loader Class Initialized
INFO - 2024-09-25 16:20:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:39 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:39 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:39 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:39 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:20:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:20:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/proyectos.php
INFO - 2024-09-25 16:20:39 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:39 --> Total execution time: 0.0098
INFO - 2024-09-25 16:20:39 --> Config Class Initialized
INFO - 2024-09-25 16:20:39 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:39 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:39 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:39 --> URI Class Initialized
INFO - 2024-09-25 16:20:39 --> Router Class Initialized
INFO - 2024-09-25 16:20:39 --> Output Class Initialized
INFO - 2024-09-25 16:20:39 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:39 --> Input Class Initialized
INFO - 2024-09-25 16:20:39 --> Language Class Initialized
INFO - 2024-09-25 16:20:39 --> Loader Class Initialized
INFO - 2024-09-25 16:20:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:39 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:39 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:39 --> Config Class Initialized
INFO - 2024-09-25 16:20:39 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:20:39 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:20:39 --> Utf8 Class Initialized
INFO - 2024-09-25 16:20:39 --> URI Class Initialized
INFO - 2024-09-25 16:20:39 --> Router Class Initialized
INFO - 2024-09-25 16:20:39 --> Output Class Initialized
INFO - 2024-09-25 16:20:39 --> Security Class Initialized
DEBUG - 2024-09-25 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:20:39 --> Input Class Initialized
INFO - 2024-09-25 16:20:39 --> Language Class Initialized
INFO - 2024-09-25 16:20:39 --> Loader Class Initialized
INFO - 2024-09-25 16:20:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:20:39 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:20:39 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:39 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:39 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:39 --> Total execution time: 0.0153
INFO - 2024-09-25 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:20:39 --> Controller Class Initialized
DEBUG - 2024-09-25 16:20:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:20:39 --> Database Driver Class Initialized
INFO - 2024-09-25 16:20:39 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:20:39 --> Final output sent to browser
DEBUG - 2024-09-25 16:20:39 --> Total execution time: 0.0315
INFO - 2024-09-25 16:28:17 --> Config Class Initialized
INFO - 2024-09-25 16:28:17 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:17 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:17 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:17 --> URI Class Initialized
DEBUG - 2024-09-25 16:28:17 --> No URI present. Default controller set.
INFO - 2024-09-25 16:28:17 --> Router Class Initialized
INFO - 2024-09-25 16:28:17 --> Output Class Initialized
INFO - 2024-09-25 16:28:17 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:17 --> Input Class Initialized
INFO - 2024-09-25 16:28:17 --> Language Class Initialized
INFO - 2024-09-25 16:28:17 --> Loader Class Initialized
INFO - 2024-09-25 16:28:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:17 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:17 --> Controller Class Initialized
INFO - 2024-09-25 16:28:18 --> Config Class Initialized
INFO - 2024-09-25 16:28:18 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:18 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:18 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:18 --> URI Class Initialized
INFO - 2024-09-25 16:28:18 --> Router Class Initialized
INFO - 2024-09-25 16:28:18 --> Output Class Initialized
INFO - 2024-09-25 16:28:18 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:18 --> Input Class Initialized
INFO - 2024-09-25 16:28:18 --> Language Class Initialized
INFO - 2024-09-25 16:28:18 --> Loader Class Initialized
INFO - 2024-09-25 16:28:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:18 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:18 --> Controller Class Initialized
DEBUG - 2024-09-25 16:28:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:28:18 --> Database Driver Class Initialized
INFO - 2024-09-25 16:28:18 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:28:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:28:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:28:18 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-25 16:28:18 --> Final output sent to browser
DEBUG - 2024-09-25 16:28:18 --> Total execution time: 0.0136
INFO - 2024-09-25 16:28:18 --> Config Class Initialized
INFO - 2024-09-25 16:28:18 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:18 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:18 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:18 --> URI Class Initialized
INFO - 2024-09-25 16:28:18 --> Router Class Initialized
INFO - 2024-09-25 16:28:18 --> Output Class Initialized
INFO - 2024-09-25 16:28:18 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:18 --> Input Class Initialized
INFO - 2024-09-25 16:28:18 --> Language Class Initialized
INFO - 2024-09-25 16:28:18 --> Loader Class Initialized
INFO - 2024-09-25 16:28:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:18 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:18 --> Controller Class Initialized
INFO - 2024-09-25 16:28:21 --> Config Class Initialized
INFO - 2024-09-25 16:28:21 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:21 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:21 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:21 --> URI Class Initialized
INFO - 2024-09-25 16:28:21 --> Router Class Initialized
INFO - 2024-09-25 16:28:21 --> Output Class Initialized
INFO - 2024-09-25 16:28:21 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:21 --> Input Class Initialized
INFO - 2024-09-25 16:28:21 --> Language Class Initialized
INFO - 2024-09-25 16:28:21 --> Loader Class Initialized
INFO - 2024-09-25 16:28:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:21 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:21 --> Controller Class Initialized
DEBUG - 2024-09-25 16:28:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:28:21 --> Database Driver Class Initialized
INFO - 2024-09-25 16:28:21 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:28:21 --> Helper loaded: form_helper
INFO - 2024-09-25 16:28:21 --> Form Validation Class Initialized
INFO - 2024-09-25 16:28:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-25 16:28:21 --> Config Class Initialized
INFO - 2024-09-25 16:28:21 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:21 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:21 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:21 --> URI Class Initialized
INFO - 2024-09-25 16:28:21 --> Router Class Initialized
INFO - 2024-09-25 16:28:21 --> Output Class Initialized
INFO - 2024-09-25 16:28:21 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:21 --> Input Class Initialized
INFO - 2024-09-25 16:28:21 --> Language Class Initialized
INFO - 2024-09-25 16:28:21 --> Loader Class Initialized
INFO - 2024-09-25 16:28:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:21 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:21 --> Controller Class Initialized
INFO - 2024-09-25 16:28:21 --> Database Driver Class Initialized
DEBUG - 2024-09-25 16:28:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:28:21 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:28:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:28:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:28:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-09-25 16:28:21 --> Final output sent to browser
DEBUG - 2024-09-25 16:28:21 --> Total execution time: 0.0091
INFO - 2024-09-25 16:28:22 --> Config Class Initialized
INFO - 2024-09-25 16:28:22 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:22 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:22 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:22 --> URI Class Initialized
INFO - 2024-09-25 16:28:22 --> Router Class Initialized
INFO - 2024-09-25 16:28:22 --> Output Class Initialized
INFO - 2024-09-25 16:28:22 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:22 --> Input Class Initialized
INFO - 2024-09-25 16:28:22 --> Language Class Initialized
INFO - 2024-09-25 16:28:22 --> Loader Class Initialized
INFO - 2024-09-25 16:28:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:22 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:22 --> Controller Class Initialized
DEBUG - 2024-09-25 16:28:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:28:22 --> Database Driver Class Initialized
INFO - 2024-09-25 16:28:22 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:28:22 --> Final output sent to browser
DEBUG - 2024-09-25 16:28:22 --> Total execution time: 0.0193
INFO - 2024-09-25 16:28:28 --> Config Class Initialized
INFO - 2024-09-25 16:28:28 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:28 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:28 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:28 --> URI Class Initialized
INFO - 2024-09-25 16:28:28 --> Router Class Initialized
INFO - 2024-09-25 16:28:28 --> Output Class Initialized
INFO - 2024-09-25 16:28:28 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:28 --> Input Class Initialized
INFO - 2024-09-25 16:28:28 --> Language Class Initialized
INFO - 2024-09-25 16:28:28 --> Loader Class Initialized
INFO - 2024-09-25 16:28:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:28 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:28 --> Controller Class Initialized
DEBUG - 2024-09-25 16:28:28 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:28:28 --> Database Driver Class Initialized
INFO - 2024-09-25 16:28:28 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:28:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:28:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:28:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-09-25 16:28:28 --> Final output sent to browser
DEBUG - 2024-09-25 16:28:28 --> Total execution time: 0.0109
INFO - 2024-09-25 16:28:28 --> Config Class Initialized
INFO - 2024-09-25 16:28:28 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:28 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:28 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:28 --> URI Class Initialized
INFO - 2024-09-25 16:28:28 --> Router Class Initialized
INFO - 2024-09-25 16:28:28 --> Output Class Initialized
INFO - 2024-09-25 16:28:28 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:28 --> Input Class Initialized
INFO - 2024-09-25 16:28:28 --> Language Class Initialized
INFO - 2024-09-25 16:28:28 --> Loader Class Initialized
INFO - 2024-09-25 16:28:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:28 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:28 --> Controller Class Initialized
DEBUG - 2024-09-25 16:28:28 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:28:28 --> Database Driver Class Initialized
INFO - 2024-09-25 16:28:28 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:28:28 --> Final output sent to browser
DEBUG - 2024-09-25 16:28:28 --> Total execution time: 0.0160
INFO - 2024-09-25 16:28:49 --> Config Class Initialized
INFO - 2024-09-25 16:28:49 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:49 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:49 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:49 --> URI Class Initialized
INFO - 2024-09-25 16:28:49 --> Router Class Initialized
INFO - 2024-09-25 16:28:49 --> Output Class Initialized
INFO - 2024-09-25 16:28:49 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:49 --> Input Class Initialized
INFO - 2024-09-25 16:28:49 --> Language Class Initialized
INFO - 2024-09-25 16:28:49 --> Loader Class Initialized
INFO - 2024-09-25 16:28:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:49 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:49 --> Controller Class Initialized
DEBUG - 2024-09-25 16:28:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:28:49 --> Database Driver Class Initialized
INFO - 2024-09-25 16:28:49 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:28:49 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:28:49 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:28:49 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-09-25 16:28:49 --> Final output sent to browser
DEBUG - 2024-09-25 16:28:49 --> Total execution time: 0.0091
INFO - 2024-09-25 16:28:50 --> Config Class Initialized
INFO - 2024-09-25 16:28:50 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:28:50 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:28:50 --> Utf8 Class Initialized
INFO - 2024-09-25 16:28:50 --> URI Class Initialized
INFO - 2024-09-25 16:28:50 --> Router Class Initialized
INFO - 2024-09-25 16:28:50 --> Output Class Initialized
INFO - 2024-09-25 16:28:50 --> Security Class Initialized
DEBUG - 2024-09-25 16:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:28:50 --> Input Class Initialized
INFO - 2024-09-25 16:28:50 --> Language Class Initialized
INFO - 2024-09-25 16:28:50 --> Loader Class Initialized
INFO - 2024-09-25 16:28:50 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:28:50 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:28:50 --> Controller Class Initialized
INFO - 2024-09-25 16:29:02 --> Config Class Initialized
INFO - 2024-09-25 16:29:02 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:02 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:02 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:02 --> URI Class Initialized
INFO - 2024-09-25 16:29:02 --> Router Class Initialized
INFO - 2024-09-25 16:29:02 --> Output Class Initialized
INFO - 2024-09-25 16:29:02 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:02 --> Input Class Initialized
INFO - 2024-09-25 16:29:02 --> Language Class Initialized
INFO - 2024-09-25 16:29:02 --> Loader Class Initialized
INFO - 2024-09-25 16:29:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:02 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:02 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:29:02 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:02 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:29:02 --> Config Class Initialized
INFO - 2024-09-25 16:29:02 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:02 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:02 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:02 --> URI Class Initialized
INFO - 2024-09-25 16:29:02 --> Router Class Initialized
INFO - 2024-09-25 16:29:02 --> Output Class Initialized
INFO - 2024-09-25 16:29:02 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:02 --> Input Class Initialized
INFO - 2024-09-25 16:29:02 --> Language Class Initialized
INFO - 2024-09-25 16:29:02 --> Loader Class Initialized
INFO - 2024-09-25 16:29:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:02 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:02 --> Controller Class Initialized
INFO - 2024-09-25 16:29:02 --> Database Driver Class Initialized
DEBUG - 2024-09-25 16:29:02 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:29:02 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:29:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:29:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:29:02 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-09-25 16:29:02 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:02 --> Total execution time: 0.0101
INFO - 2024-09-25 16:29:03 --> Config Class Initialized
INFO - 2024-09-25 16:29:03 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:03 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:03 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:03 --> URI Class Initialized
INFO - 2024-09-25 16:29:03 --> Router Class Initialized
INFO - 2024-09-25 16:29:03 --> Output Class Initialized
INFO - 2024-09-25 16:29:03 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:03 --> Input Class Initialized
INFO - 2024-09-25 16:29:03 --> Language Class Initialized
INFO - 2024-09-25 16:29:03 --> Loader Class Initialized
INFO - 2024-09-25 16:29:03 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:03 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:03 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:03 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:03 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:03 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:03 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:03 --> Total execution time: 0.0176
INFO - 2024-09-25 16:29:09 --> Config Class Initialized
INFO - 2024-09-25 16:29:09 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:09 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:09 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:09 --> URI Class Initialized
INFO - 2024-09-25 16:29:09 --> Router Class Initialized
INFO - 2024-09-25 16:29:09 --> Output Class Initialized
INFO - 2024-09-25 16:29:09 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:09 --> Input Class Initialized
INFO - 2024-09-25 16:29:09 --> Language Class Initialized
INFO - 2024-09-25 16:29:09 --> Loader Class Initialized
INFO - 2024-09-25 16:29:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:09 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:09 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:09 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:09 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:09 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:09 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:29:09 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:29:09 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-09-25 16:29:09 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:09 --> Total execution time: 0.0097
INFO - 2024-09-25 16:29:10 --> Config Class Initialized
INFO - 2024-09-25 16:29:10 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:10 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:10 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:10 --> URI Class Initialized
INFO - 2024-09-25 16:29:10 --> Router Class Initialized
INFO - 2024-09-25 16:29:10 --> Output Class Initialized
INFO - 2024-09-25 16:29:10 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:10 --> Input Class Initialized
INFO - 2024-09-25 16:29:10 --> Language Class Initialized
INFO - 2024-09-25 16:29:10 --> Loader Class Initialized
INFO - 2024-09-25 16:29:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:10 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:10 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:10 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:10 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:10 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:10 --> Total execution time: 0.0132
INFO - 2024-09-25 16:29:20 --> Config Class Initialized
INFO - 2024-09-25 16:29:20 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:20 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:20 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:20 --> URI Class Initialized
INFO - 2024-09-25 16:29:20 --> Router Class Initialized
INFO - 2024-09-25 16:29:20 --> Output Class Initialized
INFO - 2024-09-25 16:29:20 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:20 --> Input Class Initialized
INFO - 2024-09-25 16:29:20 --> Language Class Initialized
INFO - 2024-09-25 16:29:20 --> Loader Class Initialized
INFO - 2024-09-25 16:29:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:20 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:20 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cotizaciones.php
INFO - 2024-09-25 16:29:20 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:20 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:20 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:29:20 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:29:20 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cotizaciones.php
INFO - 2024-09-25 16:29:20 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:20 --> Total execution time: 0.0116
INFO - 2024-09-25 16:29:20 --> Config Class Initialized
INFO - 2024-09-25 16:29:20 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:20 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:20 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:20 --> URI Class Initialized
INFO - 2024-09-25 16:29:20 --> Router Class Initialized
INFO - 2024-09-25 16:29:20 --> Output Class Initialized
INFO - 2024-09-25 16:29:20 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:20 --> Input Class Initialized
INFO - 2024-09-25 16:29:20 --> Language Class Initialized
INFO - 2024-09-25 16:29:20 --> Loader Class Initialized
INFO - 2024-09-25 16:29:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:20 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:20 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:20 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:20 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:20 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:20 --> Total execution time: 0.0206
INFO - 2024-09-25 16:29:20 --> Config Class Initialized
INFO - 2024-09-25 16:29:20 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:20 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:20 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:20 --> URI Class Initialized
INFO - 2024-09-25 16:29:20 --> Router Class Initialized
INFO - 2024-09-25 16:29:20 --> Output Class Initialized
INFO - 2024-09-25 16:29:20 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:20 --> Input Class Initialized
INFO - 2024-09-25 16:29:20 --> Language Class Initialized
INFO - 2024-09-25 16:29:20 --> Loader Class Initialized
INFO - 2024-09-25 16:29:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:20 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:20 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cotizaciones.php
INFO - 2024-09-25 16:29:20 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:20 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:20 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:20 --> Total execution time: 0.0179
INFO - 2024-09-25 16:29:21 --> Config Class Initialized
INFO - 2024-09-25 16:29:21 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:21 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:21 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:21 --> URI Class Initialized
INFO - 2024-09-25 16:29:21 --> Router Class Initialized
INFO - 2024-09-25 16:29:21 --> Output Class Initialized
INFO - 2024-09-25 16:29:21 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:21 --> Input Class Initialized
INFO - 2024-09-25 16:29:21 --> Language Class Initialized
INFO - 2024-09-25 16:29:21 --> Loader Class Initialized
INFO - 2024-09-25 16:29:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:21 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:21 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_caja.php
INFO - 2024-09-25 16:29:21 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:21 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:29:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:29:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informescaja.php
INFO - 2024-09-25 16:29:21 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:21 --> Total execution time: 0.0137
INFO - 2024-09-25 16:29:21 --> Config Class Initialized
INFO - 2024-09-25 16:29:21 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:21 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:21 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:21 --> URI Class Initialized
INFO - 2024-09-25 16:29:21 --> Router Class Initialized
INFO - 2024-09-25 16:29:21 --> Output Class Initialized
INFO - 2024-09-25 16:29:21 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:21 --> Input Class Initialized
INFO - 2024-09-25 16:29:21 --> Language Class Initialized
INFO - 2024-09-25 16:29:21 --> Loader Class Initialized
INFO - 2024-09-25 16:29:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:21 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:21 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:21 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:21 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:21 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:21 --> Total execution time: 0.0155
INFO - 2024-09-25 16:29:23 --> Config Class Initialized
INFO - 2024-09-25 16:29:23 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:23 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:23 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:23 --> URI Class Initialized
INFO - 2024-09-25 16:29:23 --> Router Class Initialized
INFO - 2024-09-25 16:29:23 --> Output Class Initialized
INFO - 2024-09-25 16:29:23 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:23 --> Input Class Initialized
INFO - 2024-09-25 16:29:23 --> Language Class Initialized
INFO - 2024-09-25 16:29:23 --> Loader Class Initialized
INFO - 2024-09-25 16:29:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:23 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:23 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_caja.php
INFO - 2024-09-25 16:29:23 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:23 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:23 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:23 --> Total execution time: 0.0331
INFO - 2024-09-25 16:29:28 --> Config Class Initialized
INFO - 2024-09-25 16:29:28 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:28 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:28 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:28 --> URI Class Initialized
INFO - 2024-09-25 16:29:28 --> Router Class Initialized
INFO - 2024-09-25 16:29:28 --> Output Class Initialized
INFO - 2024-09-25 16:29:28 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:28 --> Input Class Initialized
INFO - 2024-09-25 16:29:28 --> Language Class Initialized
INFO - 2024-09-25 16:29:28 --> Loader Class Initialized
INFO - 2024-09-25 16:29:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:28 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:28 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:28 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:28 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:28 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:29:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:29:28 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informeschq.php
INFO - 2024-09-25 16:29:28 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:28 --> Total execution time: 0.0127
INFO - 2024-09-25 16:29:29 --> Config Class Initialized
INFO - 2024-09-25 16:29:29 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:29 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:29 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:29 --> URI Class Initialized
INFO - 2024-09-25 16:29:29 --> Router Class Initialized
INFO - 2024-09-25 16:29:29 --> Output Class Initialized
INFO - 2024-09-25 16:29:29 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:29 --> Input Class Initialized
INFO - 2024-09-25 16:29:29 --> Language Class Initialized
INFO - 2024-09-25 16:29:29 --> Config Class Initialized
INFO - 2024-09-25 16:29:29 --> Hooks Class Initialized
INFO - 2024-09-25 16:29:29 --> Loader Class Initialized
DEBUG - 2024-09-25 16:29:29 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:29 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:29 --> URI Class Initialized
INFO - 2024-09-25 16:29:29 --> Helper loaded: url_helper
INFO - 2024-09-25 16:29:29 --> Router Class Initialized
INFO - 2024-09-25 16:29:29 --> Output Class Initialized
INFO - 2024-09-25 16:29:29 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-09-25 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:29 --> Input Class Initialized
INFO - 2024-09-25 16:29:29 --> Language Class Initialized
INFO - 2024-09-25 16:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:29 --> Loader Class Initialized
INFO - 2024-09-25 16:29:29 --> Controller Class Initialized
INFO - 2024-09-25 16:29:29 --> Helper loaded: is_loged_in_helper
DEBUG - 2024-09-25 16:29:29 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:29 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:29 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:29 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:29 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:29 --> Total execution time: 0.0165
INFO - 2024-09-25 16:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:29 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:29 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:29 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:29 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:29 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:29 --> Total execution time: 0.0351
INFO - 2024-09-25 16:29:30 --> Config Class Initialized
INFO - 2024-09-25 16:29:30 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:30 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:30 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:30 --> URI Class Initialized
INFO - 2024-09-25 16:29:30 --> Router Class Initialized
INFO - 2024-09-25 16:29:30 --> Output Class Initialized
INFO - 2024-09-25 16:29:30 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:30 --> Input Class Initialized
INFO - 2024-09-25 16:29:30 --> Language Class Initialized
INFO - 2024-09-25 16:29:30 --> Loader Class Initialized
INFO - 2024-09-25 16:29:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:30 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:30 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:30 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:30 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:30 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:30 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:30 --> Total execution time: 0.0250
INFO - 2024-09-25 16:29:36 --> Config Class Initialized
INFO - 2024-09-25 16:29:36 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:36 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:36 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:36 --> URI Class Initialized
INFO - 2024-09-25 16:29:36 --> Router Class Initialized
INFO - 2024-09-25 16:29:36 --> Output Class Initialized
INFO - 2024-09-25 16:29:36 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:36 --> Input Class Initialized
INFO - 2024-09-25 16:29:36 --> Language Class Initialized
INFO - 2024-09-25 16:29:36 --> Loader Class Initialized
INFO - 2024-09-25 16:29:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:36 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:36 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:36 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:36 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:36 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:36 --> Total execution time: 0.0363
INFO - 2024-09-25 16:29:37 --> Config Class Initialized
INFO - 2024-09-25 16:29:37 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:37 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:37 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:37 --> URI Class Initialized
INFO - 2024-09-25 16:29:37 --> Router Class Initialized
INFO - 2024-09-25 16:29:37 --> Output Class Initialized
INFO - 2024-09-25 16:29:37 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:37 --> Input Class Initialized
INFO - 2024-09-25 16:29:37 --> Language Class Initialized
INFO - 2024-09-25 16:29:37 --> Loader Class Initialized
INFO - 2024-09-25 16:29:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:37 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:37 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:37 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:37 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:29:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:29:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-09-25 16:29:37 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:37 --> Total execution time: 0.0166
INFO - 2024-09-25 16:29:38 --> Config Class Initialized
INFO - 2024-09-25 16:29:38 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:38 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:38 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:38 --> URI Class Initialized
INFO - 2024-09-25 16:29:38 --> Router Class Initialized
INFO - 2024-09-25 16:29:38 --> Output Class Initialized
INFO - 2024-09-25 16:29:38 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:38 --> Input Class Initialized
INFO - 2024-09-25 16:29:38 --> Language Class Initialized
INFO - 2024-09-25 16:29:38 --> Loader Class Initialized
INFO - 2024-09-25 16:29:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:38 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:38 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:38 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:38 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:38 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:38 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:38 --> Total execution time: 0.0141
INFO - 2024-09-25 16:29:39 --> Config Class Initialized
INFO - 2024-09-25 16:29:39 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:39 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:39 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:39 --> URI Class Initialized
INFO - 2024-09-25 16:29:39 --> Router Class Initialized
INFO - 2024-09-25 16:29:39 --> Output Class Initialized
INFO - 2024-09-25 16:29:39 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:39 --> Input Class Initialized
INFO - 2024-09-25 16:29:39 --> Language Class Initialized
INFO - 2024-09-25 16:29:39 --> Loader Class Initialized
INFO - 2024-09-25 16:29:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:39 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:39 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:39 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:39 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:39 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:39 --> Total execution time: 0.0264
INFO - 2024-09-25 16:29:40 --> Config Class Initialized
INFO - 2024-09-25 16:29:40 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:40 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:40 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:40 --> URI Class Initialized
INFO - 2024-09-25 16:29:40 --> Router Class Initialized
INFO - 2024-09-25 16:29:40 --> Output Class Initialized
INFO - 2024-09-25 16:29:40 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:40 --> Input Class Initialized
INFO - 2024-09-25 16:29:40 --> Language Class Initialized
INFO - 2024-09-25 16:29:40 --> Loader Class Initialized
INFO - 2024-09-25 16:29:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:40 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:40 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:40 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:40 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:40 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:40 --> Total execution time: 0.0254
INFO - 2024-09-25 16:29:41 --> Config Class Initialized
INFO - 2024-09-25 16:29:41 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:41 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:41 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:41 --> URI Class Initialized
INFO - 2024-09-25 16:29:41 --> Router Class Initialized
INFO - 2024-09-25 16:29:41 --> Output Class Initialized
INFO - 2024-09-25 16:29:41 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:41 --> Input Class Initialized
INFO - 2024-09-25 16:29:41 --> Language Class Initialized
INFO - 2024-09-25 16:29:41 --> Loader Class Initialized
INFO - 2024-09-25 16:29:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:41 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:41 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:41 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:41 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:41 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:41 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:41 --> Total execution time: 0.0336
INFO - 2024-09-25 16:29:42 --> Config Class Initialized
INFO - 2024-09-25 16:29:42 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:42 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:42 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:42 --> URI Class Initialized
INFO - 2024-09-25 16:29:42 --> Router Class Initialized
INFO - 2024-09-25 16:29:42 --> Output Class Initialized
INFO - 2024-09-25 16:29:42 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:42 --> Input Class Initialized
INFO - 2024-09-25 16:29:42 --> Language Class Initialized
INFO - 2024-09-25 16:29:42 --> Loader Class Initialized
INFO - 2024-09-25 16:29:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:42 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:42 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_chq.php
INFO - 2024-09-25 16:29:42 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:42 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:42 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:42 --> Total execution time: 0.0238
INFO - 2024-09-25 16:29:48 --> Config Class Initialized
INFO - 2024-09-25 16:29:48 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:48 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:48 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:48 --> URI Class Initialized
INFO - 2024-09-25 16:29:48 --> Router Class Initialized
INFO - 2024-09-25 16:29:48 --> Output Class Initialized
INFO - 2024-09-25 16:29:48 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:48 --> Input Class Initialized
INFO - 2024-09-25 16:29:48 --> Language Class Initialized
INFO - 2024-09-25 16:29:48 --> Loader Class Initialized
INFO - 2024-09-25 16:29:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:48 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:48 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-09-25 16:29:48 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:48 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:29:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:29:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-09-25 16:29:48 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:48 --> Total execution time: 0.0104
INFO - 2024-09-25 16:29:49 --> Config Class Initialized
INFO - 2024-09-25 16:29:49 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:49 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:49 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:49 --> URI Class Initialized
INFO - 2024-09-25 16:29:49 --> Router Class Initialized
INFO - 2024-09-25 16:29:49 --> Output Class Initialized
INFO - 2024-09-25 16:29:49 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:49 --> Input Class Initialized
INFO - 2024-09-25 16:29:49 --> Language Class Initialized
INFO - 2024-09-25 16:29:49 --> Loader Class Initialized
INFO - 2024-09-25 16:29:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:49 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:49 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-09-25 16:29:49 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:49 --> Config Class Initialized
INFO - 2024-09-25 16:29:49 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:49 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:49 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:49 --> URI Class Initialized
INFO - 2024-09-25 16:29:49 --> Router Class Initialized
INFO - 2024-09-25 16:29:49 --> Output Class Initialized
INFO - 2024-09-25 16:29:49 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:49 --> Input Class Initialized
INFO - 2024-09-25 16:29:49 --> Language Class Initialized
INFO - 2024-09-25 16:29:49 --> Loader Class Initialized
INFO - 2024-09-25 16:29:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:49 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:49 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:49 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:49 --> Total execution time: 0.0426
INFO - 2024-09-25 16:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:49 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:29:49 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:49 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:49 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:49 --> Total execution time: 0.0576
INFO - 2024-09-25 16:29:51 --> Config Class Initialized
INFO - 2024-09-25 16:29:51 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:51 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:51 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:51 --> URI Class Initialized
INFO - 2024-09-25 16:29:51 --> Router Class Initialized
INFO - 2024-09-25 16:29:51 --> Output Class Initialized
INFO - 2024-09-25 16:29:51 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:51 --> Input Class Initialized
INFO - 2024-09-25 16:29:51 --> Language Class Initialized
INFO - 2024-09-25 16:29:51 --> Loader Class Initialized
INFO - 2024-09-25 16:29:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:51 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:51 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-09-25 16:29:51 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:51 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:51 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:51 --> Total execution time: 0.0369
INFO - 2024-09-25 16:29:53 --> Config Class Initialized
INFO - 2024-09-25 16:29:53 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:29:53 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:29:53 --> Utf8 Class Initialized
INFO - 2024-09-25 16:29:53 --> URI Class Initialized
INFO - 2024-09-25 16:29:53 --> Router Class Initialized
INFO - 2024-09-25 16:29:53 --> Output Class Initialized
INFO - 2024-09-25 16:29:53 --> Security Class Initialized
DEBUG - 2024-09-25 16:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:29:53 --> Input Class Initialized
INFO - 2024-09-25 16:29:53 --> Language Class Initialized
INFO - 2024-09-25 16:29:53 --> Loader Class Initialized
INFO - 2024-09-25 16:29:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:29:53 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:29:53 --> Controller Class Initialized
DEBUG - 2024-09-25 16:29:53 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-09-25 16:29:53 --> Database Driver Class Initialized
INFO - 2024-09-25 16:29:53 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:29:53 --> Final output sent to browser
DEBUG - 2024-09-25 16:29:53 --> Total execution time: 0.0319
INFO - 2024-09-25 16:30:17 --> Config Class Initialized
INFO - 2024-09-25 16:30:17 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:30:17 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:30:17 --> Utf8 Class Initialized
INFO - 2024-09-25 16:30:17 --> URI Class Initialized
INFO - 2024-09-25 16:30:17 --> Router Class Initialized
INFO - 2024-09-25 16:30:17 --> Output Class Initialized
INFO - 2024-09-25 16:30:17 --> Security Class Initialized
DEBUG - 2024-09-25 16:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:30:17 --> Input Class Initialized
INFO - 2024-09-25 16:30:17 --> Language Class Initialized
INFO - 2024-09-25 16:30:17 --> Loader Class Initialized
INFO - 2024-09-25 16:30:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:30:17 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:30:17 --> Controller Class Initialized
DEBUG - 2024-09-25 16:30:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:30:17 --> Database Driver Class Initialized
INFO - 2024-09-25 16:30:17 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:30:17 --> Helper loaded: form_helper
INFO - 2024-09-25 16:30:17 --> Form Validation Class Initialized
INFO - 2024-09-25 16:30:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-25 16:30:17 --> Config Class Initialized
INFO - 2024-09-25 16:30:17 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:30:17 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:30:17 --> Utf8 Class Initialized
INFO - 2024-09-25 16:30:17 --> URI Class Initialized
INFO - 2024-09-25 16:30:17 --> Router Class Initialized
INFO - 2024-09-25 16:30:17 --> Output Class Initialized
INFO - 2024-09-25 16:30:17 --> Security Class Initialized
DEBUG - 2024-09-25 16:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:30:17 --> Input Class Initialized
INFO - 2024-09-25 16:30:17 --> Language Class Initialized
INFO - 2024-09-25 16:30:17 --> Loader Class Initialized
INFO - 2024-09-25 16:30:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:30:17 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:30:17 --> Controller Class Initialized
INFO - 2024-09-25 16:30:17 --> Database Driver Class Initialized
DEBUG - 2024-09-25 16:30:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-09-25 16:30:17 --> Helper loaded: cookie_helper
INFO - 2024-09-25 16:30:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:30:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:30:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-09-25 16:30:17 --> Final output sent to browser
DEBUG - 2024-09-25 16:30:17 --> Total execution time: 0.0089
INFO - 2024-09-25 16:30:18 --> Config Class Initialized
INFO - 2024-09-25 16:30:18 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:30:18 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:30:18 --> Utf8 Class Initialized
INFO - 2024-09-25 16:30:18 --> URI Class Initialized
INFO - 2024-09-25 16:30:18 --> Router Class Initialized
INFO - 2024-09-25 16:30:18 --> Output Class Initialized
INFO - 2024-09-25 16:30:18 --> Security Class Initialized
DEBUG - 2024-09-25 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:30:18 --> Input Class Initialized
INFO - 2024-09-25 16:30:18 --> Language Class Initialized
INFO - 2024-09-25 16:30:18 --> Loader Class Initialized
INFO - 2024-09-25 16:30:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:30:18 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:30:18 --> Controller Class Initialized
DEBUG - 2024-09-25 16:30:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:30:18 --> Database Driver Class Initialized
INFO - 2024-09-25 16:30:18 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:30:18 --> Final output sent to browser
DEBUG - 2024-09-25 16:30:18 --> Total execution time: 0.0195
INFO - 2024-09-25 16:30:25 --> Config Class Initialized
INFO - 2024-09-25 16:30:25 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:30:25 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:30:25 --> Utf8 Class Initialized
INFO - 2024-09-25 16:30:25 --> URI Class Initialized
INFO - 2024-09-25 16:30:25 --> Router Class Initialized
INFO - 2024-09-25 16:30:25 --> Output Class Initialized
INFO - 2024-09-25 16:30:25 --> Security Class Initialized
DEBUG - 2024-09-25 16:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:30:25 --> Input Class Initialized
INFO - 2024-09-25 16:30:25 --> Language Class Initialized
INFO - 2024-09-25 16:30:25 --> Loader Class Initialized
INFO - 2024-09-25 16:30:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:30:25 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:30:25 --> Controller Class Initialized
DEBUG - 2024-09-25 16:30:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:30:25 --> Database Driver Class Initialized
INFO - 2024-09-25 16:30:25 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:30:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-09-25 16:30:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-09-25 16:30:25 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/proyectos.php
INFO - 2024-09-25 16:30:25 --> Final output sent to browser
DEBUG - 2024-09-25 16:30:25 --> Total execution time: 0.0117
INFO - 2024-09-25 16:30:25 --> Config Class Initialized
INFO - 2024-09-25 16:30:25 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:30:25 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:30:25 --> Utf8 Class Initialized
INFO - 2024-09-25 16:30:25 --> URI Class Initialized
INFO - 2024-09-25 16:30:25 --> Router Class Initialized
INFO - 2024-09-25 16:30:25 --> Output Class Initialized
INFO - 2024-09-25 16:30:25 --> Security Class Initialized
DEBUG - 2024-09-25 16:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:30:25 --> Input Class Initialized
INFO - 2024-09-25 16:30:25 --> Language Class Initialized
INFO - 2024-09-25 16:30:25 --> Loader Class Initialized
INFO - 2024-09-25 16:30:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:30:25 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:30:25 --> Controller Class Initialized
DEBUG - 2024-09-25 16:30:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:30:25 --> Database Driver Class Initialized
INFO - 2024-09-25 16:30:25 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:30:25 --> Final output sent to browser
DEBUG - 2024-09-25 16:30:25 --> Total execution time: 0.0179
INFO - 2024-09-25 16:30:25 --> Config Class Initialized
INFO - 2024-09-25 16:30:25 --> Hooks Class Initialized
DEBUG - 2024-09-25 16:30:25 --> UTF-8 Support Enabled
INFO - 2024-09-25 16:30:25 --> Utf8 Class Initialized
INFO - 2024-09-25 16:30:25 --> URI Class Initialized
INFO - 2024-09-25 16:30:25 --> Router Class Initialized
INFO - 2024-09-25 16:30:25 --> Output Class Initialized
INFO - 2024-09-25 16:30:25 --> Security Class Initialized
DEBUG - 2024-09-25 16:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 16:30:25 --> Input Class Initialized
INFO - 2024-09-25 16:30:25 --> Language Class Initialized
INFO - 2024-09-25 16:30:25 --> Loader Class Initialized
INFO - 2024-09-25 16:30:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-25 16:30:25 --> Helper loaded: url_helper
DEBUG - 2024-09-25 16:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-25 16:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 16:30:25 --> Controller Class Initialized
DEBUG - 2024-09-25 16:30:25 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-09-25 16:30:25 --> Database Driver Class Initialized
INFO - 2024-09-25 16:30:25 --> Helper loaded: funciones_helper
INFO - 2024-09-25 16:30:25 --> Final output sent to browser
DEBUG - 2024-09-25 16:30:25 --> Total execution time: 0.0190
