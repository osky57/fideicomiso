<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-02 00:03:05 --> Config Class Initialized
INFO - 2024-06-02 00:03:05 --> Hooks Class Initialized
DEBUG - 2024-06-02 00:03:05 --> UTF-8 Support Enabled
INFO - 2024-06-02 00:03:05 --> Utf8 Class Initialized
INFO - 2024-06-02 00:03:05 --> URI Class Initialized
DEBUG - 2024-06-02 00:03:05 --> No URI present. Default controller set.
INFO - 2024-06-02 00:03:05 --> Router Class Initialized
INFO - 2024-06-02 00:03:05 --> Output Class Initialized
INFO - 2024-06-02 00:03:05 --> Security Class Initialized
DEBUG - 2024-06-02 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 00:03:05 --> Input Class Initialized
INFO - 2024-06-02 00:03:05 --> Language Class Initialized
INFO - 2024-06-02 00:03:05 --> Loader Class Initialized
INFO - 2024-06-02 00:03:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-02 00:03:05 --> Helper loaded: url_helper
DEBUG - 2024-06-02 00:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-02 00:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 00:03:05 --> Controller Class Initialized
INFO - 2024-06-02 12:48:52 --> Config Class Initialized
INFO - 2024-06-02 12:48:52 --> Hooks Class Initialized
DEBUG - 2024-06-02 12:48:52 --> UTF-8 Support Enabled
INFO - 2024-06-02 12:48:52 --> Utf8 Class Initialized
INFO - 2024-06-02 12:48:52 --> URI Class Initialized
DEBUG - 2024-06-02 12:48:52 --> No URI present. Default controller set.
INFO - 2024-06-02 12:48:52 --> Router Class Initialized
INFO - 2024-06-02 12:48:52 --> Output Class Initialized
INFO - 2024-06-02 12:48:52 --> Security Class Initialized
DEBUG - 2024-06-02 12:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 12:48:52 --> Input Class Initialized
INFO - 2024-06-02 12:48:52 --> Language Class Initialized
INFO - 2024-06-02 12:48:52 --> Loader Class Initialized
INFO - 2024-06-02 12:48:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-02 12:48:52 --> Helper loaded: url_helper
DEBUG - 2024-06-02 12:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-02 12:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 12:48:52 --> Controller Class Initialized
INFO - 2024-06-02 13:03:19 --> Config Class Initialized
INFO - 2024-06-02 13:03:19 --> Hooks Class Initialized
DEBUG - 2024-06-02 13:03:19 --> UTF-8 Support Enabled
INFO - 2024-06-02 13:03:19 --> Utf8 Class Initialized
INFO - 2024-06-02 13:03:19 --> URI Class Initialized
DEBUG - 2024-06-02 13:03:19 --> No URI present. Default controller set.
INFO - 2024-06-02 13:03:19 --> Router Class Initialized
INFO - 2024-06-02 13:03:19 --> Output Class Initialized
INFO - 2024-06-02 13:03:19 --> Security Class Initialized
DEBUG - 2024-06-02 13:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 13:03:19 --> Input Class Initialized
INFO - 2024-06-02 13:03:19 --> Language Class Initialized
INFO - 2024-06-02 13:03:19 --> Loader Class Initialized
INFO - 2024-06-02 13:03:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-02 13:03:19 --> Helper loaded: url_helper
DEBUG - 2024-06-02 13:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-02 13:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 13:03:19 --> Controller Class Initialized
INFO - 2024-06-02 16:04:47 --> Config Class Initialized
INFO - 2024-06-02 16:04:47 --> Hooks Class Initialized
DEBUG - 2024-06-02 16:04:47 --> UTF-8 Support Enabled
INFO - 2024-06-02 16:04:47 --> Utf8 Class Initialized
INFO - 2024-06-02 16:04:47 --> URI Class Initialized
DEBUG - 2024-06-02 16:04:47 --> No URI present. Default controller set.
INFO - 2024-06-02 16:04:47 --> Router Class Initialized
INFO - 2024-06-02 16:04:47 --> Output Class Initialized
INFO - 2024-06-02 16:04:47 --> Security Class Initialized
DEBUG - 2024-06-02 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 16:04:47 --> Input Class Initialized
INFO - 2024-06-02 16:04:47 --> Language Class Initialized
INFO - 2024-06-02 16:04:47 --> Loader Class Initialized
INFO - 2024-06-02 16:04:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-02 16:04:47 --> Helper loaded: url_helper
DEBUG - 2024-06-02 16:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-02 16:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 16:04:47 --> Controller Class Initialized
INFO - 2024-06-02 18:01:32 --> Config Class Initialized
INFO - 2024-06-02 18:01:32 --> Hooks Class Initialized
DEBUG - 2024-06-02 18:01:32 --> UTF-8 Support Enabled
INFO - 2024-06-02 18:01:32 --> Utf8 Class Initialized
INFO - 2024-06-02 18:01:32 --> URI Class Initialized
INFO - 2024-06-02 18:01:32 --> Router Class Initialized
INFO - 2024-06-02 18:01:32 --> Output Class Initialized
INFO - 2024-06-02 18:01:32 --> Security Class Initialized
DEBUG - 2024-06-02 18:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 18:01:32 --> Input Class Initialized
INFO - 2024-06-02 18:01:32 --> Language Class Initialized
INFO - 2024-06-02 18:01:32 --> Loader Class Initialized
INFO - 2024-06-02 18:01:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-02 18:01:32 --> Helper loaded: url_helper
DEBUG - 2024-06-02 18:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-02 18:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 18:01:32 --> Controller Class Initialized
DEBUG - 2024-06-02 18:01:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-02 18:01:32 --> Database Driver Class Initialized
INFO - 2024-06-02 18:01:32 --> Helper loaded: cookie_helper
INFO - 2024-06-02 18:01:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-02 18:01:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-02 18:01:32 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-02 18:01:32 --> Final output sent to browser
DEBUG - 2024-06-02 18:01:32 --> Total execution time: 0.0380
INFO - 2024-06-02 18:01:33 --> Config Class Initialized
INFO - 2024-06-02 18:01:33 --> Hooks Class Initialized
DEBUG - 2024-06-02 18:01:33 --> UTF-8 Support Enabled
INFO - 2024-06-02 18:01:33 --> Utf8 Class Initialized
INFO - 2024-06-02 18:01:33 --> URI Class Initialized
INFO - 2024-06-02 18:01:33 --> Router Class Initialized
INFO - 2024-06-02 18:01:33 --> Output Class Initialized
INFO - 2024-06-02 18:01:33 --> Security Class Initialized
DEBUG - 2024-06-02 18:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 18:01:33 --> Input Class Initialized
INFO - 2024-06-02 18:01:33 --> Language Class Initialized
INFO - 2024-06-02 18:01:33 --> Loader Class Initialized
INFO - 2024-06-02 18:01:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-02 18:01:33 --> Helper loaded: url_helper
DEBUG - 2024-06-02 18:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-02 18:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 18:01:33 --> Controller Class Initialized
