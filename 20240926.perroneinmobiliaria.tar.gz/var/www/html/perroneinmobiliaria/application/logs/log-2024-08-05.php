<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-05 00:02:28 --> Config Class Initialized
INFO - 2024-08-05 00:02:28 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:28 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:28 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:28 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:28 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:28 --> Router Class Initialized
INFO - 2024-08-05 00:02:28 --> Output Class Initialized
INFO - 2024-08-05 00:02:28 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:28 --> Input Class Initialized
INFO - 2024-08-05 00:02:28 --> Language Class Initialized
INFO - 2024-08-05 00:02:28 --> Loader Class Initialized
INFO - 2024-08-05 00:02:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:28 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:28 --> Controller Class Initialized
INFO - 2024-08-05 00:02:28 --> Config Class Initialized
INFO - 2024-08-05 00:02:28 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:28 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:28 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:28 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:28 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:28 --> Router Class Initialized
INFO - 2024-08-05 00:02:28 --> Output Class Initialized
INFO - 2024-08-05 00:02:28 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:28 --> Input Class Initialized
INFO - 2024-08-05 00:02:28 --> Language Class Initialized
INFO - 2024-08-05 00:02:28 --> Loader Class Initialized
INFO - 2024-08-05 00:02:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:28 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:28 --> Controller Class Initialized
INFO - 2024-08-05 00:02:29 --> Config Class Initialized
INFO - 2024-08-05 00:02:29 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:29 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:29 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:29 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:29 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:29 --> Router Class Initialized
INFO - 2024-08-05 00:02:29 --> Output Class Initialized
INFO - 2024-08-05 00:02:29 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:29 --> Input Class Initialized
INFO - 2024-08-05 00:02:29 --> Language Class Initialized
INFO - 2024-08-05 00:02:29 --> Loader Class Initialized
INFO - 2024-08-05 00:02:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:29 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:29 --> Controller Class Initialized
INFO - 2024-08-05 00:02:31 --> Config Class Initialized
INFO - 2024-08-05 00:02:31 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:31 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:31 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:31 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:31 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:31 --> Router Class Initialized
INFO - 2024-08-05 00:02:31 --> Output Class Initialized
INFO - 2024-08-05 00:02:31 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:31 --> Input Class Initialized
INFO - 2024-08-05 00:02:31 --> Language Class Initialized
INFO - 2024-08-05 00:02:31 --> Loader Class Initialized
INFO - 2024-08-05 00:02:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:31 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:31 --> Controller Class Initialized
INFO - 2024-08-05 00:02:34 --> Config Class Initialized
INFO - 2024-08-05 00:02:34 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:34 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:34 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:34 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:34 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:34 --> Router Class Initialized
INFO - 2024-08-05 00:02:34 --> Output Class Initialized
INFO - 2024-08-05 00:02:34 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:34 --> Input Class Initialized
INFO - 2024-08-05 00:02:34 --> Language Class Initialized
INFO - 2024-08-05 00:02:34 --> Loader Class Initialized
INFO - 2024-08-05 00:02:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:34 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:34 --> Controller Class Initialized
INFO - 2024-08-05 00:02:39 --> Config Class Initialized
INFO - 2024-08-05 00:02:39 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:39 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:39 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:39 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:39 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:39 --> Router Class Initialized
INFO - 2024-08-05 00:02:39 --> Output Class Initialized
INFO - 2024-08-05 00:02:39 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:39 --> Input Class Initialized
INFO - 2024-08-05 00:02:39 --> Language Class Initialized
INFO - 2024-08-05 00:02:39 --> Loader Class Initialized
INFO - 2024-08-05 00:02:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:39 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:39 --> Controller Class Initialized
INFO - 2024-08-05 00:02:39 --> Config Class Initialized
INFO - 2024-08-05 00:02:39 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:39 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:39 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:39 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:39 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:39 --> Router Class Initialized
INFO - 2024-08-05 00:02:39 --> Output Class Initialized
INFO - 2024-08-05 00:02:39 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:39 --> Input Class Initialized
INFO - 2024-08-05 00:02:39 --> Language Class Initialized
INFO - 2024-08-05 00:02:39 --> Loader Class Initialized
INFO - 2024-08-05 00:02:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:39 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:39 --> Controller Class Initialized
INFO - 2024-08-05 00:02:48 --> Config Class Initialized
INFO - 2024-08-05 00:02:48 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:02:48 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:02:48 --> Utf8 Class Initialized
INFO - 2024-08-05 00:02:48 --> URI Class Initialized
DEBUG - 2024-08-05 00:02:48 --> No URI present. Default controller set.
INFO - 2024-08-05 00:02:48 --> Router Class Initialized
INFO - 2024-08-05 00:02:48 --> Output Class Initialized
INFO - 2024-08-05 00:02:48 --> Security Class Initialized
DEBUG - 2024-08-05 00:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:02:48 --> Input Class Initialized
INFO - 2024-08-05 00:02:48 --> Language Class Initialized
INFO - 2024-08-05 00:02:48 --> Loader Class Initialized
INFO - 2024-08-05 00:02:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:02:48 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:02:48 --> Controller Class Initialized
INFO - 2024-08-05 00:03:34 --> Config Class Initialized
INFO - 2024-08-05 00:03:34 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:34 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:34 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:34 --> URI Class Initialized
DEBUG - 2024-08-05 00:03:34 --> No URI present. Default controller set.
INFO - 2024-08-05 00:03:34 --> Router Class Initialized
INFO - 2024-08-05 00:03:34 --> Output Class Initialized
INFO - 2024-08-05 00:03:34 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:34 --> Input Class Initialized
INFO - 2024-08-05 00:03:34 --> Language Class Initialized
INFO - 2024-08-05 00:03:34 --> Loader Class Initialized
INFO - 2024-08-05 00:03:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:34 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:34 --> Controller Class Initialized
INFO - 2024-08-05 00:03:34 --> Config Class Initialized
INFO - 2024-08-05 00:03:34 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:34 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:34 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:34 --> URI Class Initialized
INFO - 2024-08-05 00:03:34 --> Router Class Initialized
INFO - 2024-08-05 00:03:34 --> Output Class Initialized
INFO - 2024-08-05 00:03:34 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:34 --> Input Class Initialized
INFO - 2024-08-05 00:03:34 --> Language Class Initialized
INFO - 2024-08-05 00:03:34 --> Loader Class Initialized
INFO - 2024-08-05 00:03:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:34 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:34 --> Controller Class Initialized
DEBUG - 2024-08-05 00:03:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 00:03:34 --> Database Driver Class Initialized
INFO - 2024-08-05 00:03:34 --> Helper loaded: cookie_helper
INFO - 2024-08-05 00:03:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 00:03:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 00:03:34 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 00:03:34 --> Final output sent to browser
DEBUG - 2024-08-05 00:03:34 --> Total execution time: 0.0422
INFO - 2024-08-05 00:03:35 --> Config Class Initialized
INFO - 2024-08-05 00:03:35 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:35 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:35 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:35 --> URI Class Initialized
INFO - 2024-08-05 00:03:35 --> Router Class Initialized
INFO - 2024-08-05 00:03:35 --> Output Class Initialized
INFO - 2024-08-05 00:03:35 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:35 --> Input Class Initialized
INFO - 2024-08-05 00:03:35 --> Language Class Initialized
INFO - 2024-08-05 00:03:35 --> Loader Class Initialized
INFO - 2024-08-05 00:03:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:35 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:35 --> Controller Class Initialized
INFO - 2024-08-05 00:03:36 --> Config Class Initialized
INFO - 2024-08-05 00:03:36 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:36 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:36 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:36 --> URI Class Initialized
DEBUG - 2024-08-05 00:03:36 --> No URI present. Default controller set.
INFO - 2024-08-05 00:03:36 --> Router Class Initialized
INFO - 2024-08-05 00:03:36 --> Output Class Initialized
INFO - 2024-08-05 00:03:36 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:36 --> Input Class Initialized
INFO - 2024-08-05 00:03:36 --> Language Class Initialized
INFO - 2024-08-05 00:03:36 --> Loader Class Initialized
INFO - 2024-08-05 00:03:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:36 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:36 --> Controller Class Initialized
INFO - 2024-08-05 00:03:36 --> Config Class Initialized
INFO - 2024-08-05 00:03:36 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:36 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:36 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:36 --> URI Class Initialized
DEBUG - 2024-08-05 00:03:36 --> No URI present. Default controller set.
INFO - 2024-08-05 00:03:36 --> Router Class Initialized
INFO - 2024-08-05 00:03:36 --> Output Class Initialized
INFO - 2024-08-05 00:03:36 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:36 --> Input Class Initialized
INFO - 2024-08-05 00:03:36 --> Language Class Initialized
INFO - 2024-08-05 00:03:36 --> Loader Class Initialized
INFO - 2024-08-05 00:03:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:36 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:36 --> Controller Class Initialized
INFO - 2024-08-05 00:03:36 --> Config Class Initialized
INFO - 2024-08-05 00:03:36 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:36 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:36 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:36 --> URI Class Initialized
INFO - 2024-08-05 00:03:36 --> Router Class Initialized
INFO - 2024-08-05 00:03:36 --> Output Class Initialized
INFO - 2024-08-05 00:03:36 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:36 --> Input Class Initialized
INFO - 2024-08-05 00:03:36 --> Language Class Initialized
INFO - 2024-08-05 00:03:36 --> Loader Class Initialized
INFO - 2024-08-05 00:03:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:36 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:36 --> Controller Class Initialized
DEBUG - 2024-08-05 00:03:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 00:03:36 --> Database Driver Class Initialized
INFO - 2024-08-05 00:03:36 --> Helper loaded: cookie_helper
INFO - 2024-08-05 00:03:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 00:03:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 00:03:36 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 00:03:36 --> Final output sent to browser
DEBUG - 2024-08-05 00:03:36 --> Total execution time: 0.0113
INFO - 2024-08-05 00:03:38 --> Config Class Initialized
INFO - 2024-08-05 00:03:38 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:38 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:38 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:38 --> URI Class Initialized
INFO - 2024-08-05 00:03:38 --> Router Class Initialized
INFO - 2024-08-05 00:03:38 --> Output Class Initialized
INFO - 2024-08-05 00:03:38 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:38 --> Input Class Initialized
INFO - 2024-08-05 00:03:38 --> Language Class Initialized
INFO - 2024-08-05 00:03:38 --> Loader Class Initialized
INFO - 2024-08-05 00:03:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:38 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:38 --> Controller Class Initialized
INFO - 2024-08-05 00:03:43 --> Config Class Initialized
INFO - 2024-08-05 00:03:43 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:43 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:43 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:43 --> URI Class Initialized
DEBUG - 2024-08-05 00:03:43 --> No URI present. Default controller set.
INFO - 2024-08-05 00:03:43 --> Router Class Initialized
INFO - 2024-08-05 00:03:43 --> Output Class Initialized
INFO - 2024-08-05 00:03:43 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:43 --> Input Class Initialized
INFO - 2024-08-05 00:03:43 --> Language Class Initialized
INFO - 2024-08-05 00:03:43 --> Loader Class Initialized
INFO - 2024-08-05 00:03:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:43 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:43 --> Controller Class Initialized
INFO - 2024-08-05 00:03:43 --> Config Class Initialized
INFO - 2024-08-05 00:03:43 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:43 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:43 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:43 --> URI Class Initialized
INFO - 2024-08-05 00:03:43 --> Router Class Initialized
INFO - 2024-08-05 00:03:43 --> Output Class Initialized
INFO - 2024-08-05 00:03:43 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:43 --> Input Class Initialized
INFO - 2024-08-05 00:03:43 --> Language Class Initialized
INFO - 2024-08-05 00:03:43 --> Loader Class Initialized
INFO - 2024-08-05 00:03:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:43 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:43 --> Controller Class Initialized
DEBUG - 2024-08-05 00:03:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 00:03:43 --> Database Driver Class Initialized
INFO - 2024-08-05 00:03:43 --> Helper loaded: cookie_helper
INFO - 2024-08-05 00:03:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 00:03:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 00:03:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 00:03:43 --> Final output sent to browser
DEBUG - 2024-08-05 00:03:43 --> Total execution time: 0.0175
INFO - 2024-08-05 00:03:47 --> Config Class Initialized
INFO - 2024-08-05 00:03:47 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:47 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:47 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:47 --> URI Class Initialized
DEBUG - 2024-08-05 00:03:47 --> No URI present. Default controller set.
INFO - 2024-08-05 00:03:47 --> Router Class Initialized
INFO - 2024-08-05 00:03:47 --> Output Class Initialized
INFO - 2024-08-05 00:03:47 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:47 --> Input Class Initialized
INFO - 2024-08-05 00:03:47 --> Language Class Initialized
INFO - 2024-08-05 00:03:47 --> Loader Class Initialized
INFO - 2024-08-05 00:03:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:47 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:47 --> Controller Class Initialized
INFO - 2024-08-05 00:03:47 --> Config Class Initialized
INFO - 2024-08-05 00:03:47 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:47 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:47 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:47 --> URI Class Initialized
INFO - 2024-08-05 00:03:47 --> Router Class Initialized
INFO - 2024-08-05 00:03:47 --> Output Class Initialized
INFO - 2024-08-05 00:03:47 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:47 --> Input Class Initialized
INFO - 2024-08-05 00:03:47 --> Language Class Initialized
INFO - 2024-08-05 00:03:47 --> Loader Class Initialized
INFO - 2024-08-05 00:03:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:47 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:47 --> Controller Class Initialized
DEBUG - 2024-08-05 00:03:47 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 00:03:47 --> Database Driver Class Initialized
INFO - 2024-08-05 00:03:47 --> Helper loaded: cookie_helper
INFO - 2024-08-05 00:03:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 00:03:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 00:03:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 00:03:47 --> Final output sent to browser
DEBUG - 2024-08-05 00:03:47 --> Total execution time: 0.0113
INFO - 2024-08-05 00:03:48 --> Config Class Initialized
INFO - 2024-08-05 00:03:48 --> Hooks Class Initialized
DEBUG - 2024-08-05 00:03:48 --> UTF-8 Support Enabled
INFO - 2024-08-05 00:03:48 --> Utf8 Class Initialized
INFO - 2024-08-05 00:03:48 --> URI Class Initialized
INFO - 2024-08-05 00:03:48 --> Router Class Initialized
INFO - 2024-08-05 00:03:48 --> Output Class Initialized
INFO - 2024-08-05 00:03:48 --> Security Class Initialized
DEBUG - 2024-08-05 00:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 00:03:48 --> Input Class Initialized
INFO - 2024-08-05 00:03:48 --> Language Class Initialized
INFO - 2024-08-05 00:03:48 --> Loader Class Initialized
INFO - 2024-08-05 00:03:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 00:03:48 --> Helper loaded: url_helper
DEBUG - 2024-08-05 00:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 00:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 00:03:48 --> Controller Class Initialized
INFO - 2024-08-05 01:49:27 --> Config Class Initialized
INFO - 2024-08-05 01:49:27 --> Hooks Class Initialized
DEBUG - 2024-08-05 01:49:27 --> UTF-8 Support Enabled
INFO - 2024-08-05 01:49:27 --> Utf8 Class Initialized
INFO - 2024-08-05 01:49:27 --> URI Class Initialized
DEBUG - 2024-08-05 01:49:27 --> No URI present. Default controller set.
INFO - 2024-08-05 01:49:27 --> Router Class Initialized
INFO - 2024-08-05 01:49:27 --> Output Class Initialized
INFO - 2024-08-05 01:49:27 --> Security Class Initialized
DEBUG - 2024-08-05 01:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 01:49:27 --> Input Class Initialized
INFO - 2024-08-05 01:49:27 --> Language Class Initialized
INFO - 2024-08-05 01:49:27 --> Loader Class Initialized
INFO - 2024-08-05 01:49:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 01:49:27 --> Helper loaded: url_helper
DEBUG - 2024-08-05 01:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 01:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 01:49:27 --> Controller Class Initialized
INFO - 2024-08-05 03:06:15 --> Config Class Initialized
INFO - 2024-08-05 03:06:15 --> Hooks Class Initialized
DEBUG - 2024-08-05 03:06:15 --> UTF-8 Support Enabled
INFO - 2024-08-05 03:06:15 --> Utf8 Class Initialized
INFO - 2024-08-05 03:06:15 --> URI Class Initialized
DEBUG - 2024-08-05 03:06:15 --> No URI present. Default controller set.
INFO - 2024-08-05 03:06:15 --> Router Class Initialized
INFO - 2024-08-05 03:06:15 --> Output Class Initialized
INFO - 2024-08-05 03:06:15 --> Security Class Initialized
DEBUG - 2024-08-05 03:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 03:06:15 --> Input Class Initialized
INFO - 2024-08-05 03:06:15 --> Language Class Initialized
INFO - 2024-08-05 03:06:15 --> Loader Class Initialized
INFO - 2024-08-05 03:06:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 03:06:15 --> Helper loaded: url_helper
DEBUG - 2024-08-05 03:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 03:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 03:06:15 --> Controller Class Initialized
INFO - 2024-08-05 03:06:15 --> Config Class Initialized
INFO - 2024-08-05 03:06:15 --> Hooks Class Initialized
DEBUG - 2024-08-05 03:06:15 --> UTF-8 Support Enabled
INFO - 2024-08-05 03:06:15 --> Utf8 Class Initialized
INFO - 2024-08-05 03:06:15 --> URI Class Initialized
INFO - 2024-08-05 03:06:15 --> Router Class Initialized
INFO - 2024-08-05 03:06:15 --> Output Class Initialized
INFO - 2024-08-05 03:06:15 --> Security Class Initialized
DEBUG - 2024-08-05 03:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 03:06:15 --> Input Class Initialized
INFO - 2024-08-05 03:06:15 --> Language Class Initialized
INFO - 2024-08-05 03:06:15 --> Loader Class Initialized
INFO - 2024-08-05 03:06:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 03:06:15 --> Helper loaded: url_helper
DEBUG - 2024-08-05 03:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 03:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 03:06:15 --> Controller Class Initialized
DEBUG - 2024-08-05 03:06:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 03:06:15 --> Database Driver Class Initialized
INFO - 2024-08-05 03:06:15 --> Helper loaded: cookie_helper
INFO - 2024-08-05 03:06:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 03:06:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 03:06:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 03:06:15 --> Final output sent to browser
DEBUG - 2024-08-05 03:06:15 --> Total execution time: 0.0216
INFO - 2024-08-05 03:49:45 --> Config Class Initialized
INFO - 2024-08-05 03:49:45 --> Hooks Class Initialized
DEBUG - 2024-08-05 03:49:45 --> UTF-8 Support Enabled
INFO - 2024-08-05 03:49:45 --> Utf8 Class Initialized
INFO - 2024-08-05 03:49:45 --> URI Class Initialized
DEBUG - 2024-08-05 03:49:45 --> No URI present. Default controller set.
INFO - 2024-08-05 03:49:45 --> Router Class Initialized
INFO - 2024-08-05 03:49:45 --> Output Class Initialized
INFO - 2024-08-05 03:49:45 --> Security Class Initialized
DEBUG - 2024-08-05 03:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 03:49:45 --> Input Class Initialized
INFO - 2024-08-05 03:49:45 --> Language Class Initialized
INFO - 2024-08-05 03:49:45 --> Loader Class Initialized
INFO - 2024-08-05 03:49:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 03:49:45 --> Helper loaded: url_helper
DEBUG - 2024-08-05 03:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 03:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 03:49:45 --> Controller Class Initialized
INFO - 2024-08-05 08:33:09 --> Config Class Initialized
INFO - 2024-08-05 08:33:09 --> Hooks Class Initialized
DEBUG - 2024-08-05 08:33:09 --> UTF-8 Support Enabled
INFO - 2024-08-05 08:33:09 --> Utf8 Class Initialized
INFO - 2024-08-05 08:33:09 --> URI Class Initialized
DEBUG - 2024-08-05 08:33:09 --> No URI present. Default controller set.
INFO - 2024-08-05 08:33:09 --> Router Class Initialized
INFO - 2024-08-05 08:33:09 --> Output Class Initialized
INFO - 2024-08-05 08:33:09 --> Security Class Initialized
DEBUG - 2024-08-05 08:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 08:33:09 --> Input Class Initialized
INFO - 2024-08-05 08:33:09 --> Language Class Initialized
INFO - 2024-08-05 08:33:09 --> Loader Class Initialized
INFO - 2024-08-05 08:33:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 08:33:09 --> Helper loaded: url_helper
DEBUG - 2024-08-05 08:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 08:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 08:33:09 --> Controller Class Initialized
INFO - 2024-08-05 12:03:37 --> Config Class Initialized
INFO - 2024-08-05 12:03:37 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:03:37 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:03:37 --> Utf8 Class Initialized
INFO - 2024-08-05 12:03:37 --> URI Class Initialized
DEBUG - 2024-08-05 12:03:37 --> No URI present. Default controller set.
INFO - 2024-08-05 12:03:37 --> Router Class Initialized
INFO - 2024-08-05 12:03:37 --> Output Class Initialized
INFO - 2024-08-05 12:03:37 --> Security Class Initialized
DEBUG - 2024-08-05 12:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:03:37 --> Input Class Initialized
INFO - 2024-08-05 12:03:37 --> Language Class Initialized
INFO - 2024-08-05 12:03:37 --> Loader Class Initialized
INFO - 2024-08-05 12:03:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:03:37 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:03:37 --> Controller Class Initialized
INFO - 2024-08-05 12:03:38 --> Config Class Initialized
INFO - 2024-08-05 12:03:38 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:03:38 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:03:38 --> Utf8 Class Initialized
INFO - 2024-08-05 12:03:38 --> URI Class Initialized
INFO - 2024-08-05 12:03:38 --> Router Class Initialized
INFO - 2024-08-05 12:03:38 --> Output Class Initialized
INFO - 2024-08-05 12:03:38 --> Security Class Initialized
DEBUG - 2024-08-05 12:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:03:38 --> Input Class Initialized
INFO - 2024-08-05 12:03:38 --> Language Class Initialized
INFO - 2024-08-05 12:03:38 --> Loader Class Initialized
INFO - 2024-08-05 12:03:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:03:38 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:03:38 --> Controller Class Initialized
DEBUG - 2024-08-05 12:03:38 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 12:03:38 --> Database Driver Class Initialized
INFO - 2024-08-05 12:03:38 --> Helper loaded: cookie_helper
INFO - 2024-08-05 12:03:38 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 12:03:38 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 12:03:38 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 12:03:38 --> Final output sent to browser
DEBUG - 2024-08-05 12:03:38 --> Total execution time: 0.0442
INFO - 2024-08-05 12:03:50 --> Config Class Initialized
INFO - 2024-08-05 12:03:50 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:03:50 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:03:50 --> Utf8 Class Initialized
INFO - 2024-08-05 12:03:50 --> URI Class Initialized
DEBUG - 2024-08-05 12:03:50 --> No URI present. Default controller set.
INFO - 2024-08-05 12:03:50 --> Router Class Initialized
INFO - 2024-08-05 12:03:50 --> Output Class Initialized
INFO - 2024-08-05 12:03:50 --> Security Class Initialized
DEBUG - 2024-08-05 12:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:03:50 --> Input Class Initialized
INFO - 2024-08-05 12:03:50 --> Language Class Initialized
INFO - 2024-08-05 12:03:50 --> Loader Class Initialized
INFO - 2024-08-05 12:03:50 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:03:50 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:03:50 --> Controller Class Initialized
INFO - 2024-08-05 12:12:01 --> Config Class Initialized
INFO - 2024-08-05 12:12:01 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:12:01 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:12:01 --> Utf8 Class Initialized
INFO - 2024-08-05 12:12:01 --> URI Class Initialized
DEBUG - 2024-08-05 12:12:01 --> No URI present. Default controller set.
INFO - 2024-08-05 12:12:01 --> Router Class Initialized
INFO - 2024-08-05 12:12:01 --> Output Class Initialized
INFO - 2024-08-05 12:12:01 --> Security Class Initialized
DEBUG - 2024-08-05 12:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:12:01 --> Input Class Initialized
INFO - 2024-08-05 12:12:01 --> Language Class Initialized
INFO - 2024-08-05 12:12:01 --> Loader Class Initialized
INFO - 2024-08-05 12:12:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:12:01 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:12:01 --> Controller Class Initialized
INFO - 2024-08-05 12:37:18 --> Config Class Initialized
INFO - 2024-08-05 12:37:18 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:37:18 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:37:18 --> Utf8 Class Initialized
INFO - 2024-08-05 12:37:18 --> URI Class Initialized
DEBUG - 2024-08-05 12:37:18 --> No URI present. Default controller set.
INFO - 2024-08-05 12:37:18 --> Router Class Initialized
INFO - 2024-08-05 12:37:18 --> Output Class Initialized
INFO - 2024-08-05 12:37:18 --> Security Class Initialized
DEBUG - 2024-08-05 12:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:37:18 --> Input Class Initialized
INFO - 2024-08-05 12:37:18 --> Language Class Initialized
INFO - 2024-08-05 12:37:18 --> Loader Class Initialized
INFO - 2024-08-05 12:37:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:37:18 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:37:18 --> Controller Class Initialized
INFO - 2024-08-05 12:37:25 --> Config Class Initialized
INFO - 2024-08-05 12:37:25 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:37:25 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:37:25 --> Utf8 Class Initialized
INFO - 2024-08-05 12:37:25 --> URI Class Initialized
DEBUG - 2024-08-05 12:37:25 --> No URI present. Default controller set.
INFO - 2024-08-05 12:37:25 --> Router Class Initialized
INFO - 2024-08-05 12:37:25 --> Output Class Initialized
INFO - 2024-08-05 12:37:25 --> Security Class Initialized
DEBUG - 2024-08-05 12:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:37:25 --> Input Class Initialized
INFO - 2024-08-05 12:37:25 --> Language Class Initialized
INFO - 2024-08-05 12:37:25 --> Loader Class Initialized
INFO - 2024-08-05 12:37:25 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:37:25 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:37:25 --> Controller Class Initialized
INFO - 2024-08-05 12:37:26 --> Config Class Initialized
INFO - 2024-08-05 12:37:26 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:37:26 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:37:26 --> Utf8 Class Initialized
INFO - 2024-08-05 12:37:26 --> URI Class Initialized
INFO - 2024-08-05 12:37:26 --> Router Class Initialized
INFO - 2024-08-05 12:37:26 --> Output Class Initialized
INFO - 2024-08-05 12:37:26 --> Security Class Initialized
DEBUG - 2024-08-05 12:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:37:26 --> Input Class Initialized
INFO - 2024-08-05 12:37:26 --> Language Class Initialized
INFO - 2024-08-05 12:37:26 --> Loader Class Initialized
INFO - 2024-08-05 12:37:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:37:26 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:37:26 --> Controller Class Initialized
DEBUG - 2024-08-05 12:37:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 12:37:26 --> Database Driver Class Initialized
INFO - 2024-08-05 12:37:26 --> Helper loaded: cookie_helper
INFO - 2024-08-05 12:37:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 12:37:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 12:37:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 12:37:26 --> Final output sent to browser
DEBUG - 2024-08-05 12:37:26 --> Total execution time: 0.0183
INFO - 2024-08-05 12:37:29 --> Config Class Initialized
INFO - 2024-08-05 12:37:29 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:37:29 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:37:29 --> Utf8 Class Initialized
INFO - 2024-08-05 12:37:29 --> URI Class Initialized
DEBUG - 2024-08-05 12:37:29 --> No URI present. Default controller set.
INFO - 2024-08-05 12:37:29 --> Router Class Initialized
INFO - 2024-08-05 12:37:29 --> Output Class Initialized
INFO - 2024-08-05 12:37:29 --> Security Class Initialized
DEBUG - 2024-08-05 12:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:37:29 --> Input Class Initialized
INFO - 2024-08-05 12:37:29 --> Language Class Initialized
INFO - 2024-08-05 12:37:29 --> Loader Class Initialized
INFO - 2024-08-05 12:37:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:37:29 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:37:29 --> Controller Class Initialized
INFO - 2024-08-05 12:40:41 --> Config Class Initialized
INFO - 2024-08-05 12:40:41 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:40:41 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:40:41 --> Utf8 Class Initialized
INFO - 2024-08-05 12:40:41 --> URI Class Initialized
DEBUG - 2024-08-05 12:40:41 --> No URI present. Default controller set.
INFO - 2024-08-05 12:40:41 --> Router Class Initialized
INFO - 2024-08-05 12:40:41 --> Output Class Initialized
INFO - 2024-08-05 12:40:41 --> Security Class Initialized
DEBUG - 2024-08-05 12:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:40:41 --> Input Class Initialized
INFO - 2024-08-05 12:40:41 --> Language Class Initialized
INFO - 2024-08-05 12:40:41 --> Loader Class Initialized
INFO - 2024-08-05 12:40:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:40:41 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:40:41 --> Controller Class Initialized
INFO - 2024-08-05 12:42:28 --> Config Class Initialized
INFO - 2024-08-05 12:42:28 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:42:28 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:42:28 --> Utf8 Class Initialized
INFO - 2024-08-05 12:42:28 --> URI Class Initialized
DEBUG - 2024-08-05 12:42:28 --> No URI present. Default controller set.
INFO - 2024-08-05 12:42:28 --> Router Class Initialized
INFO - 2024-08-05 12:42:28 --> Output Class Initialized
INFO - 2024-08-05 12:42:28 --> Security Class Initialized
DEBUG - 2024-08-05 12:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:42:28 --> Input Class Initialized
INFO - 2024-08-05 12:42:28 --> Language Class Initialized
INFO - 2024-08-05 12:42:28 --> Loader Class Initialized
INFO - 2024-08-05 12:42:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:42:28 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:42:28 --> Controller Class Initialized
INFO - 2024-08-05 12:42:36 --> Config Class Initialized
INFO - 2024-08-05 12:42:36 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:42:36 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:42:36 --> Utf8 Class Initialized
INFO - 2024-08-05 12:42:36 --> URI Class Initialized
DEBUG - 2024-08-05 12:42:36 --> No URI present. Default controller set.
INFO - 2024-08-05 12:42:36 --> Router Class Initialized
INFO - 2024-08-05 12:42:36 --> Output Class Initialized
INFO - 2024-08-05 12:42:36 --> Security Class Initialized
DEBUG - 2024-08-05 12:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:42:36 --> Input Class Initialized
INFO - 2024-08-05 12:42:36 --> Language Class Initialized
INFO - 2024-08-05 12:42:36 --> Loader Class Initialized
INFO - 2024-08-05 12:42:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 12:42:36 --> Helper loaded: url_helper
DEBUG - 2024-08-05 12:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 12:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:42:36 --> Controller Class Initialized
INFO - 2024-08-05 13:41:04 --> Config Class Initialized
INFO - 2024-08-05 13:41:04 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:41:04 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:41:04 --> Utf8 Class Initialized
INFO - 2024-08-05 13:41:04 --> URI Class Initialized
DEBUG - 2024-08-05 13:41:04 --> No URI present. Default controller set.
INFO - 2024-08-05 13:41:04 --> Router Class Initialized
INFO - 2024-08-05 13:41:04 --> Output Class Initialized
INFO - 2024-08-05 13:41:04 --> Security Class Initialized
DEBUG - 2024-08-05 13:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:41:04 --> Input Class Initialized
INFO - 2024-08-05 13:41:04 --> Language Class Initialized
INFO - 2024-08-05 13:41:04 --> Loader Class Initialized
INFO - 2024-08-05 13:41:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 13:41:04 --> Helper loaded: url_helper
DEBUG - 2024-08-05 13:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 13:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:41:04 --> Controller Class Initialized
INFO - 2024-08-05 15:08:14 --> Config Class Initialized
INFO - 2024-08-05 15:08:14 --> Hooks Class Initialized
DEBUG - 2024-08-05 15:08:14 --> UTF-8 Support Enabled
INFO - 2024-08-05 15:08:14 --> Utf8 Class Initialized
INFO - 2024-08-05 15:08:14 --> URI Class Initialized
DEBUG - 2024-08-05 15:08:14 --> No URI present. Default controller set.
INFO - 2024-08-05 15:08:14 --> Router Class Initialized
INFO - 2024-08-05 15:08:14 --> Output Class Initialized
INFO - 2024-08-05 15:08:14 --> Security Class Initialized
DEBUG - 2024-08-05 15:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 15:08:14 --> Input Class Initialized
INFO - 2024-08-05 15:08:14 --> Language Class Initialized
INFO - 2024-08-05 15:08:14 --> Loader Class Initialized
INFO - 2024-08-05 15:08:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 15:08:14 --> Helper loaded: url_helper
DEBUG - 2024-08-05 15:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 15:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 15:08:14 --> Controller Class Initialized
INFO - 2024-08-05 15:12:07 --> Config Class Initialized
INFO - 2024-08-05 15:12:07 --> Hooks Class Initialized
DEBUG - 2024-08-05 15:12:07 --> UTF-8 Support Enabled
INFO - 2024-08-05 15:12:07 --> Utf8 Class Initialized
INFO - 2024-08-05 15:12:07 --> URI Class Initialized
DEBUG - 2024-08-05 15:12:07 --> No URI present. Default controller set.
INFO - 2024-08-05 15:12:07 --> Router Class Initialized
INFO - 2024-08-05 15:12:07 --> Output Class Initialized
INFO - 2024-08-05 15:12:07 --> Security Class Initialized
DEBUG - 2024-08-05 15:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 15:12:07 --> Input Class Initialized
INFO - 2024-08-05 15:12:07 --> Language Class Initialized
INFO - 2024-08-05 15:12:07 --> Loader Class Initialized
INFO - 2024-08-05 15:12:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 15:12:07 --> Helper loaded: url_helper
DEBUG - 2024-08-05 15:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 15:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 15:12:07 --> Controller Class Initialized
INFO - 2024-08-05 15:20:18 --> Config Class Initialized
INFO - 2024-08-05 15:20:18 --> Hooks Class Initialized
DEBUG - 2024-08-05 15:20:18 --> UTF-8 Support Enabled
INFO - 2024-08-05 15:20:18 --> Utf8 Class Initialized
INFO - 2024-08-05 15:20:18 --> URI Class Initialized
DEBUG - 2024-08-05 15:20:18 --> No URI present. Default controller set.
INFO - 2024-08-05 15:20:18 --> Router Class Initialized
INFO - 2024-08-05 15:20:18 --> Output Class Initialized
INFO - 2024-08-05 15:20:18 --> Security Class Initialized
DEBUG - 2024-08-05 15:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 15:20:18 --> Input Class Initialized
INFO - 2024-08-05 15:20:18 --> Language Class Initialized
INFO - 2024-08-05 15:20:18 --> Loader Class Initialized
INFO - 2024-08-05 15:20:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 15:20:18 --> Helper loaded: url_helper
DEBUG - 2024-08-05 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 15:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 15:20:18 --> Controller Class Initialized
INFO - 2024-08-05 15:37:46 --> Config Class Initialized
INFO - 2024-08-05 15:37:46 --> Hooks Class Initialized
DEBUG - 2024-08-05 15:37:46 --> UTF-8 Support Enabled
INFO - 2024-08-05 15:37:46 --> Utf8 Class Initialized
INFO - 2024-08-05 15:37:46 --> URI Class Initialized
DEBUG - 2024-08-05 15:37:46 --> No URI present. Default controller set.
INFO - 2024-08-05 15:37:46 --> Router Class Initialized
INFO - 2024-08-05 15:37:46 --> Output Class Initialized
INFO - 2024-08-05 15:37:46 --> Security Class Initialized
DEBUG - 2024-08-05 15:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 15:37:46 --> Input Class Initialized
INFO - 2024-08-05 15:37:46 --> Language Class Initialized
INFO - 2024-08-05 15:37:46 --> Loader Class Initialized
INFO - 2024-08-05 15:37:46 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 15:37:46 --> Helper loaded: url_helper
DEBUG - 2024-08-05 15:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 15:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 15:37:46 --> Controller Class Initialized
INFO - 2024-08-05 15:37:46 --> Config Class Initialized
INFO - 2024-08-05 15:37:46 --> Hooks Class Initialized
DEBUG - 2024-08-05 15:37:46 --> UTF-8 Support Enabled
INFO - 2024-08-05 15:37:46 --> Utf8 Class Initialized
INFO - 2024-08-05 15:37:46 --> URI Class Initialized
INFO - 2024-08-05 15:37:46 --> Router Class Initialized
INFO - 2024-08-05 15:37:46 --> Output Class Initialized
INFO - 2024-08-05 15:37:46 --> Security Class Initialized
DEBUG - 2024-08-05 15:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 15:37:46 --> Input Class Initialized
INFO - 2024-08-05 15:37:46 --> Language Class Initialized
INFO - 2024-08-05 15:37:46 --> Loader Class Initialized
INFO - 2024-08-05 15:37:46 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 15:37:46 --> Helper loaded: url_helper
DEBUG - 2024-08-05 15:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 15:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 15:37:46 --> Controller Class Initialized
DEBUG - 2024-08-05 15:37:46 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-05 15:37:46 --> Database Driver Class Initialized
INFO - 2024-08-05 15:37:46 --> Helper loaded: cookie_helper
INFO - 2024-08-05 15:37:46 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-05 15:37:46 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-05 15:37:46 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-05 15:37:46 --> Final output sent to browser
DEBUG - 2024-08-05 15:37:46 --> Total execution time: 0.0183
INFO - 2024-08-05 16:27:56 --> Config Class Initialized
INFO - 2024-08-05 16:27:56 --> Hooks Class Initialized
DEBUG - 2024-08-05 16:27:56 --> UTF-8 Support Enabled
INFO - 2024-08-05 16:27:56 --> Utf8 Class Initialized
INFO - 2024-08-05 16:27:56 --> URI Class Initialized
DEBUG - 2024-08-05 16:27:56 --> No URI present. Default controller set.
INFO - 2024-08-05 16:27:56 --> Router Class Initialized
INFO - 2024-08-05 16:27:56 --> Output Class Initialized
INFO - 2024-08-05 16:27:56 --> Security Class Initialized
DEBUG - 2024-08-05 16:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 16:27:56 --> Input Class Initialized
INFO - 2024-08-05 16:27:56 --> Language Class Initialized
INFO - 2024-08-05 16:27:56 --> Loader Class Initialized
INFO - 2024-08-05 16:27:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 16:27:56 --> Helper loaded: url_helper
DEBUG - 2024-08-05 16:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 16:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 16:27:56 --> Controller Class Initialized
INFO - 2024-08-05 21:08:07 --> Config Class Initialized
INFO - 2024-08-05 21:08:07 --> Hooks Class Initialized
DEBUG - 2024-08-05 21:08:07 --> UTF-8 Support Enabled
INFO - 2024-08-05 21:08:07 --> Utf8 Class Initialized
INFO - 2024-08-05 21:08:07 --> URI Class Initialized
DEBUG - 2024-08-05 21:08:07 --> No URI present. Default controller set.
INFO - 2024-08-05 21:08:07 --> Router Class Initialized
INFO - 2024-08-05 21:08:07 --> Output Class Initialized
INFO - 2024-08-05 21:08:07 --> Security Class Initialized
DEBUG - 2024-08-05 21:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 21:08:07 --> Input Class Initialized
INFO - 2024-08-05 21:08:07 --> Language Class Initialized
INFO - 2024-08-05 21:08:07 --> Loader Class Initialized
INFO - 2024-08-05 21:08:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-05 21:08:07 --> Helper loaded: url_helper
DEBUG - 2024-08-05 21:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-05 21:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 21:08:07 --> Controller Class Initialized
