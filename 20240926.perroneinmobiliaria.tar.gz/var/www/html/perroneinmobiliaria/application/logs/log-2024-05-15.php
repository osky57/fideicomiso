<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-15 00:01:12 --> Config Class Initialized
INFO - 2024-05-15 00:01:12 --> Hooks Class Initialized
DEBUG - 2024-05-15 00:01:12 --> UTF-8 Support Enabled
INFO - 2024-05-15 00:01:12 --> Utf8 Class Initialized
INFO - 2024-05-15 00:01:12 --> URI Class Initialized
DEBUG - 2024-05-15 00:01:12 --> No URI present. Default controller set.
INFO - 2024-05-15 00:01:12 --> Router Class Initialized
INFO - 2024-05-15 00:01:12 --> Output Class Initialized
INFO - 2024-05-15 00:01:12 --> Security Class Initialized
DEBUG - 2024-05-15 00:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 00:01:12 --> Input Class Initialized
INFO - 2024-05-15 00:01:12 --> Language Class Initialized
INFO - 2024-05-15 00:01:12 --> Loader Class Initialized
INFO - 2024-05-15 00:01:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 00:01:12 --> Helper loaded: url_helper
DEBUG - 2024-05-15 00:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 00:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 00:01:12 --> Controller Class Initialized
INFO - 2024-05-15 15:19:29 --> Config Class Initialized
INFO - 2024-05-15 15:19:29 --> Hooks Class Initialized
DEBUG - 2024-05-15 15:19:29 --> UTF-8 Support Enabled
INFO - 2024-05-15 15:19:29 --> Utf8 Class Initialized
INFO - 2024-05-15 15:19:29 --> URI Class Initialized
DEBUG - 2024-05-15 15:19:29 --> No URI present. Default controller set.
INFO - 2024-05-15 15:19:29 --> Router Class Initialized
INFO - 2024-05-15 15:19:29 --> Output Class Initialized
INFO - 2024-05-15 15:19:29 --> Security Class Initialized
DEBUG - 2024-05-15 15:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 15:19:29 --> Input Class Initialized
INFO - 2024-05-15 15:19:29 --> Language Class Initialized
INFO - 2024-05-15 15:19:29 --> Loader Class Initialized
INFO - 2024-05-15 15:19:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 15:19:29 --> Helper loaded: url_helper
DEBUG - 2024-05-15 15:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 15:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 15:19:29 --> Controller Class Initialized
INFO - 2024-05-15 15:19:29 --> Config Class Initialized
INFO - 2024-05-15 15:19:29 --> Hooks Class Initialized
DEBUG - 2024-05-15 15:19:29 --> UTF-8 Support Enabled
INFO - 2024-05-15 15:19:29 --> Utf8 Class Initialized
INFO - 2024-05-15 15:19:29 --> URI Class Initialized
INFO - 2024-05-15 15:19:29 --> Router Class Initialized
INFO - 2024-05-15 15:19:29 --> Output Class Initialized
INFO - 2024-05-15 15:19:29 --> Security Class Initialized
DEBUG - 2024-05-15 15:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 15:19:29 --> Input Class Initialized
INFO - 2024-05-15 15:19:29 --> Language Class Initialized
INFO - 2024-05-15 15:19:29 --> Loader Class Initialized
INFO - 2024-05-15 15:19:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 15:19:29 --> Helper loaded: url_helper
DEBUG - 2024-05-15 15:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 15:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 15:19:29 --> Controller Class Initialized
DEBUG - 2024-05-15 15:19:29 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-15 15:19:29 --> Database Driver Class Initialized
INFO - 2024-05-15 15:19:29 --> Helper loaded: cookie_helper
INFO - 2024-05-15 15:19:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-15 15:19:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-15 15:19:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-15 15:19:29 --> Final output sent to browser
DEBUG - 2024-05-15 15:19:29 --> Total execution time: 0.0429
INFO - 2024-05-15 15:19:30 --> Config Class Initialized
INFO - 2024-05-15 15:19:30 --> Hooks Class Initialized
DEBUG - 2024-05-15 15:19:30 --> UTF-8 Support Enabled
INFO - 2024-05-15 15:19:30 --> Utf8 Class Initialized
INFO - 2024-05-15 15:19:30 --> URI Class Initialized
INFO - 2024-05-15 15:19:30 --> Router Class Initialized
INFO - 2024-05-15 15:19:30 --> Output Class Initialized
INFO - 2024-05-15 15:19:30 --> Security Class Initialized
DEBUG - 2024-05-15 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 15:19:30 --> Input Class Initialized
INFO - 2024-05-15 15:19:30 --> Language Class Initialized
INFO - 2024-05-15 15:19:30 --> Loader Class Initialized
INFO - 2024-05-15 15:19:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 15:19:30 --> Helper loaded: url_helper
DEBUG - 2024-05-15 15:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 15:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 15:19:30 --> Controller Class Initialized
INFO - 2024-05-15 15:32:21 --> Config Class Initialized
INFO - 2024-05-15 15:32:21 --> Hooks Class Initialized
DEBUG - 2024-05-15 15:32:21 --> UTF-8 Support Enabled
INFO - 2024-05-15 15:32:21 --> Utf8 Class Initialized
INFO - 2024-05-15 15:32:21 --> URI Class Initialized
DEBUG - 2024-05-15 15:32:21 --> No URI present. Default controller set.
INFO - 2024-05-15 15:32:21 --> Router Class Initialized
INFO - 2024-05-15 15:32:21 --> Output Class Initialized
INFO - 2024-05-15 15:32:21 --> Security Class Initialized
DEBUG - 2024-05-15 15:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 15:32:21 --> Input Class Initialized
INFO - 2024-05-15 15:32:21 --> Language Class Initialized
INFO - 2024-05-15 15:32:21 --> Loader Class Initialized
INFO - 2024-05-15 15:32:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 15:32:21 --> Helper loaded: url_helper
DEBUG - 2024-05-15 15:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 15:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 15:32:21 --> Controller Class Initialized
INFO - 2024-05-15 20:36:33 --> Config Class Initialized
INFO - 2024-05-15 20:36:33 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:33 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:33 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:33 --> URI Class Initialized
DEBUG - 2024-05-15 20:36:33 --> No URI present. Default controller set.
INFO - 2024-05-15 20:36:33 --> Router Class Initialized
INFO - 2024-05-15 20:36:33 --> Output Class Initialized
INFO - 2024-05-15 20:36:33 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:33 --> Input Class Initialized
INFO - 2024-05-15 20:36:33 --> Language Class Initialized
INFO - 2024-05-15 20:36:33 --> Loader Class Initialized
INFO - 2024-05-15 20:36:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:33 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:33 --> Controller Class Initialized
INFO - 2024-05-15 20:36:33 --> Config Class Initialized
INFO - 2024-05-15 20:36:33 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:33 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:33 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:33 --> URI Class Initialized
INFO - 2024-05-15 20:36:33 --> Router Class Initialized
INFO - 2024-05-15 20:36:33 --> Output Class Initialized
INFO - 2024-05-15 20:36:33 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:33 --> Input Class Initialized
INFO - 2024-05-15 20:36:33 --> Language Class Initialized
INFO - 2024-05-15 20:36:33 --> Loader Class Initialized
INFO - 2024-05-15 20:36:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:33 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:33 --> Controller Class Initialized
DEBUG - 2024-05-15 20:36:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-15 20:36:33 --> Database Driver Class Initialized
INFO - 2024-05-15 20:36:33 --> Helper loaded: cookie_helper
INFO - 2024-05-15 20:36:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-15 20:36:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-15 20:36:33 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-15 20:36:33 --> Final output sent to browser
DEBUG - 2024-05-15 20:36:33 --> Total execution time: 0.0118
INFO - 2024-05-15 20:36:34 --> Config Class Initialized
INFO - 2024-05-15 20:36:34 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:34 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:34 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:34 --> URI Class Initialized
INFO - 2024-05-15 20:36:34 --> Router Class Initialized
INFO - 2024-05-15 20:36:34 --> Output Class Initialized
INFO - 2024-05-15 20:36:34 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:34 --> Input Class Initialized
INFO - 2024-05-15 20:36:34 --> Language Class Initialized
INFO - 2024-05-15 20:36:34 --> Loader Class Initialized
INFO - 2024-05-15 20:36:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:34 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:34 --> Controller Class Initialized
INFO - 2024-05-15 20:36:37 --> Config Class Initialized
INFO - 2024-05-15 20:36:37 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:37 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:37 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:37 --> URI Class Initialized
INFO - 2024-05-15 20:36:37 --> Router Class Initialized
INFO - 2024-05-15 20:36:37 --> Output Class Initialized
INFO - 2024-05-15 20:36:37 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:37 --> Input Class Initialized
INFO - 2024-05-15 20:36:37 --> Language Class Initialized
INFO - 2024-05-15 20:36:37 --> Loader Class Initialized
INFO - 2024-05-15 20:36:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:37 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:37 --> Controller Class Initialized
DEBUG - 2024-05-15 20:36:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-15 20:36:37 --> Database Driver Class Initialized
INFO - 2024-05-15 20:36:37 --> Helper loaded: cookie_helper
INFO - 2024-05-15 20:36:37 --> Helper loaded: form_helper
INFO - 2024-05-15 20:36:37 --> Form Validation Class Initialized
INFO - 2024-05-15 20:36:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-15 20:36:37 --> Config Class Initialized
INFO - 2024-05-15 20:36:37 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:37 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:37 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:37 --> URI Class Initialized
INFO - 2024-05-15 20:36:37 --> Router Class Initialized
INFO - 2024-05-15 20:36:37 --> Output Class Initialized
INFO - 2024-05-15 20:36:37 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:37 --> Input Class Initialized
INFO - 2024-05-15 20:36:37 --> Language Class Initialized
INFO - 2024-05-15 20:36:37 --> Loader Class Initialized
INFO - 2024-05-15 20:36:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:37 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:37 --> Controller Class Initialized
INFO - 2024-05-15 20:36:37 --> Database Driver Class Initialized
DEBUG - 2024-05-15 20:36:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-15 20:36:37 --> Helper loaded: cookie_helper
INFO - 2024-05-15 20:36:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-15 20:36:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-15 20:36:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-15 20:36:37 --> Final output sent to browser
DEBUG - 2024-05-15 20:36:37 --> Total execution time: 0.0094
INFO - 2024-05-15 20:36:38 --> Config Class Initialized
INFO - 2024-05-15 20:36:38 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:38 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:38 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:38 --> URI Class Initialized
INFO - 2024-05-15 20:36:38 --> Router Class Initialized
INFO - 2024-05-15 20:36:38 --> Output Class Initialized
INFO - 2024-05-15 20:36:38 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:38 --> Input Class Initialized
INFO - 2024-05-15 20:36:38 --> Language Class Initialized
INFO - 2024-05-15 20:36:38 --> Loader Class Initialized
INFO - 2024-05-15 20:36:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:38 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:38 --> Controller Class Initialized
DEBUG - 2024-05-15 20:36:38 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-15 20:36:38 --> Database Driver Class Initialized
INFO - 2024-05-15 20:36:38 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:36:38 --> Final output sent to browser
DEBUG - 2024-05-15 20:36:38 --> Total execution time: 0.0325
INFO - 2024-05-15 20:36:41 --> Config Class Initialized
INFO - 2024-05-15 20:36:41 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:41 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:41 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:41 --> URI Class Initialized
INFO - 2024-05-15 20:36:41 --> Router Class Initialized
INFO - 2024-05-15 20:36:41 --> Output Class Initialized
INFO - 2024-05-15 20:36:41 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:41 --> Input Class Initialized
INFO - 2024-05-15 20:36:41 --> Language Class Initialized
INFO - 2024-05-15 20:36:41 --> Loader Class Initialized
INFO - 2024-05-15 20:36:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:41 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:41 --> Controller Class Initialized
DEBUG - 2024-05-15 20:36:41 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-15 20:36:41 --> Database Driver Class Initialized
INFO - 2024-05-15 20:36:41 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:36:41 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-15 20:36:41 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-15 20:36:41 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-15 20:36:41 --> Final output sent to browser
DEBUG - 2024-05-15 20:36:41 --> Total execution time: 0.0107
INFO - 2024-05-15 20:36:41 --> Config Class Initialized
INFO - 2024-05-15 20:36:41 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:36:41 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:36:41 --> Utf8 Class Initialized
INFO - 2024-05-15 20:36:41 --> URI Class Initialized
INFO - 2024-05-15 20:36:41 --> Router Class Initialized
INFO - 2024-05-15 20:36:41 --> Output Class Initialized
INFO - 2024-05-15 20:36:41 --> Security Class Initialized
DEBUG - 2024-05-15 20:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:36:41 --> Input Class Initialized
INFO - 2024-05-15 20:36:41 --> Language Class Initialized
INFO - 2024-05-15 20:36:41 --> Loader Class Initialized
INFO - 2024-05-15 20:36:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:36:41 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:36:41 --> Controller Class Initialized
DEBUG - 2024-05-15 20:36:41 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-15 20:36:41 --> Database Driver Class Initialized
INFO - 2024-05-15 20:36:41 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:36:41 --> Final output sent to browser
DEBUG - 2024-05-15 20:36:41 --> Total execution time: 0.0157
INFO - 2024-05-15 20:37:48 --> Config Class Initialized
INFO - 2024-05-15 20:37:48 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:37:48 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:37:48 --> Utf8 Class Initialized
INFO - 2024-05-15 20:37:48 --> URI Class Initialized
INFO - 2024-05-15 20:37:48 --> Router Class Initialized
INFO - 2024-05-15 20:37:48 --> Output Class Initialized
INFO - 2024-05-15 20:37:48 --> Security Class Initialized
DEBUG - 2024-05-15 20:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:37:48 --> Input Class Initialized
INFO - 2024-05-15 20:37:48 --> Language Class Initialized
INFO - 2024-05-15 20:37:48 --> Loader Class Initialized
INFO - 2024-05-15 20:37:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:37:48 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:37:48 --> Controller Class Initialized
DEBUG - 2024-05-15 20:37:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cotizaciones.php
INFO - 2024-05-15 20:37:48 --> Database Driver Class Initialized
INFO - 2024-05-15 20:37:48 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:37:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-15 20:37:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-15 20:37:48 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cotizaciones.php
INFO - 2024-05-15 20:37:48 --> Final output sent to browser
DEBUG - 2024-05-15 20:37:48 --> Total execution time: 0.0186
INFO - 2024-05-15 20:37:49 --> Config Class Initialized
INFO - 2024-05-15 20:37:49 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:37:49 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:37:49 --> Utf8 Class Initialized
INFO - 2024-05-15 20:37:49 --> URI Class Initialized
INFO - 2024-05-15 20:37:49 --> Router Class Initialized
INFO - 2024-05-15 20:37:49 --> Output Class Initialized
INFO - 2024-05-15 20:37:49 --> Security Class Initialized
DEBUG - 2024-05-15 20:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:37:49 --> Input Class Initialized
INFO - 2024-05-15 20:37:49 --> Language Class Initialized
INFO - 2024-05-15 20:37:49 --> Loader Class Initialized
INFO - 2024-05-15 20:37:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:37:49 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:37:49 --> Controller Class Initialized
DEBUG - 2024-05-15 20:37:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cotizaciones.php
INFO - 2024-05-15 20:37:49 --> Database Driver Class Initialized
INFO - 2024-05-15 20:37:49 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:37:49 --> Final output sent to browser
DEBUG - 2024-05-15 20:37:49 --> Total execution time: 0.0171
INFO - 2024-05-15 20:37:49 --> Config Class Initialized
INFO - 2024-05-15 20:37:49 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:37:49 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:37:49 --> Utf8 Class Initialized
INFO - 2024-05-15 20:37:49 --> URI Class Initialized
INFO - 2024-05-15 20:37:49 --> Router Class Initialized
INFO - 2024-05-15 20:37:49 --> Output Class Initialized
INFO - 2024-05-15 20:37:49 --> Security Class Initialized
DEBUG - 2024-05-15 20:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:37:49 --> Input Class Initialized
INFO - 2024-05-15 20:37:49 --> Language Class Initialized
INFO - 2024-05-15 20:37:49 --> Loader Class Initialized
INFO - 2024-05-15 20:37:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:37:49 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:37:49 --> Controller Class Initialized
DEBUG - 2024-05-15 20:37:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-15 20:37:49 --> Database Driver Class Initialized
INFO - 2024-05-15 20:37:49 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:37:49 --> Final output sent to browser
DEBUG - 2024-05-15 20:37:49 --> Total execution time: 0.0196
INFO - 2024-05-15 20:38:17 --> Config Class Initialized
INFO - 2024-05-15 20:38:17 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:17 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:17 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:17 --> URI Class Initialized
INFO - 2024-05-15 20:38:17 --> Router Class Initialized
INFO - 2024-05-15 20:38:17 --> Output Class Initialized
INFO - 2024-05-15 20:38:17 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:17 --> Input Class Initialized
INFO - 2024-05-15 20:38:17 --> Language Class Initialized
INFO - 2024-05-15 20:38:17 --> Loader Class Initialized
INFO - 2024-05-15 20:38:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:17 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:17 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:17 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:17 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-15 20:38:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-15 20:38:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-05-15 20:38:17 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:17 --> Total execution time: 0.0169
INFO - 2024-05-15 20:38:18 --> Config Class Initialized
INFO - 2024-05-15 20:38:18 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:18 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:18 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:18 --> URI Class Initialized
INFO - 2024-05-15 20:38:18 --> Router Class Initialized
INFO - 2024-05-15 20:38:18 --> Output Class Initialized
INFO - 2024-05-15 20:38:18 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:18 --> Input Class Initialized
INFO - 2024-05-15 20:38:18 --> Language Class Initialized
INFO - 2024-05-15 20:38:18 --> Loader Class Initialized
INFO - 2024-05-15 20:38:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:18 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:18 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:18 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:18 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:18 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:18 --> Total execution time: 0.0605
INFO - 2024-05-15 20:38:18 --> Config Class Initialized
INFO - 2024-05-15 20:38:18 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:18 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:18 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:18 --> URI Class Initialized
INFO - 2024-05-15 20:38:18 --> Router Class Initialized
INFO - 2024-05-15 20:38:18 --> Output Class Initialized
INFO - 2024-05-15 20:38:18 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:18 --> Input Class Initialized
INFO - 2024-05-15 20:38:18 --> Language Class Initialized
INFO - 2024-05-15 20:38:18 --> Loader Class Initialized
INFO - 2024-05-15 20:38:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:18 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:18 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-15 20:38:18 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:18 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:18 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:18 --> Total execution time: 0.0238
INFO - 2024-05-15 20:38:19 --> Config Class Initialized
INFO - 2024-05-15 20:38:19 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:19 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:19 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:19 --> URI Class Initialized
INFO - 2024-05-15 20:38:19 --> Router Class Initialized
INFO - 2024-05-15 20:38:19 --> Output Class Initialized
INFO - 2024-05-15 20:38:19 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:19 --> Input Class Initialized
INFO - 2024-05-15 20:38:19 --> Language Class Initialized
INFO - 2024-05-15 20:38:19 --> Loader Class Initialized
INFO - 2024-05-15 20:38:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:19 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:19 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:19 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:19 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:20 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:20 --> Total execution time: 0.0578
INFO - 2024-05-15 20:38:22 --> Config Class Initialized
INFO - 2024-05-15 20:38:22 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:22 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:22 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:22 --> URI Class Initialized
INFO - 2024-05-15 20:38:22 --> Router Class Initialized
INFO - 2024-05-15 20:38:22 --> Output Class Initialized
INFO - 2024-05-15 20:38:22 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:22 --> Input Class Initialized
INFO - 2024-05-15 20:38:22 --> Language Class Initialized
INFO - 2024-05-15 20:38:22 --> Loader Class Initialized
INFO - 2024-05-15 20:38:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:22 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:22 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:22 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:22 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:22 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:22 --> Total execution time: 0.0516
INFO - 2024-05-15 20:38:24 --> Config Class Initialized
INFO - 2024-05-15 20:38:24 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:24 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:24 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:24 --> URI Class Initialized
INFO - 2024-05-15 20:38:24 --> Router Class Initialized
INFO - 2024-05-15 20:38:24 --> Output Class Initialized
INFO - 2024-05-15 20:38:24 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:24 --> Input Class Initialized
INFO - 2024-05-15 20:38:24 --> Language Class Initialized
INFO - 2024-05-15 20:38:24 --> Loader Class Initialized
INFO - 2024-05-15 20:38:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:24 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:24 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:24 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:24 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:24 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:24 --> Total execution time: 0.0529
INFO - 2024-05-15 20:38:26 --> Config Class Initialized
INFO - 2024-05-15 20:38:26 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:26 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:26 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:26 --> URI Class Initialized
INFO - 2024-05-15 20:38:26 --> Router Class Initialized
INFO - 2024-05-15 20:38:26 --> Output Class Initialized
INFO - 2024-05-15 20:38:26 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:26 --> Input Class Initialized
INFO - 2024-05-15 20:38:26 --> Language Class Initialized
INFO - 2024-05-15 20:38:26 --> Loader Class Initialized
INFO - 2024-05-15 20:38:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:26 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:26 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:26 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:26 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:26 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:26 --> Total execution time: 0.0609
INFO - 2024-05-15 20:38:30 --> Config Class Initialized
INFO - 2024-05-15 20:38:30 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:30 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:30 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:30 --> URI Class Initialized
INFO - 2024-05-15 20:38:30 --> Router Class Initialized
INFO - 2024-05-15 20:38:30 --> Output Class Initialized
INFO - 2024-05-15 20:38:30 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:30 --> Input Class Initialized
INFO - 2024-05-15 20:38:30 --> Language Class Initialized
INFO - 2024-05-15 20:38:30 --> Loader Class Initialized
INFO - 2024-05-15 20:38:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:30 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:30 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:30 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:30 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:30 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:30 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:30 --> Total execution time: 0.0609
INFO - 2024-05-15 20:38:52 --> Config Class Initialized
INFO - 2024-05-15 20:38:52 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:52 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:52 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:52 --> URI Class Initialized
INFO - 2024-05-15 20:38:52 --> Router Class Initialized
INFO - 2024-05-15 20:38:52 --> Output Class Initialized
INFO - 2024-05-15 20:38:52 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:52 --> Input Class Initialized
INFO - 2024-05-15 20:38:52 --> Language Class Initialized
INFO - 2024-05-15 20:38:52 --> Loader Class Initialized
INFO - 2024-05-15 20:38:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:52 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:52 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:52 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-05-15 20:38:52 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:52 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-entidad.php
INFO - 2024-05-15 20:38:52 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:52 --> Total execution time: 0.0296
INFO - 2024-05-15 20:38:57 --> Config Class Initialized
INFO - 2024-05-15 20:38:57 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:57 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:57 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:57 --> URI Class Initialized
INFO - 2024-05-15 20:38:57 --> Router Class Initialized
INFO - 2024-05-15 20:38:57 --> Output Class Initialized
INFO - 2024-05-15 20:38:57 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:57 --> Input Class Initialized
INFO - 2024-05-15 20:38:57 --> Language Class Initialized
INFO - 2024-05-15 20:38:57 --> Loader Class Initialized
INFO - 2024-05-15 20:38:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:57 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:57 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-15 20:38:57 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:57 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-15 20:38:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-15 20:38:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-05-15 20:38:57 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:57 --> Total execution time: 0.0434
INFO - 2024-05-15 20:38:58 --> Config Class Initialized
INFO - 2024-05-15 20:38:58 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:58 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:58 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:58 --> URI Class Initialized
INFO - 2024-05-15 20:38:58 --> Router Class Initialized
INFO - 2024-05-15 20:38:58 --> Output Class Initialized
INFO - 2024-05-15 20:38:58 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:58 --> Input Class Initialized
INFO - 2024-05-15 20:38:58 --> Language Class Initialized
INFO - 2024-05-15 20:38:58 --> Loader Class Initialized
INFO - 2024-05-15 20:38:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:58 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:58 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-15 20:38:58 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:58 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:58 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:58 --> Total execution time: 0.1067
INFO - 2024-05-15 20:38:58 --> Config Class Initialized
INFO - 2024-05-15 20:38:58 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:38:58 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:38:58 --> Utf8 Class Initialized
INFO - 2024-05-15 20:38:58 --> URI Class Initialized
INFO - 2024-05-15 20:38:58 --> Router Class Initialized
INFO - 2024-05-15 20:38:58 --> Output Class Initialized
INFO - 2024-05-15 20:38:58 --> Security Class Initialized
DEBUG - 2024-05-15 20:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:38:58 --> Input Class Initialized
INFO - 2024-05-15 20:38:58 --> Language Class Initialized
INFO - 2024-05-15 20:38:58 --> Loader Class Initialized
INFO - 2024-05-15 20:38:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:38:58 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:38:58 --> Controller Class Initialized
DEBUG - 2024-05-15 20:38:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-15 20:38:58 --> Database Driver Class Initialized
INFO - 2024-05-15 20:38:58 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:38:58 --> Final output sent to browser
DEBUG - 2024-05-15 20:38:58 --> Total execution time: 0.0195
INFO - 2024-05-15 20:39:07 --> Config Class Initialized
INFO - 2024-05-15 20:39:07 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:39:07 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:39:07 --> Utf8 Class Initialized
INFO - 2024-05-15 20:39:07 --> URI Class Initialized
INFO - 2024-05-15 20:39:07 --> Router Class Initialized
INFO - 2024-05-15 20:39:07 --> Output Class Initialized
INFO - 2024-05-15 20:39:07 --> Security Class Initialized
DEBUG - 2024-05-15 20:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:39:07 --> Input Class Initialized
INFO - 2024-05-15 20:39:07 --> Language Class Initialized
INFO - 2024-05-15 20:39:07 --> Loader Class Initialized
INFO - 2024-05-15 20:39:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:39:07 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:39:07 --> Controller Class Initialized
DEBUG - 2024-05-15 20:39:07 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-15 20:39:07 --> Database Driver Class Initialized
INFO - 2024-05-15 20:39:07 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:39:07 --> Final output sent to browser
DEBUG - 2024-05-15 20:39:07 --> Total execution time: 0.0673
INFO - 2024-05-15 20:39:13 --> Config Class Initialized
INFO - 2024-05-15 20:39:13 --> Hooks Class Initialized
DEBUG - 2024-05-15 20:39:13 --> UTF-8 Support Enabled
INFO - 2024-05-15 20:39:13 --> Utf8 Class Initialized
INFO - 2024-05-15 20:39:13 --> URI Class Initialized
INFO - 2024-05-15 20:39:13 --> Router Class Initialized
INFO - 2024-05-15 20:39:13 --> Output Class Initialized
INFO - 2024-05-15 20:39:13 --> Security Class Initialized
DEBUG - 2024-05-15 20:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 20:39:13 --> Input Class Initialized
INFO - 2024-05-15 20:39:13 --> Language Class Initialized
INFO - 2024-05-15 20:39:13 --> Loader Class Initialized
INFO - 2024-05-15 20:39:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 20:39:13 --> Helper loaded: url_helper
DEBUG - 2024-05-15 20:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 20:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 20:39:13 --> Controller Class Initialized
DEBUG - 2024-05-15 20:39:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-05-15 20:39:13 --> Database Driver Class Initialized
INFO - 2024-05-15 20:39:13 --> Helper loaded: funciones_helper
INFO - 2024-05-15 20:39:13 --> Final output sent to browser
DEBUG - 2024-05-15 20:39:13 --> Total execution time: 0.0660
INFO - 2024-05-15 21:16:45 --> Config Class Initialized
INFO - 2024-05-15 21:16:45 --> Hooks Class Initialized
DEBUG - 2024-05-15 21:16:45 --> UTF-8 Support Enabled
INFO - 2024-05-15 21:16:45 --> Utf8 Class Initialized
INFO - 2024-05-15 21:16:45 --> URI Class Initialized
DEBUG - 2024-05-15 21:16:45 --> No URI present. Default controller set.
INFO - 2024-05-15 21:16:45 --> Router Class Initialized
INFO - 2024-05-15 21:16:45 --> Output Class Initialized
INFO - 2024-05-15 21:16:45 --> Security Class Initialized
DEBUG - 2024-05-15 21:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 21:16:45 --> Input Class Initialized
INFO - 2024-05-15 21:16:45 --> Language Class Initialized
INFO - 2024-05-15 21:16:45 --> Loader Class Initialized
INFO - 2024-05-15 21:16:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 21:16:45 --> Helper loaded: url_helper
DEBUG - 2024-05-15 21:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 21:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 21:16:45 --> Controller Class Initialized
INFO - 2024-05-15 21:16:47 --> Config Class Initialized
INFO - 2024-05-15 21:16:47 --> Hooks Class Initialized
DEBUG - 2024-05-15 21:16:47 --> UTF-8 Support Enabled
INFO - 2024-05-15 21:16:47 --> Utf8 Class Initialized
INFO - 2024-05-15 21:16:47 --> URI Class Initialized
DEBUG - 2024-05-15 21:16:47 --> No URI present. Default controller set.
INFO - 2024-05-15 21:16:47 --> Router Class Initialized
INFO - 2024-05-15 21:16:47 --> Output Class Initialized
INFO - 2024-05-15 21:16:47 --> Security Class Initialized
DEBUG - 2024-05-15 21:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 21:16:47 --> Input Class Initialized
INFO - 2024-05-15 21:16:47 --> Language Class Initialized
INFO - 2024-05-15 21:16:47 --> Loader Class Initialized
INFO - 2024-05-15 21:16:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 21:16:47 --> Helper loaded: url_helper
DEBUG - 2024-05-15 21:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 21:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 21:16:47 --> Controller Class Initialized
INFO - 2024-05-15 21:16:51 --> Config Class Initialized
INFO - 2024-05-15 21:16:51 --> Hooks Class Initialized
DEBUG - 2024-05-15 21:16:51 --> UTF-8 Support Enabled
INFO - 2024-05-15 21:16:51 --> Utf8 Class Initialized
INFO - 2024-05-15 21:16:51 --> URI Class Initialized
DEBUG - 2024-05-15 21:16:51 --> No URI present. Default controller set.
INFO - 2024-05-15 21:16:51 --> Router Class Initialized
INFO - 2024-05-15 21:16:51 --> Output Class Initialized
INFO - 2024-05-15 21:16:51 --> Security Class Initialized
DEBUG - 2024-05-15 21:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 21:16:51 --> Input Class Initialized
INFO - 2024-05-15 21:16:51 --> Language Class Initialized
INFO - 2024-05-15 21:16:51 --> Loader Class Initialized
INFO - 2024-05-15 21:16:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 21:16:51 --> Helper loaded: url_helper
DEBUG - 2024-05-15 21:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 21:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 21:16:51 --> Controller Class Initialized
INFO - 2024-05-15 21:50:07 --> Config Class Initialized
INFO - 2024-05-15 21:50:07 --> Hooks Class Initialized
DEBUG - 2024-05-15 21:50:07 --> UTF-8 Support Enabled
INFO - 2024-05-15 21:50:07 --> Utf8 Class Initialized
INFO - 2024-05-15 21:50:07 --> URI Class Initialized
DEBUG - 2024-05-15 21:50:07 --> No URI present. Default controller set.
INFO - 2024-05-15 21:50:07 --> Router Class Initialized
INFO - 2024-05-15 21:50:07 --> Output Class Initialized
INFO - 2024-05-15 21:50:07 --> Security Class Initialized
DEBUG - 2024-05-15 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 21:50:07 --> Input Class Initialized
INFO - 2024-05-15 21:50:07 --> Language Class Initialized
INFO - 2024-05-15 21:50:07 --> Loader Class Initialized
INFO - 2024-05-15 21:50:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-15 21:50:07 --> Helper loaded: url_helper
DEBUG - 2024-05-15 21:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-15 21:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 21:50:07 --> Controller Class Initialized
