<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-25 13:47:28 --> Config Class Initialized
INFO - 2024-06-25 13:47:28 --> Hooks Class Initialized
DEBUG - 2024-06-25 13:47:28 --> UTF-8 Support Enabled
INFO - 2024-06-25 13:47:28 --> Utf8 Class Initialized
INFO - 2024-06-25 13:47:28 --> URI Class Initialized
DEBUG - 2024-06-25 13:47:28 --> No URI present. Default controller set.
INFO - 2024-06-25 13:47:28 --> Router Class Initialized
INFO - 2024-06-25 13:47:28 --> Output Class Initialized
INFO - 2024-06-25 13:47:28 --> Security Class Initialized
DEBUG - 2024-06-25 13:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-25 13:47:28 --> Input Class Initialized
INFO - 2024-06-25 13:47:28 --> Language Class Initialized
INFO - 2024-06-25 13:47:28 --> Loader Class Initialized
INFO - 2024-06-25 13:47:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-25 13:47:28 --> Helper loaded: url_helper
DEBUG - 2024-06-25 13:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-25 13:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-25 13:47:28 --> Controller Class Initialized
