<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-02 00:07:33 --> Config Class Initialized
INFO - 2024-08-02 00:07:33 --> Hooks Class Initialized
DEBUG - 2024-08-02 00:07:33 --> UTF-8 Support Enabled
INFO - 2024-08-02 00:07:33 --> Utf8 Class Initialized
INFO - 2024-08-02 00:07:33 --> URI Class Initialized
DEBUG - 2024-08-02 00:07:33 --> No URI present. Default controller set.
INFO - 2024-08-02 00:07:33 --> Router Class Initialized
INFO - 2024-08-02 00:07:33 --> Output Class Initialized
INFO - 2024-08-02 00:07:33 --> Security Class Initialized
DEBUG - 2024-08-02 00:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 00:07:33 --> Input Class Initialized
INFO - 2024-08-02 00:07:33 --> Language Class Initialized
INFO - 2024-08-02 00:07:33 --> Loader Class Initialized
INFO - 2024-08-02 00:07:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-02 00:07:33 --> Helper loaded: url_helper
DEBUG - 2024-08-02 00:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-02 00:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 00:07:33 --> Controller Class Initialized
INFO - 2024-08-02 04:41:21 --> Config Class Initialized
INFO - 2024-08-02 04:41:21 --> Hooks Class Initialized
DEBUG - 2024-08-02 04:41:21 --> UTF-8 Support Enabled
INFO - 2024-08-02 04:41:21 --> Utf8 Class Initialized
INFO - 2024-08-02 04:41:21 --> URI Class Initialized
DEBUG - 2024-08-02 04:41:21 --> No URI present. Default controller set.
INFO - 2024-08-02 04:41:21 --> Router Class Initialized
INFO - 2024-08-02 04:41:21 --> Output Class Initialized
INFO - 2024-08-02 04:41:21 --> Security Class Initialized
DEBUG - 2024-08-02 04:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 04:41:21 --> Input Class Initialized
INFO - 2024-08-02 04:41:21 --> Language Class Initialized
INFO - 2024-08-02 04:41:21 --> Loader Class Initialized
INFO - 2024-08-02 04:41:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-02 04:41:21 --> Helper loaded: url_helper
DEBUG - 2024-08-02 04:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-02 04:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 04:41:21 --> Controller Class Initialized
