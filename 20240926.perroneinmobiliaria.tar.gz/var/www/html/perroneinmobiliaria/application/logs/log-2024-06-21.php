<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-21 01:32:11 --> Config Class Initialized
INFO - 2024-06-21 01:32:11 --> Hooks Class Initialized
DEBUG - 2024-06-21 01:32:11 --> UTF-8 Support Enabled
INFO - 2024-06-21 01:32:11 --> Utf8 Class Initialized
INFO - 2024-06-21 01:32:11 --> URI Class Initialized
DEBUG - 2024-06-21 01:32:11 --> No URI present. Default controller set.
INFO - 2024-06-21 01:32:11 --> Router Class Initialized
INFO - 2024-06-21 01:32:11 --> Output Class Initialized
INFO - 2024-06-21 01:32:11 --> Security Class Initialized
DEBUG - 2024-06-21 01:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 01:32:11 --> Input Class Initialized
INFO - 2024-06-21 01:32:11 --> Language Class Initialized
INFO - 2024-06-21 01:32:11 --> Loader Class Initialized
INFO - 2024-06-21 01:32:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-21 01:32:11 --> Helper loaded: url_helper
DEBUG - 2024-06-21 01:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-21 01:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 01:32:11 --> Controller Class Initialized
INFO - 2024-06-21 02:44:34 --> Config Class Initialized
INFO - 2024-06-21 02:44:34 --> Hooks Class Initialized
DEBUG - 2024-06-21 02:44:34 --> UTF-8 Support Enabled
INFO - 2024-06-21 02:44:34 --> Utf8 Class Initialized
INFO - 2024-06-21 02:44:34 --> URI Class Initialized
DEBUG - 2024-06-21 02:44:34 --> No URI present. Default controller set.
INFO - 2024-06-21 02:44:34 --> Router Class Initialized
INFO - 2024-06-21 02:44:34 --> Output Class Initialized
INFO - 2024-06-21 02:44:34 --> Security Class Initialized
DEBUG - 2024-06-21 02:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 02:44:34 --> Input Class Initialized
INFO - 2024-06-21 02:44:34 --> Language Class Initialized
INFO - 2024-06-21 02:44:34 --> Loader Class Initialized
INFO - 2024-06-21 02:44:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-21 02:44:34 --> Helper loaded: url_helper
DEBUG - 2024-06-21 02:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-21 02:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 02:44:34 --> Controller Class Initialized
INFO - 2024-06-21 07:00:36 --> Config Class Initialized
INFO - 2024-06-21 07:00:36 --> Hooks Class Initialized
DEBUG - 2024-06-21 07:00:36 --> UTF-8 Support Enabled
INFO - 2024-06-21 07:00:36 --> Utf8 Class Initialized
INFO - 2024-06-21 07:00:36 --> URI Class Initialized
DEBUG - 2024-06-21 07:00:36 --> No URI present. Default controller set.
INFO - 2024-06-21 07:00:36 --> Router Class Initialized
INFO - 2024-06-21 07:00:36 --> Output Class Initialized
INFO - 2024-06-21 07:00:36 --> Security Class Initialized
DEBUG - 2024-06-21 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 07:00:36 --> Input Class Initialized
INFO - 2024-06-21 07:00:36 --> Language Class Initialized
INFO - 2024-06-21 07:00:36 --> Loader Class Initialized
INFO - 2024-06-21 07:00:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-21 07:00:36 --> Helper loaded: url_helper
DEBUG - 2024-06-21 07:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-21 07:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 07:00:36 --> Controller Class Initialized
INFO - 2024-06-21 23:16:46 --> Config Class Initialized
INFO - 2024-06-21 23:16:46 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:16:46 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:16:46 --> Utf8 Class Initialized
INFO - 2024-06-21 23:16:46 --> URI Class Initialized
DEBUG - 2024-06-21 23:16:47 --> No URI present. Default controller set.
INFO - 2024-06-21 23:16:47 --> Router Class Initialized
INFO - 2024-06-21 23:16:47 --> Output Class Initialized
INFO - 2024-06-21 23:16:47 --> Security Class Initialized
DEBUG - 2024-06-21 23:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:16:47 --> Input Class Initialized
INFO - 2024-06-21 23:16:47 --> Language Class Initialized
INFO - 2024-06-21 23:16:47 --> Loader Class Initialized
INFO - 2024-06-21 23:16:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-21 23:16:47 --> Helper loaded: url_helper
DEBUG - 2024-06-21 23:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-21 23:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:16:47 --> Controller Class Initialized
INFO - 2024-06-21 23:16:47 --> Config Class Initialized
INFO - 2024-06-21 23:16:47 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:16:47 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:16:47 --> Utf8 Class Initialized
INFO - 2024-06-21 23:16:47 --> URI Class Initialized
DEBUG - 2024-06-21 23:16:47 --> No URI present. Default controller set.
INFO - 2024-06-21 23:16:47 --> Router Class Initialized
INFO - 2024-06-21 23:16:47 --> Output Class Initialized
INFO - 2024-06-21 23:16:47 --> Security Class Initialized
DEBUG - 2024-06-21 23:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:16:47 --> Input Class Initialized
INFO - 2024-06-21 23:16:47 --> Language Class Initialized
INFO - 2024-06-21 23:16:47 --> Loader Class Initialized
INFO - 2024-06-21 23:16:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-21 23:16:47 --> Helper loaded: url_helper
DEBUG - 2024-06-21 23:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-21 23:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:16:47 --> Controller Class Initialized
