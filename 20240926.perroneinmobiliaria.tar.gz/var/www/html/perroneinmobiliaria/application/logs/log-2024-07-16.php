<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-16 02:13:43 --> Config Class Initialized
INFO - 2024-07-16 02:13:43 --> Hooks Class Initialized
DEBUG - 2024-07-16 02:13:43 --> UTF-8 Support Enabled
INFO - 2024-07-16 02:13:43 --> Utf8 Class Initialized
INFO - 2024-07-16 02:13:43 --> URI Class Initialized
DEBUG - 2024-07-16 02:13:43 --> No URI present. Default controller set.
INFO - 2024-07-16 02:13:43 --> Router Class Initialized
INFO - 2024-07-16 02:13:43 --> Output Class Initialized
INFO - 2024-07-16 02:13:43 --> Security Class Initialized
DEBUG - 2024-07-16 02:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 02:13:43 --> Input Class Initialized
INFO - 2024-07-16 02:13:43 --> Language Class Initialized
INFO - 2024-07-16 02:13:43 --> Loader Class Initialized
INFO - 2024-07-16 02:13:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-16 02:13:43 --> Helper loaded: url_helper
DEBUG - 2024-07-16 02:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-16 02:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 02:13:43 --> Controller Class Initialized
INFO - 2024-07-16 13:43:55 --> Config Class Initialized
INFO - 2024-07-16 13:43:55 --> Hooks Class Initialized
DEBUG - 2024-07-16 13:43:55 --> UTF-8 Support Enabled
INFO - 2024-07-16 13:43:55 --> Utf8 Class Initialized
INFO - 2024-07-16 13:43:55 --> URI Class Initialized
DEBUG - 2024-07-16 13:43:55 --> No URI present. Default controller set.
INFO - 2024-07-16 13:43:55 --> Router Class Initialized
INFO - 2024-07-16 13:43:55 --> Output Class Initialized
INFO - 2024-07-16 13:43:55 --> Security Class Initialized
DEBUG - 2024-07-16 13:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 13:43:55 --> Input Class Initialized
INFO - 2024-07-16 13:43:55 --> Language Class Initialized
INFO - 2024-07-16 13:43:55 --> Loader Class Initialized
INFO - 2024-07-16 13:43:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-16 13:43:55 --> Helper loaded: url_helper
DEBUG - 2024-07-16 13:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-16 13:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 13:43:55 --> Controller Class Initialized
INFO - 2024-07-16 17:08:18 --> Config Class Initialized
INFO - 2024-07-16 17:08:18 --> Hooks Class Initialized
DEBUG - 2024-07-16 17:08:18 --> UTF-8 Support Enabled
INFO - 2024-07-16 17:08:18 --> Utf8 Class Initialized
INFO - 2024-07-16 17:08:18 --> URI Class Initialized
DEBUG - 2024-07-16 17:08:18 --> No URI present. Default controller set.
INFO - 2024-07-16 17:08:18 --> Router Class Initialized
INFO - 2024-07-16 17:08:18 --> Output Class Initialized
INFO - 2024-07-16 17:08:18 --> Security Class Initialized
DEBUG - 2024-07-16 17:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 17:08:18 --> Input Class Initialized
INFO - 2024-07-16 17:08:18 --> Language Class Initialized
INFO - 2024-07-16 17:08:18 --> Loader Class Initialized
INFO - 2024-07-16 17:08:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-16 17:08:18 --> Helper loaded: url_helper
DEBUG - 2024-07-16 17:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-16 17:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 17:08:18 --> Controller Class Initialized
INFO - 2024-07-16 17:08:18 --> Config Class Initialized
INFO - 2024-07-16 17:08:18 --> Hooks Class Initialized
DEBUG - 2024-07-16 17:08:18 --> UTF-8 Support Enabled
INFO - 2024-07-16 17:08:18 --> Utf8 Class Initialized
INFO - 2024-07-16 17:08:18 --> URI Class Initialized
DEBUG - 2024-07-16 17:08:18 --> No URI present. Default controller set.
INFO - 2024-07-16 17:08:18 --> Router Class Initialized
INFO - 2024-07-16 17:08:18 --> Output Class Initialized
INFO - 2024-07-16 17:08:18 --> Security Class Initialized
DEBUG - 2024-07-16 17:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 17:08:18 --> Input Class Initialized
INFO - 2024-07-16 17:08:18 --> Language Class Initialized
INFO - 2024-07-16 17:08:18 --> Loader Class Initialized
INFO - 2024-07-16 17:08:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-16 17:08:18 --> Helper loaded: url_helper
DEBUG - 2024-07-16 17:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-16 17:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 17:08:18 --> Controller Class Initialized
