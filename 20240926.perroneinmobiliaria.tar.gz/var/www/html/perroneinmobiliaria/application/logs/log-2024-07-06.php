<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-06 02:04:16 --> Config Class Initialized
INFO - 2024-07-06 02:04:16 --> Hooks Class Initialized
DEBUG - 2024-07-06 02:04:16 --> UTF-8 Support Enabled
INFO - 2024-07-06 02:04:16 --> Utf8 Class Initialized
INFO - 2024-07-06 02:04:16 --> URI Class Initialized
DEBUG - 2024-07-06 02:04:16 --> No URI present. Default controller set.
INFO - 2024-07-06 02:04:16 --> Router Class Initialized
INFO - 2024-07-06 02:04:16 --> Output Class Initialized
INFO - 2024-07-06 02:04:16 --> Security Class Initialized
DEBUG - 2024-07-06 02:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 02:04:16 --> Input Class Initialized
INFO - 2024-07-06 02:04:16 --> Language Class Initialized
INFO - 2024-07-06 02:04:16 --> Loader Class Initialized
INFO - 2024-07-06 02:04:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-06 02:04:16 --> Helper loaded: url_helper
DEBUG - 2024-07-06 02:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-06 02:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 02:04:16 --> Controller Class Initialized
