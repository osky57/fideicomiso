<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-23 16:01:31 --> Config Class Initialized
INFO - 2024-05-23 16:01:31 --> Hooks Class Initialized
DEBUG - 2024-05-23 16:01:31 --> UTF-8 Support Enabled
INFO - 2024-05-23 16:01:31 --> Utf8 Class Initialized
INFO - 2024-05-23 16:01:31 --> URI Class Initialized
DEBUG - 2024-05-23 16:01:31 --> No URI present. Default controller set.
INFO - 2024-05-23 16:01:31 --> Router Class Initialized
INFO - 2024-05-23 16:01:31 --> Output Class Initialized
INFO - 2024-05-23 16:01:31 --> Security Class Initialized
DEBUG - 2024-05-23 16:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-23 16:01:31 --> Input Class Initialized
INFO - 2024-05-23 16:01:31 --> Language Class Initialized
INFO - 2024-05-23 16:01:31 --> Loader Class Initialized
INFO - 2024-05-23 16:01:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-23 16:01:31 --> Helper loaded: url_helper
DEBUG - 2024-05-23 16:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-23 16:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-23 16:01:31 --> Controller Class Initialized
INFO - 2024-05-23 19:21:27 --> Config Class Initialized
INFO - 2024-05-23 19:21:27 --> Hooks Class Initialized
DEBUG - 2024-05-23 19:21:27 --> UTF-8 Support Enabled
INFO - 2024-05-23 19:21:27 --> Utf8 Class Initialized
INFO - 2024-05-23 19:21:27 --> URI Class Initialized
DEBUG - 2024-05-23 19:21:27 --> No URI present. Default controller set.
INFO - 2024-05-23 19:21:27 --> Router Class Initialized
INFO - 2024-05-23 19:21:27 --> Output Class Initialized
INFO - 2024-05-23 19:21:27 --> Security Class Initialized
DEBUG - 2024-05-23 19:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-23 19:21:27 --> Input Class Initialized
INFO - 2024-05-23 19:21:27 --> Language Class Initialized
INFO - 2024-05-23 19:21:27 --> Loader Class Initialized
INFO - 2024-05-23 19:21:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-23 19:21:27 --> Helper loaded: url_helper
DEBUG - 2024-05-23 19:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-23 19:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-23 19:21:27 --> Controller Class Initialized
