<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-04 16:15:40 --> Config Class Initialized
INFO - 2024-05-04 16:15:40 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:40 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:40 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:40 --> URI Class Initialized
DEBUG - 2024-05-04 16:15:40 --> No URI present. Default controller set.
INFO - 2024-05-04 16:15:40 --> Router Class Initialized
INFO - 2024-05-04 16:15:40 --> Output Class Initialized
INFO - 2024-05-04 16:15:40 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:40 --> Input Class Initialized
INFO - 2024-05-04 16:15:40 --> Language Class Initialized
INFO - 2024-05-04 16:15:40 --> Loader Class Initialized
INFO - 2024-05-04 16:15:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:40 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:40 --> Controller Class Initialized
INFO - 2024-05-04 16:15:40 --> Config Class Initialized
INFO - 2024-05-04 16:15:40 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:40 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:40 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:40 --> URI Class Initialized
INFO - 2024-05-04 16:15:40 --> Router Class Initialized
INFO - 2024-05-04 16:15:40 --> Output Class Initialized
INFO - 2024-05-04 16:15:40 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:40 --> Input Class Initialized
INFO - 2024-05-04 16:15:40 --> Language Class Initialized
INFO - 2024-05-04 16:15:40 --> Loader Class Initialized
INFO - 2024-05-04 16:15:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:40 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:40 --> Controller Class Initialized
DEBUG - 2024-05-04 16:15:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:15:40 --> Database Driver Class Initialized
INFO - 2024-05-04 16:15:40 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:15:40 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:15:40 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:15:40 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-04 16:15:40 --> Final output sent to browser
DEBUG - 2024-05-04 16:15:40 --> Total execution time: 0.0416
INFO - 2024-05-04 16:15:41 --> Config Class Initialized
INFO - 2024-05-04 16:15:41 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:41 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:41 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:41 --> URI Class Initialized
INFO - 2024-05-04 16:15:41 --> Router Class Initialized
INFO - 2024-05-04 16:15:41 --> Output Class Initialized
INFO - 2024-05-04 16:15:41 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:41 --> Input Class Initialized
INFO - 2024-05-04 16:15:41 --> Language Class Initialized
INFO - 2024-05-04 16:15:41 --> Loader Class Initialized
INFO - 2024-05-04 16:15:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:41 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:41 --> Controller Class Initialized
INFO - 2024-05-04 16:15:43 --> Config Class Initialized
INFO - 2024-05-04 16:15:43 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:43 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:43 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:43 --> URI Class Initialized
INFO - 2024-05-04 16:15:43 --> Router Class Initialized
INFO - 2024-05-04 16:15:43 --> Output Class Initialized
INFO - 2024-05-04 16:15:43 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:43 --> Input Class Initialized
INFO - 2024-05-04 16:15:43 --> Language Class Initialized
INFO - 2024-05-04 16:15:43 --> Loader Class Initialized
INFO - 2024-05-04 16:15:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:43 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:43 --> Controller Class Initialized
DEBUG - 2024-05-04 16:15:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:15:43 --> Database Driver Class Initialized
INFO - 2024-05-04 16:15:43 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:15:43 --> Helper loaded: form_helper
INFO - 2024-05-04 16:15:43 --> Form Validation Class Initialized
INFO - 2024-05-04 16:15:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-04 16:15:44 --> Config Class Initialized
INFO - 2024-05-04 16:15:44 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:44 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:44 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:44 --> URI Class Initialized
INFO - 2024-05-04 16:15:44 --> Router Class Initialized
INFO - 2024-05-04 16:15:44 --> Output Class Initialized
INFO - 2024-05-04 16:15:44 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:44 --> Input Class Initialized
INFO - 2024-05-04 16:15:44 --> Language Class Initialized
INFO - 2024-05-04 16:15:44 --> Loader Class Initialized
INFO - 2024-05-04 16:15:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:44 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:44 --> Controller Class Initialized
INFO - 2024-05-04 16:15:44 --> Database Driver Class Initialized
DEBUG - 2024-05-04 16:15:44 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:15:44 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:15:44 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:15:44 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:15:44 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-04 16:15:44 --> Final output sent to browser
DEBUG - 2024-05-04 16:15:44 --> Total execution time: 0.0159
INFO - 2024-05-04 16:15:44 --> Config Class Initialized
INFO - 2024-05-04 16:15:44 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:44 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:44 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:44 --> URI Class Initialized
INFO - 2024-05-04 16:15:44 --> Router Class Initialized
INFO - 2024-05-04 16:15:44 --> Output Class Initialized
INFO - 2024-05-04 16:15:44 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:44 --> Input Class Initialized
INFO - 2024-05-04 16:15:44 --> Language Class Initialized
INFO - 2024-05-04 16:15:44 --> Loader Class Initialized
INFO - 2024-05-04 16:15:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:44 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:44 --> Controller Class Initialized
DEBUG - 2024-05-04 16:15:44 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:15:44 --> Database Driver Class Initialized
INFO - 2024-05-04 16:15:44 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:15:44 --> Final output sent to browser
DEBUG - 2024-05-04 16:15:44 --> Total execution time: 0.0316
INFO - 2024-05-04 16:15:54 --> Config Class Initialized
INFO - 2024-05-04 16:15:54 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:54 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:54 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:54 --> URI Class Initialized
INFO - 2024-05-04 16:15:54 --> Router Class Initialized
INFO - 2024-05-04 16:15:54 --> Output Class Initialized
INFO - 2024-05-04 16:15:54 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:54 --> Input Class Initialized
INFO - 2024-05-04 16:15:54 --> Language Class Initialized
INFO - 2024-05-04 16:15:54 --> Loader Class Initialized
INFO - 2024-05-04 16:15:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:54 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:54 --> Controller Class Initialized
DEBUG - 2024-05-04 16:15:54 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:15:54 --> Database Driver Class Initialized
INFO - 2024-05-04 16:15:54 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:15:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:15:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:15:54 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-04 16:15:54 --> Final output sent to browser
DEBUG - 2024-05-04 16:15:54 --> Total execution time: 0.0962
INFO - 2024-05-04 16:15:54 --> Config Class Initialized
INFO - 2024-05-04 16:15:54 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:54 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:54 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:54 --> URI Class Initialized
INFO - 2024-05-04 16:15:54 --> Router Class Initialized
INFO - 2024-05-04 16:15:54 --> Output Class Initialized
INFO - 2024-05-04 16:15:54 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:54 --> Input Class Initialized
INFO - 2024-05-04 16:15:54 --> Language Class Initialized
INFO - 2024-05-04 16:15:54 --> Loader Class Initialized
INFO - 2024-05-04 16:15:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:15:54 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:54 --> Controller Class Initialized
DEBUG - 2024-05-04 16:15:54 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:15:54 --> Database Driver Class Initialized
INFO - 2024-05-04 16:15:54 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:15:54 --> Final output sent to browser
DEBUG - 2024-05-04 16:15:54 --> Total execution time: 0.0892
INFO - 2024-05-04 16:43:34 --> Config Class Initialized
INFO - 2024-05-04 16:43:34 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:34 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:34 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:34 --> URI Class Initialized
INFO - 2024-05-04 16:43:34 --> Router Class Initialized
INFO - 2024-05-04 16:43:34 --> Output Class Initialized
INFO - 2024-05-04 16:43:34 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:34 --> Input Class Initialized
INFO - 2024-05-04 16:43:34 --> Language Class Initialized
INFO - 2024-05-04 16:43:34 --> Loader Class Initialized
INFO - 2024-05-04 16:43:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:34 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:34 --> Controller Class Initialized
DEBUG - 2024-05-04 16:43:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:43:34 --> Database Driver Class Initialized
INFO - 2024-05-04 16:43:34 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:43:34 --> Config Class Initialized
INFO - 2024-05-04 16:43:34 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:34 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:34 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:34 --> URI Class Initialized
DEBUG - 2024-05-04 16:43:34 --> No URI present. Default controller set.
INFO - 2024-05-04 16:43:34 --> Router Class Initialized
INFO - 2024-05-04 16:43:34 --> Output Class Initialized
INFO - 2024-05-04 16:43:34 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:34 --> Input Class Initialized
INFO - 2024-05-04 16:43:34 --> Language Class Initialized
INFO - 2024-05-04 16:43:34 --> Loader Class Initialized
INFO - 2024-05-04 16:43:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:34 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:34 --> Controller Class Initialized
INFO - 2024-05-04 16:43:35 --> Config Class Initialized
INFO - 2024-05-04 16:43:35 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:35 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:35 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:35 --> URI Class Initialized
INFO - 2024-05-04 16:43:35 --> Router Class Initialized
INFO - 2024-05-04 16:43:35 --> Output Class Initialized
INFO - 2024-05-04 16:43:35 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:35 --> Input Class Initialized
INFO - 2024-05-04 16:43:35 --> Language Class Initialized
INFO - 2024-05-04 16:43:35 --> Loader Class Initialized
INFO - 2024-05-04 16:43:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:35 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:35 --> Controller Class Initialized
DEBUG - 2024-05-04 16:43:35 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:43:35 --> Database Driver Class Initialized
INFO - 2024-05-04 16:43:35 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:43:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:43:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:43:35 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-04 16:43:35 --> Final output sent to browser
DEBUG - 2024-05-04 16:43:35 --> Total execution time: 0.0151
INFO - 2024-05-04 16:43:35 --> Config Class Initialized
INFO - 2024-05-04 16:43:35 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:35 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:35 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:35 --> URI Class Initialized
INFO - 2024-05-04 16:43:35 --> Router Class Initialized
INFO - 2024-05-04 16:43:35 --> Output Class Initialized
INFO - 2024-05-04 16:43:35 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:35 --> Input Class Initialized
INFO - 2024-05-04 16:43:35 --> Language Class Initialized
INFO - 2024-05-04 16:43:35 --> Loader Class Initialized
INFO - 2024-05-04 16:43:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:35 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:35 --> Controller Class Initialized
INFO - 2024-05-04 16:43:37 --> Config Class Initialized
INFO - 2024-05-04 16:43:37 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:37 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:37 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:37 --> URI Class Initialized
INFO - 2024-05-04 16:43:37 --> Router Class Initialized
INFO - 2024-05-04 16:43:37 --> Output Class Initialized
INFO - 2024-05-04 16:43:37 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:37 --> Input Class Initialized
INFO - 2024-05-04 16:43:37 --> Language Class Initialized
INFO - 2024-05-04 16:43:37 --> Loader Class Initialized
INFO - 2024-05-04 16:43:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:37 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:37 --> Controller Class Initialized
DEBUG - 2024-05-04 16:43:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:43:37 --> Database Driver Class Initialized
INFO - 2024-05-04 16:43:37 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:43:37 --> Helper loaded: form_helper
INFO - 2024-05-04 16:43:37 --> Form Validation Class Initialized
INFO - 2024-05-04 16:43:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-04 16:43:37 --> Config Class Initialized
INFO - 2024-05-04 16:43:37 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:37 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:37 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:37 --> URI Class Initialized
INFO - 2024-05-04 16:43:37 --> Router Class Initialized
INFO - 2024-05-04 16:43:37 --> Output Class Initialized
INFO - 2024-05-04 16:43:37 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:37 --> Input Class Initialized
INFO - 2024-05-04 16:43:37 --> Language Class Initialized
INFO - 2024-05-04 16:43:37 --> Loader Class Initialized
INFO - 2024-05-04 16:43:37 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:37 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:37 --> Controller Class Initialized
INFO - 2024-05-04 16:43:37 --> Database Driver Class Initialized
DEBUG - 2024-05-04 16:43:37 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:43:37 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:43:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:43:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:43:37 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-04 16:43:37 --> Final output sent to browser
DEBUG - 2024-05-04 16:43:37 --> Total execution time: 0.0105
INFO - 2024-05-04 16:43:38 --> Config Class Initialized
INFO - 2024-05-04 16:43:38 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:38 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:38 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:38 --> URI Class Initialized
INFO - 2024-05-04 16:43:38 --> Router Class Initialized
INFO - 2024-05-04 16:43:38 --> Output Class Initialized
INFO - 2024-05-04 16:43:38 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:38 --> Input Class Initialized
INFO - 2024-05-04 16:43:38 --> Language Class Initialized
INFO - 2024-05-04 16:43:38 --> Loader Class Initialized
INFO - 2024-05-04 16:43:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:38 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:38 --> Controller Class Initialized
DEBUG - 2024-05-04 16:43:38 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:43:38 --> Database Driver Class Initialized
INFO - 2024-05-04 16:43:38 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:43:38 --> Final output sent to browser
DEBUG - 2024-05-04 16:43:38 --> Total execution time: 0.0236
INFO - 2024-05-04 16:43:42 --> Config Class Initialized
INFO - 2024-05-04 16:43:42 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:42 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:42 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:42 --> URI Class Initialized
INFO - 2024-05-04 16:43:42 --> Router Class Initialized
INFO - 2024-05-04 16:43:42 --> Output Class Initialized
INFO - 2024-05-04 16:43:42 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:42 --> Input Class Initialized
INFO - 2024-05-04 16:43:42 --> Language Class Initialized
INFO - 2024-05-04 16:43:42 --> Loader Class Initialized
INFO - 2024-05-04 16:43:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:42 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:42 --> Controller Class Initialized
DEBUG - 2024-05-04 16:43:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:43:42 --> Database Driver Class Initialized
INFO - 2024-05-04 16:43:42 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:43:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:43:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:43:42 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-04 16:43:42 --> Final output sent to browser
DEBUG - 2024-05-04 16:43:42 --> Total execution time: 0.0475
INFO - 2024-05-04 16:43:42 --> Config Class Initialized
INFO - 2024-05-04 16:43:42 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:42 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:42 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:42 --> URI Class Initialized
INFO - 2024-05-04 16:43:42 --> Router Class Initialized
INFO - 2024-05-04 16:43:42 --> Output Class Initialized
INFO - 2024-05-04 16:43:42 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:42 --> Input Class Initialized
INFO - 2024-05-04 16:43:42 --> Language Class Initialized
INFO - 2024-05-04 16:43:42 --> Loader Class Initialized
INFO - 2024-05-04 16:43:42 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:42 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:42 --> Controller Class Initialized
DEBUG - 2024-05-04 16:43:42 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:43:42 --> Database Driver Class Initialized
INFO - 2024-05-04 16:43:42 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:43:42 --> Final output sent to browser
DEBUG - 2024-05-04 16:43:42 --> Total execution time: 0.0161
INFO - 2024-05-04 16:43:45 --> Config Class Initialized
INFO - 2024-05-04 16:43:45 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:43:45 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:43:45 --> Utf8 Class Initialized
INFO - 2024-05-04 16:43:45 --> URI Class Initialized
INFO - 2024-05-04 16:43:45 --> Router Class Initialized
INFO - 2024-05-04 16:43:45 --> Output Class Initialized
INFO - 2024-05-04 16:43:45 --> Security Class Initialized
DEBUG - 2024-05-04 16:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:43:45 --> Input Class Initialized
INFO - 2024-05-04 16:43:45 --> Language Class Initialized
INFO - 2024-05-04 16:43:45 --> Loader Class Initialized
INFO - 2024-05-04 16:43:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:43:45 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:43:45 --> Controller Class Initialized
DEBUG - 2024-05-04 16:43:45 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:43:45 --> Database Driver Class Initialized
INFO - 2024-05-04 16:43:45 --> Helper loaded: funciones_helper
ERROR - 2024-05-04 16:43:45 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column pre.moneda_id does not exist
LINE 7:    ,pre.moneda_id AS pre_moneda_id 
            ^
HINT:  Perhaps you meant to reference the column &quot;cc.moneda_id&quot; or the column &quot;ccc.moneda_id&quot;. /var/www/html/perroneinmobiliaria/system/database/drivers/postgre/postgre_driver.php 242
ERROR - 2024-05-04 16:43:45 --> Query error: ERROR:  column pre.moneda_id does not exist
LINE 7:    ,pre.moneda_id AS pre_moneda_id 
            ^
HINT:  Perhaps you meant to reference the column "cc.moneda_id" or the column "ccc.moneda_id". - Invalid query: SELECT   pre.id AS pre_id
			,pre.fecha_inicio AS pre_fecha_inicio
			,pre.titulo AS pre_titulo
			,pre.comentario AS pre_comentario
			,pre.importe_inicial AS pre_importe_inicial
			,to_char(COALESCE(pre.importe_inicial, 0), '9,999,999,999,999D99'::text) AS pre_importe_inicialxx
			,pre.moneda_id	AS pre_moneda_id 
			,pre.proyecto_id AS pre_proyecto_id
			,pro.nombre AS pro_nombre
			,pre.estado pre_estado
			,e.id AS e_id
			,e.razon_social AS e_razon_social
			,rpc.id AS rpc_id
			,rpc.cuenta_corriente_id AS rpc_cuenta_corriente_id
			,rpc.presupuesto_id AS rpc_presupuesto_id
			,rpc.estado AS rpc_estado
			,cc.id AS cc_id
			,cc.tipo_comprobante_id AS cc_tipo_comprobante_id
			,cc.importe AS cc_importe 
			,to_char(COALESCE(cc.importe, 0), '9,999,999,999,999D99'::text) AS cc_importexx
			,cc.fecha AS cc_fecha
			,cc.numero AS cc_numero
			,cc.moneda_id AS cc_moneda_id
			,tc.abreviado AS tc_abreviado
			,cc.docu_letra||cc.docu_sucu::text||' '||cc.docu_nume::text AS cclsn
			,cc.estado AS cc_estado
			,rcc.id AS rcc_id
			,rcc.monto_pesos AS rcc_monto_pesos
			,to_char(COALESCE(rcc.monto_pesos, 0), '9,999,999,999,999D99'::text) AS rcc_monto_pesosxx
			,rcc.monto_divisa AS rcc_monto_divisa
			,to_char(COALESCE(rcc.monto_divisa, 0), '9,999,999,999,999D99'::text) AS rcc_monto_divisaxx
			,rcc.estado AS rcc_estado
			,ccc.id AS ccc_id
			,ccc.fecha AS ccc_fecha
			--	,tcc.abreviado AS tcc_abreviado
			,tcc.abreviado || ' '|| ccc.numero  AS ccclsn
			--	,ccc.docu_letra||ccc.docu_sucu::text||' '||ccc.docu_nume::text AS ccclsnn
			,ccc.numero AS ccc_numero
			,ccc.estado AS ccc_estado
		FROM presupuestos pre
		LEFT JOIN entidades e            ON pre.entidad_id = e.id
		LEFT JOIN proyectos pro          ON pre.proyecto_id = pro.id
		LEFT JOIN relacion_presu_ctactes rpc ON pre.id = rpc.presupuesto_id
		LEFT JOIN cuentas_corrientes cc  ON rpc.cuenta_corriente_id = cc.id
		LEFT JOIN tipos_comprobantes tc  ON cc.tipo_comprobante_id = tc.id
		LEFT JOIN relacion_ctas_ctes rcc ON cc.id = rcc.cuenta_corriente_id
		LEFT JOIN cuentas_corrientes ccc ON rcc.relacion_id = ccc.id
		LEFT JOIN tipos_comprobantes tcc ON ccc.tipo_comprobante_id = tcc.id
		WHERE pre.estado = 0
		  AND COALESCE(rpc.estado,0) = 0
		  AND COALESCE(cc.estado,0)  = 0
		  AND COALESCE(rcc.estado,0) = 0
		  AND COALESCE(ccc.estado,0) = 0
		  AND pre.fecha_inicio BETWEEN '2023-05-05' AND '2024-05-04'
		 AND pre.entidad_id = 62
		ORDER BY pre.entidad_id, pre.fecha_inicio
ERROR - 2024-05-04 16:43:45 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/html/perroneinmobiliaria/application/models/Informepresu_model.php 83
INFO - 2024-05-04 16:44:52 --> Config Class Initialized
INFO - 2024-05-04 16:44:52 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:44:52 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:44:52 --> Utf8 Class Initialized
INFO - 2024-05-04 16:44:52 --> URI Class Initialized
INFO - 2024-05-04 16:44:52 --> Router Class Initialized
INFO - 2024-05-04 16:44:52 --> Output Class Initialized
INFO - 2024-05-04 16:44:52 --> Security Class Initialized
DEBUG - 2024-05-04 16:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:44:52 --> Input Class Initialized
INFO - 2024-05-04 16:44:52 --> Language Class Initialized
INFO - 2024-05-04 16:44:52 --> Loader Class Initialized
INFO - 2024-05-04 16:44:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:44:52 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:44:52 --> Controller Class Initialized
DEBUG - 2024-05-04 16:44:52 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:44:52 --> Database Driver Class Initialized
INFO - 2024-05-04 16:44:52 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:44:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:44:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:44:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/presupuestos.php
INFO - 2024-05-04 16:44:52 --> Final output sent to browser
DEBUG - 2024-05-04 16:44:52 --> Total execution time: 0.0316
INFO - 2024-05-04 16:44:53 --> Config Class Initialized
INFO - 2024-05-04 16:44:53 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:44:53 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:44:53 --> Utf8 Class Initialized
INFO - 2024-05-04 16:44:53 --> URI Class Initialized
INFO - 2024-05-04 16:44:53 --> Router Class Initialized
INFO - 2024-05-04 16:44:53 --> Output Class Initialized
INFO - 2024-05-04 16:44:53 --> Security Class Initialized
DEBUG - 2024-05-04 16:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:44:53 --> Input Class Initialized
INFO - 2024-05-04 16:44:53 --> Language Class Initialized
INFO - 2024-05-04 16:44:53 --> Loader Class Initialized
INFO - 2024-05-04 16:44:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:44:53 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:44:53 --> Controller Class Initialized
DEBUG - 2024-05-04 16:44:53 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:44:53 --> Database Driver Class Initialized
INFO - 2024-05-04 16:44:53 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:44:53 --> Final output sent to browser
DEBUG - 2024-05-04 16:44:53 --> Total execution time: 0.0136
INFO - 2024-05-04 16:44:53 --> Config Class Initialized
INFO - 2024-05-04 16:44:53 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:44:53 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:44:53 --> Utf8 Class Initialized
INFO - 2024-05-04 16:44:53 --> URI Class Initialized
INFO - 2024-05-04 16:44:53 --> Router Class Initialized
INFO - 2024-05-04 16:44:53 --> Output Class Initialized
INFO - 2024-05-04 16:44:53 --> Security Class Initialized
DEBUG - 2024-05-04 16:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:44:53 --> Input Class Initialized
INFO - 2024-05-04 16:44:53 --> Language Class Initialized
INFO - 2024-05-04 16:44:53 --> Loader Class Initialized
INFO - 2024-05-04 16:44:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:44:53 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:44:53 --> Controller Class Initialized
DEBUG - 2024-05-04 16:44:53 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:44:53 --> Database Driver Class Initialized
INFO - 2024-05-04 16:44:53 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:44:53 --> Final output sent to browser
DEBUG - 2024-05-04 16:44:53 --> Total execution time: 0.0134
INFO - 2024-05-04 16:44:56 --> Config Class Initialized
INFO - 2024-05-04 16:44:56 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:44:56 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:44:56 --> Utf8 Class Initialized
INFO - 2024-05-04 16:44:56 --> URI Class Initialized
INFO - 2024-05-04 16:44:56 --> Router Class Initialized
INFO - 2024-05-04 16:44:56 --> Output Class Initialized
INFO - 2024-05-04 16:44:56 --> Security Class Initialized
DEBUG - 2024-05-04 16:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:44:56 --> Input Class Initialized
INFO - 2024-05-04 16:44:56 --> Language Class Initialized
INFO - 2024-05-04 16:44:56 --> Loader Class Initialized
INFO - 2024-05-04 16:44:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:44:56 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:44:56 --> Controller Class Initialized
DEBUG - 2024-05-04 16:44:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:44:56 --> Database Driver Class Initialized
INFO - 2024-05-04 16:44:56 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:44:56 --> Final output sent to browser
DEBUG - 2024-05-04 16:44:56 --> Total execution time: 0.0157
INFO - 2024-05-04 16:44:59 --> Config Class Initialized
INFO - 2024-05-04 16:44:59 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:44:59 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:44:59 --> Utf8 Class Initialized
INFO - 2024-05-04 16:44:59 --> URI Class Initialized
INFO - 2024-05-04 16:44:59 --> Router Class Initialized
INFO - 2024-05-04 16:44:59 --> Output Class Initialized
INFO - 2024-05-04 16:44:59 --> Security Class Initialized
DEBUG - 2024-05-04 16:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:44:59 --> Input Class Initialized
INFO - 2024-05-04 16:44:59 --> Language Class Initialized
INFO - 2024-05-04 16:44:59 --> Loader Class Initialized
INFO - 2024-05-04 16:44:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:44:59 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:44:59 --> Controller Class Initialized
DEBUG - 2024-05-04 16:44:59 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:44:59 --> Database Driver Class Initialized
INFO - 2024-05-04 16:44:59 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:44:59 --> Final output sent to browser
DEBUG - 2024-05-04 16:44:59 --> Total execution time: 0.0153
INFO - 2024-05-04 16:45:01 --> Config Class Initialized
INFO - 2024-05-04 16:45:01 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:45:01 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:45:01 --> Utf8 Class Initialized
INFO - 2024-05-04 16:45:01 --> URI Class Initialized
INFO - 2024-05-04 16:45:01 --> Router Class Initialized
INFO - 2024-05-04 16:45:01 --> Output Class Initialized
INFO - 2024-05-04 16:45:01 --> Security Class Initialized
DEBUG - 2024-05-04 16:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:45:01 --> Input Class Initialized
INFO - 2024-05-04 16:45:01 --> Language Class Initialized
INFO - 2024-05-04 16:45:01 --> Loader Class Initialized
INFO - 2024-05-04 16:45:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:45:01 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:45:01 --> Controller Class Initialized
DEBUG - 2024-05-04 16:45:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:45:01 --> Database Driver Class Initialized
INFO - 2024-05-04 16:45:01 --> Helper loaded: funciones_helper
ERROR - 2024-05-04 16:45:01 --> Severity: Warning --> Creating default object from empty value /var/www/html/perroneinmobiliaria/application/controllers/Presupuestos.php 98
INFO - 2024-05-04 16:45:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-04 16:45:01 --> Final output sent to browser
DEBUG - 2024-05-04 16:45:01 --> Total execution time: 0.0158
INFO - 2024-05-04 16:46:11 --> Config Class Initialized
INFO - 2024-05-04 16:46:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:11 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:11 --> URI Class Initialized
INFO - 2024-05-04 16:46:11 --> Router Class Initialized
INFO - 2024-05-04 16:46:11 --> Output Class Initialized
INFO - 2024-05-04 16:46:11 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:11 --> Input Class Initialized
INFO - 2024-05-04 16:46:11 --> Language Class Initialized
INFO - 2024-05-04 16:46:11 --> Loader Class Initialized
INFO - 2024-05-04 16:46:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:11 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:11 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:11 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:11 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:11 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:11 --> Total execution time: 0.0194
INFO - 2024-05-04 16:46:15 --> Config Class Initialized
INFO - 2024-05-04 16:46:15 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:15 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:15 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:15 --> URI Class Initialized
INFO - 2024-05-04 16:46:15 --> Router Class Initialized
INFO - 2024-05-04 16:46:15 --> Output Class Initialized
INFO - 2024-05-04 16:46:15 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:15 --> Input Class Initialized
INFO - 2024-05-04 16:46:15 --> Language Class Initialized
INFO - 2024-05-04 16:46:15 --> Loader Class Initialized
INFO - 2024-05-04 16:46:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:15 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:15 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:15 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:15 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-04 16:46:15 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:15 --> Total execution time: 0.0794
INFO - 2024-05-04 16:46:20 --> Config Class Initialized
INFO - 2024-05-04 16:46:20 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:20 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:20 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:20 --> URI Class Initialized
INFO - 2024-05-04 16:46:20 --> Router Class Initialized
INFO - 2024-05-04 16:46:20 --> Output Class Initialized
INFO - 2024-05-04 16:46:20 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:20 --> Input Class Initialized
INFO - 2024-05-04 16:46:20 --> Language Class Initialized
INFO - 2024-05-04 16:46:20 --> Loader Class Initialized
INFO - 2024-05-04 16:46:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:20 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:20 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:20 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:20 --> Helper loaded: funciones_helper
ERROR - 2024-05-04 16:46:20 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;moneda_id&quot; of relation &quot;presupuestos&quot; does not exist
LINE 1: ...orte_final&quot; = '12345678.00', &quot;entidad_id&quot; = '62', &quot;moneda_id...
                                                             ^ /var/www/html/perroneinmobiliaria/system/database/drivers/postgre/postgre_driver.php 242
ERROR - 2024-05-04 16:46:20 --> Query error: ERROR:  column "moneda_id" of relation "presupuestos" does not exist
LINE 1: ...orte_final" = '12345678.00', "entidad_id" = '62', "moneda_id...
                                                             ^ - Invalid query: UPDATE "presupuestos" SET "fecha_inicio" = '2024-04-21', "fecha_final" = '2024-04-21', "comentario" = 'ccccccccccccccccccc', "importe_inicial" = '12345678.00', "importe_final" = '12345678.00', "entidad_id" = '62', "moneda_id" = '1', "proyecto_id" = '3', "titulo" = 'qqqqqqqqqqqqqq'
WHERE "id" = 1
INFO - 2024-05-04 16:46:20 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:20 --> Total execution time: 0.0922
INFO - 2024-05-04 16:46:20 --> Config Class Initialized
INFO - 2024-05-04 16:46:20 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:20 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:20 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:20 --> URI Class Initialized
INFO - 2024-05-04 16:46:20 --> Router Class Initialized
INFO - 2024-05-04 16:46:20 --> Output Class Initialized
INFO - 2024-05-04 16:46:20 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:20 --> Input Class Initialized
INFO - 2024-05-04 16:46:20 --> Language Class Initialized
INFO - 2024-05-04 16:46:20 --> Loader Class Initialized
INFO - 2024-05-04 16:46:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:20 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:20 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:20 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:20 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:20 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:20 --> Total execution time: 0.0842
INFO - 2024-05-04 16:46:26 --> Config Class Initialized
INFO - 2024-05-04 16:46:26 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:26 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:26 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:26 --> URI Class Initialized
INFO - 2024-05-04 16:46:26 --> Router Class Initialized
INFO - 2024-05-04 16:46:26 --> Output Class Initialized
INFO - 2024-05-04 16:46:26 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:26 --> Input Class Initialized
INFO - 2024-05-04 16:46:26 --> Language Class Initialized
INFO - 2024-05-04 16:46:26 --> Loader Class Initialized
INFO - 2024-05-04 16:46:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:26 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:26 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:26 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:26 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-04 16:46:26 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:26 --> Total execution time: 0.0189
INFO - 2024-05-04 16:46:33 --> Config Class Initialized
INFO - 2024-05-04 16:46:33 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:33 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:33 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:33 --> URI Class Initialized
INFO - 2024-05-04 16:46:33 --> Router Class Initialized
INFO - 2024-05-04 16:46:33 --> Output Class Initialized
INFO - 2024-05-04 16:46:33 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:33 --> Input Class Initialized
INFO - 2024-05-04 16:46:33 --> Language Class Initialized
INFO - 2024-05-04 16:46:33 --> Loader Class Initialized
INFO - 2024-05-04 16:46:33 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:33 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:33 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:33 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:33 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:33 --> Helper loaded: funciones_helper
ERROR - 2024-05-04 16:46:33 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;moneda_id&quot; of relation &quot;presupuestos&quot; does not exist
LINE 1: ...orte_final&quot; = '12345678.00', &quot;entidad_id&quot; = '62', &quot;moneda_id...
                                                             ^ /var/www/html/perroneinmobiliaria/system/database/drivers/postgre/postgre_driver.php 242
ERROR - 2024-05-04 16:46:33 --> Query error: ERROR:  column "moneda_id" of relation "presupuestos" does not exist
LINE 1: ...orte_final" = '12345678.00', "entidad_id" = '62', "moneda_id...
                                                             ^ - Invalid query: UPDATE "presupuestos" SET "fecha_inicio" = '2024-04-21', "fecha_final" = '2024-04-21', "comentario" = 'ccccccccccccccccccc', "importe_inicial" = '12345678.00', "importe_final" = '12345678.00', "entidad_id" = '62', "moneda_id" = '2', "proyecto_id" = '3', "titulo" = 'qqqqqqqqqqqqqq'
WHERE "id" = 1
INFO - 2024-05-04 16:46:33 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:33 --> Total execution time: 0.0125
INFO - 2024-05-04 16:46:34 --> Config Class Initialized
INFO - 2024-05-04 16:46:34 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:34 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:34 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:34 --> URI Class Initialized
INFO - 2024-05-04 16:46:34 --> Router Class Initialized
INFO - 2024-05-04 16:46:34 --> Output Class Initialized
INFO - 2024-05-04 16:46:34 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:34 --> Input Class Initialized
INFO - 2024-05-04 16:46:34 --> Language Class Initialized
INFO - 2024-05-04 16:46:34 --> Loader Class Initialized
INFO - 2024-05-04 16:46:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:34 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:34 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:34 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:34 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:34 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:34 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:34 --> Total execution time: 0.0182
INFO - 2024-05-04 16:46:36 --> Config Class Initialized
INFO - 2024-05-04 16:46:36 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:36 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:36 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:36 --> URI Class Initialized
INFO - 2024-05-04 16:46:36 --> Router Class Initialized
INFO - 2024-05-04 16:46:36 --> Output Class Initialized
INFO - 2024-05-04 16:46:36 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:36 --> Input Class Initialized
INFO - 2024-05-04 16:46:36 --> Language Class Initialized
INFO - 2024-05-04 16:46:36 --> Loader Class Initialized
INFO - 2024-05-04 16:46:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:36 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:36 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:36 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:36 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:36 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:36 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:36 --> Total execution time: 0.0177
INFO - 2024-05-04 16:46:38 --> Config Class Initialized
INFO - 2024-05-04 16:46:38 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:38 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:38 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:38 --> URI Class Initialized
INFO - 2024-05-04 16:46:38 --> Router Class Initialized
INFO - 2024-05-04 16:46:38 --> Output Class Initialized
INFO - 2024-05-04 16:46:38 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:38 --> Input Class Initialized
INFO - 2024-05-04 16:46:38 --> Language Class Initialized
INFO - 2024-05-04 16:46:38 --> Loader Class Initialized
INFO - 2024-05-04 16:46:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:38 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:38 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:38 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:38 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:38 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:38 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:38 --> Total execution time: 0.0182
INFO - 2024-05-04 16:46:43 --> Config Class Initialized
INFO - 2024-05-04 16:46:43 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:46:43 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:46:43 --> Utf8 Class Initialized
INFO - 2024-05-04 16:46:43 --> URI Class Initialized
INFO - 2024-05-04 16:46:43 --> Router Class Initialized
INFO - 2024-05-04 16:46:43 --> Output Class Initialized
INFO - 2024-05-04 16:46:43 --> Security Class Initialized
DEBUG - 2024-05-04 16:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:46:43 --> Input Class Initialized
INFO - 2024-05-04 16:46:43 --> Language Class Initialized
INFO - 2024-05-04 16:46:43 --> Loader Class Initialized
INFO - 2024-05-04 16:46:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:46:43 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:46:43 --> Controller Class Initialized
DEBUG - 2024-05-04 16:46:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:46:43 --> Database Driver Class Initialized
INFO - 2024-05-04 16:46:43 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:46:43 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-04 16:46:43 --> Final output sent to browser
DEBUG - 2024-05-04 16:46:43 --> Total execution time: 0.0115
INFO - 2024-05-04 16:49:01 --> Config Class Initialized
INFO - 2024-05-04 16:49:01 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:49:01 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:49:01 --> Utf8 Class Initialized
INFO - 2024-05-04 16:49:01 --> URI Class Initialized
INFO - 2024-05-04 16:49:01 --> Router Class Initialized
INFO - 2024-05-04 16:49:01 --> Output Class Initialized
INFO - 2024-05-04 16:49:01 --> Security Class Initialized
DEBUG - 2024-05-04 16:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:49:01 --> Input Class Initialized
INFO - 2024-05-04 16:49:01 --> Language Class Initialized
INFO - 2024-05-04 16:49:01 --> Loader Class Initialized
INFO - 2024-05-04 16:49:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:49:01 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:49:01 --> Controller Class Initialized
DEBUG - 2024-05-04 16:49:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:49:01 --> Database Driver Class Initialized
INFO - 2024-05-04 16:49:01 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:49:01 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-04 16:49:01 --> Final output sent to browser
DEBUG - 2024-05-04 16:49:01 --> Total execution time: 0.0280
INFO - 2024-05-04 16:49:04 --> Config Class Initialized
INFO - 2024-05-04 16:49:04 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:49:04 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:49:04 --> Utf8 Class Initialized
INFO - 2024-05-04 16:49:04 --> URI Class Initialized
INFO - 2024-05-04 16:49:04 --> Router Class Initialized
INFO - 2024-05-04 16:49:04 --> Output Class Initialized
INFO - 2024-05-04 16:49:04 --> Security Class Initialized
DEBUG - 2024-05-04 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:49:04 --> Input Class Initialized
INFO - 2024-05-04 16:49:04 --> Language Class Initialized
INFO - 2024-05-04 16:49:04 --> Loader Class Initialized
INFO - 2024-05-04 16:49:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:49:04 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:49:04 --> Controller Class Initialized
DEBUG - 2024-05-04 16:49:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:49:04 --> Database Driver Class Initialized
INFO - 2024-05-04 16:49:04 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:49:04 --> Final output sent to browser
DEBUG - 2024-05-04 16:49:04 --> Total execution time: 0.0216
INFO - 2024-05-04 16:49:04 --> Config Class Initialized
INFO - 2024-05-04 16:49:04 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:49:04 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:49:04 --> Utf8 Class Initialized
INFO - 2024-05-04 16:49:04 --> URI Class Initialized
INFO - 2024-05-04 16:49:04 --> Router Class Initialized
INFO - 2024-05-04 16:49:04 --> Output Class Initialized
INFO - 2024-05-04 16:49:04 --> Security Class Initialized
DEBUG - 2024-05-04 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:49:04 --> Input Class Initialized
INFO - 2024-05-04 16:49:04 --> Language Class Initialized
INFO - 2024-05-04 16:49:04 --> Loader Class Initialized
INFO - 2024-05-04 16:49:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:49:04 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:49:04 --> Controller Class Initialized
DEBUG - 2024-05-04 16:49:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:49:04 --> Database Driver Class Initialized
INFO - 2024-05-04 16:49:04 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:49:04 --> Final output sent to browser
DEBUG - 2024-05-04 16:49:04 --> Total execution time: 0.0225
INFO - 2024-05-04 16:49:16 --> Config Class Initialized
INFO - 2024-05-04 16:49:16 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:49:16 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:49:16 --> Utf8 Class Initialized
INFO - 2024-05-04 16:49:16 --> URI Class Initialized
INFO - 2024-05-04 16:49:16 --> Router Class Initialized
INFO - 2024-05-04 16:49:16 --> Output Class Initialized
INFO - 2024-05-04 16:49:16 --> Security Class Initialized
DEBUG - 2024-05-04 16:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:49:16 --> Input Class Initialized
INFO - 2024-05-04 16:49:16 --> Language Class Initialized
INFO - 2024-05-04 16:49:16 --> Loader Class Initialized
INFO - 2024-05-04 16:49:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:49:16 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:49:16 --> Controller Class Initialized
DEBUG - 2024-05-04 16:49:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:49:16 --> Database Driver Class Initialized
INFO - 2024-05-04 16:49:16 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:49:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-04 16:49:16 --> Final output sent to browser
DEBUG - 2024-05-04 16:49:16 --> Total execution time: 0.0191
INFO - 2024-05-04 16:49:21 --> Config Class Initialized
INFO - 2024-05-04 16:49:21 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:49:21 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:49:21 --> Utf8 Class Initialized
INFO - 2024-05-04 16:49:21 --> URI Class Initialized
INFO - 2024-05-04 16:49:21 --> Router Class Initialized
INFO - 2024-05-04 16:49:21 --> Output Class Initialized
INFO - 2024-05-04 16:49:21 --> Security Class Initialized
DEBUG - 2024-05-04 16:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:49:21 --> Input Class Initialized
INFO - 2024-05-04 16:49:21 --> Language Class Initialized
INFO - 2024-05-04 16:49:21 --> Loader Class Initialized
INFO - 2024-05-04 16:49:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:49:21 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:49:21 --> Controller Class Initialized
DEBUG - 2024-05-04 16:49:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:49:21 --> Database Driver Class Initialized
INFO - 2024-05-04 16:49:21 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:49:21 --> Final output sent to browser
DEBUG - 2024-05-04 16:49:21 --> Total execution time: 0.0666
INFO - 2024-05-04 16:49:21 --> Config Class Initialized
INFO - 2024-05-04 16:49:21 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:49:21 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:49:21 --> Utf8 Class Initialized
INFO - 2024-05-04 16:49:21 --> URI Class Initialized
INFO - 2024-05-04 16:49:21 --> Router Class Initialized
INFO - 2024-05-04 16:49:21 --> Output Class Initialized
INFO - 2024-05-04 16:49:21 --> Security Class Initialized
DEBUG - 2024-05-04 16:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:49:21 --> Input Class Initialized
INFO - 2024-05-04 16:49:21 --> Language Class Initialized
INFO - 2024-05-04 16:49:21 --> Loader Class Initialized
INFO - 2024-05-04 16:49:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:49:21 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:49:21 --> Controller Class Initialized
DEBUG - 2024-05-04 16:49:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:49:21 --> Database Driver Class Initialized
INFO - 2024-05-04 16:49:21 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:49:21 --> Final output sent to browser
DEBUG - 2024-05-04 16:49:21 --> Total execution time: 0.0192
INFO - 2024-05-04 16:52:07 --> Config Class Initialized
INFO - 2024-05-04 16:52:07 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:07 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:07 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:07 --> URI Class Initialized
INFO - 2024-05-04 16:52:07 --> Router Class Initialized
INFO - 2024-05-04 16:52:07 --> Output Class Initialized
INFO - 2024-05-04 16:52:07 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:07 --> Input Class Initialized
INFO - 2024-05-04 16:52:07 --> Language Class Initialized
INFO - 2024-05-04 16:52:07 --> Loader Class Initialized
INFO - 2024-05-04 16:52:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:07 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:07 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:07 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:52:07 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:07 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:07 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:07 --> Total execution time: 0.0282
INFO - 2024-05-04 16:52:09 --> Config Class Initialized
INFO - 2024-05-04 16:52:09 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:09 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:09 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:09 --> URI Class Initialized
INFO - 2024-05-04 16:52:09 --> Router Class Initialized
INFO - 2024-05-04 16:52:09 --> Output Class Initialized
INFO - 2024-05-04 16:52:09 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:09 --> Input Class Initialized
INFO - 2024-05-04 16:52:09 --> Language Class Initialized
INFO - 2024-05-04 16:52:09 --> Loader Class Initialized
INFO - 2024-05-04 16:52:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:09 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:09 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:09 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:52:09 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:09 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:09 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:09 --> Total execution time: 0.0132
INFO - 2024-05-04 16:52:11 --> Config Class Initialized
INFO - 2024-05-04 16:52:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:11 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:11 --> URI Class Initialized
INFO - 2024-05-04 16:52:11 --> Router Class Initialized
INFO - 2024-05-04 16:52:11 --> Output Class Initialized
INFO - 2024-05-04 16:52:11 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:11 --> Input Class Initialized
INFO - 2024-05-04 16:52:11 --> Language Class Initialized
INFO - 2024-05-04 16:52:11 --> Loader Class Initialized
INFO - 2024-05-04 16:52:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:11 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:11 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:52:11 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:11 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-presupuestos.php
INFO - 2024-05-04 16:52:11 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:11 --> Total execution time: 0.0121
INFO - 2024-05-04 16:52:17 --> Config Class Initialized
INFO - 2024-05-04 16:52:17 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:17 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:17 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:17 --> URI Class Initialized
INFO - 2024-05-04 16:52:17 --> Router Class Initialized
INFO - 2024-05-04 16:52:17 --> Output Class Initialized
INFO - 2024-05-04 16:52:17 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:17 --> Input Class Initialized
INFO - 2024-05-04 16:52:17 --> Language Class Initialized
INFO - 2024-05-04 16:52:17 --> Loader Class Initialized
INFO - 2024-05-04 16:52:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:17 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:17 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:52:17 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:17 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:17 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:17 --> Total execution time: 0.0923
INFO - 2024-05-04 16:52:18 --> Config Class Initialized
INFO - 2024-05-04 16:52:18 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:18 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:18 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:18 --> URI Class Initialized
INFO - 2024-05-04 16:52:18 --> Router Class Initialized
INFO - 2024-05-04 16:52:18 --> Output Class Initialized
INFO - 2024-05-04 16:52:18 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:18 --> Input Class Initialized
INFO - 2024-05-04 16:52:18 --> Language Class Initialized
INFO - 2024-05-04 16:52:18 --> Loader Class Initialized
INFO - 2024-05-04 16:52:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:18 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:18 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:18 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_presupuestos.php
INFO - 2024-05-04 16:52:18 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:18 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:18 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:18 --> Total execution time: 0.0877
INFO - 2024-05-04 16:52:27 --> Config Class Initialized
INFO - 2024-05-04 16:52:27 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:27 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:27 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:27 --> URI Class Initialized
INFO - 2024-05-04 16:52:27 --> Router Class Initialized
INFO - 2024-05-04 16:52:27 --> Output Class Initialized
INFO - 2024-05-04 16:52:27 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:27 --> Input Class Initialized
INFO - 2024-05-04 16:52:27 --> Language Class Initialized
INFO - 2024-05-04 16:52:27 --> Loader Class Initialized
INFO - 2024-05-04 16:52:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:27 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:27 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:27 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:52:27 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:27 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:27 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:52:27 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:52:27 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-04 16:52:27 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:27 --> Total execution time: 0.0573
INFO - 2024-05-04 16:52:28 --> Config Class Initialized
INFO - 2024-05-04 16:52:28 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:28 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:28 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:28 --> URI Class Initialized
INFO - 2024-05-04 16:52:28 --> Router Class Initialized
INFO - 2024-05-04 16:52:28 --> Output Class Initialized
INFO - 2024-05-04 16:52:28 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:28 --> Input Class Initialized
INFO - 2024-05-04 16:52:28 --> Language Class Initialized
INFO - 2024-05-04 16:52:28 --> Loader Class Initialized
INFO - 2024-05-04 16:52:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:28 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:28 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:28 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:52:28 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:28 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:28 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:28 --> Total execution time: 0.0156
INFO - 2024-05-04 16:52:31 --> Config Class Initialized
INFO - 2024-05-04 16:52:31 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:52:31 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:52:31 --> Utf8 Class Initialized
INFO - 2024-05-04 16:52:31 --> URI Class Initialized
INFO - 2024-05-04 16:52:31 --> Router Class Initialized
INFO - 2024-05-04 16:52:31 --> Output Class Initialized
INFO - 2024-05-04 16:52:31 --> Security Class Initialized
DEBUG - 2024-05-04 16:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:52:31 --> Input Class Initialized
INFO - 2024-05-04 16:52:31 --> Language Class Initialized
INFO - 2024-05-04 16:52:31 --> Loader Class Initialized
INFO - 2024-05-04 16:52:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:52:31 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:52:31 --> Controller Class Initialized
DEBUG - 2024-05-04 16:52:31 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:52:31 --> Database Driver Class Initialized
INFO - 2024-05-04 16:52:31 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:52:31 --> Final output sent to browser
DEBUG - 2024-05-04 16:52:31 --> Total execution time: 0.0273
INFO - 2024-05-04 16:54:11 --> Config Class Initialized
INFO - 2024-05-04 16:54:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:54:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:54:11 --> Utf8 Class Initialized
INFO - 2024-05-04 16:54:11 --> URI Class Initialized
INFO - 2024-05-04 16:54:11 --> Router Class Initialized
INFO - 2024-05-04 16:54:11 --> Output Class Initialized
INFO - 2024-05-04 16:54:11 --> Security Class Initialized
DEBUG - 2024-05-04 16:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:54:11 --> Input Class Initialized
INFO - 2024-05-04 16:54:11 --> Language Class Initialized
INFO - 2024-05-04 16:54:11 --> Loader Class Initialized
INFO - 2024-05-04 16:54:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:54:11 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:54:11 --> Controller Class Initialized
DEBUG - 2024-05-04 16:54:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:54:11 --> Database Driver Class Initialized
INFO - 2024-05-04 16:54:11 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:54:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:54:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:54:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-04 16:54:11 --> Final output sent to browser
DEBUG - 2024-05-04 16:54:11 --> Total execution time: 0.0462
INFO - 2024-05-04 16:54:11 --> Config Class Initialized
INFO - 2024-05-04 16:54:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:54:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:54:11 --> Utf8 Class Initialized
INFO - 2024-05-04 16:54:11 --> URI Class Initialized
INFO - 2024-05-04 16:54:11 --> Router Class Initialized
INFO - 2024-05-04 16:54:11 --> Output Class Initialized
INFO - 2024-05-04 16:54:11 --> Security Class Initialized
DEBUG - 2024-05-04 16:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:54:11 --> Input Class Initialized
INFO - 2024-05-04 16:54:11 --> Language Class Initialized
INFO - 2024-05-04 16:54:11 --> Loader Class Initialized
INFO - 2024-05-04 16:54:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:54:11 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:54:11 --> Controller Class Initialized
DEBUG - 2024-05-04 16:54:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:54:11 --> Database Driver Class Initialized
INFO - 2024-05-04 16:54:11 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:54:11 --> Final output sent to browser
DEBUG - 2024-05-04 16:54:11 --> Total execution time: 0.0202
INFO - 2024-05-04 16:54:19 --> Config Class Initialized
INFO - 2024-05-04 16:54:19 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:54:19 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:54:19 --> Utf8 Class Initialized
INFO - 2024-05-04 16:54:19 --> URI Class Initialized
INFO - 2024-05-04 16:54:19 --> Router Class Initialized
INFO - 2024-05-04 16:54:19 --> Output Class Initialized
INFO - 2024-05-04 16:54:19 --> Security Class Initialized
DEBUG - 2024-05-04 16:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:54:19 --> Input Class Initialized
INFO - 2024-05-04 16:54:19 --> Language Class Initialized
INFO - 2024-05-04 16:54:19 --> Loader Class Initialized
INFO - 2024-05-04 16:54:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:54:19 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:54:19 --> Controller Class Initialized
DEBUG - 2024-05-04 16:54:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:54:19 --> Database Driver Class Initialized
INFO - 2024-05-04 16:54:19 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:54:19 --> Final output sent to browser
DEBUG - 2024-05-04 16:54:19 --> Total execution time: 0.1340
INFO - 2024-05-04 16:54:40 --> Config Class Initialized
INFO - 2024-05-04 16:54:40 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:54:40 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:54:40 --> Utf8 Class Initialized
INFO - 2024-05-04 16:54:40 --> URI Class Initialized
INFO - 2024-05-04 16:54:40 --> Router Class Initialized
INFO - 2024-05-04 16:54:40 --> Output Class Initialized
INFO - 2024-05-04 16:54:40 --> Security Class Initialized
DEBUG - 2024-05-04 16:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:54:40 --> Input Class Initialized
INFO - 2024-05-04 16:54:40 --> Language Class Initialized
INFO - 2024-05-04 16:54:40 --> Loader Class Initialized
INFO - 2024-05-04 16:54:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:54:40 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:54:40 --> Controller Class Initialized
DEBUG - 2024-05-04 16:54:40 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:54:40 --> Database Driver Class Initialized
INFO - 2024-05-04 16:54:40 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:54:40 --> Final output sent to browser
DEBUG - 2024-05-04 16:54:40 --> Total execution time: 0.0239
INFO - 2024-05-04 16:57:52 --> Config Class Initialized
INFO - 2024-05-04 16:57:52 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:57:52 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:57:52 --> Utf8 Class Initialized
INFO - 2024-05-04 16:57:52 --> URI Class Initialized
INFO - 2024-05-04 16:57:52 --> Router Class Initialized
INFO - 2024-05-04 16:57:52 --> Output Class Initialized
INFO - 2024-05-04 16:57:52 --> Security Class Initialized
DEBUG - 2024-05-04 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:57:52 --> Input Class Initialized
INFO - 2024-05-04 16:57:52 --> Language Class Initialized
INFO - 2024-05-04 16:57:52 --> Loader Class Initialized
INFO - 2024-05-04 16:57:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:57:52 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:57:52 --> Controller Class Initialized
DEBUG - 2024-05-04 16:57:52 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:57:52 --> Database Driver Class Initialized
INFO - 2024-05-04 16:57:52 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:57:52 --> Config Class Initialized
INFO - 2024-05-04 16:57:52 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:57:52 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:57:52 --> Utf8 Class Initialized
INFO - 2024-05-04 16:57:52 --> URI Class Initialized
DEBUG - 2024-05-04 16:57:52 --> No URI present. Default controller set.
INFO - 2024-05-04 16:57:52 --> Router Class Initialized
INFO - 2024-05-04 16:57:52 --> Output Class Initialized
INFO - 2024-05-04 16:57:52 --> Security Class Initialized
DEBUG - 2024-05-04 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:57:52 --> Input Class Initialized
INFO - 2024-05-04 16:57:52 --> Language Class Initialized
INFO - 2024-05-04 16:57:52 --> Loader Class Initialized
INFO - 2024-05-04 16:57:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:57:52 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:57:52 --> Controller Class Initialized
INFO - 2024-05-04 16:57:52 --> Config Class Initialized
INFO - 2024-05-04 16:57:52 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:57:52 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:57:52 --> Utf8 Class Initialized
INFO - 2024-05-04 16:57:52 --> URI Class Initialized
INFO - 2024-05-04 16:57:52 --> Router Class Initialized
INFO - 2024-05-04 16:57:52 --> Output Class Initialized
INFO - 2024-05-04 16:57:52 --> Security Class Initialized
DEBUG - 2024-05-04 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:57:52 --> Input Class Initialized
INFO - 2024-05-04 16:57:52 --> Language Class Initialized
INFO - 2024-05-04 16:57:52 --> Loader Class Initialized
INFO - 2024-05-04 16:57:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:57:52 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:57:52 --> Controller Class Initialized
DEBUG - 2024-05-04 16:57:52 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:57:52 --> Database Driver Class Initialized
INFO - 2024-05-04 16:57:52 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:57:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:57:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:57:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-04 16:57:52 --> Final output sent to browser
DEBUG - 2024-05-04 16:57:52 --> Total execution time: 0.0106
INFO - 2024-05-04 16:57:53 --> Config Class Initialized
INFO - 2024-05-04 16:57:53 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:57:53 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:57:53 --> Utf8 Class Initialized
INFO - 2024-05-04 16:57:53 --> URI Class Initialized
INFO - 2024-05-04 16:57:53 --> Router Class Initialized
INFO - 2024-05-04 16:57:53 --> Output Class Initialized
INFO - 2024-05-04 16:57:53 --> Security Class Initialized
DEBUG - 2024-05-04 16:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:57:53 --> Input Class Initialized
INFO - 2024-05-04 16:57:53 --> Language Class Initialized
INFO - 2024-05-04 16:57:53 --> Loader Class Initialized
INFO - 2024-05-04 16:57:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:57:53 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:57:53 --> Controller Class Initialized
INFO - 2024-05-04 16:57:55 --> Config Class Initialized
INFO - 2024-05-04 16:57:55 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:57:55 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:57:55 --> Utf8 Class Initialized
INFO - 2024-05-04 16:57:55 --> URI Class Initialized
INFO - 2024-05-04 16:57:55 --> Router Class Initialized
INFO - 2024-05-04 16:57:55 --> Output Class Initialized
INFO - 2024-05-04 16:57:55 --> Security Class Initialized
DEBUG - 2024-05-04 16:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:57:55 --> Input Class Initialized
INFO - 2024-05-04 16:57:55 --> Language Class Initialized
INFO - 2024-05-04 16:57:55 --> Loader Class Initialized
INFO - 2024-05-04 16:57:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:57:55 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:57:55 --> Controller Class Initialized
DEBUG - 2024-05-04 16:57:55 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:57:55 --> Database Driver Class Initialized
INFO - 2024-05-04 16:57:55 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:57:55 --> Helper loaded: form_helper
INFO - 2024-05-04 16:57:55 --> Form Validation Class Initialized
INFO - 2024-05-04 16:57:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-04 16:57:56 --> Config Class Initialized
INFO - 2024-05-04 16:57:56 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:57:56 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:57:56 --> Utf8 Class Initialized
INFO - 2024-05-04 16:57:56 --> URI Class Initialized
INFO - 2024-05-04 16:57:56 --> Router Class Initialized
INFO - 2024-05-04 16:57:56 --> Output Class Initialized
INFO - 2024-05-04 16:57:56 --> Security Class Initialized
DEBUG - 2024-05-04 16:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:57:56 --> Input Class Initialized
INFO - 2024-05-04 16:57:56 --> Language Class Initialized
INFO - 2024-05-04 16:57:56 --> Loader Class Initialized
INFO - 2024-05-04 16:57:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:57:56 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:57:56 --> Controller Class Initialized
INFO - 2024-05-04 16:57:56 --> Database Driver Class Initialized
DEBUG - 2024-05-04 16:57:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-04 16:57:56 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:57:56 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:57:56 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:57:56 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-04 16:57:56 --> Final output sent to browser
DEBUG - 2024-05-04 16:57:56 --> Total execution time: 0.0110
INFO - 2024-05-04 16:57:56 --> Config Class Initialized
INFO - 2024-05-04 16:57:56 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:57:56 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:57:56 --> Utf8 Class Initialized
INFO - 2024-05-04 16:57:56 --> URI Class Initialized
INFO - 2024-05-04 16:57:56 --> Router Class Initialized
INFO - 2024-05-04 16:57:56 --> Output Class Initialized
INFO - 2024-05-04 16:57:56 --> Security Class Initialized
DEBUG - 2024-05-04 16:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:57:56 --> Input Class Initialized
INFO - 2024-05-04 16:57:56 --> Language Class Initialized
INFO - 2024-05-04 16:57:56 --> Loader Class Initialized
INFO - 2024-05-04 16:57:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:57:56 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:57:56 --> Controller Class Initialized
DEBUG - 2024-05-04 16:57:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:57:56 --> Database Driver Class Initialized
INFO - 2024-05-04 16:57:56 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:57:56 --> Final output sent to browser
DEBUG - 2024-05-04 16:57:56 --> Total execution time: 0.0173
INFO - 2024-05-04 16:58:00 --> Config Class Initialized
INFO - 2024-05-04 16:58:00 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:58:00 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:58:00 --> Utf8 Class Initialized
INFO - 2024-05-04 16:58:00 --> URI Class Initialized
INFO - 2024-05-04 16:58:00 --> Router Class Initialized
INFO - 2024-05-04 16:58:00 --> Output Class Initialized
INFO - 2024-05-04 16:58:00 --> Security Class Initialized
DEBUG - 2024-05-04 16:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:58:00 --> Input Class Initialized
INFO - 2024-05-04 16:58:00 --> Language Class Initialized
INFO - 2024-05-04 16:58:00 --> Loader Class Initialized
INFO - 2024-05-04 16:58:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:58:00 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:58:00 --> Controller Class Initialized
DEBUG - 2024-05-04 16:58:00 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:58:00 --> Database Driver Class Initialized
INFO - 2024-05-04 16:58:00 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:58:00 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-04 16:58:00 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-04 16:58:00 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-04 16:58:00 --> Final output sent to browser
DEBUG - 2024-05-04 16:58:00 --> Total execution time: 0.0366
INFO - 2024-05-04 16:58:01 --> Config Class Initialized
INFO - 2024-05-04 16:58:01 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:58:01 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:58:01 --> Utf8 Class Initialized
INFO - 2024-05-04 16:58:01 --> URI Class Initialized
INFO - 2024-05-04 16:58:01 --> Router Class Initialized
INFO - 2024-05-04 16:58:01 --> Output Class Initialized
INFO - 2024-05-04 16:58:01 --> Security Class Initialized
DEBUG - 2024-05-04 16:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:58:01 --> Input Class Initialized
INFO - 2024-05-04 16:58:01 --> Language Class Initialized
INFO - 2024-05-04 16:58:01 --> Loader Class Initialized
INFO - 2024-05-04 16:58:01 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:58:01 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:58:01 --> Controller Class Initialized
DEBUG - 2024-05-04 16:58:01 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-04 16:58:01 --> Database Driver Class Initialized
INFO - 2024-05-04 16:58:01 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:58:01 --> Final output sent to browser
DEBUG - 2024-05-04 16:58:01 --> Total execution time: 0.0203
INFO - 2024-05-04 16:58:03 --> Config Class Initialized
INFO - 2024-05-04 16:58:03 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:58:03 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:58:03 --> Utf8 Class Initialized
INFO - 2024-05-04 16:58:03 --> URI Class Initialized
INFO - 2024-05-04 16:58:03 --> Router Class Initialized
INFO - 2024-05-04 16:58:03 --> Output Class Initialized
INFO - 2024-05-04 16:58:03 --> Security Class Initialized
DEBUG - 2024-05-04 16:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:58:03 --> Input Class Initialized
INFO - 2024-05-04 16:58:03 --> Language Class Initialized
INFO - 2024-05-04 16:58:03 --> Loader Class Initialized
INFO - 2024-05-04 16:58:03 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-04 16:58:03 --> Helper loaded: url_helper
DEBUG - 2024-05-04 16:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-04 16:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:58:03 --> Controller Class Initialized
DEBUG - 2024-05-04 16:58:03 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-04 16:58:03 --> Database Driver Class Initialized
INFO - 2024-05-04 16:58:03 --> Helper loaded: funciones_helper
INFO - 2024-05-04 16:58:03 --> Final output sent to browser
DEBUG - 2024-05-04 16:58:03 --> Total execution time: 0.0268
