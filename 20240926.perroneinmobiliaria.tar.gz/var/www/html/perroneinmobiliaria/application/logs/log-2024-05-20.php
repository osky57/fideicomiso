<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-20 14:00:24 --> Config Class Initialized
INFO - 2024-05-20 14:00:24 --> Hooks Class Initialized
DEBUG - 2024-05-20 14:00:24 --> UTF-8 Support Enabled
INFO - 2024-05-20 14:00:24 --> Utf8 Class Initialized
INFO - 2024-05-20 14:00:25 --> URI Class Initialized
DEBUG - 2024-05-20 14:00:25 --> No URI present. Default controller set.
INFO - 2024-05-20 14:00:25 --> Router Class Initialized
INFO - 2024-05-20 14:00:25 --> Output Class Initialized
INFO - 2024-05-20 14:00:26 --> Security Class Initialized
DEBUG - 2024-05-20 14:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 14:00:26 --> Input Class Initialized
INFO - 2024-05-20 14:00:26 --> Language Class Initialized
INFO - 2024-05-20 14:00:26 --> Loader Class Initialized
INFO - 2024-05-20 14:00:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-20 14:00:27 --> Helper loaded: url_helper
DEBUG - 2024-05-20 14:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-20 14:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 14:00:27 --> Controller Class Initialized
