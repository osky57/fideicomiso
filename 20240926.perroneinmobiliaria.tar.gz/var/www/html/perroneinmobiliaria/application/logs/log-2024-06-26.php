<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-26 17:05:27 --> Config Class Initialized
INFO - 2024-06-26 17:05:27 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:05:27 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:05:27 --> Utf8 Class Initialized
INFO - 2024-06-26 17:05:27 --> URI Class Initialized
DEBUG - 2024-06-26 17:05:27 --> No URI present. Default controller set.
INFO - 2024-06-26 17:05:27 --> Router Class Initialized
INFO - 2024-06-26 17:05:27 --> Output Class Initialized
INFO - 2024-06-26 17:05:27 --> Security Class Initialized
DEBUG - 2024-06-26 17:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:05:27 --> Input Class Initialized
INFO - 2024-06-26 17:05:27 --> Language Class Initialized
INFO - 2024-06-26 17:05:27 --> Loader Class Initialized
INFO - 2024-06-26 17:05:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:05:27 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:05:27 --> Controller Class Initialized
INFO - 2024-06-26 17:14:29 --> Config Class Initialized
INFO - 2024-06-26 17:14:29 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:14:29 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:14:29 --> Utf8 Class Initialized
INFO - 2024-06-26 17:14:29 --> URI Class Initialized
DEBUG - 2024-06-26 17:14:29 --> No URI present. Default controller set.
INFO - 2024-06-26 17:14:29 --> Router Class Initialized
INFO - 2024-06-26 17:14:29 --> Output Class Initialized
INFO - 2024-06-26 17:14:29 --> Security Class Initialized
DEBUG - 2024-06-26 17:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:14:29 --> Input Class Initialized
INFO - 2024-06-26 17:14:29 --> Language Class Initialized
INFO - 2024-06-26 17:14:29 --> Loader Class Initialized
INFO - 2024-06-26 17:14:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:14:29 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:14:29 --> Controller Class Initialized
INFO - 2024-06-26 17:14:29 --> Config Class Initialized
INFO - 2024-06-26 17:14:29 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:14:29 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:14:29 --> Utf8 Class Initialized
INFO - 2024-06-26 17:14:29 --> URI Class Initialized
INFO - 2024-06-26 17:14:29 --> Router Class Initialized
INFO - 2024-06-26 17:14:29 --> Output Class Initialized
INFO - 2024-06-26 17:14:29 --> Security Class Initialized
DEBUG - 2024-06-26 17:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:14:29 --> Input Class Initialized
INFO - 2024-06-26 17:14:29 --> Language Class Initialized
INFO - 2024-06-26 17:14:29 --> Loader Class Initialized
INFO - 2024-06-26 17:14:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:14:29 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:14:29 --> Controller Class Initialized
DEBUG - 2024-06-26 17:14:29 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-26 17:14:29 --> Database Driver Class Initialized
INFO - 2024-06-26 17:14:29 --> Helper loaded: cookie_helper
INFO - 2024-06-26 17:14:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 17:14:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 17:14:29 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-26 17:14:29 --> Final output sent to browser
DEBUG - 2024-06-26 17:14:29 --> Total execution time: 0.0348
INFO - 2024-06-26 17:14:30 --> Config Class Initialized
INFO - 2024-06-26 17:14:30 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:14:30 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:14:30 --> Utf8 Class Initialized
INFO - 2024-06-26 17:14:30 --> URI Class Initialized
INFO - 2024-06-26 17:14:30 --> Router Class Initialized
INFO - 2024-06-26 17:14:30 --> Output Class Initialized
INFO - 2024-06-26 17:14:30 --> Security Class Initialized
DEBUG - 2024-06-26 17:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:14:30 --> Input Class Initialized
INFO - 2024-06-26 17:14:30 --> Language Class Initialized
INFO - 2024-06-26 17:14:30 --> Loader Class Initialized
INFO - 2024-06-26 17:14:30 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:14:30 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:14:30 --> Controller Class Initialized
INFO - 2024-06-26 17:42:07 --> Config Class Initialized
INFO - 2024-06-26 17:42:07 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:07 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:07 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:07 --> URI Class Initialized
DEBUG - 2024-06-26 17:42:07 --> No URI present. Default controller set.
INFO - 2024-06-26 17:42:07 --> Router Class Initialized
INFO - 2024-06-26 17:42:07 --> Output Class Initialized
INFO - 2024-06-26 17:42:07 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:07 --> Input Class Initialized
INFO - 2024-06-26 17:42:07 --> Language Class Initialized
INFO - 2024-06-26 17:42:07 --> Loader Class Initialized
INFO - 2024-06-26 17:42:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:07 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:07 --> Controller Class Initialized
INFO - 2024-06-26 17:42:07 --> Config Class Initialized
INFO - 2024-06-26 17:42:07 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:07 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:07 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:07 --> URI Class Initialized
INFO - 2024-06-26 17:42:07 --> Router Class Initialized
INFO - 2024-06-26 17:42:07 --> Output Class Initialized
INFO - 2024-06-26 17:42:07 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:07 --> Input Class Initialized
INFO - 2024-06-26 17:42:07 --> Language Class Initialized
INFO - 2024-06-26 17:42:07 --> Loader Class Initialized
INFO - 2024-06-26 17:42:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:07 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:07 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:07 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-26 17:42:07 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:07 --> Helper loaded: cookie_helper
INFO - 2024-06-26 17:42:07 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 17:42:07 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 17:42:07 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-26 17:42:07 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:07 --> Total execution time: 0.0132
INFO - 2024-06-26 17:42:09 --> Config Class Initialized
INFO - 2024-06-26 17:42:09 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:09 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:09 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:09 --> URI Class Initialized
INFO - 2024-06-26 17:42:09 --> Router Class Initialized
INFO - 2024-06-26 17:42:09 --> Output Class Initialized
INFO - 2024-06-26 17:42:09 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:09 --> Input Class Initialized
INFO - 2024-06-26 17:42:09 --> Language Class Initialized
INFO - 2024-06-26 17:42:09 --> Loader Class Initialized
INFO - 2024-06-26 17:42:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:09 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:09 --> Controller Class Initialized
INFO - 2024-06-26 17:42:11 --> Config Class Initialized
INFO - 2024-06-26 17:42:11 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:11 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:11 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:11 --> URI Class Initialized
INFO - 2024-06-26 17:42:11 --> Router Class Initialized
INFO - 2024-06-26 17:42:11 --> Output Class Initialized
INFO - 2024-06-26 17:42:11 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:11 --> Input Class Initialized
INFO - 2024-06-26 17:42:11 --> Language Class Initialized
INFO - 2024-06-26 17:42:11 --> Loader Class Initialized
INFO - 2024-06-26 17:42:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:11 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:11 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-26 17:42:11 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:11 --> Helper loaded: cookie_helper
INFO - 2024-06-26 17:42:11 --> Helper loaded: form_helper
INFO - 2024-06-26 17:42:11 --> Form Validation Class Initialized
INFO - 2024-06-26 17:42:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-26 17:42:12 --> Config Class Initialized
INFO - 2024-06-26 17:42:12 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:12 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:12 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:12 --> URI Class Initialized
INFO - 2024-06-26 17:42:12 --> Router Class Initialized
INFO - 2024-06-26 17:42:12 --> Output Class Initialized
INFO - 2024-06-26 17:42:12 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:12 --> Input Class Initialized
INFO - 2024-06-26 17:42:12 --> Language Class Initialized
INFO - 2024-06-26 17:42:12 --> Loader Class Initialized
INFO - 2024-06-26 17:42:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:12 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:12 --> Controller Class Initialized
INFO - 2024-06-26 17:42:12 --> Database Driver Class Initialized
DEBUG - 2024-06-26 17:42:12 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-26 17:42:12 --> Helper loaded: cookie_helper
INFO - 2024-06-26 17:42:12 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 17:42:12 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 17:42:12 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-06-26 17:42:12 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:12 --> Total execution time: 0.0115
INFO - 2024-06-26 17:42:12 --> Config Class Initialized
INFO - 2024-06-26 17:42:12 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:12 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:12 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:12 --> URI Class Initialized
INFO - 2024-06-26 17:42:12 --> Router Class Initialized
INFO - 2024-06-26 17:42:12 --> Output Class Initialized
INFO - 2024-06-26 17:42:12 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:12 --> Input Class Initialized
INFO - 2024-06-26 17:42:12 --> Language Class Initialized
INFO - 2024-06-26 17:42:12 --> Loader Class Initialized
INFO - 2024-06-26 17:42:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:12 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:12 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:12 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 17:42:12 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:12 --> Helper loaded: funciones_helper
INFO - 2024-06-26 17:42:12 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:12 --> Total execution time: 0.0340
INFO - 2024-06-26 17:42:16 --> Config Class Initialized
INFO - 2024-06-26 17:42:16 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:16 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:16 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:16 --> URI Class Initialized
INFO - 2024-06-26 17:42:16 --> Router Class Initialized
INFO - 2024-06-26 17:42:16 --> Output Class Initialized
INFO - 2024-06-26 17:42:16 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:16 --> Input Class Initialized
INFO - 2024-06-26 17:42:16 --> Language Class Initialized
INFO - 2024-06-26 17:42:16 --> Loader Class Initialized
INFO - 2024-06-26 17:42:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:16 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:16 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 17:42:16 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:16 --> Helper loaded: funciones_helper
INFO - 2024-06-26 17:42:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 17:42:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 17:42:16 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-06-26 17:42:16 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:16 --> Total execution time: 0.0227
INFO - 2024-06-26 17:42:16 --> Config Class Initialized
INFO - 2024-06-26 17:42:16 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:16 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:16 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:16 --> URI Class Initialized
INFO - 2024-06-26 17:42:16 --> Router Class Initialized
INFO - 2024-06-26 17:42:16 --> Output Class Initialized
INFO - 2024-06-26 17:42:16 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:16 --> Input Class Initialized
INFO - 2024-06-26 17:42:16 --> Language Class Initialized
INFO - 2024-06-26 17:42:16 --> Loader Class Initialized
INFO - 2024-06-26 17:42:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:16 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:16 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 17:42:16 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:16 --> Helper loaded: funciones_helper
INFO - 2024-06-26 17:42:16 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:16 --> Total execution time: 0.0209
INFO - 2024-06-26 17:42:23 --> Config Class Initialized
INFO - 2024-06-26 17:42:23 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:23 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:23 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:23 --> URI Class Initialized
INFO - 2024-06-26 17:42:23 --> Router Class Initialized
INFO - 2024-06-26 17:42:23 --> Output Class Initialized
INFO - 2024-06-26 17:42:23 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:23 --> Input Class Initialized
INFO - 2024-06-26 17:42:23 --> Language Class Initialized
INFO - 2024-06-26 17:42:23 --> Loader Class Initialized
INFO - 2024-06-26 17:42:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:23 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:23 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-06-26 17:42:23 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:23 --> Helper loaded: funciones_helper
INFO - 2024-06-26 17:42:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 17:42:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 17:42:23 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-06-26 17:42:23 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:23 --> Total execution time: 0.0642
INFO - 2024-06-26 17:42:23 --> Config Class Initialized
INFO - 2024-06-26 17:42:23 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:23 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:23 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:23 --> URI Class Initialized
INFO - 2024-06-26 17:42:23 --> Router Class Initialized
INFO - 2024-06-26 17:42:23 --> Output Class Initialized
INFO - 2024-06-26 17:42:23 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:23 --> Input Class Initialized
INFO - 2024-06-26 17:42:23 --> Language Class Initialized
INFO - 2024-06-26 17:42:23 --> Loader Class Initialized
INFO - 2024-06-26 17:42:23 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:23 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:23 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:23 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-06-26 17:42:23 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:23 --> Helper loaded: funciones_helper
INFO - 2024-06-26 17:42:24 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:24 --> Total execution time: 0.0655
INFO - 2024-06-26 17:42:24 --> Config Class Initialized
INFO - 2024-06-26 17:42:24 --> Hooks Class Initialized
DEBUG - 2024-06-26 17:42:24 --> UTF-8 Support Enabled
INFO - 2024-06-26 17:42:24 --> Utf8 Class Initialized
INFO - 2024-06-26 17:42:24 --> URI Class Initialized
INFO - 2024-06-26 17:42:24 --> Router Class Initialized
INFO - 2024-06-26 17:42:24 --> Output Class Initialized
INFO - 2024-06-26 17:42:24 --> Security Class Initialized
DEBUG - 2024-06-26 17:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 17:42:24 --> Input Class Initialized
INFO - 2024-06-26 17:42:24 --> Language Class Initialized
INFO - 2024-06-26 17:42:24 --> Loader Class Initialized
INFO - 2024-06-26 17:42:24 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 17:42:24 --> Helper loaded: url_helper
DEBUG - 2024-06-26 17:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 17:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 17:42:24 --> Controller Class Initialized
DEBUG - 2024-06-26 17:42:24 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 17:42:24 --> Database Driver Class Initialized
INFO - 2024-06-26 17:42:24 --> Helper loaded: funciones_helper
INFO - 2024-06-26 17:42:24 --> Final output sent to browser
DEBUG - 2024-06-26 17:42:24 --> Total execution time: 0.0253
INFO - 2024-06-26 20:18:47 --> Config Class Initialized
INFO - 2024-06-26 20:18:47 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:47 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:47 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:47 --> URI Class Initialized
DEBUG - 2024-06-26 20:18:47 --> No URI present. Default controller set.
INFO - 2024-06-26 20:18:47 --> Router Class Initialized
INFO - 2024-06-26 20:18:47 --> Output Class Initialized
INFO - 2024-06-26 20:18:47 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:47 --> Input Class Initialized
INFO - 2024-06-26 20:18:47 --> Language Class Initialized
INFO - 2024-06-26 20:18:47 --> Loader Class Initialized
INFO - 2024-06-26 20:18:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:47 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:47 --> Controller Class Initialized
INFO - 2024-06-26 20:18:47 --> Config Class Initialized
INFO - 2024-06-26 20:18:47 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:47 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:47 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:47 --> URI Class Initialized
INFO - 2024-06-26 20:18:47 --> Router Class Initialized
INFO - 2024-06-26 20:18:47 --> Output Class Initialized
INFO - 2024-06-26 20:18:47 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:47 --> Input Class Initialized
INFO - 2024-06-26 20:18:47 --> Language Class Initialized
INFO - 2024-06-26 20:18:47 --> Loader Class Initialized
INFO - 2024-06-26 20:18:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:47 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:47 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:47 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-26 20:18:47 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:47 --> Helper loaded: cookie_helper
INFO - 2024-06-26 20:18:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 20:18:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 20:18:47 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-06-26 20:18:47 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:47 --> Total execution time: 0.0177
INFO - 2024-06-26 20:18:48 --> Config Class Initialized
INFO - 2024-06-26 20:18:48 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:48 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:48 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:48 --> URI Class Initialized
INFO - 2024-06-26 20:18:48 --> Router Class Initialized
INFO - 2024-06-26 20:18:48 --> Output Class Initialized
INFO - 2024-06-26 20:18:48 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:48 --> Input Class Initialized
INFO - 2024-06-26 20:18:48 --> Language Class Initialized
INFO - 2024-06-26 20:18:48 --> Loader Class Initialized
INFO - 2024-06-26 20:18:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:48 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:48 --> Controller Class Initialized
INFO - 2024-06-26 20:18:51 --> Config Class Initialized
INFO - 2024-06-26 20:18:51 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:51 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:51 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:51 --> URI Class Initialized
INFO - 2024-06-26 20:18:51 --> Router Class Initialized
INFO - 2024-06-26 20:18:51 --> Output Class Initialized
INFO - 2024-06-26 20:18:51 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:51 --> Input Class Initialized
INFO - 2024-06-26 20:18:51 --> Language Class Initialized
INFO - 2024-06-26 20:18:51 --> Loader Class Initialized
INFO - 2024-06-26 20:18:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:51 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:51 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-26 20:18:51 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:51 --> Helper loaded: cookie_helper
INFO - 2024-06-26 20:18:51 --> Helper loaded: form_helper
INFO - 2024-06-26 20:18:51 --> Form Validation Class Initialized
INFO - 2024-06-26 20:18:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-26 20:18:51 --> Config Class Initialized
INFO - 2024-06-26 20:18:51 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:51 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:51 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:51 --> URI Class Initialized
INFO - 2024-06-26 20:18:51 --> Router Class Initialized
INFO - 2024-06-26 20:18:51 --> Output Class Initialized
INFO - 2024-06-26 20:18:51 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:51 --> Input Class Initialized
INFO - 2024-06-26 20:18:51 --> Language Class Initialized
INFO - 2024-06-26 20:18:51 --> Loader Class Initialized
INFO - 2024-06-26 20:18:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:51 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:51 --> Controller Class Initialized
INFO - 2024-06-26 20:18:51 --> Database Driver Class Initialized
DEBUG - 2024-06-26 20:18:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-06-26 20:18:51 --> Helper loaded: cookie_helper
INFO - 2024-06-26 20:18:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 20:18:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 20:18:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-06-26 20:18:52 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:52 --> Total execution time: 0.0137
INFO - 2024-06-26 20:18:52 --> Config Class Initialized
INFO - 2024-06-26 20:18:52 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:52 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:52 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:52 --> URI Class Initialized
INFO - 2024-06-26 20:18:52 --> Router Class Initialized
INFO - 2024-06-26 20:18:52 --> Output Class Initialized
INFO - 2024-06-26 20:18:52 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:52 --> Input Class Initialized
INFO - 2024-06-26 20:18:52 --> Language Class Initialized
INFO - 2024-06-26 20:18:52 --> Loader Class Initialized
INFO - 2024-06-26 20:18:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:52 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:52 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:52 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 20:18:52 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:52 --> Helper loaded: funciones_helper
INFO - 2024-06-26 20:18:52 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:52 --> Total execution time: 0.0233
INFO - 2024-06-26 20:18:55 --> Config Class Initialized
INFO - 2024-06-26 20:18:55 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:55 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:55 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:55 --> URI Class Initialized
INFO - 2024-06-26 20:18:55 --> Router Class Initialized
INFO - 2024-06-26 20:18:55 --> Output Class Initialized
INFO - 2024-06-26 20:18:55 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:55 --> Input Class Initialized
INFO - 2024-06-26 20:18:55 --> Language Class Initialized
INFO - 2024-06-26 20:18:55 --> Loader Class Initialized
INFO - 2024-06-26 20:18:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:55 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:55 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:55 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 20:18:55 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:55 --> Helper loaded: funciones_helper
INFO - 2024-06-26 20:18:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 20:18:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 20:18:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-06-26 20:18:55 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:55 --> Total execution time: 0.0171
INFO - 2024-06-26 20:18:55 --> Config Class Initialized
INFO - 2024-06-26 20:18:55 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:55 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:55 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:55 --> URI Class Initialized
INFO - 2024-06-26 20:18:55 --> Router Class Initialized
INFO - 2024-06-26 20:18:55 --> Output Class Initialized
INFO - 2024-06-26 20:18:55 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:55 --> Input Class Initialized
INFO - 2024-06-26 20:18:55 --> Language Class Initialized
INFO - 2024-06-26 20:18:55 --> Loader Class Initialized
INFO - 2024-06-26 20:18:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:55 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:55 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:55 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 20:18:55 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:55 --> Helper loaded: funciones_helper
INFO - 2024-06-26 20:18:55 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:55 --> Total execution time: 0.0209
INFO - 2024-06-26 20:18:57 --> Config Class Initialized
INFO - 2024-06-26 20:18:57 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:57 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:57 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:57 --> URI Class Initialized
INFO - 2024-06-26 20:18:57 --> Router Class Initialized
INFO - 2024-06-26 20:18:57 --> Output Class Initialized
INFO - 2024-06-26 20:18:57 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:57 --> Input Class Initialized
INFO - 2024-06-26 20:18:57 --> Language Class Initialized
INFO - 2024-06-26 20:18:57 --> Loader Class Initialized
INFO - 2024-06-26 20:18:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:57 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:57 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-06-26 20:18:57 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:57 --> Helper loaded: funciones_helper
INFO - 2024-06-26 20:18:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-06-26 20:18:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-06-26 20:18:57 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-06-26 20:18:57 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:57 --> Total execution time: 0.0454
INFO - 2024-06-26 20:18:58 --> Config Class Initialized
INFO - 2024-06-26 20:18:58 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:58 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:58 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:58 --> URI Class Initialized
INFO - 2024-06-26 20:18:58 --> Router Class Initialized
INFO - 2024-06-26 20:18:58 --> Output Class Initialized
INFO - 2024-06-26 20:18:58 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:58 --> Input Class Initialized
INFO - 2024-06-26 20:18:58 --> Language Class Initialized
INFO - 2024-06-26 20:18:58 --> Loader Class Initialized
INFO - 2024-06-26 20:18:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:58 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:58 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-06-26 20:18:58 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:58 --> Helper loaded: funciones_helper
INFO - 2024-06-26 20:18:58 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:58 --> Total execution time: 0.0694
INFO - 2024-06-26 20:18:58 --> Config Class Initialized
INFO - 2024-06-26 20:18:58 --> Hooks Class Initialized
DEBUG - 2024-06-26 20:18:58 --> UTF-8 Support Enabled
INFO - 2024-06-26 20:18:58 --> Utf8 Class Initialized
INFO - 2024-06-26 20:18:58 --> URI Class Initialized
INFO - 2024-06-26 20:18:58 --> Router Class Initialized
INFO - 2024-06-26 20:18:58 --> Output Class Initialized
INFO - 2024-06-26 20:18:58 --> Security Class Initialized
DEBUG - 2024-06-26 20:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-26 20:18:58 --> Input Class Initialized
INFO - 2024-06-26 20:18:58 --> Language Class Initialized
INFO - 2024-06-26 20:18:58 --> Loader Class Initialized
INFO - 2024-06-26 20:18:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-26 20:18:58 --> Helper loaded: url_helper
DEBUG - 2024-06-26 20:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-26 20:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-26 20:18:58 --> Controller Class Initialized
DEBUG - 2024-06-26 20:18:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-06-26 20:18:58 --> Database Driver Class Initialized
INFO - 2024-06-26 20:18:58 --> Helper loaded: funciones_helper
INFO - 2024-06-26 20:18:58 --> Final output sent to browser
DEBUG - 2024-06-26 20:18:58 --> Total execution time: 0.0211
