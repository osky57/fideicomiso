<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-19 13:48:13 --> Config Class Initialized
INFO - 2024-05-19 13:48:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:48:14 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:48:14 --> Utf8 Class Initialized
INFO - 2024-05-19 13:48:14 --> URI Class Initialized
DEBUG - 2024-05-19 13:48:14 --> No URI present. Default controller set.
INFO - 2024-05-19 13:48:14 --> Router Class Initialized
INFO - 2024-05-19 13:48:14 --> Output Class Initialized
INFO - 2024-05-19 13:48:14 --> Security Class Initialized
DEBUG - 2024-05-19 13:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:48:14 --> Input Class Initialized
INFO - 2024-05-19 13:48:14 --> Language Class Initialized
INFO - 2024-05-19 13:48:14 --> Loader Class Initialized
INFO - 2024-05-19 13:48:14 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-19 13:48:14 --> Helper loaded: url_helper
DEBUG - 2024-05-19 13:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-19 13:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:48:14 --> Controller Class Initialized
INFO - 2024-05-19 14:46:59 --> Config Class Initialized
INFO - 2024-05-19 14:46:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 14:46:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 14:46:59 --> Utf8 Class Initialized
INFO - 2024-05-19 14:46:59 --> URI Class Initialized
DEBUG - 2024-05-19 14:46:59 --> No URI present. Default controller set.
INFO - 2024-05-19 14:46:59 --> Router Class Initialized
INFO - 2024-05-19 14:46:59 --> Output Class Initialized
INFO - 2024-05-19 14:46:59 --> Security Class Initialized
DEBUG - 2024-05-19 14:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 14:46:59 --> Input Class Initialized
INFO - 2024-05-19 14:46:59 --> Language Class Initialized
INFO - 2024-05-19 14:46:59 --> Loader Class Initialized
INFO - 2024-05-19 14:46:59 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-19 14:46:59 --> Helper loaded: url_helper
DEBUG - 2024-05-19 14:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-19 14:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 14:46:59 --> Controller Class Initialized
INFO - 2024-05-19 16:21:45 --> Config Class Initialized
INFO - 2024-05-19 16:21:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:21:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:21:45 --> Utf8 Class Initialized
INFO - 2024-05-19 16:21:45 --> URI Class Initialized
DEBUG - 2024-05-19 16:21:45 --> No URI present. Default controller set.
INFO - 2024-05-19 16:21:45 --> Router Class Initialized
INFO - 2024-05-19 16:21:45 --> Output Class Initialized
INFO - 2024-05-19 16:21:45 --> Security Class Initialized
DEBUG - 2024-05-19 16:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:21:45 --> Input Class Initialized
INFO - 2024-05-19 16:21:45 --> Language Class Initialized
INFO - 2024-05-19 16:21:45 --> Loader Class Initialized
INFO - 2024-05-19 16:21:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-19 16:21:45 --> Helper loaded: url_helper
DEBUG - 2024-05-19 16:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-19 16:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:21:45 --> Controller Class Initialized
