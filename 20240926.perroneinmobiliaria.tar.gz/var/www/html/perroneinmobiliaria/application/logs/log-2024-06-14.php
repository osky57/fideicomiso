<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-14 07:46:28 --> Config Class Initialized
INFO - 2024-06-14 07:46:28 --> Hooks Class Initialized
DEBUG - 2024-06-14 07:46:28 --> UTF-8 Support Enabled
INFO - 2024-06-14 07:46:28 --> Utf8 Class Initialized
INFO - 2024-06-14 07:46:28 --> URI Class Initialized
DEBUG - 2024-06-14 07:46:28 --> No URI present. Default controller set.
INFO - 2024-06-14 07:46:28 --> Router Class Initialized
INFO - 2024-06-14 07:46:28 --> Output Class Initialized
INFO - 2024-06-14 07:46:28 --> Security Class Initialized
DEBUG - 2024-06-14 07:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-14 07:46:28 --> Input Class Initialized
INFO - 2024-06-14 07:46:28 --> Language Class Initialized
INFO - 2024-06-14 07:46:28 --> Loader Class Initialized
INFO - 2024-06-14 07:46:28 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-14 07:46:28 --> Helper loaded: url_helper
DEBUG - 2024-06-14 07:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-14 07:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-14 07:46:28 --> Controller Class Initialized
INFO - 2024-06-14 14:38:26 --> Config Class Initialized
INFO - 2024-06-14 14:38:26 --> Hooks Class Initialized
DEBUG - 2024-06-14 14:38:26 --> UTF-8 Support Enabled
INFO - 2024-06-14 14:38:26 --> Utf8 Class Initialized
INFO - 2024-06-14 14:38:26 --> URI Class Initialized
DEBUG - 2024-06-14 14:38:26 --> No URI present. Default controller set.
INFO - 2024-06-14 14:38:26 --> Router Class Initialized
INFO - 2024-06-14 14:38:26 --> Output Class Initialized
INFO - 2024-06-14 14:38:26 --> Security Class Initialized
DEBUG - 2024-06-14 14:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-14 14:38:26 --> Input Class Initialized
INFO - 2024-06-14 14:38:26 --> Language Class Initialized
INFO - 2024-06-14 14:38:26 --> Loader Class Initialized
INFO - 2024-06-14 14:38:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-14 14:38:26 --> Helper loaded: url_helper
DEBUG - 2024-06-14 14:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-14 14:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-14 14:38:26 --> Controller Class Initialized
INFO - 2024-06-14 19:17:47 --> Config Class Initialized
INFO - 2024-06-14 19:17:47 --> Hooks Class Initialized
DEBUG - 2024-06-14 19:17:47 --> UTF-8 Support Enabled
INFO - 2024-06-14 19:17:47 --> Utf8 Class Initialized
INFO - 2024-06-14 19:17:47 --> URI Class Initialized
DEBUG - 2024-06-14 19:17:47 --> No URI present. Default controller set.
INFO - 2024-06-14 19:17:47 --> Router Class Initialized
INFO - 2024-06-14 19:17:47 --> Output Class Initialized
INFO - 2024-06-14 19:17:47 --> Security Class Initialized
DEBUG - 2024-06-14 19:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-14 19:17:47 --> Input Class Initialized
INFO - 2024-06-14 19:17:47 --> Language Class Initialized
INFO - 2024-06-14 19:17:47 --> Loader Class Initialized
INFO - 2024-06-14 19:17:47 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-14 19:17:47 --> Helper loaded: url_helper
DEBUG - 2024-06-14 19:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-14 19:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-14 19:17:47 --> Controller Class Initialized
INFO - 2024-06-14 23:01:38 --> Config Class Initialized
INFO - 2024-06-14 23:01:38 --> Hooks Class Initialized
DEBUG - 2024-06-14 23:01:38 --> UTF-8 Support Enabled
INFO - 2024-06-14 23:01:38 --> Utf8 Class Initialized
INFO - 2024-06-14 23:01:38 --> URI Class Initialized
DEBUG - 2024-06-14 23:01:38 --> No URI present. Default controller set.
INFO - 2024-06-14 23:01:38 --> Router Class Initialized
INFO - 2024-06-14 23:01:38 --> Output Class Initialized
INFO - 2024-06-14 23:01:38 --> Security Class Initialized
DEBUG - 2024-06-14 23:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-14 23:01:38 --> Input Class Initialized
INFO - 2024-06-14 23:01:38 --> Language Class Initialized
INFO - 2024-06-14 23:01:38 --> Loader Class Initialized
INFO - 2024-06-14 23:01:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-14 23:01:38 --> Helper loaded: url_helper
DEBUG - 2024-06-14 23:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-14 23:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-14 23:01:38 --> Controller Class Initialized
