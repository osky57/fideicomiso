<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-21 06:10:06 --> Config Class Initialized
INFO - 2024-05-21 06:10:06 --> Hooks Class Initialized
DEBUG - 2024-05-21 06:10:07 --> UTF-8 Support Enabled
INFO - 2024-05-21 06:10:07 --> Utf8 Class Initialized
INFO - 2024-05-21 06:10:07 --> URI Class Initialized
DEBUG - 2024-05-21 06:10:07 --> No URI present. Default controller set.
INFO - 2024-05-21 06:10:07 --> Router Class Initialized
INFO - 2024-05-21 06:10:08 --> Output Class Initialized
INFO - 2024-05-21 06:10:08 --> Security Class Initialized
DEBUG - 2024-05-21 06:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 06:10:08 --> Input Class Initialized
INFO - 2024-05-21 06:10:09 --> Language Class Initialized
INFO - 2024-05-21 06:10:09 --> Loader Class Initialized
INFO - 2024-05-21 06:10:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-21 06:10:10 --> Helper loaded: url_helper
DEBUG - 2024-05-21 06:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-21 06:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 06:10:10 --> Controller Class Initialized
INFO - 2024-05-21 09:00:20 --> Config Class Initialized
INFO - 2024-05-21 09:00:20 --> Hooks Class Initialized
DEBUG - 2024-05-21 09:00:20 --> UTF-8 Support Enabled
INFO - 2024-05-21 09:00:20 --> Utf8 Class Initialized
INFO - 2024-05-21 09:00:20 --> URI Class Initialized
DEBUG - 2024-05-21 09:00:20 --> No URI present. Default controller set.
INFO - 2024-05-21 09:00:20 --> Router Class Initialized
INFO - 2024-05-21 09:00:20 --> Output Class Initialized
INFO - 2024-05-21 09:00:20 --> Security Class Initialized
DEBUG - 2024-05-21 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 09:00:20 --> Input Class Initialized
INFO - 2024-05-21 09:00:20 --> Language Class Initialized
INFO - 2024-05-21 09:00:20 --> Loader Class Initialized
INFO - 2024-05-21 09:00:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-21 09:00:20 --> Helper loaded: url_helper
DEBUG - 2024-05-21 09:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-21 09:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 09:00:20 --> Controller Class Initialized
INFO - 2024-05-21 09:00:20 --> Config Class Initialized
INFO - 2024-05-21 09:00:20 --> Hooks Class Initialized
DEBUG - 2024-05-21 09:00:20 --> UTF-8 Support Enabled
INFO - 2024-05-21 09:00:20 --> Utf8 Class Initialized
INFO - 2024-05-21 09:00:20 --> URI Class Initialized
INFO - 2024-05-21 09:00:20 --> Router Class Initialized
INFO - 2024-05-21 09:00:20 --> Output Class Initialized
INFO - 2024-05-21 09:00:20 --> Security Class Initialized
DEBUG - 2024-05-21 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 09:00:20 --> Input Class Initialized
INFO - 2024-05-21 09:00:20 --> Language Class Initialized
INFO - 2024-05-21 09:00:20 --> Loader Class Initialized
INFO - 2024-05-21 09:00:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-21 09:00:20 --> Helper loaded: url_helper
DEBUG - 2024-05-21 09:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-21 09:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 09:00:20 --> Controller Class Initialized
DEBUG - 2024-05-21 09:00:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-21 09:00:21 --> Database Driver Class Initialized
INFO - 2024-05-21 09:00:21 --> Helper loaded: cookie_helper
INFO - 2024-05-21 09:00:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-21 09:00:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-21 09:00:21 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-21 09:00:21 --> Final output sent to browser
DEBUG - 2024-05-21 09:00:21 --> Total execution time: 0.1057
INFO - 2024-05-21 09:00:22 --> Config Class Initialized
INFO - 2024-05-21 09:00:22 --> Hooks Class Initialized
DEBUG - 2024-05-21 09:00:22 --> UTF-8 Support Enabled
INFO - 2024-05-21 09:00:22 --> Utf8 Class Initialized
INFO - 2024-05-21 09:00:22 --> URI Class Initialized
INFO - 2024-05-21 09:00:22 --> Router Class Initialized
INFO - 2024-05-21 09:00:22 --> Output Class Initialized
INFO - 2024-05-21 09:00:22 --> Security Class Initialized
DEBUG - 2024-05-21 09:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 09:00:22 --> Input Class Initialized
INFO - 2024-05-21 09:00:22 --> Language Class Initialized
INFO - 2024-05-21 09:00:22 --> Loader Class Initialized
INFO - 2024-05-21 09:00:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-21 09:00:22 --> Helper loaded: url_helper
DEBUG - 2024-05-21 09:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-21 09:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 09:00:22 --> Controller Class Initialized
INFO - 2024-05-21 15:15:07 --> Config Class Initialized
INFO - 2024-05-21 15:15:07 --> Hooks Class Initialized
DEBUG - 2024-05-21 15:15:07 --> UTF-8 Support Enabled
INFO - 2024-05-21 15:15:07 --> Utf8 Class Initialized
INFO - 2024-05-21 15:15:07 --> URI Class Initialized
DEBUG - 2024-05-21 15:15:07 --> No URI present. Default controller set.
INFO - 2024-05-21 15:15:07 --> Router Class Initialized
INFO - 2024-05-21 15:15:07 --> Output Class Initialized
INFO - 2024-05-21 15:15:07 --> Security Class Initialized
DEBUG - 2024-05-21 15:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 15:15:07 --> Input Class Initialized
INFO - 2024-05-21 15:15:07 --> Language Class Initialized
INFO - 2024-05-21 15:15:07 --> Loader Class Initialized
INFO - 2024-05-21 15:15:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-21 15:15:07 --> Helper loaded: url_helper
DEBUG - 2024-05-21 15:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-21 15:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 15:15:07 --> Controller Class Initialized
INFO - 2024-05-21 16:10:00 --> Config Class Initialized
INFO - 2024-05-21 16:10:00 --> Hooks Class Initialized
DEBUG - 2024-05-21 16:10:00 --> UTF-8 Support Enabled
INFO - 2024-05-21 16:10:00 --> Utf8 Class Initialized
INFO - 2024-05-21 16:10:00 --> URI Class Initialized
DEBUG - 2024-05-21 16:10:00 --> No URI present. Default controller set.
INFO - 2024-05-21 16:10:00 --> Router Class Initialized
INFO - 2024-05-21 16:10:00 --> Output Class Initialized
INFO - 2024-05-21 16:10:00 --> Security Class Initialized
DEBUG - 2024-05-21 16:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 16:10:00 --> Input Class Initialized
INFO - 2024-05-21 16:10:00 --> Language Class Initialized
INFO - 2024-05-21 16:10:00 --> Loader Class Initialized
INFO - 2024-05-21 16:10:00 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-21 16:10:00 --> Helper loaded: url_helper
DEBUG - 2024-05-21 16:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-21 16:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 16:10:00 --> Controller Class Initialized
INFO - 2024-05-21 17:35:43 --> Config Class Initialized
INFO - 2024-05-21 17:35:43 --> Hooks Class Initialized
DEBUG - 2024-05-21 17:35:43 --> UTF-8 Support Enabled
INFO - 2024-05-21 17:35:43 --> Utf8 Class Initialized
INFO - 2024-05-21 17:35:43 --> URI Class Initialized
DEBUG - 2024-05-21 17:35:43 --> No URI present. Default controller set.
INFO - 2024-05-21 17:35:43 --> Router Class Initialized
INFO - 2024-05-21 17:35:43 --> Output Class Initialized
INFO - 2024-05-21 17:35:43 --> Security Class Initialized
DEBUG - 2024-05-21 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 17:35:43 --> Input Class Initialized
INFO - 2024-05-21 17:35:43 --> Language Class Initialized
INFO - 2024-05-21 17:35:43 --> Loader Class Initialized
INFO - 2024-05-21 17:35:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-21 17:35:43 --> Helper loaded: url_helper
DEBUG - 2024-05-21 17:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-21 17:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 17:35:43 --> Controller Class Initialized
