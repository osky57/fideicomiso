<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-06 00:37:45 --> Config Class Initialized
INFO - 2024-08-06 00:37:45 --> Hooks Class Initialized
DEBUG - 2024-08-06 00:37:45 --> UTF-8 Support Enabled
INFO - 2024-08-06 00:37:45 --> Utf8 Class Initialized
INFO - 2024-08-06 00:37:45 --> URI Class Initialized
DEBUG - 2024-08-06 00:37:45 --> No URI present. Default controller set.
INFO - 2024-08-06 00:37:45 --> Router Class Initialized
INFO - 2024-08-06 00:37:45 --> Output Class Initialized
INFO - 2024-08-06 00:37:45 --> Security Class Initialized
DEBUG - 2024-08-06 00:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 00:37:45 --> Input Class Initialized
INFO - 2024-08-06 00:37:45 --> Language Class Initialized
INFO - 2024-08-06 00:37:45 --> Loader Class Initialized
INFO - 2024-08-06 00:37:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 00:37:45 --> Helper loaded: url_helper
DEBUG - 2024-08-06 00:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 00:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 00:37:45 --> Controller Class Initialized
INFO - 2024-08-06 00:37:45 --> Config Class Initialized
INFO - 2024-08-06 00:37:45 --> Hooks Class Initialized
DEBUG - 2024-08-06 00:37:45 --> UTF-8 Support Enabled
INFO - 2024-08-06 00:37:45 --> Utf8 Class Initialized
INFO - 2024-08-06 00:37:45 --> URI Class Initialized
INFO - 2024-08-06 00:37:45 --> Router Class Initialized
INFO - 2024-08-06 00:37:45 --> Output Class Initialized
INFO - 2024-08-06 00:37:45 --> Security Class Initialized
DEBUG - 2024-08-06 00:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 00:37:45 --> Input Class Initialized
INFO - 2024-08-06 00:37:45 --> Language Class Initialized
INFO - 2024-08-06 00:37:45 --> Loader Class Initialized
INFO - 2024-08-06 00:37:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 00:37:45 --> Helper loaded: url_helper
DEBUG - 2024-08-06 00:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 00:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 00:37:45 --> Controller Class Initialized
DEBUG - 2024-08-06 00:37:45 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-08-06 00:37:45 --> Database Driver Class Initialized
INFO - 2024-08-06 00:37:45 --> Helper loaded: cookie_helper
INFO - 2024-08-06 00:37:45 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-08-06 00:37:45 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-08-06 00:37:45 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-08-06 00:37:45 --> Final output sent to browser
DEBUG - 2024-08-06 00:37:45 --> Total execution time: 0.0432
INFO - 2024-08-06 01:16:29 --> Config Class Initialized
INFO - 2024-08-06 01:16:29 --> Hooks Class Initialized
DEBUG - 2024-08-06 01:16:29 --> UTF-8 Support Enabled
INFO - 2024-08-06 01:16:29 --> Utf8 Class Initialized
INFO - 2024-08-06 01:16:29 --> URI Class Initialized
DEBUG - 2024-08-06 01:16:29 --> No URI present. Default controller set.
INFO - 2024-08-06 01:16:29 --> Router Class Initialized
INFO - 2024-08-06 01:16:29 --> Output Class Initialized
INFO - 2024-08-06 01:16:29 --> Security Class Initialized
DEBUG - 2024-08-06 01:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 01:16:29 --> Input Class Initialized
INFO - 2024-08-06 01:16:29 --> Language Class Initialized
INFO - 2024-08-06 01:16:29 --> Loader Class Initialized
INFO - 2024-08-06 01:16:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 01:16:29 --> Helper loaded: url_helper
DEBUG - 2024-08-06 01:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 01:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 01:16:29 --> Controller Class Initialized
INFO - 2024-08-06 01:19:50 --> Config Class Initialized
INFO - 2024-08-06 01:19:50 --> Hooks Class Initialized
DEBUG - 2024-08-06 01:19:50 --> UTF-8 Support Enabled
INFO - 2024-08-06 01:19:50 --> Utf8 Class Initialized
INFO - 2024-08-06 01:19:50 --> URI Class Initialized
DEBUG - 2024-08-06 01:19:50 --> No URI present. Default controller set.
INFO - 2024-08-06 01:19:50 --> Router Class Initialized
INFO - 2024-08-06 01:19:50 --> Output Class Initialized
INFO - 2024-08-06 01:19:50 --> Security Class Initialized
DEBUG - 2024-08-06 01:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 01:19:50 --> Input Class Initialized
INFO - 2024-08-06 01:19:50 --> Language Class Initialized
INFO - 2024-08-06 01:19:50 --> Loader Class Initialized
INFO - 2024-08-06 01:19:50 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 01:19:50 --> Helper loaded: url_helper
DEBUG - 2024-08-06 01:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 01:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 01:19:50 --> Controller Class Initialized
INFO - 2024-08-06 01:20:04 --> Config Class Initialized
INFO - 2024-08-06 01:20:04 --> Hooks Class Initialized
DEBUG - 2024-08-06 01:20:04 --> UTF-8 Support Enabled
INFO - 2024-08-06 01:20:04 --> Utf8 Class Initialized
INFO - 2024-08-06 01:20:04 --> URI Class Initialized
DEBUG - 2024-08-06 01:20:04 --> No URI present. Default controller set.
INFO - 2024-08-06 01:20:04 --> Router Class Initialized
INFO - 2024-08-06 01:20:04 --> Output Class Initialized
INFO - 2024-08-06 01:20:04 --> Security Class Initialized
DEBUG - 2024-08-06 01:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 01:20:04 --> Input Class Initialized
INFO - 2024-08-06 01:20:04 --> Language Class Initialized
INFO - 2024-08-06 01:20:04 --> Loader Class Initialized
INFO - 2024-08-06 01:20:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 01:20:04 --> Helper loaded: url_helper
DEBUG - 2024-08-06 01:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 01:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 01:20:04 --> Controller Class Initialized
INFO - 2024-08-06 02:52:36 --> Config Class Initialized
INFO - 2024-08-06 02:52:36 --> Hooks Class Initialized
DEBUG - 2024-08-06 02:52:36 --> UTF-8 Support Enabled
INFO - 2024-08-06 02:52:36 --> Utf8 Class Initialized
INFO - 2024-08-06 02:52:36 --> URI Class Initialized
DEBUG - 2024-08-06 02:52:36 --> No URI present. Default controller set.
INFO - 2024-08-06 02:52:36 --> Router Class Initialized
INFO - 2024-08-06 02:52:36 --> Output Class Initialized
INFO - 2024-08-06 02:52:36 --> Security Class Initialized
DEBUG - 2024-08-06 02:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 02:52:36 --> Input Class Initialized
INFO - 2024-08-06 02:52:36 --> Language Class Initialized
INFO - 2024-08-06 02:52:36 --> Loader Class Initialized
INFO - 2024-08-06 02:52:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 02:52:36 --> Helper loaded: url_helper
DEBUG - 2024-08-06 02:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 02:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 02:52:36 --> Controller Class Initialized
INFO - 2024-08-06 07:01:19 --> Config Class Initialized
INFO - 2024-08-06 07:01:19 --> Hooks Class Initialized
DEBUG - 2024-08-06 07:01:19 --> UTF-8 Support Enabled
INFO - 2024-08-06 07:01:19 --> Utf8 Class Initialized
INFO - 2024-08-06 07:01:19 --> URI Class Initialized
DEBUG - 2024-08-06 07:01:19 --> No URI present. Default controller set.
INFO - 2024-08-06 07:01:19 --> Router Class Initialized
INFO - 2024-08-06 07:01:19 --> Output Class Initialized
INFO - 2024-08-06 07:01:19 --> Security Class Initialized
DEBUG - 2024-08-06 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 07:01:19 --> Input Class Initialized
INFO - 2024-08-06 07:01:19 --> Language Class Initialized
INFO - 2024-08-06 07:01:19 --> Loader Class Initialized
INFO - 2024-08-06 07:01:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 07:01:19 --> Helper loaded: url_helper
DEBUG - 2024-08-06 07:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 07:01:19 --> Controller Class Initialized
INFO - 2024-08-06 07:01:19 --> Config Class Initialized
INFO - 2024-08-06 07:01:19 --> Hooks Class Initialized
DEBUG - 2024-08-06 07:01:19 --> UTF-8 Support Enabled
INFO - 2024-08-06 07:01:19 --> Utf8 Class Initialized
INFO - 2024-08-06 07:01:19 --> URI Class Initialized
DEBUG - 2024-08-06 07:01:19 --> No URI present. Default controller set.
INFO - 2024-08-06 07:01:19 --> Router Class Initialized
INFO - 2024-08-06 07:01:19 --> Output Class Initialized
INFO - 2024-08-06 07:01:19 --> Security Class Initialized
DEBUG - 2024-08-06 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 07:01:19 --> Input Class Initialized
INFO - 2024-08-06 07:01:19 --> Language Class Initialized
INFO - 2024-08-06 07:01:19 --> Loader Class Initialized
INFO - 2024-08-06 07:01:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 07:01:19 --> Helper loaded: url_helper
DEBUG - 2024-08-06 07:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 07:01:19 --> Controller Class Initialized
INFO - 2024-08-06 07:02:02 --> Config Class Initialized
INFO - 2024-08-06 07:02:02 --> Hooks Class Initialized
DEBUG - 2024-08-06 07:02:02 --> UTF-8 Support Enabled
INFO - 2024-08-06 07:02:02 --> Utf8 Class Initialized
INFO - 2024-08-06 07:02:02 --> URI Class Initialized
DEBUG - 2024-08-06 07:02:02 --> No URI present. Default controller set.
INFO - 2024-08-06 07:02:02 --> Router Class Initialized
INFO - 2024-08-06 07:02:02 --> Output Class Initialized
INFO - 2024-08-06 07:02:02 --> Security Class Initialized
DEBUG - 2024-08-06 07:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 07:02:02 --> Input Class Initialized
INFO - 2024-08-06 07:02:02 --> Language Class Initialized
INFO - 2024-08-06 07:02:02 --> Loader Class Initialized
INFO - 2024-08-06 07:02:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 07:02:02 --> Helper loaded: url_helper
DEBUG - 2024-08-06 07:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 07:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 07:02:02 --> Controller Class Initialized
INFO - 2024-08-06 07:26:18 --> Config Class Initialized
INFO - 2024-08-06 07:26:18 --> Hooks Class Initialized
DEBUG - 2024-08-06 07:26:18 --> UTF-8 Support Enabled
INFO - 2024-08-06 07:26:18 --> Utf8 Class Initialized
INFO - 2024-08-06 07:26:18 --> URI Class Initialized
DEBUG - 2024-08-06 07:26:18 --> No URI present. Default controller set.
INFO - 2024-08-06 07:26:18 --> Router Class Initialized
INFO - 2024-08-06 07:26:18 --> Output Class Initialized
INFO - 2024-08-06 07:26:18 --> Security Class Initialized
DEBUG - 2024-08-06 07:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 07:26:18 --> Input Class Initialized
INFO - 2024-08-06 07:26:18 --> Language Class Initialized
INFO - 2024-08-06 07:26:18 --> Loader Class Initialized
INFO - 2024-08-06 07:26:18 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 07:26:18 --> Helper loaded: url_helper
DEBUG - 2024-08-06 07:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 07:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 07:26:18 --> Controller Class Initialized
INFO - 2024-08-06 20:54:04 --> Config Class Initialized
INFO - 2024-08-06 20:54:04 --> Hooks Class Initialized
DEBUG - 2024-08-06 20:54:04 --> UTF-8 Support Enabled
INFO - 2024-08-06 20:54:04 --> Utf8 Class Initialized
INFO - 2024-08-06 20:54:04 --> URI Class Initialized
DEBUG - 2024-08-06 20:54:04 --> No URI present. Default controller set.
INFO - 2024-08-06 20:54:04 --> Router Class Initialized
INFO - 2024-08-06 20:54:04 --> Output Class Initialized
INFO - 2024-08-06 20:54:04 --> Security Class Initialized
DEBUG - 2024-08-06 20:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 20:54:04 --> Input Class Initialized
INFO - 2024-08-06 20:54:04 --> Language Class Initialized
INFO - 2024-08-06 20:54:04 --> Loader Class Initialized
INFO - 2024-08-06 20:54:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-06 20:54:04 --> Helper loaded: url_helper
DEBUG - 2024-08-06 20:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-06 20:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 20:54:04 --> Controller Class Initialized
