<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-19 09:09:44 --> Config Class Initialized
INFO - 2024-08-19 09:09:44 --> Hooks Class Initialized
DEBUG - 2024-08-19 09:09:44 --> UTF-8 Support Enabled
INFO - 2024-08-19 09:09:44 --> Utf8 Class Initialized
INFO - 2024-08-19 09:09:44 --> URI Class Initialized
DEBUG - 2024-08-19 09:09:44 --> No URI present. Default controller set.
INFO - 2024-08-19 09:09:44 --> Router Class Initialized
INFO - 2024-08-19 09:09:45 --> Output Class Initialized
INFO - 2024-08-19 09:09:45 --> Security Class Initialized
DEBUG - 2024-08-19 09:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-19 09:09:45 --> Input Class Initialized
INFO - 2024-08-19 09:09:45 --> Language Class Initialized
INFO - 2024-08-19 09:09:45 --> Loader Class Initialized
INFO - 2024-08-19 09:09:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-19 09:09:45 --> Helper loaded: url_helper
DEBUG - 2024-08-19 09:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-19 09:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-19 09:09:45 --> Controller Class Initialized
