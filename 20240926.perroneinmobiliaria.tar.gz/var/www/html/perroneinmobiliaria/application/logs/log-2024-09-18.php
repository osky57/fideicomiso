<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-18 06:34:41 --> Config Class Initialized
INFO - 2024-09-18 06:34:41 --> Hooks Class Initialized
DEBUG - 2024-09-18 06:34:41 --> UTF-8 Support Enabled
INFO - 2024-09-18 06:34:41 --> Utf8 Class Initialized
INFO - 2024-09-18 06:34:41 --> URI Class Initialized
DEBUG - 2024-09-18 06:34:41 --> No URI present. Default controller set.
INFO - 2024-09-18 06:34:41 --> Router Class Initialized
INFO - 2024-09-18 06:34:41 --> Output Class Initialized
INFO - 2024-09-18 06:34:41 --> Security Class Initialized
DEBUG - 2024-09-18 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-18 06:34:41 --> Input Class Initialized
INFO - 2024-09-18 06:34:41 --> Language Class Initialized
INFO - 2024-09-18 06:34:41 --> Loader Class Initialized
INFO - 2024-09-18 06:34:41 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-18 06:34:41 --> Helper loaded: url_helper
DEBUG - 2024-09-18 06:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-18 06:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-18 06:34:41 --> Controller Class Initialized
INFO - 2024-09-18 13:37:57 --> Config Class Initialized
INFO - 2024-09-18 13:37:57 --> Hooks Class Initialized
DEBUG - 2024-09-18 13:37:57 --> UTF-8 Support Enabled
INFO - 2024-09-18 13:37:57 --> Utf8 Class Initialized
INFO - 2024-09-18 13:37:57 --> URI Class Initialized
DEBUG - 2024-09-18 13:37:57 --> No URI present. Default controller set.
INFO - 2024-09-18 13:37:57 --> Router Class Initialized
INFO - 2024-09-18 13:37:57 --> Output Class Initialized
INFO - 2024-09-18 13:37:57 --> Security Class Initialized
DEBUG - 2024-09-18 13:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-18 13:37:57 --> Input Class Initialized
INFO - 2024-09-18 13:37:57 --> Language Class Initialized
INFO - 2024-09-18 13:37:57 --> Loader Class Initialized
INFO - 2024-09-18 13:37:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-18 13:37:57 --> Helper loaded: url_helper
DEBUG - 2024-09-18 13:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-18 13:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-18 13:37:57 --> Controller Class Initialized
