<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-01 01:38:27 --> Config Class Initialized
INFO - 2024-09-01 01:38:27 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:38:27 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:38:27 --> Utf8 Class Initialized
INFO - 2024-09-01 01:38:28 --> URI Class Initialized
DEBUG - 2024-09-01 01:38:28 --> No URI present. Default controller set.
INFO - 2024-09-01 01:38:28 --> Router Class Initialized
INFO - 2024-09-01 01:38:28 --> Output Class Initialized
INFO - 2024-09-01 01:38:28 --> Security Class Initialized
DEBUG - 2024-09-01 01:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:38:28 --> Input Class Initialized
INFO - 2024-09-01 01:38:28 --> Language Class Initialized
INFO - 2024-09-01 01:38:28 --> Loader Class Initialized
INFO - 2024-09-01 01:38:29 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-01 01:38:29 --> Helper loaded: url_helper
DEBUG - 2024-09-01 01:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-01 01:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:38:29 --> Controller Class Initialized
INFO - 2024-09-01 12:31:33 --> Config Class Initialized
INFO - 2024-09-01 12:31:33 --> Hooks Class Initialized
DEBUG - 2024-09-01 12:31:34 --> UTF-8 Support Enabled
INFO - 2024-09-01 12:31:34 --> Utf8 Class Initialized
INFO - 2024-09-01 12:31:34 --> URI Class Initialized
DEBUG - 2024-09-01 12:31:34 --> No URI present. Default controller set.
INFO - 2024-09-01 12:31:34 --> Router Class Initialized
INFO - 2024-09-01 12:31:34 --> Output Class Initialized
INFO - 2024-09-01 12:31:34 --> Security Class Initialized
DEBUG - 2024-09-01 12:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 12:31:35 --> Input Class Initialized
INFO - 2024-09-01 12:31:35 --> Language Class Initialized
INFO - 2024-09-01 12:31:35 --> Loader Class Initialized
INFO - 2024-09-01 12:31:36 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-01 12:31:36 --> Helper loaded: url_helper
DEBUG - 2024-09-01 12:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-01 12:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 12:31:36 --> Controller Class Initialized
