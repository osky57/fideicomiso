<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-30 10:12:09 --> Config Class Initialized
INFO - 2024-07-30 10:12:09 --> Hooks Class Initialized
DEBUG - 2024-07-30 10:12:09 --> UTF-8 Support Enabled
INFO - 2024-07-30 10:12:09 --> Utf8 Class Initialized
INFO - 2024-07-30 10:12:09 --> URI Class Initialized
DEBUG - 2024-07-30 10:12:09 --> No URI present. Default controller set.
INFO - 2024-07-30 10:12:09 --> Router Class Initialized
INFO - 2024-07-30 10:12:09 --> Output Class Initialized
INFO - 2024-07-30 10:12:09 --> Security Class Initialized
DEBUG - 2024-07-30 10:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 10:12:09 --> Input Class Initialized
INFO - 2024-07-30 10:12:09 --> Language Class Initialized
INFO - 2024-07-30 10:12:09 --> Loader Class Initialized
INFO - 2024-07-30 10:12:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-30 10:12:09 --> Helper loaded: url_helper
DEBUG - 2024-07-30 10:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-30 10:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 10:12:09 --> Controller Class Initialized
INFO - 2024-07-30 10:12:10 --> Config Class Initialized
INFO - 2024-07-30 10:12:10 --> Hooks Class Initialized
DEBUG - 2024-07-30 10:12:10 --> UTF-8 Support Enabled
INFO - 2024-07-30 10:12:10 --> Utf8 Class Initialized
INFO - 2024-07-30 10:12:10 --> URI Class Initialized
DEBUG - 2024-07-30 10:12:10 --> No URI present. Default controller set.
INFO - 2024-07-30 10:12:10 --> Router Class Initialized
INFO - 2024-07-30 10:12:10 --> Output Class Initialized
INFO - 2024-07-30 10:12:10 --> Security Class Initialized
DEBUG - 2024-07-30 10:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 10:12:10 --> Input Class Initialized
INFO - 2024-07-30 10:12:10 --> Language Class Initialized
INFO - 2024-07-30 10:12:10 --> Loader Class Initialized
INFO - 2024-07-30 10:12:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-30 10:12:10 --> Helper loaded: url_helper
DEBUG - 2024-07-30 10:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-30 10:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 10:12:10 --> Controller Class Initialized
INFO - 2024-07-30 21:38:17 --> Config Class Initialized
INFO - 2024-07-30 21:38:17 --> Hooks Class Initialized
INFO - 2024-07-30 21:38:17 --> Config Class Initialized
INFO - 2024-07-30 21:38:17 --> Hooks Class Initialized
DEBUG - 2024-07-30 21:38:17 --> UTF-8 Support Enabled
INFO - 2024-07-30 21:38:17 --> Utf8 Class Initialized
INFO - 2024-07-30 21:38:17 --> URI Class Initialized
DEBUG - 2024-07-30 21:38:17 --> No URI present. Default controller set.
INFO - 2024-07-30 21:38:17 --> Router Class Initialized
INFO - 2024-07-30 21:38:17 --> Output Class Initialized
INFO - 2024-07-30 21:38:17 --> Security Class Initialized
DEBUG - 2024-07-30 21:38:17 --> UTF-8 Support Enabled
INFO - 2024-07-30 21:38:17 --> Utf8 Class Initialized
INFO - 2024-07-30 21:38:17 --> URI Class Initialized
INFO - 2024-07-30 21:38:17 --> Router Class Initialized
INFO - 2024-07-30 21:38:17 --> Output Class Initialized
INFO - 2024-07-30 21:38:17 --> Security Class Initialized
DEBUG - 2024-07-30 21:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 21:38:17 --> Input Class Initialized
INFO - 2024-07-30 21:38:17 --> Language Class Initialized
INFO - 2024-07-30 21:38:17 --> Loader Class Initialized
INFO - 2024-07-30 21:38:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-30 21:38:17 --> Helper loaded: url_helper
DEBUG - 2024-07-30 21:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 21:38:17 --> Input Class Initialized
INFO - 2024-07-30 21:38:17 --> Language Class Initialized
INFO - 2024-07-30 21:38:17 --> Loader Class Initialized
INFO - 2024-07-30 21:38:17 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-30 21:38:17 --> Helper loaded: url_helper
DEBUG - 2024-07-30 21:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-30 21:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 21:38:17 --> Controller Class Initialized
DEBUG - 2024-07-30 21:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-30 21:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 21:38:17 --> Controller Class Initialized
DEBUG - 2024-07-30 21:38:17 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-30 21:38:17 --> Database Driver Class Initialized
INFO - 2024-07-30 21:38:17 --> Helper loaded: cookie_helper
INFO - 2024-07-30 21:38:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-30 21:38:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-30 21:38:17 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-07-30 21:38:17 --> Final output sent to browser
DEBUG - 2024-07-30 21:38:17 --> Total execution time: 0.0761
INFO - 2024-07-30 22:49:08 --> Config Class Initialized
INFO - 2024-07-30 22:49:08 --> Hooks Class Initialized
DEBUG - 2024-07-30 22:49:08 --> UTF-8 Support Enabled
INFO - 2024-07-30 22:49:08 --> Utf8 Class Initialized
INFO - 2024-07-30 22:49:08 --> URI Class Initialized
DEBUG - 2024-07-30 22:49:08 --> No URI present. Default controller set.
INFO - 2024-07-30 22:49:08 --> Router Class Initialized
INFO - 2024-07-30 22:49:08 --> Output Class Initialized
INFO - 2024-07-30 22:49:08 --> Security Class Initialized
DEBUG - 2024-07-30 22:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 22:49:08 --> Input Class Initialized
INFO - 2024-07-30 22:49:08 --> Language Class Initialized
INFO - 2024-07-30 22:49:08 --> Loader Class Initialized
INFO - 2024-07-30 22:49:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-30 22:49:08 --> Helper loaded: url_helper
DEBUG - 2024-07-30 22:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-30 22:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 22:49:08 --> Controller Class Initialized
