<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-02 02:31:19 --> Config Class Initialized
INFO - 2024-07-02 02:31:19 --> Hooks Class Initialized
DEBUG - 2024-07-02 02:31:19 --> UTF-8 Support Enabled
INFO - 2024-07-02 02:31:19 --> Utf8 Class Initialized
INFO - 2024-07-02 02:31:19 --> URI Class Initialized
DEBUG - 2024-07-02 02:31:19 --> No URI present. Default controller set.
INFO - 2024-07-02 02:31:19 --> Router Class Initialized
INFO - 2024-07-02 02:31:19 --> Output Class Initialized
INFO - 2024-07-02 02:31:19 --> Security Class Initialized
DEBUG - 2024-07-02 02:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 02:31:19 --> Input Class Initialized
INFO - 2024-07-02 02:31:19 --> Language Class Initialized
INFO - 2024-07-02 02:31:19 --> Loader Class Initialized
INFO - 2024-07-02 02:31:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 02:31:19 --> Helper loaded: url_helper
DEBUG - 2024-07-02 02:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 02:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 02:31:19 --> Controller Class Initialized
INFO - 2024-07-02 11:17:38 --> Config Class Initialized
INFO - 2024-07-02 11:17:38 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:38 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:38 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:38 --> URI Class Initialized
INFO - 2024-07-02 11:17:38 --> Router Class Initialized
INFO - 2024-07-02 11:17:38 --> Output Class Initialized
INFO - 2024-07-02 11:17:38 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:38 --> Input Class Initialized
INFO - 2024-07-02 11:17:38 --> Language Class Initialized
INFO - 2024-07-02 11:17:38 --> Loader Class Initialized
INFO - 2024-07-02 11:17:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:38 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:38 --> Controller Class Initialized
INFO - 2024-07-02 11:17:39 --> Config Class Initialized
INFO - 2024-07-02 11:17:39 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:39 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:39 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:39 --> URI Class Initialized
INFO - 2024-07-02 11:17:39 --> Router Class Initialized
INFO - 2024-07-02 11:17:39 --> Output Class Initialized
INFO - 2024-07-02 11:17:39 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:39 --> Input Class Initialized
INFO - 2024-07-02 11:17:39 --> Language Class Initialized
INFO - 2024-07-02 11:17:39 --> Loader Class Initialized
INFO - 2024-07-02 11:17:39 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:39 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:39 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:39 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-02 11:17:39 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:39 --> Helper loaded: cookie_helper
INFO - 2024-07-02 11:17:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 11:17:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 11:17:39 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-07-02 11:17:39 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:39 --> Total execution time: 0.0396
INFO - 2024-07-02 11:17:40 --> Config Class Initialized
INFO - 2024-07-02 11:17:40 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:40 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:40 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:40 --> URI Class Initialized
INFO - 2024-07-02 11:17:40 --> Router Class Initialized
INFO - 2024-07-02 11:17:40 --> Output Class Initialized
INFO - 2024-07-02 11:17:40 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:40 --> Input Class Initialized
INFO - 2024-07-02 11:17:40 --> Language Class Initialized
INFO - 2024-07-02 11:17:40 --> Loader Class Initialized
INFO - 2024-07-02 11:17:40 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:40 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:40 --> Controller Class Initialized
INFO - 2024-07-02 11:17:43 --> Config Class Initialized
INFO - 2024-07-02 11:17:43 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:43 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:43 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:43 --> URI Class Initialized
INFO - 2024-07-02 11:17:43 --> Router Class Initialized
INFO - 2024-07-02 11:17:43 --> Output Class Initialized
INFO - 2024-07-02 11:17:43 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:43 --> Input Class Initialized
INFO - 2024-07-02 11:17:43 --> Language Class Initialized
INFO - 2024-07-02 11:17:43 --> Loader Class Initialized
INFO - 2024-07-02 11:17:43 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:43 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:43 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:43 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-02 11:17:43 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:43 --> Helper loaded: cookie_helper
INFO - 2024-07-02 11:17:43 --> Helper loaded: form_helper
INFO - 2024-07-02 11:17:43 --> Form Validation Class Initialized
INFO - 2024-07-02 11:17:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-07-02 11:17:44 --> Config Class Initialized
INFO - 2024-07-02 11:17:44 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:44 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:44 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:44 --> URI Class Initialized
INFO - 2024-07-02 11:17:44 --> Router Class Initialized
INFO - 2024-07-02 11:17:44 --> Output Class Initialized
INFO - 2024-07-02 11:17:44 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:44 --> Input Class Initialized
INFO - 2024-07-02 11:17:44 --> Language Class Initialized
INFO - 2024-07-02 11:17:44 --> Loader Class Initialized
INFO - 2024-07-02 11:17:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:44 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:44 --> Controller Class Initialized
INFO - 2024-07-02 11:17:44 --> Database Driver Class Initialized
DEBUG - 2024-07-02 11:17:44 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-02 11:17:44 --> Helper loaded: cookie_helper
INFO - 2024-07-02 11:17:44 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 11:17:44 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 11:17:44 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-07-02 11:17:44 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:44 --> Total execution time: 0.0111
INFO - 2024-07-02 11:17:44 --> Config Class Initialized
INFO - 2024-07-02 11:17:44 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:44 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:44 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:44 --> URI Class Initialized
INFO - 2024-07-02 11:17:44 --> Router Class Initialized
INFO - 2024-07-02 11:17:44 --> Output Class Initialized
INFO - 2024-07-02 11:17:44 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:44 --> Input Class Initialized
INFO - 2024-07-02 11:17:44 --> Language Class Initialized
INFO - 2024-07-02 11:17:44 --> Loader Class Initialized
INFO - 2024-07-02 11:17:44 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:44 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:44 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:44 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:17:44 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:44 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:17:44 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:44 --> Total execution time: 0.0425
INFO - 2024-07-02 11:17:52 --> Config Class Initialized
INFO - 2024-07-02 11:17:52 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:52 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:52 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:52 --> URI Class Initialized
INFO - 2024-07-02 11:17:52 --> Router Class Initialized
INFO - 2024-07-02 11:17:52 --> Output Class Initialized
INFO - 2024-07-02 11:17:52 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:52 --> Input Class Initialized
INFO - 2024-07-02 11:17:52 --> Language Class Initialized
INFO - 2024-07-02 11:17:52 --> Loader Class Initialized
INFO - 2024-07-02 11:17:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:52 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:52 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:52 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:17:52 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:52 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:17:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 11:17:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 11:17:52 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-07-02 11:17:52 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:52 --> Total execution time: 0.0154
INFO - 2024-07-02 11:17:53 --> Config Class Initialized
INFO - 2024-07-02 11:17:53 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:53 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:53 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:53 --> URI Class Initialized
INFO - 2024-07-02 11:17:53 --> Router Class Initialized
INFO - 2024-07-02 11:17:53 --> Output Class Initialized
INFO - 2024-07-02 11:17:53 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:53 --> Input Class Initialized
INFO - 2024-07-02 11:17:53 --> Language Class Initialized
INFO - 2024-07-02 11:17:53 --> Loader Class Initialized
INFO - 2024-07-02 11:17:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:53 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:53 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:53 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:17:53 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:53 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:17:53 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:53 --> Total execution time: 0.0203
INFO - 2024-07-02 11:17:55 --> Config Class Initialized
INFO - 2024-07-02 11:17:55 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:55 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:55 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:55 --> URI Class Initialized
INFO - 2024-07-02 11:17:55 --> Router Class Initialized
INFO - 2024-07-02 11:17:55 --> Output Class Initialized
INFO - 2024-07-02 11:17:55 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:55 --> Input Class Initialized
INFO - 2024-07-02 11:17:55 --> Language Class Initialized
INFO - 2024-07-02 11:17:55 --> Loader Class Initialized
INFO - 2024-07-02 11:17:55 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:55 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:55 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:55 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:17:55 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:55 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:17:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 11:17:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 11:17:55 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-07-02 11:17:55 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:55 --> Total execution time: 0.0230
INFO - 2024-07-02 11:17:56 --> Config Class Initialized
INFO - 2024-07-02 11:17:56 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:56 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:56 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:56 --> URI Class Initialized
INFO - 2024-07-02 11:17:56 --> Router Class Initialized
INFO - 2024-07-02 11:17:56 --> Output Class Initialized
INFO - 2024-07-02 11:17:56 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:56 --> Input Class Initialized
INFO - 2024-07-02 11:17:56 --> Language Class Initialized
INFO - 2024-07-02 11:17:56 --> Loader Class Initialized
INFO - 2024-07-02 11:17:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:56 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:56 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:17:56 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:56 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:17:56 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:56 --> Total execution time: 0.0696
INFO - 2024-07-02 11:17:56 --> Config Class Initialized
INFO - 2024-07-02 11:17:56 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:56 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:56 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:56 --> URI Class Initialized
INFO - 2024-07-02 11:17:56 --> Router Class Initialized
INFO - 2024-07-02 11:17:56 --> Output Class Initialized
INFO - 2024-07-02 11:17:56 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:56 --> Input Class Initialized
INFO - 2024-07-02 11:17:56 --> Language Class Initialized
INFO - 2024-07-02 11:17:56 --> Loader Class Initialized
INFO - 2024-07-02 11:17:56 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:56 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:56 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:56 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:17:56 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:56 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:17:56 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:56 --> Total execution time: 0.0151
INFO - 2024-07-02 11:17:58 --> Config Class Initialized
INFO - 2024-07-02 11:17:58 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:17:58 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:17:58 --> Utf8 Class Initialized
INFO - 2024-07-02 11:17:58 --> URI Class Initialized
INFO - 2024-07-02 11:17:58 --> Router Class Initialized
INFO - 2024-07-02 11:17:58 --> Output Class Initialized
INFO - 2024-07-02 11:17:58 --> Security Class Initialized
DEBUG - 2024-07-02 11:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:17:58 --> Input Class Initialized
INFO - 2024-07-02 11:17:58 --> Language Class Initialized
INFO - 2024-07-02 11:17:58 --> Loader Class Initialized
INFO - 2024-07-02 11:17:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:17:58 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:17:58 --> Controller Class Initialized
DEBUG - 2024-07-02 11:17:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:17:58 --> Database Driver Class Initialized
INFO - 2024-07-02 11:17:58 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:17:58 --> Final output sent to browser
DEBUG - 2024-07-02 11:17:58 --> Total execution time: 0.0694
INFO - 2024-07-02 11:18:13 --> Config Class Initialized
INFO - 2024-07-02 11:18:13 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:18:13 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:18:13 --> Utf8 Class Initialized
INFO - 2024-07-02 11:18:13 --> URI Class Initialized
INFO - 2024-07-02 11:18:13 --> Router Class Initialized
INFO - 2024-07-02 11:18:13 --> Output Class Initialized
INFO - 2024-07-02 11:18:13 --> Security Class Initialized
DEBUG - 2024-07-02 11:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:18:13 --> Input Class Initialized
INFO - 2024-07-02 11:18:13 --> Language Class Initialized
INFO - 2024-07-02 11:18:13 --> Loader Class Initialized
INFO - 2024-07-02 11:18:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:18:13 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:18:13 --> Controller Class Initialized
DEBUG - 2024-07-02 11:18:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:18:13 --> Database Driver Class Initialized
INFO - 2024-07-02 11:18:13 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:18:13 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-entidad.php
INFO - 2024-07-02 11:18:13 --> Final output sent to browser
DEBUG - 2024-07-02 11:18:13 --> Total execution time: 0.0336
INFO - 2024-07-02 11:18:53 --> Config Class Initialized
INFO - 2024-07-02 11:18:53 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:18:53 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:18:53 --> Utf8 Class Initialized
INFO - 2024-07-02 11:18:53 --> URI Class Initialized
INFO - 2024-07-02 11:18:53 --> Router Class Initialized
INFO - 2024-07-02 11:18:53 --> Output Class Initialized
INFO - 2024-07-02 11:18:53 --> Security Class Initialized
DEBUG - 2024-07-02 11:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:18:53 --> Input Class Initialized
INFO - 2024-07-02 11:18:53 --> Language Class Initialized
INFO - 2024-07-02 11:18:53 --> Loader Class Initialized
INFO - 2024-07-02 11:18:53 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:18:53 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:18:53 --> Controller Class Initialized
DEBUG - 2024-07-02 11:18:53 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:18:53 --> Database Driver Class Initialized
INFO - 2024-07-02 11:18:53 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:18:53 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 11:18:53 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 11:18:53 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/proyectos.php
INFO - 2024-07-02 11:18:53 --> Final output sent to browser
DEBUG - 2024-07-02 11:18:53 --> Total execution time: 0.0202
INFO - 2024-07-02 11:18:54 --> Config Class Initialized
INFO - 2024-07-02 11:18:54 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:18:54 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:18:54 --> Utf8 Class Initialized
INFO - 2024-07-02 11:18:54 --> URI Class Initialized
INFO - 2024-07-02 11:18:54 --> Router Class Initialized
INFO - 2024-07-02 11:18:54 --> Output Class Initialized
INFO - 2024-07-02 11:18:54 --> Security Class Initialized
DEBUG - 2024-07-02 11:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:18:54 --> Input Class Initialized
INFO - 2024-07-02 11:18:54 --> Language Class Initialized
INFO - 2024-07-02 11:18:54 --> Loader Class Initialized
INFO - 2024-07-02 11:18:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:18:54 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:18:54 --> Controller Class Initialized
DEBUG - 2024-07-02 11:18:54 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:18:54 --> Database Driver Class Initialized
INFO - 2024-07-02 11:18:54 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:18:54 --> Final output sent to browser
DEBUG - 2024-07-02 11:18:54 --> Total execution time: 0.0250
INFO - 2024-07-02 11:18:54 --> Config Class Initialized
INFO - 2024-07-02 11:18:54 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:18:54 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:18:54 --> Utf8 Class Initialized
INFO - 2024-07-02 11:18:54 --> URI Class Initialized
INFO - 2024-07-02 11:18:54 --> Router Class Initialized
INFO - 2024-07-02 11:18:54 --> Output Class Initialized
INFO - 2024-07-02 11:18:54 --> Security Class Initialized
DEBUG - 2024-07-02 11:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:18:54 --> Input Class Initialized
INFO - 2024-07-02 11:18:54 --> Language Class Initialized
INFO - 2024-07-02 11:18:54 --> Loader Class Initialized
INFO - 2024-07-02 11:18:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:18:54 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:18:54 --> Controller Class Initialized
DEBUG - 2024-07-02 11:18:54 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:18:54 --> Database Driver Class Initialized
INFO - 2024-07-02 11:18:54 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:18:54 --> Final output sent to browser
DEBUG - 2024-07-02 11:18:54 --> Total execution time: 0.0251
INFO - 2024-07-02 11:18:58 --> Config Class Initialized
INFO - 2024-07-02 11:18:58 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:18:58 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:18:58 --> Utf8 Class Initialized
INFO - 2024-07-02 11:18:58 --> URI Class Initialized
INFO - 2024-07-02 11:18:58 --> Router Class Initialized
INFO - 2024-07-02 11:18:58 --> Output Class Initialized
INFO - 2024-07-02 11:18:58 --> Security Class Initialized
DEBUG - 2024-07-02 11:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:18:58 --> Input Class Initialized
INFO - 2024-07-02 11:18:58 --> Language Class Initialized
INFO - 2024-07-02 11:18:58 --> Loader Class Initialized
INFO - 2024-07-02 11:18:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:18:58 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:18:58 --> Controller Class Initialized
DEBUG - 2024-07-02 11:18:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:18:58 --> Database Driver Class Initialized
INFO - 2024-07-02 11:18:58 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:18:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 11:18:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 11:18:58 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/entidades.php
INFO - 2024-07-02 11:18:58 --> Final output sent to browser
DEBUG - 2024-07-02 11:18:58 --> Total execution time: 0.0150
INFO - 2024-07-02 11:18:58 --> Config Class Initialized
INFO - 2024-07-02 11:18:58 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:18:58 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:18:58 --> Utf8 Class Initialized
INFO - 2024-07-02 11:18:58 --> URI Class Initialized
INFO - 2024-07-02 11:18:58 --> Router Class Initialized
INFO - 2024-07-02 11:18:58 --> Output Class Initialized
INFO - 2024-07-02 11:18:58 --> Security Class Initialized
DEBUG - 2024-07-02 11:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:18:58 --> Input Class Initialized
INFO - 2024-07-02 11:18:58 --> Language Class Initialized
INFO - 2024-07-02 11:18:58 --> Loader Class Initialized
INFO - 2024-07-02 11:18:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:18:58 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:18:58 --> Controller Class Initialized
DEBUG - 2024-07-02 11:18:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:18:58 --> Database Driver Class Initialized
INFO - 2024-07-02 11:18:58 --> Config Class Initialized
INFO - 2024-07-02 11:18:58 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:18:58 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:18:58 --> Utf8 Class Initialized
INFO - 2024-07-02 11:18:58 --> URI Class Initialized
INFO - 2024-07-02 11:18:58 --> Router Class Initialized
INFO - 2024-07-02 11:18:58 --> Output Class Initialized
INFO - 2024-07-02 11:18:58 --> Security Class Initialized
DEBUG - 2024-07-02 11:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:18:58 --> Input Class Initialized
INFO - 2024-07-02 11:18:58 --> Language Class Initialized
INFO - 2024-07-02 11:18:58 --> Loader Class Initialized
INFO - 2024-07-02 11:18:58 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:18:58 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:18:58 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:18:58 --> Final output sent to browser
DEBUG - 2024-07-02 11:18:58 --> Total execution time: 0.0269
INFO - 2024-07-02 11:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:18:58 --> Controller Class Initialized
DEBUG - 2024-07-02 11:18:58 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:18:58 --> Database Driver Class Initialized
INFO - 2024-07-02 11:18:58 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:18:58 --> Final output sent to browser
DEBUG - 2024-07-02 11:18:58 --> Total execution time: 0.0865
INFO - 2024-07-02 11:19:06 --> Config Class Initialized
INFO - 2024-07-02 11:19:06 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:19:06 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:19:06 --> Utf8 Class Initialized
INFO - 2024-07-02 11:19:06 --> URI Class Initialized
INFO - 2024-07-02 11:19:06 --> Router Class Initialized
INFO - 2024-07-02 11:19:06 --> Output Class Initialized
INFO - 2024-07-02 11:19:06 --> Security Class Initialized
DEBUG - 2024-07-02 11:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:19:06 --> Input Class Initialized
INFO - 2024-07-02 11:19:06 --> Language Class Initialized
INFO - 2024-07-02 11:19:06 --> Loader Class Initialized
INFO - 2024-07-02 11:19:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:19:06 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:19:06 --> Controller Class Initialized
DEBUG - 2024-07-02 11:19:06 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:19:06 --> Database Driver Class Initialized
INFO - 2024-07-02 11:19:06 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:19:06 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-entidad.php
INFO - 2024-07-02 11:19:06 --> Final output sent to browser
DEBUG - 2024-07-02 11:19:06 --> Total execution time: 0.0354
INFO - 2024-07-02 11:19:57 --> Config Class Initialized
INFO - 2024-07-02 11:19:57 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:19:57 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:19:57 --> Utf8 Class Initialized
INFO - 2024-07-02 11:19:57 --> URI Class Initialized
INFO - 2024-07-02 11:19:57 --> Router Class Initialized
INFO - 2024-07-02 11:19:57 --> Output Class Initialized
INFO - 2024-07-02 11:19:57 --> Security Class Initialized
DEBUG - 2024-07-02 11:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:19:57 --> Input Class Initialized
INFO - 2024-07-02 11:19:57 --> Language Class Initialized
INFO - 2024-07-02 11:19:57 --> Loader Class Initialized
INFO - 2024-07-02 11:19:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:19:57 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:19:57 --> Controller Class Initialized
DEBUG - 2024-07-02 11:19:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:19:57 --> Database Driver Class Initialized
INFO - 2024-07-02 11:19:57 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:19:57 --> Final output sent to browser
DEBUG - 2024-07-02 11:19:57 --> Total execution time: 0.0369
INFO - 2024-07-02 11:19:57 --> Config Class Initialized
INFO - 2024-07-02 11:19:57 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:19:57 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:19:57 --> Utf8 Class Initialized
INFO - 2024-07-02 11:19:57 --> URI Class Initialized
INFO - 2024-07-02 11:19:57 --> Router Class Initialized
INFO - 2024-07-02 11:19:57 --> Output Class Initialized
INFO - 2024-07-02 11:19:57 --> Security Class Initialized
DEBUG - 2024-07-02 11:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:19:57 --> Input Class Initialized
INFO - 2024-07-02 11:19:57 --> Language Class Initialized
INFO - 2024-07-02 11:19:57 --> Loader Class Initialized
INFO - 2024-07-02 11:19:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:19:57 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:19:57 --> Controller Class Initialized
DEBUG - 2024-07-02 11:19:57 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:19:57 --> Database Driver Class Initialized
INFO - 2024-07-02 11:19:57 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:19:57 --> Final output sent to browser
DEBUG - 2024-07-02 11:19:57 --> Total execution time: 0.0797
INFO - 2024-07-02 11:20:04 --> Config Class Initialized
INFO - 2024-07-02 11:20:04 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:20:04 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:20:04 --> Utf8 Class Initialized
INFO - 2024-07-02 11:20:04 --> URI Class Initialized
INFO - 2024-07-02 11:20:04 --> Router Class Initialized
INFO - 2024-07-02 11:20:04 --> Output Class Initialized
INFO - 2024-07-02 11:20:04 --> Security Class Initialized
DEBUG - 2024-07-02 11:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:20:04 --> Input Class Initialized
INFO - 2024-07-02 11:20:04 --> Language Class Initialized
INFO - 2024-07-02 11:20:04 --> Loader Class Initialized
INFO - 2024-07-02 11:20:04 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:20:04 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:20:04 --> Controller Class Initialized
DEBUG - 2024-07-02 11:20:04 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_entidades.php
INFO - 2024-07-02 11:20:04 --> Database Driver Class Initialized
INFO - 2024-07-02 11:20:04 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:20:04 --> Final output sent to browser
DEBUG - 2024-07-02 11:20:04 --> Total execution time: 0.0752
INFO - 2024-07-02 11:24:51 --> Config Class Initialized
INFO - 2024-07-02 11:24:51 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:24:51 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:24:51 --> Utf8 Class Initialized
INFO - 2024-07-02 11:24:51 --> URI Class Initialized
INFO - 2024-07-02 11:24:51 --> Router Class Initialized
INFO - 2024-07-02 11:24:51 --> Output Class Initialized
INFO - 2024-07-02 11:24:51 --> Security Class Initialized
DEBUG - 2024-07-02 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:24:51 --> Input Class Initialized
INFO - 2024-07-02 11:24:51 --> Language Class Initialized
INFO - 2024-07-02 11:24:51 --> Loader Class Initialized
INFO - 2024-07-02 11:24:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:24:51 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:24:51 --> Controller Class Initialized
DEBUG - 2024-07-02 11:24:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-02 11:24:51 --> Database Driver Class Initialized
INFO - 2024-07-02 11:24:51 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:24:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 11:24:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 11:24:51 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/cuentascorrientes.php
INFO - 2024-07-02 11:24:51 --> Final output sent to browser
DEBUG - 2024-07-02 11:24:51 --> Total execution time: 0.0615
INFO - 2024-07-02 11:24:51 --> Config Class Initialized
INFO - 2024-07-02 11:24:51 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:24:51 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:24:51 --> Utf8 Class Initialized
INFO - 2024-07-02 11:24:51 --> URI Class Initialized
INFO - 2024-07-02 11:24:51 --> Router Class Initialized
INFO - 2024-07-02 11:24:51 --> Output Class Initialized
INFO - 2024-07-02 11:24:51 --> Security Class Initialized
DEBUG - 2024-07-02 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:24:51 --> Input Class Initialized
INFO - 2024-07-02 11:24:51 --> Language Class Initialized
INFO - 2024-07-02 11:24:51 --> Loader Class Initialized
INFO - 2024-07-02 11:24:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:24:51 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:24:51 --> Controller Class Initialized
DEBUG - 2024-07-02 11:24:51 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-02 11:24:51 --> Database Driver Class Initialized
INFO - 2024-07-02 11:24:51 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:24:52 --> Final output sent to browser
DEBUG - 2024-07-02 11:24:52 --> Total execution time: 0.0730
INFO - 2024-07-02 11:24:52 --> Config Class Initialized
INFO - 2024-07-02 11:24:52 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:24:52 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:24:52 --> Utf8 Class Initialized
INFO - 2024-07-02 11:24:52 --> URI Class Initialized
INFO - 2024-07-02 11:24:52 --> Router Class Initialized
INFO - 2024-07-02 11:24:52 --> Output Class Initialized
INFO - 2024-07-02 11:24:52 --> Security Class Initialized
DEBUG - 2024-07-02 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:24:52 --> Input Class Initialized
INFO - 2024-07-02 11:24:52 --> Language Class Initialized
INFO - 2024-07-02 11:24:52 --> Loader Class Initialized
INFO - 2024-07-02 11:24:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:24:52 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:24:52 --> Controller Class Initialized
DEBUG - 2024-07-02 11:24:52 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-07-02 11:24:52 --> Database Driver Class Initialized
INFO - 2024-07-02 11:24:52 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:24:52 --> Final output sent to browser
DEBUG - 2024-07-02 11:24:52 --> Total execution time: 0.0235
INFO - 2024-07-02 11:25:48 --> Config Class Initialized
INFO - 2024-07-02 11:25:48 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:25:48 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:25:48 --> Utf8 Class Initialized
INFO - 2024-07-02 11:25:48 --> URI Class Initialized
INFO - 2024-07-02 11:25:48 --> Router Class Initialized
INFO - 2024-07-02 11:25:48 --> Output Class Initialized
INFO - 2024-07-02 11:25:48 --> Security Class Initialized
DEBUG - 2024-07-02 11:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:25:48 --> Input Class Initialized
INFO - 2024-07-02 11:25:48 --> Language Class Initialized
INFO - 2024-07-02 11:25:48 --> Loader Class Initialized
INFO - 2024-07-02 11:25:48 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:25:48 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:25:48 --> Controller Class Initialized
DEBUG - 2024-07-02 11:25:48 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-02 11:25:48 --> Database Driver Class Initialized
INFO - 2024-07-02 11:25:48 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:25:48 --> Final output sent to browser
DEBUG - 2024-07-02 11:25:48 --> Total execution time: 0.0394
INFO - 2024-07-02 11:25:49 --> Config Class Initialized
INFO - 2024-07-02 11:25:49 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:25:49 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:25:49 --> Utf8 Class Initialized
INFO - 2024-07-02 11:25:49 --> URI Class Initialized
INFO - 2024-07-02 11:25:49 --> Router Class Initialized
INFO - 2024-07-02 11:25:49 --> Output Class Initialized
INFO - 2024-07-02 11:25:49 --> Security Class Initialized
DEBUG - 2024-07-02 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:25:49 --> Input Class Initialized
INFO - 2024-07-02 11:25:49 --> Language Class Initialized
INFO - 2024-07-02 11:25:49 --> Loader Class Initialized
INFO - 2024-07-02 11:25:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:25:49 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:25:49 --> Controller Class Initialized
DEBUG - 2024-07-02 11:25:49 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-02 11:25:49 --> Database Driver Class Initialized
INFO - 2024-07-02 11:25:49 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:25:49 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/frm-cuentascorrientes.php
INFO - 2024-07-02 11:25:49 --> Final output sent to browser
DEBUG - 2024-07-02 11:25:49 --> Total execution time: 0.0694
INFO - 2024-07-02 11:25:50 --> Config Class Initialized
INFO - 2024-07-02 11:25:50 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:25:50 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:25:50 --> Utf8 Class Initialized
INFO - 2024-07-02 11:25:50 --> URI Class Initialized
INFO - 2024-07-02 11:25:50 --> Router Class Initialized
INFO - 2024-07-02 11:25:50 --> Output Class Initialized
INFO - 2024-07-02 11:25:50 --> Security Class Initialized
DEBUG - 2024-07-02 11:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:25:50 --> Input Class Initialized
INFO - 2024-07-02 11:25:50 --> Language Class Initialized
INFO - 2024-07-02 11:25:50 --> Loader Class Initialized
INFO - 2024-07-02 11:25:50 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:25:50 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:25:50 --> Controller Class Initialized
DEBUG - 2024-07-02 11:25:50 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-02 11:25:50 --> Database Driver Class Initialized
INFO - 2024-07-02 11:25:50 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:25:50 --> Final output sent to browser
DEBUG - 2024-07-02 11:25:50 --> Total execution time: 0.0263
INFO - 2024-07-02 11:25:50 --> Config Class Initialized
INFO - 2024-07-02 11:25:50 --> Hooks Class Initialized
DEBUG - 2024-07-02 11:25:50 --> UTF-8 Support Enabled
INFO - 2024-07-02 11:25:50 --> Utf8 Class Initialized
INFO - 2024-07-02 11:25:50 --> URI Class Initialized
INFO - 2024-07-02 11:25:50 --> Router Class Initialized
INFO - 2024-07-02 11:25:50 --> Output Class Initialized
INFO - 2024-07-02 11:25:50 --> Security Class Initialized
DEBUG - 2024-07-02 11:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 11:25:50 --> Input Class Initialized
INFO - 2024-07-02 11:25:50 --> Language Class Initialized
INFO - 2024-07-02 11:25:50 --> Loader Class Initialized
INFO - 2024-07-02 11:25:50 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 11:25:50 --> Helper loaded: url_helper
DEBUG - 2024-07-02 11:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 11:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 11:25:50 --> Controller Class Initialized
DEBUG - 2024-07-02 11:25:50 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_cuentascorrientes.php
INFO - 2024-07-02 11:25:50 --> Database Driver Class Initialized
INFO - 2024-07-02 11:25:50 --> Helper loaded: funciones_helper
INFO - 2024-07-02 11:25:50 --> Final output sent to browser
DEBUG - 2024-07-02 11:25:50 --> Total execution time: 0.0288
INFO - 2024-07-02 20:17:26 --> Config Class Initialized
INFO - 2024-07-02 20:17:26 --> Hooks Class Initialized
DEBUG - 2024-07-02 20:17:26 --> UTF-8 Support Enabled
INFO - 2024-07-02 20:17:26 --> Utf8 Class Initialized
INFO - 2024-07-02 20:17:26 --> URI Class Initialized
INFO - 2024-07-02 20:17:26 --> Router Class Initialized
INFO - 2024-07-02 20:17:26 --> Output Class Initialized
INFO - 2024-07-02 20:17:26 --> Security Class Initialized
DEBUG - 2024-07-02 20:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 20:17:26 --> Input Class Initialized
INFO - 2024-07-02 20:17:26 --> Language Class Initialized
INFO - 2024-07-02 20:17:26 --> Loader Class Initialized
INFO - 2024-07-02 20:17:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 20:17:26 --> Helper loaded: url_helper
DEBUG - 2024-07-02 20:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 20:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 20:17:26 --> Controller Class Initialized
INFO - 2024-07-02 20:17:26 --> Config Class Initialized
INFO - 2024-07-02 20:17:26 --> Hooks Class Initialized
DEBUG - 2024-07-02 20:17:26 --> UTF-8 Support Enabled
INFO - 2024-07-02 20:17:26 --> Utf8 Class Initialized
INFO - 2024-07-02 20:17:26 --> URI Class Initialized
INFO - 2024-07-02 20:17:26 --> Router Class Initialized
INFO - 2024-07-02 20:17:26 --> Output Class Initialized
INFO - 2024-07-02 20:17:26 --> Security Class Initialized
DEBUG - 2024-07-02 20:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 20:17:26 --> Input Class Initialized
INFO - 2024-07-02 20:17:26 --> Language Class Initialized
INFO - 2024-07-02 20:17:26 --> Loader Class Initialized
INFO - 2024-07-02 20:17:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 20:17:26 --> Helper loaded: url_helper
DEBUG - 2024-07-02 20:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 20:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 20:17:26 --> Controller Class Initialized
DEBUG - 2024-07-02 20:17:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-07-02 20:17:26 --> Database Driver Class Initialized
INFO - 2024-07-02 20:17:26 --> Helper loaded: cookie_helper
INFO - 2024-07-02 20:17:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-07-02 20:17:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-07-02 20:17:26 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-07-02 20:17:26 --> Final output sent to browser
DEBUG - 2024-07-02 20:17:26 --> Total execution time: 0.0177
INFO - 2024-07-02 20:17:27 --> Config Class Initialized
INFO - 2024-07-02 20:17:27 --> Hooks Class Initialized
DEBUG - 2024-07-02 20:17:27 --> UTF-8 Support Enabled
INFO - 2024-07-02 20:17:27 --> Utf8 Class Initialized
INFO - 2024-07-02 20:17:27 --> URI Class Initialized
INFO - 2024-07-02 20:17:27 --> Router Class Initialized
INFO - 2024-07-02 20:17:27 --> Output Class Initialized
INFO - 2024-07-02 20:17:27 --> Security Class Initialized
DEBUG - 2024-07-02 20:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 20:17:27 --> Input Class Initialized
INFO - 2024-07-02 20:17:27 --> Language Class Initialized
INFO - 2024-07-02 20:17:27 --> Loader Class Initialized
INFO - 2024-07-02 20:17:27 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 20:17:27 --> Helper loaded: url_helper
DEBUG - 2024-07-02 20:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 20:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 20:17:27 --> Controller Class Initialized
INFO - 2024-07-02 20:35:34 --> Config Class Initialized
INFO - 2024-07-02 20:35:34 --> Hooks Class Initialized
DEBUG - 2024-07-02 20:35:34 --> UTF-8 Support Enabled
INFO - 2024-07-02 20:35:34 --> Utf8 Class Initialized
INFO - 2024-07-02 20:35:34 --> URI Class Initialized
DEBUG - 2024-07-02 20:35:34 --> No URI present. Default controller set.
INFO - 2024-07-02 20:35:34 --> Router Class Initialized
INFO - 2024-07-02 20:35:34 --> Output Class Initialized
INFO - 2024-07-02 20:35:34 --> Security Class Initialized
DEBUG - 2024-07-02 20:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 20:35:34 --> Input Class Initialized
INFO - 2024-07-02 20:35:34 --> Language Class Initialized
INFO - 2024-07-02 20:35:34 --> Loader Class Initialized
INFO - 2024-07-02 20:35:34 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-02 20:35:34 --> Helper loaded: url_helper
DEBUG - 2024-07-02 20:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-02 20:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 20:35:34 --> Controller Class Initialized
