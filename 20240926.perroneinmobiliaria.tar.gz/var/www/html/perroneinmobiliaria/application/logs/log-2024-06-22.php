<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-22 16:19:02 --> Config Class Initialized
INFO - 2024-06-22 16:19:02 --> Hooks Class Initialized
DEBUG - 2024-06-22 16:19:02 --> UTF-8 Support Enabled
INFO - 2024-06-22 16:19:02 --> Utf8 Class Initialized
INFO - 2024-06-22 16:19:02 --> URI Class Initialized
DEBUG - 2024-06-22 16:19:02 --> No URI present. Default controller set.
INFO - 2024-06-22 16:19:02 --> Router Class Initialized
INFO - 2024-06-22 16:19:02 --> Output Class Initialized
INFO - 2024-06-22 16:19:02 --> Security Class Initialized
DEBUG - 2024-06-22 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 16:19:02 --> Input Class Initialized
INFO - 2024-06-22 16:19:02 --> Language Class Initialized
INFO - 2024-06-22 16:19:02 --> Loader Class Initialized
INFO - 2024-06-22 16:19:02 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-22 16:19:02 --> Helper loaded: url_helper
DEBUG - 2024-06-22 16:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-22 16:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 16:19:02 --> Controller Class Initialized
INFO - 2024-06-22 21:42:57 --> Config Class Initialized
INFO - 2024-06-22 21:42:57 --> Hooks Class Initialized
DEBUG - 2024-06-22 21:42:57 --> UTF-8 Support Enabled
INFO - 2024-06-22 21:42:57 --> Utf8 Class Initialized
INFO - 2024-06-22 21:42:57 --> URI Class Initialized
DEBUG - 2024-06-22 21:42:57 --> No URI present. Default controller set.
INFO - 2024-06-22 21:42:57 --> Router Class Initialized
INFO - 2024-06-22 21:42:57 --> Output Class Initialized
INFO - 2024-06-22 21:42:57 --> Security Class Initialized
DEBUG - 2024-06-22 21:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 21:42:57 --> Input Class Initialized
INFO - 2024-06-22 21:42:57 --> Language Class Initialized
INFO - 2024-06-22 21:42:57 --> Loader Class Initialized
INFO - 2024-06-22 21:42:57 --> Helper loaded: is_loged_in_helper
INFO - 2024-06-22 21:42:57 --> Helper loaded: url_helper
DEBUG - 2024-06-22 21:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-22 21:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 21:42:57 --> Controller Class Initialized
