<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-18 10:09:38 --> Config Class Initialized
INFO - 2024-08-18 10:09:38 --> Hooks Class Initialized
DEBUG - 2024-08-18 10:09:38 --> UTF-8 Support Enabled
INFO - 2024-08-18 10:09:38 --> Utf8 Class Initialized
INFO - 2024-08-18 10:09:38 --> URI Class Initialized
DEBUG - 2024-08-18 10:09:38 --> No URI present. Default controller set.
INFO - 2024-08-18 10:09:38 --> Router Class Initialized
INFO - 2024-08-18 10:09:38 --> Output Class Initialized
INFO - 2024-08-18 10:09:38 --> Security Class Initialized
DEBUG - 2024-08-18 10:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 10:09:38 --> Input Class Initialized
INFO - 2024-08-18 10:09:38 --> Language Class Initialized
INFO - 2024-08-18 10:09:38 --> Loader Class Initialized
INFO - 2024-08-18 10:09:38 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-18 10:09:38 --> Helper loaded: url_helper
DEBUG - 2024-08-18 10:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-18 10:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 10:09:38 --> Controller Class Initialized
INFO - 2024-08-18 21:18:31 --> Config Class Initialized
INFO - 2024-08-18 21:18:31 --> Hooks Class Initialized
DEBUG - 2024-08-18 21:18:31 --> UTF-8 Support Enabled
INFO - 2024-08-18 21:18:31 --> Utf8 Class Initialized
INFO - 2024-08-18 21:18:31 --> URI Class Initialized
DEBUG - 2024-08-18 21:18:31 --> No URI present. Default controller set.
INFO - 2024-08-18 21:18:31 --> Router Class Initialized
INFO - 2024-08-18 21:18:31 --> Output Class Initialized
INFO - 2024-08-18 21:18:31 --> Security Class Initialized
DEBUG - 2024-08-18 21:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 21:18:31 --> Input Class Initialized
INFO - 2024-08-18 21:18:31 --> Language Class Initialized
INFO - 2024-08-18 21:18:31 --> Loader Class Initialized
INFO - 2024-08-18 21:18:31 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-18 21:18:31 --> Helper loaded: url_helper
DEBUG - 2024-08-18 21:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-18 21:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 21:18:31 --> Controller Class Initialized
INFO - 2024-08-18 21:18:35 --> Config Class Initialized
INFO - 2024-08-18 21:18:35 --> Hooks Class Initialized
DEBUG - 2024-08-18 21:18:35 --> UTF-8 Support Enabled
INFO - 2024-08-18 21:18:35 --> Utf8 Class Initialized
INFO - 2024-08-18 21:18:35 --> URI Class Initialized
DEBUG - 2024-08-18 21:18:35 --> No URI present. Default controller set.
INFO - 2024-08-18 21:18:35 --> Router Class Initialized
INFO - 2024-08-18 21:18:35 --> Output Class Initialized
INFO - 2024-08-18 21:18:35 --> Security Class Initialized
DEBUG - 2024-08-18 21:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 21:18:35 --> Input Class Initialized
INFO - 2024-08-18 21:18:35 --> Language Class Initialized
INFO - 2024-08-18 21:18:35 --> Loader Class Initialized
INFO - 2024-08-18 21:18:35 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-18 21:18:35 --> Helper loaded: url_helper
DEBUG - 2024-08-18 21:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-18 21:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 21:18:35 --> Controller Class Initialized
INFO - 2024-08-18 22:47:54 --> Config Class Initialized
INFO - 2024-08-18 22:47:54 --> Hooks Class Initialized
DEBUG - 2024-08-18 22:47:54 --> UTF-8 Support Enabled
INFO - 2024-08-18 22:47:54 --> Utf8 Class Initialized
INFO - 2024-08-18 22:47:54 --> URI Class Initialized
DEBUG - 2024-08-18 22:47:54 --> No URI present. Default controller set.
INFO - 2024-08-18 22:47:54 --> Router Class Initialized
INFO - 2024-08-18 22:47:54 --> Output Class Initialized
INFO - 2024-08-18 22:47:54 --> Security Class Initialized
DEBUG - 2024-08-18 22:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 22:47:54 --> Input Class Initialized
INFO - 2024-08-18 22:47:54 --> Language Class Initialized
INFO - 2024-08-18 22:47:54 --> Loader Class Initialized
INFO - 2024-08-18 22:47:54 --> Helper loaded: is_loged_in_helper
INFO - 2024-08-18 22:47:54 --> Helper loaded: url_helper
DEBUG - 2024-08-18 22:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-18 22:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 22:47:54 --> Controller Class Initialized
