<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-11 10:34:46 --> Config Class Initialized
INFO - 2024-09-11 10:34:46 --> Hooks Class Initialized
DEBUG - 2024-09-11 10:34:46 --> UTF-8 Support Enabled
INFO - 2024-09-11 10:34:46 --> Utf8 Class Initialized
INFO - 2024-09-11 10:34:46 --> URI Class Initialized
DEBUG - 2024-09-11 10:34:46 --> No URI present. Default controller set.
INFO - 2024-09-11 10:34:46 --> Router Class Initialized
INFO - 2024-09-11 10:34:46 --> Output Class Initialized
INFO - 2024-09-11 10:34:46 --> Security Class Initialized
DEBUG - 2024-09-11 10:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 10:34:46 --> Input Class Initialized
INFO - 2024-09-11 10:34:46 --> Language Class Initialized
INFO - 2024-09-11 10:34:46 --> Loader Class Initialized
INFO - 2024-09-11 10:34:46 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-11 10:34:46 --> Helper loaded: url_helper
DEBUG - 2024-09-11 10:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 10:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 10:34:46 --> Controller Class Initialized
INFO - 2024-09-11 20:41:49 --> Config Class Initialized
INFO - 2024-09-11 20:41:49 --> Hooks Class Initialized
DEBUG - 2024-09-11 20:41:49 --> UTF-8 Support Enabled
INFO - 2024-09-11 20:41:49 --> Utf8 Class Initialized
INFO - 2024-09-11 20:41:49 --> URI Class Initialized
DEBUG - 2024-09-11 20:41:49 --> No URI present. Default controller set.
INFO - 2024-09-11 20:41:49 --> Router Class Initialized
INFO - 2024-09-11 20:41:49 --> Output Class Initialized
INFO - 2024-09-11 20:41:49 --> Security Class Initialized
DEBUG - 2024-09-11 20:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 20:41:49 --> Input Class Initialized
INFO - 2024-09-11 20:41:49 --> Language Class Initialized
INFO - 2024-09-11 20:41:49 --> Loader Class Initialized
INFO - 2024-09-11 20:41:49 --> Helper loaded: is_loged_in_helper
INFO - 2024-09-11 20:41:49 --> Helper loaded: url_helper
DEBUG - 2024-09-11 20:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 20:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 20:41:49 --> Controller Class Initialized
