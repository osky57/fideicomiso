<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-08 02:27:09 --> Config Class Initialized
INFO - 2024-05-08 02:27:09 --> Hooks Class Initialized
DEBUG - 2024-05-08 02:27:09 --> UTF-8 Support Enabled
INFO - 2024-05-08 02:27:09 --> Utf8 Class Initialized
INFO - 2024-05-08 02:27:09 --> URI Class Initialized
DEBUG - 2024-05-08 02:27:09 --> No URI present. Default controller set.
INFO - 2024-05-08 02:27:09 --> Router Class Initialized
INFO - 2024-05-08 02:27:09 --> Output Class Initialized
INFO - 2024-05-08 02:27:09 --> Security Class Initialized
DEBUG - 2024-05-08 02:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 02:27:09 --> Input Class Initialized
INFO - 2024-05-08 02:27:09 --> Language Class Initialized
INFO - 2024-05-08 02:27:09 --> Loader Class Initialized
INFO - 2024-05-08 02:27:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 02:27:09 --> Helper loaded: url_helper
DEBUG - 2024-05-08 02:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 02:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 02:27:09 --> Controller Class Initialized
INFO - 2024-05-08 09:29:11 --> Config Class Initialized
INFO - 2024-05-08 09:29:11 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:11 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:11 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:11 --> URI Class Initialized
DEBUG - 2024-05-08 09:29:11 --> No URI present. Default controller set.
INFO - 2024-05-08 09:29:11 --> Router Class Initialized
INFO - 2024-05-08 09:29:11 --> Output Class Initialized
INFO - 2024-05-08 09:29:11 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:11 --> Input Class Initialized
INFO - 2024-05-08 09:29:11 --> Language Class Initialized
INFO - 2024-05-08 09:29:11 --> Loader Class Initialized
INFO - 2024-05-08 09:29:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:11 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:11 --> Controller Class Initialized
INFO - 2024-05-08 09:29:11 --> Config Class Initialized
INFO - 2024-05-08 09:29:11 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:11 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:11 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:11 --> URI Class Initialized
INFO - 2024-05-08 09:29:11 --> Router Class Initialized
INFO - 2024-05-08 09:29:11 --> Output Class Initialized
INFO - 2024-05-08 09:29:11 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:11 --> Input Class Initialized
INFO - 2024-05-08 09:29:11 --> Language Class Initialized
INFO - 2024-05-08 09:29:11 --> Loader Class Initialized
INFO - 2024-05-08 09:29:11 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:11 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:11 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:11 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-08 09:29:11 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:11 --> Helper loaded: cookie_helper
INFO - 2024-05-08 09:29:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 09:29:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 09:29:11 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-08 09:29:11 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:11 --> Total execution time: 0.0476
INFO - 2024-05-08 09:29:12 --> Config Class Initialized
INFO - 2024-05-08 09:29:12 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:12 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:12 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:12 --> URI Class Initialized
INFO - 2024-05-08 09:29:12 --> Router Class Initialized
INFO - 2024-05-08 09:29:12 --> Output Class Initialized
INFO - 2024-05-08 09:29:12 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:12 --> Input Class Initialized
INFO - 2024-05-08 09:29:12 --> Language Class Initialized
INFO - 2024-05-08 09:29:12 --> Loader Class Initialized
INFO - 2024-05-08 09:29:12 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:12 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:12 --> Controller Class Initialized
INFO - 2024-05-08 09:29:15 --> Config Class Initialized
INFO - 2024-05-08 09:29:15 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:15 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:15 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:15 --> URI Class Initialized
INFO - 2024-05-08 09:29:15 --> Router Class Initialized
INFO - 2024-05-08 09:29:15 --> Output Class Initialized
INFO - 2024-05-08 09:29:15 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:15 --> Input Class Initialized
INFO - 2024-05-08 09:29:15 --> Language Class Initialized
INFO - 2024-05-08 09:29:15 --> Loader Class Initialized
INFO - 2024-05-08 09:29:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:15 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:15 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-08 09:29:15 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:15 --> Helper loaded: cookie_helper
INFO - 2024-05-08 09:29:15 --> Helper loaded: form_helper
INFO - 2024-05-08 09:29:15 --> Form Validation Class Initialized
INFO - 2024-05-08 09:29:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-08 09:29:15 --> Config Class Initialized
INFO - 2024-05-08 09:29:15 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:15 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:15 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:15 --> URI Class Initialized
INFO - 2024-05-08 09:29:15 --> Router Class Initialized
INFO - 2024-05-08 09:29:15 --> Output Class Initialized
INFO - 2024-05-08 09:29:15 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:15 --> Input Class Initialized
INFO - 2024-05-08 09:29:15 --> Language Class Initialized
INFO - 2024-05-08 09:29:15 --> Loader Class Initialized
INFO - 2024-05-08 09:29:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:15 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:15 --> Controller Class Initialized
INFO - 2024-05-08 09:29:15 --> Database Driver Class Initialized
DEBUG - 2024-05-08 09:29:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-08 09:29:15 --> Helper loaded: cookie_helper
INFO - 2024-05-08 09:29:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 09:29:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 09:29:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-08 09:29:15 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:15 --> Total execution time: 0.0094
INFO - 2024-05-08 09:29:15 --> Config Class Initialized
INFO - 2024-05-08 09:29:15 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:15 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:15 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:15 --> URI Class Initialized
INFO - 2024-05-08 09:29:15 --> Router Class Initialized
INFO - 2024-05-08 09:29:15 --> Output Class Initialized
INFO - 2024-05-08 09:29:15 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:15 --> Input Class Initialized
INFO - 2024-05-08 09:29:15 --> Language Class Initialized
INFO - 2024-05-08 09:29:15 --> Loader Class Initialized
INFO - 2024-05-08 09:29:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:15 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:15 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 09:29:15 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:15 --> Helper loaded: funciones_helper
INFO - 2024-05-08 09:29:15 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:15 --> Total execution time: 0.0336
INFO - 2024-05-08 09:29:19 --> Config Class Initialized
INFO - 2024-05-08 09:29:19 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:19 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:19 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:19 --> URI Class Initialized
INFO - 2024-05-08 09:29:19 --> Router Class Initialized
INFO - 2024-05-08 09:29:19 --> Output Class Initialized
INFO - 2024-05-08 09:29:19 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:19 --> Input Class Initialized
INFO - 2024-05-08 09:29:19 --> Language Class Initialized
INFO - 2024-05-08 09:29:19 --> Loader Class Initialized
INFO - 2024-05-08 09:29:19 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:19 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:19 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:19 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 09:29:19 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:19 --> Helper loaded: funciones_helper
INFO - 2024-05-08 09:29:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 09:29:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 09:29:19 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-08 09:29:19 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:19 --> Total execution time: 0.0113
INFO - 2024-05-08 09:29:20 --> Config Class Initialized
INFO - 2024-05-08 09:29:20 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:20 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:20 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:20 --> URI Class Initialized
INFO - 2024-05-08 09:29:20 --> Router Class Initialized
INFO - 2024-05-08 09:29:20 --> Output Class Initialized
INFO - 2024-05-08 09:29:20 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:20 --> Input Class Initialized
INFO - 2024-05-08 09:29:20 --> Language Class Initialized
INFO - 2024-05-08 09:29:20 --> Loader Class Initialized
INFO - 2024-05-08 09:29:20 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:20 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:20 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:20 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 09:29:20 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:20 --> Helper loaded: funciones_helper
INFO - 2024-05-08 09:29:20 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:20 --> Total execution time: 0.0300
INFO - 2024-05-08 09:29:22 --> Config Class Initialized
INFO - 2024-05-08 09:29:22 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:22 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:22 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:22 --> URI Class Initialized
INFO - 2024-05-08 09:29:22 --> Router Class Initialized
INFO - 2024-05-08 09:29:22 --> Output Class Initialized
INFO - 2024-05-08 09:29:22 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:22 --> Input Class Initialized
INFO - 2024-05-08 09:29:22 --> Language Class Initialized
INFO - 2024-05-08 09:29:22 --> Loader Class Initialized
INFO - 2024-05-08 09:29:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:22 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:22 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-08 09:29:22 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:22 --> Helper loaded: funciones_helper
INFO - 2024-05-08 09:29:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 09:29:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 09:29:22 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-08 09:29:22 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:22 --> Total execution time: 0.0338
INFO - 2024-05-08 09:29:22 --> Config Class Initialized
INFO - 2024-05-08 09:29:22 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:22 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:22 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:22 --> URI Class Initialized
INFO - 2024-05-08 09:29:22 --> Router Class Initialized
INFO - 2024-05-08 09:29:22 --> Output Class Initialized
INFO - 2024-05-08 09:29:22 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:22 --> Input Class Initialized
INFO - 2024-05-08 09:29:22 --> Language Class Initialized
INFO - 2024-05-08 09:29:22 --> Loader Class Initialized
INFO - 2024-05-08 09:29:22 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:22 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:22 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:22 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 09:29:22 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:22 --> Helper loaded: funciones_helper
INFO - 2024-05-08 09:29:22 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:22 --> Total execution time: 0.0217
INFO - 2024-05-08 09:29:26 --> Config Class Initialized
INFO - 2024-05-08 09:29:26 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:26 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:26 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:26 --> URI Class Initialized
INFO - 2024-05-08 09:29:26 --> Router Class Initialized
INFO - 2024-05-08 09:29:26 --> Output Class Initialized
INFO - 2024-05-08 09:29:26 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:26 --> Input Class Initialized
INFO - 2024-05-08 09:29:26 --> Language Class Initialized
INFO - 2024-05-08 09:29:26 --> Loader Class Initialized
INFO - 2024-05-08 09:29:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:26 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:26 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:26 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-08 09:29:26 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:26 --> Helper loaded: funciones_helper
INFO - 2024-05-08 09:29:26 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:26 --> Total execution time: 0.0241
INFO - 2024-05-08 09:29:32 --> Config Class Initialized
INFO - 2024-05-08 09:29:32 --> Hooks Class Initialized
DEBUG - 2024-05-08 09:29:32 --> UTF-8 Support Enabled
INFO - 2024-05-08 09:29:32 --> Utf8 Class Initialized
INFO - 2024-05-08 09:29:32 --> URI Class Initialized
INFO - 2024-05-08 09:29:32 --> Router Class Initialized
INFO - 2024-05-08 09:29:32 --> Output Class Initialized
INFO - 2024-05-08 09:29:32 --> Security Class Initialized
DEBUG - 2024-05-08 09:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 09:29:32 --> Input Class Initialized
INFO - 2024-05-08 09:29:32 --> Language Class Initialized
INFO - 2024-05-08 09:29:32 --> Loader Class Initialized
INFO - 2024-05-08 09:29:32 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 09:29:32 --> Helper loaded: url_helper
DEBUG - 2024-05-08 09:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 09:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 09:29:32 --> Controller Class Initialized
DEBUG - 2024-05-08 09:29:32 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-08 09:29:32 --> Database Driver Class Initialized
INFO - 2024-05-08 09:29:32 --> Helper loaded: funciones_helper
INFO - 2024-05-08 09:29:32 --> Final output sent to browser
DEBUG - 2024-05-08 09:29:32 --> Total execution time: 0.0185
INFO - 2024-05-08 11:34:06 --> Config Class Initialized
INFO - 2024-05-08 11:34:06 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:06 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:06 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:06 --> URI Class Initialized
DEBUG - 2024-05-08 11:34:06 --> No URI present. Default controller set.
INFO - 2024-05-08 11:34:06 --> Router Class Initialized
INFO - 2024-05-08 11:34:06 --> Output Class Initialized
INFO - 2024-05-08 11:34:06 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:06 --> Input Class Initialized
INFO - 2024-05-08 11:34:06 --> Language Class Initialized
INFO - 2024-05-08 11:34:06 --> Loader Class Initialized
INFO - 2024-05-08 11:34:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:06 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:06 --> Controller Class Initialized
INFO - 2024-05-08 11:34:06 --> Config Class Initialized
INFO - 2024-05-08 11:34:06 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:06 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:06 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:06 --> URI Class Initialized
INFO - 2024-05-08 11:34:06 --> Router Class Initialized
INFO - 2024-05-08 11:34:06 --> Output Class Initialized
INFO - 2024-05-08 11:34:06 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:06 --> Input Class Initialized
INFO - 2024-05-08 11:34:06 --> Language Class Initialized
INFO - 2024-05-08 11:34:06 --> Loader Class Initialized
INFO - 2024-05-08 11:34:06 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:06 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:06 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:06 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-08 11:34:06 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:06 --> Helper loaded: cookie_helper
INFO - 2024-05-08 11:34:06 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 11:34:06 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 11:34:06 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/login.php
INFO - 2024-05-08 11:34:06 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:06 --> Total execution time: 0.0144
INFO - 2024-05-08 11:34:07 --> Config Class Initialized
INFO - 2024-05-08 11:34:07 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:07 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:07 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:07 --> URI Class Initialized
INFO - 2024-05-08 11:34:07 --> Router Class Initialized
INFO - 2024-05-08 11:34:07 --> Output Class Initialized
INFO - 2024-05-08 11:34:07 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:07 --> Input Class Initialized
INFO - 2024-05-08 11:34:07 --> Language Class Initialized
INFO - 2024-05-08 11:34:07 --> Loader Class Initialized
INFO - 2024-05-08 11:34:07 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:07 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:07 --> Controller Class Initialized
INFO - 2024-05-08 11:34:09 --> Config Class Initialized
INFO - 2024-05-08 11:34:09 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:09 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:09 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:09 --> URI Class Initialized
INFO - 2024-05-08 11:34:09 --> Router Class Initialized
INFO - 2024-05-08 11:34:09 --> Output Class Initialized
INFO - 2024-05-08 11:34:09 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:09 --> Input Class Initialized
INFO - 2024-05-08 11:34:09 --> Language Class Initialized
INFO - 2024-05-08 11:34:09 --> Loader Class Initialized
INFO - 2024-05-08 11:34:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:09 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:09 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:09 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-08 11:34:09 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:09 --> Helper loaded: cookie_helper
INFO - 2024-05-08 11:34:09 --> Helper loaded: form_helper
INFO - 2024-05-08 11:34:09 --> Form Validation Class Initialized
INFO - 2024-05-08 11:34:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-05-08 11:34:09 --> Config Class Initialized
INFO - 2024-05-08 11:34:09 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:09 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:09 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:09 --> URI Class Initialized
INFO - 2024-05-08 11:34:09 --> Router Class Initialized
INFO - 2024-05-08 11:34:09 --> Output Class Initialized
INFO - 2024-05-08 11:34:09 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:09 --> Input Class Initialized
INFO - 2024-05-08 11:34:09 --> Language Class Initialized
INFO - 2024-05-08 11:34:09 --> Loader Class Initialized
INFO - 2024-05-08 11:34:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:09 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:09 --> Controller Class Initialized
INFO - 2024-05-08 11:34:09 --> Database Driver Class Initialized
DEBUG - 2024-05-08 11:34:09 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_usuarios.php
INFO - 2024-05-08 11:34:09 --> Helper loaded: cookie_helper
INFO - 2024-05-08 11:34:09 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 11:34:09 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 11:34:09 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-08 11:34:09 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:09 --> Total execution time: 0.0210
INFO - 2024-05-08 11:34:10 --> Config Class Initialized
INFO - 2024-05-08 11:34:10 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:10 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:10 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:10 --> URI Class Initialized
INFO - 2024-05-08 11:34:10 --> Router Class Initialized
INFO - 2024-05-08 11:34:10 --> Output Class Initialized
INFO - 2024-05-08 11:34:10 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:10 --> Input Class Initialized
INFO - 2024-05-08 11:34:10 --> Language Class Initialized
INFO - 2024-05-08 11:34:10 --> Loader Class Initialized
INFO - 2024-05-08 11:34:10 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:10 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:10 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:10 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 11:34:10 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:10 --> Helper loaded: funciones_helper
INFO - 2024-05-08 11:34:10 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:10 --> Total execution time: 0.0249
INFO - 2024-05-08 11:34:13 --> Config Class Initialized
INFO - 2024-05-08 11:34:13 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:13 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:13 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:13 --> URI Class Initialized
INFO - 2024-05-08 11:34:13 --> Router Class Initialized
INFO - 2024-05-08 11:34:13 --> Output Class Initialized
INFO - 2024-05-08 11:34:13 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:13 --> Input Class Initialized
INFO - 2024-05-08 11:34:13 --> Language Class Initialized
INFO - 2024-05-08 11:34:13 --> Loader Class Initialized
INFO - 2024-05-08 11:34:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:13 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:13 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 11:34:13 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:13 --> Helper loaded: funciones_helper
INFO - 2024-05-08 11:34:13 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 11:34:13 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 11:34:13 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/escritorio.php
INFO - 2024-05-08 11:34:13 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:13 --> Total execution time: 0.0118
INFO - 2024-05-08 11:34:13 --> Config Class Initialized
INFO - 2024-05-08 11:34:13 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:13 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:13 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:13 --> URI Class Initialized
INFO - 2024-05-08 11:34:13 --> Router Class Initialized
INFO - 2024-05-08 11:34:13 --> Output Class Initialized
INFO - 2024-05-08 11:34:13 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:13 --> Input Class Initialized
INFO - 2024-05-08 11:34:13 --> Language Class Initialized
INFO - 2024-05-08 11:34:13 --> Loader Class Initialized
INFO - 2024-05-08 11:34:13 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:13 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:13 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:13 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 11:34:13 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:13 --> Helper loaded: funciones_helper
INFO - 2024-05-08 11:34:13 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:13 --> Total execution time: 0.0189
INFO - 2024-05-08 11:34:15 --> Config Class Initialized
INFO - 2024-05-08 11:34:15 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:15 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:15 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:15 --> URI Class Initialized
INFO - 2024-05-08 11:34:15 --> Router Class Initialized
INFO - 2024-05-08 11:34:15 --> Output Class Initialized
INFO - 2024-05-08 11:34:15 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:15 --> Input Class Initialized
INFO - 2024-05-08 11:34:15 --> Language Class Initialized
INFO - 2024-05-08 11:34:15 --> Loader Class Initialized
INFO - 2024-05-08 11:34:15 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:15 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:15 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:15 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-08 11:34:15 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:15 --> Helper loaded: funciones_helper
INFO - 2024-05-08 11:34:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/header.php
INFO - 2024-05-08 11:34:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/footer.php
INFO - 2024-05-08 11:34:15 --> File loaded: /var/www/html/perroneinmobiliaria/application/views/informespresu.php
INFO - 2024-05-08 11:34:15 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:15 --> Total execution time: 0.0347
INFO - 2024-05-08 11:34:16 --> Config Class Initialized
INFO - 2024-05-08 11:34:16 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:16 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:16 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:16 --> URI Class Initialized
INFO - 2024-05-08 11:34:16 --> Router Class Initialized
INFO - 2024-05-08 11:34:16 --> Output Class Initialized
INFO - 2024-05-08 11:34:16 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:16 --> Input Class Initialized
INFO - 2024-05-08 11:34:16 --> Language Class Initialized
INFO - 2024-05-08 11:34:16 --> Loader Class Initialized
INFO - 2024-05-08 11:34:16 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:16 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:16 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:16 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/crud_proyectos.php
INFO - 2024-05-08 11:34:16 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:16 --> Helper loaded: funciones_helper
INFO - 2024-05-08 11:34:16 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:16 --> Total execution time: 0.0181
INFO - 2024-05-08 11:34:21 --> Config Class Initialized
INFO - 2024-05-08 11:34:21 --> Hooks Class Initialized
DEBUG - 2024-05-08 11:34:21 --> UTF-8 Support Enabled
INFO - 2024-05-08 11:34:21 --> Utf8 Class Initialized
INFO - 2024-05-08 11:34:21 --> URI Class Initialized
INFO - 2024-05-08 11:34:21 --> Router Class Initialized
INFO - 2024-05-08 11:34:21 --> Output Class Initialized
INFO - 2024-05-08 11:34:21 --> Security Class Initialized
DEBUG - 2024-05-08 11:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 11:34:21 --> Input Class Initialized
INFO - 2024-05-08 11:34:21 --> Language Class Initialized
INFO - 2024-05-08 11:34:21 --> Loader Class Initialized
INFO - 2024-05-08 11:34:21 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 11:34:21 --> Helper loaded: url_helper
DEBUG - 2024-05-08 11:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 11:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 11:34:21 --> Controller Class Initialized
DEBUG - 2024-05-08 11:34:21 --> Config file loaded: /var/www/html/perroneinmobiliaria/application/config/nocrud_informes_presupuestos.php
INFO - 2024-05-08 11:34:21 --> Database Driver Class Initialized
INFO - 2024-05-08 11:34:21 --> Helper loaded: funciones_helper
INFO - 2024-05-08 11:34:21 --> Final output sent to browser
DEBUG - 2024-05-08 11:34:21 --> Total execution time: 0.0221
INFO - 2024-05-08 13:24:45 --> Config Class Initialized
INFO - 2024-05-08 13:24:45 --> Hooks Class Initialized
DEBUG - 2024-05-08 13:24:45 --> UTF-8 Support Enabled
INFO - 2024-05-08 13:24:45 --> Utf8 Class Initialized
INFO - 2024-05-08 13:24:45 --> URI Class Initialized
DEBUG - 2024-05-08 13:24:45 --> No URI present. Default controller set.
INFO - 2024-05-08 13:24:45 --> Router Class Initialized
INFO - 2024-05-08 13:24:45 --> Output Class Initialized
INFO - 2024-05-08 13:24:45 --> Security Class Initialized
DEBUG - 2024-05-08 13:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-08 13:24:45 --> Input Class Initialized
INFO - 2024-05-08 13:24:45 --> Language Class Initialized
INFO - 2024-05-08 13:24:45 --> Loader Class Initialized
INFO - 2024-05-08 13:24:45 --> Helper loaded: is_loged_in_helper
INFO - 2024-05-08 13:24:45 --> Helper loaded: url_helper
DEBUG - 2024-05-08 13:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-05-08 13:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-08 13:24:45 --> Controller Class Initialized
