<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-09 02:09:52 --> Config Class Initialized
INFO - 2024-07-09 02:09:52 --> Hooks Class Initialized
DEBUG - 2024-07-09 02:09:52 --> UTF-8 Support Enabled
INFO - 2024-07-09 02:09:52 --> Utf8 Class Initialized
INFO - 2024-07-09 02:09:52 --> URI Class Initialized
DEBUG - 2024-07-09 02:09:52 --> No URI present. Default controller set.
INFO - 2024-07-09 02:09:52 --> Router Class Initialized
INFO - 2024-07-09 02:09:52 --> Output Class Initialized
INFO - 2024-07-09 02:09:52 --> Security Class Initialized
DEBUG - 2024-07-09 02:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-09 02:09:52 --> Input Class Initialized
INFO - 2024-07-09 02:09:52 --> Language Class Initialized
INFO - 2024-07-09 02:09:52 --> Loader Class Initialized
INFO - 2024-07-09 02:09:52 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-09 02:09:52 --> Helper loaded: url_helper
DEBUG - 2024-07-09 02:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-09 02:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-09 02:09:52 --> Controller Class Initialized
INFO - 2024-07-09 08:46:24 --> Config Class Initialized
INFO - 2024-07-09 08:46:24 --> Hooks Class Initialized
DEBUG - 2024-07-09 08:46:24 --> UTF-8 Support Enabled
INFO - 2024-07-09 08:46:24 --> Utf8 Class Initialized
INFO - 2024-07-09 08:46:25 --> URI Class Initialized
DEBUG - 2024-07-09 08:46:25 --> No URI present. Default controller set.
INFO - 2024-07-09 08:46:25 --> Router Class Initialized
INFO - 2024-07-09 08:46:25 --> Output Class Initialized
INFO - 2024-07-09 08:46:25 --> Security Class Initialized
DEBUG - 2024-07-09 08:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-09 08:46:26 --> Input Class Initialized
INFO - 2024-07-09 08:46:26 --> Language Class Initialized
INFO - 2024-07-09 08:46:26 --> Loader Class Initialized
INFO - 2024-07-09 08:46:26 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-09 08:46:26 --> Helper loaded: url_helper
DEBUG - 2024-07-09 08:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-09 08:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-09 08:46:27 --> Controller Class Initialized
INFO - 2024-07-09 14:42:49 --> Config Class Initialized
INFO - 2024-07-09 14:42:49 --> Hooks Class Initialized
DEBUG - 2024-07-09 14:42:49 --> UTF-8 Support Enabled
INFO - 2024-07-09 14:42:49 --> Utf8 Class Initialized
INFO - 2024-07-09 14:42:49 --> URI Class Initialized
DEBUG - 2024-07-09 14:42:50 --> No URI present. Default controller set.
INFO - 2024-07-09 14:42:50 --> Router Class Initialized
INFO - 2024-07-09 14:42:50 --> Output Class Initialized
INFO - 2024-07-09 14:42:50 --> Security Class Initialized
DEBUG - 2024-07-09 14:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-09 14:42:51 --> Input Class Initialized
INFO - 2024-07-09 14:42:51 --> Language Class Initialized
INFO - 2024-07-09 14:42:51 --> Loader Class Initialized
INFO - 2024-07-09 14:42:51 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-09 14:42:51 --> Helper loaded: url_helper
DEBUG - 2024-07-09 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-09 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-09 14:42:52 --> Controller Class Initialized
INFO - 2024-07-09 21:26:04 --> Config Class Initialized
INFO - 2024-07-09 21:26:04 --> Hooks Class Initialized
DEBUG - 2024-07-09 21:26:04 --> UTF-8 Support Enabled
INFO - 2024-07-09 21:26:04 --> Utf8 Class Initialized
INFO - 2024-07-09 21:26:04 --> URI Class Initialized
DEBUG - 2024-07-09 21:26:04 --> No URI present. Default controller set.
INFO - 2024-07-09 21:26:04 --> Router Class Initialized
INFO - 2024-07-09 21:26:04 --> Output Class Initialized
INFO - 2024-07-09 21:26:04 --> Security Class Initialized
DEBUG - 2024-07-09 21:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-09 21:26:04 --> Input Class Initialized
INFO - 2024-07-09 21:26:04 --> Language Class Initialized
INFO - 2024-07-09 21:26:04 --> Loader Class Initialized
INFO - 2024-07-09 21:26:05 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-09 21:26:05 --> Helper loaded: url_helper
DEBUG - 2024-07-09 21:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-09 21:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-09 21:26:05 --> Controller Class Initialized
INFO - 2024-07-09 21:26:08 --> Config Class Initialized
INFO - 2024-07-09 21:26:08 --> Hooks Class Initialized
DEBUG - 2024-07-09 21:26:08 --> UTF-8 Support Enabled
INFO - 2024-07-09 21:26:08 --> Utf8 Class Initialized
INFO - 2024-07-09 21:26:08 --> URI Class Initialized
DEBUG - 2024-07-09 21:26:08 --> No URI present. Default controller set.
INFO - 2024-07-09 21:26:08 --> Router Class Initialized
INFO - 2024-07-09 21:26:08 --> Output Class Initialized
INFO - 2024-07-09 21:26:08 --> Security Class Initialized
DEBUG - 2024-07-09 21:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-09 21:26:08 --> Input Class Initialized
INFO - 2024-07-09 21:26:08 --> Language Class Initialized
INFO - 2024-07-09 21:26:08 --> Loader Class Initialized
INFO - 2024-07-09 21:26:08 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-09 21:26:08 --> Helper loaded: url_helper
DEBUG - 2024-07-09 21:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-09 21:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-09 21:26:08 --> Controller Class Initialized
INFO - 2024-07-09 21:26:09 --> Config Class Initialized
INFO - 2024-07-09 21:26:09 --> Hooks Class Initialized
DEBUG - 2024-07-09 21:26:09 --> UTF-8 Support Enabled
INFO - 2024-07-09 21:26:09 --> Utf8 Class Initialized
INFO - 2024-07-09 21:26:09 --> URI Class Initialized
DEBUG - 2024-07-09 21:26:09 --> No URI present. Default controller set.
INFO - 2024-07-09 21:26:09 --> Router Class Initialized
INFO - 2024-07-09 21:26:09 --> Output Class Initialized
INFO - 2024-07-09 21:26:09 --> Security Class Initialized
DEBUG - 2024-07-09 21:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-09 21:26:09 --> Input Class Initialized
INFO - 2024-07-09 21:26:09 --> Language Class Initialized
INFO - 2024-07-09 21:26:09 --> Loader Class Initialized
INFO - 2024-07-09 21:26:09 --> Helper loaded: is_loged_in_helper
INFO - 2024-07-09 21:26:09 --> Helper loaded: url_helper
DEBUG - 2024-07-09 21:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-07-09 21:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-09 21:26:09 --> Controller Class Initialized
