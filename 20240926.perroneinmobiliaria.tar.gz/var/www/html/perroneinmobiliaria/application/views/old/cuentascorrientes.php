<!-- header -->
<?php $this->load->view('header');?>

<!--
<style>
  p {
    color: blue;
    margin: 12px;
  }
  b {
    color: red;
  }
</style>
-->



<div id="dialog">
<p id="dialogMsg1"></p>
<p id="dialogMsg2"></p>
<div id="tablaApl"></div>
<div id="tablaPag"></div>
</div>

<div class="row">
	
<div class="main">
<!-- fin header -->


    <h5><b><?php echo $titulo ?></b></h5>
    <div style='padding-top:10px;padding-bottom:10px;'>
	<div class="row">
	    <div class="col-md-8">
		<div class="row">
		    <div class="col-md-5 btn btn-success">
			    Filtrar desde: <input type="date" name="frm_fdesde" id="frm_fdesde" value="<?=$fDesde;?>" >
			    <br>Filtrar hasta:         <input type="date" name="frm_fhasta" id="frm_fhasta" value="<?=$fHasta;?>" >
		    </div>
		    <div class="col-md-5 btn btn_success"> 
			    <select class="custom-select" id="frm_entidad_id" name="frm_entidad_id">
			    <?php foreach($entidades as $item){?>
				<option value="<?=$item['e_id'];?>" ><?=$item['e_razon_social'];?>-<?=$item['e_id'];?>-(<?=$item['tipoentidad'];?>)</option>
			    <?php } ?>
			    </select>
		    </div>
<!--
		    <div class="col col-md-2" id="div_proye" name="div_proye" >
			<input class="form-check-input" type="checkbox" value="1" id="frm_solo_proyecto" name="frm_solo_proyecto">
			<label class="form-check-label" for="flexCheckChecked">Proyecto actual</label>
		    </div>
-->
		</div>

	    </div>
	    <div class="col-md-2">
		<a id="llamaCC" class="btn btn-success" ><i class="material-icons">&#xE147;</i> <span>Nuevo Movimiento</span></a>
	    </div>
	    <?php if ( $titulo != 'Proveedores'){ ?>
		<div class="col-md-2" align="right">
		    <a id="llamaGenCuo" class="btn btn-success" ><i class="material-icons">&#xE147;</i> <span>Generar Cuotas</span></a>
		</div>
	    <?php } ?>
	</div>
    </div>
<!--
	    data-remember-order="true"
	    data-side-pagination="server"
	    data-search="true"
	    data-page-list="[10, 25, 50, All]"
	    data-pagination="true"

-->

<div class="container-fluid">
    <div class="row">
        <div class="col-xs-12">

	<table class="tbodyalt"
	    id="table"
	    data-toggle="table"
	    data-height="500"
	    <?php echo $elurl ?> >

	    <thead>
	    <tr>

		<?php foreach( $campos as $cr){ ?>
		    <th class="text-right" data-field="<?php echo $cr[0] ?>" <?php echo $cr[1] ?>  ><?php echo $cr[2] ?></th>
		<?php } ?>

	    </tr>
	    </thead>
	</table>

        </div>
    </div>
</div>




<script>

function fn_action(value, row) {

    if (row.cc_id > 0){
//	retE  = '<a  class="btn btn-primary" onclick="abrirFormulario(\'<?php echo $urlform ?>?name=frm-cuentascorrientes&ii='+row.cc_entidad_id+'&id='+row.cc_id+'\',\'Editar '+row.cc_id+'\')" href="#"><i class="fa fa-edit"></i></a>' ;
	retD  = '<a  class="btn btn-danger"  onclick="return confirm(\'¿Confirma eliminar?\')" href="<?php echo $urldel ?>?ii='+row.cc_entidad_id+'&id='+row.cc_id+'"><i class="fa fa-trash"></i></a>';
	if (row.tiene_apli == 0){
	    return  retD;
	}
    }
}

$(document).ready(function() {


    if ('<?php echo $sistema ?>' == 'I'){

        $("#div_proye").hide();

    }


    $("#frm_fdesde, #frm_fhasta, #frm_entidad_id").on('change', function() {
	fdesde = $("#frm_fdesde").val();
	fhasta = $("#frm_fhasta").val();
	idEnti = $("#frm_entidad_id").val();
	$('#table').bootstrapTable("refresh", {
	    url: "<?php echo $urlrecupag ?>",
	    query: { idEnti: idEnti, fDesde: fdesde, fHasta: fhasta }
	});
    });

    $("#llamaCC").click(function(){
	var idEnti = $("#frm_entidad_id").val();
	abrirFormulario('/index.php/Cuentascorrientes/cargaFormulario?name=frm-cuentascorrientes&idinv='+idEnti,'Nuevo Movimiento');
    });

    $("#llamaGenCuo").click(function(){
	abrirFormulario('/index.php/Cuentascorrientes/cargaGenCuo?name=frm-cuentascorrientes-lote','Generar Cuotas');
    });

    $("#dialog").dialog({
	autoOpen: false,
	modal: true,
	buttons: {
	    "Cerrar": function () {
		$(this).dialog("close");
	    }
	}
    });

    $('#table').on('dblclick', 'tr', function (dato) {
	elId = dato.currentTarget.cells[0].textContent;
	if ( elId > 0){
	    $.ajax({
		url : "<?=$urlinfocomp;?>",
		data : { idcomp : elId },
		type : 'GET',
		dataType : 'json',
		success : function(json) {
		    jsonC = json['comprob'];
		    jsonP = json['pagos'];
		    jsonA = json['aplicaciones'];
		    jsonC['totalmn']  =  jsonC['totalmn']  === undefined ? '' : jsonC['totalmn'];
		    jsonC['totaldiv'] =  jsonC['totaldiv'] === undefined ? '' : jsonC['totaldiv'];
		    sinApli = jsonC['saldocomprob'];
		    sinApli = sinApli.replace('(','');
		    sinApli = sinApli.replace(')','');
		    sinApliPesDol = sinApli.split(',');

		    $("#dialogMsg1").text("Entidad: "+jsonC['e_razon_social']+" ("+jsonC['cc_entidad_id']+") - Celular: "+jsonC['e_celular']);
		    $("#dialogMsg2").text("Importe: $ "+jsonC['totalmn']+" - U$S "+jsonC['totaldiv']+"   |  Sin aplicar: $ "+ sinApliPesDol[0]+" - U$S: "+ sinApliPesDol[1]  );
		    $("#dialogMsg2").css({"background-color": "yellow", "font-size": "120%"});

		    $("#dialog").dialog("option", "title", "Id: "+jsonC['cc_id']+" - Comprobante: "+jsonC['tc_num']+" - Fecha: "+jsonC['cc_fecha_dmy']);
		    lF     = 0;
		    lasA   = ""
		    nTotMN = 0;
		    nTotUS = 0;
		    jsonA.forEach((unaA) => {
			if (lF == 0){
			    lasA  = "<b>Aplicaciones</b><br><table class='table table-sm'>";   // <caption>Aplicaciones</caption>"
			    lasA += "<thead><tr>";
			    lasA += "<th class='text-right'>Id</th>";
			    lasA += "<th class='text-right'>Fecha</th>";
			    lasA += "<th class='text-right'>Comprobante</th>";
			    lasA += "<th class='text-right'>Comentario</th>";
			    lasA += "<th class='text-right'>Importe $</th>";
			    lasA += "<th class='text-right'>Importe U$S</th>";
			    lasA += "</tr></thead><tbody>";
			    lF   = 1;
			}
			lasA += "<tr>"
			lasA += "<td>"+unaA.id+"</td>";
			lasA += "<td>"+unaA.fecha_dmy+"</td>";
			lasA += "<td>"+unaA.comp_nume+"</td>";
			lasA += "<td>"+unaA.comentario+"</td>";
			lasA += "<td>"+unaA.rcc_monto_pesos+"</td>";
			lasA += "<td>"+unaA.rcc_monto_divisa+"</td>";
			lasA += "</tr>"
			nTotMN += Number(unaA.rcc_monto_pesos);
			nTotUS += Number(unaA.rcc_monto_divisa);
		    });
		    if (lF == 1){
			lasA += "<tr>"
			lasA += "<td></td>";
			lasA += "<td></td>";
			lasA += "<td></td>";
			lasA += "<td><b>TOTAL</b></td>";
			lasA += "<td><b>"+nTotMN.toFixed(2)+"</b></td>";
			lasA += "<td><b>"+nTotUS.toFixed(2)+"</b></td>";
			lasA += "</tr>"
			lasA += "</tbody></table>"
		    }
		    $("#tablaApl").html(lasA);

		    lF     = 0;
		    lasA   = ""
		    nTotMN = 0;
		    nTotUS = 0;
		    jsonP.forEach((unP) => {
			if (lF == 0){
			    lasA  = "<b>Caja</b><br><table class='table table-sm'>";   // <caption>Aplicaciones</caption>"
			    lasA += "<thead><tr>";
			    lasA += "<th class='text-right'>Id</th>";
			    lasA += "<th class='text-right'>Tipo</th>";
			    lasA += "<th class='text-right'>Comentario</th>";
			    lasA += "<th class='text-right'>Banco - Chq.Nro.</th>";
			    lasA += "<th class='text-right'>Fecha Emi.</th>";
			    lasA += "<th class='text-right'>Fecha Acr.</th>";
			    lasA += "<th class='text-right'>Importe $</th>";
			    lasA += "<th class='text-right'>Importe U$S</th>";
			    lasA += "</tr></thead><tbody>";
			    lF   = 1;
			}
			if (unP.cb_denominacion == null){
			    banco = unP.banco;    //ba2_denominacion;
			}else{
			    banco = unP.cb_denominacion;
			}

			if (unP.serienro == null){
			    chq = "";
			}else{
			    chq = unP.serienro;
			}
			lasA += "<tr>"
			lasA += "<td>"+unP.ccc_id+"</td>";
			lasA += "<td>"+(unP.tmc_descripcion   == null?"":unP.tmc_descripcion)+"</td>";
			lasA += "<td>"+(unP.ccc_comentario    == null?"":unP.ccc_comentario)+"</td>";
			lasA += "<td>"+(banco == null?"":banco+" "+chq)+"</td>";

//			lasA += "<td>"+(unP.ccc_f_emi_dmy     == null?"":unP.ccc_f_emi_dmy)+"</td>";
			lasA += "<td>"+(unP.f_emision         == null?"":unP.f_emision)+"</td>";

//			lasA += "<td>"+(unP.ccc_f_acre_dmy    == null?"":unP.ccc_f_acre_dmy)+"</td>";
			lasA += "<td>"+(unP.f_acreditacion    == null?"":unP.f_acreditacion)+"</td>";

			lasA += "<td>"+(unP.mo1_simbolo == "$"?unP.ccc_importe:"")+"</td>";
			lasA += "<td>"+(unP.mo1_simbolo != "$"?unP.ccc_importe:"")+"</td>";
			lasA += "</tr>"
			nTotMN += unP.mo1_simbolo == "$"?Number(unP.ccc_importe):0;
			nTotUS += unP.mo1_simbolo != "$"?Number(unP.ccc_importe):0;


		    });
		    if (lF == 1){
			lasA += "<tr>"
			lasA += "<td></td>";
			lasA += "<td></td>";
			lasA += "<td></td>";
			lasA += "<td></td>";
			lasA += "<td></td>";
			lasA += "<td><b>TOTAL</b></td>";
			lasA += "<td><b>"+nTotMN.toFixed(2)+"</b></td>";
			lasA += "<td><b>"+nTotUS.toFixed(2)+"</b></td>";
			lasA += "</tr>"
			lasA += "</tbody></table>"
		    }
		    $("#tablaPag").html(lasA);
		    $("#dialog").dialog("option", "width", 1300);
		    $("#dialog").dialog("option", "height", 600);
		    $("#dialog").dialog("option", "resizable", true);
		    $("#dialog").dialog("open");
		}
	    })

	}
    });

})


</script>
<!-- footer -->
</div>
</div>
<?php $this->load->view('footer');?>
<!-- fin footer -->
