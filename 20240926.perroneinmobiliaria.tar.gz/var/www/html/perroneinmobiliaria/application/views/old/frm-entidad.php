<form id="formenti" action="<?php echo base_url('index.php/entidades/guardaRegistro') ?>" method="POST" data-validation="valida_entidad">

	<div class="col">
		<!--<label for="frm_id">Id</label>-->
		<input type="hidden" readonly class="form-control" id="frm_id" name="frm_id" value="<?=$id;?>" >
	</div>
	<div class="row">
		<div class="col">
			<label for="frm_razon_social">Razón Social</label>
			<input type="text" class="form-control" id="frm_razon_social" name="frm_razon_social" value="<?=$razon_social;?>"   maxlength="100" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" />		</div>
		<div class="col">
			<label for="frm_cuit">CUIT</label>
			<input type="number" class="form-control" id="frm_cuit" name="frm_cuit" value="<?=$cuit;?>">
		</div>
	</div>
	
	<div class="row">
		<div class="col">
			<label for="frm_calle">Calle</label>
			<input type="text" class="form-control" id="frm_calle"  name="frm_calle" value="<?=$calle;?>"  maxlength="100" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" />
		</div>
		<div class="col">
			<label for="frm_numero">Número</label>
			<input type="text" class="form-control" id="frm_numero" name="frm_numero" value="<?=$numero;?>"  maxlength="20" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" /> 
		</div>
		<div class="col">
			<label for="frm_departamento">Departamento</label>
			<input type="text" class="form-control" id="frm_piso_departamento" name="frm_piso_departamento" value="<?=$piso_departamento;?>"  maxlength="20" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" />
		</div>
	</div>
	
	<div class="row">
		<div class="col">
			<label for="frm_celular">Celular</label>
			<input type="text" class="form-control" id="frm_celular" name="frm_celular" value="<?=$celular;?>"  maxlength="20" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" />
		</div>
		<div class="col">
			<label for="frm_whatsapp">Whatsapp</label>
			<input type="text" class="form-control" id="frm_whatsapp" name="frm_whatsapp" value="<?=$whatsapp;?>" maxlength="20" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" />
		</div>
	</div>
	
	<div class="row">
		<div class="col">
			<label for="frm_email">Email</label>
			<input type="email" class="form-control" id="frm_email" name="frm_email" value="<?=$email;?>"  maxlength="80" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" /> 
		</div>
		<div class="col">
			<label for="frm_localidad">Localidad</label>
			<!--<input type="number" class="form-control" id="frm_localidad" name="frm_localidad" value="<?=$localidad_id;?>">    -->
			<select class="custom-select" id="frm_localidad" name="frm_localidad">
			<?php foreach($localidades as $item){?>
				<option value="<?=$item['id'];?>"  <?=$item['selectado'];?> ><?=$item['nombre'];?></option>
			<?php } ?>
			</select>
		</div>
	</div>
	
	<div class="row">
		<div class="col">
			<label for="exampleFormControlTextarea1" class="form-label">Observaciones</label>
			<textarea class="form-control" id="frm_observaciones" name="frm_observaciones" rows="3"><?=$observaciones;?></textarea>
		</div>
	</div>
	<div class="row">
		<div class="col">
			<label for="frm_tipo_ent">Tipo Entidad</label>
			<br>
			<?php foreach($tipo_entidad_arr as $item){?>
			    <input type="checkbox" 
				    id="frm_tipoe<?=$item['id'];?>" 
				    name="frm_tipoe<?=$item['id'];?>" 
				    value="<?=$item['id'];?>" <?=$item['selectado'];?> >
			    <label for="frm_tipo_ent"><?=$item['denominacion'];?> | </label>
			<?php } ?>
		</div>
	</div>
	


<script>

$("#frm_cuit" ).change(function(){
    var cCuit = $(this).val();

    console.log(validarCuit(cCuit)); // este es bueno

});




function valida_entidad(){
	console.log('valida entidad');
	return true;
}






function validarCuit(cuit) {
 
        if(cuit.length != 11) {
            return false;
        }
 
        var acumulado   = 0;
        var digitos     = cuit.split("");
        var digito      = digitos.pop();
 
        for(var i = 0; i < digitos.length; i++) {
            acumulado += digitos[9 - i] * (2 + (i % 6));
        }
 
        var verif = 11 - (acumulado % 11);
        if(verif == 11) {
            verif = 0;
        } else if(verif == 10) {
            verif = 9;
        }
 
        return digito == verif;
}
 
 










</script>



</form>
