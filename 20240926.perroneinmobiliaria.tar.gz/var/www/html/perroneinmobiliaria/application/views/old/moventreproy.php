<!-- header -->
<?php $this->load->view('header');?>

<!--
<style>
  p {
    color: blue;
    margin: 12px;
  }
  b {
    color: red;
  }
</style>
-->



<div id="dialog">
<p id="dialogMsg1"></p>
<p id="dialogMsg2"></p>
<div id="tablaApl"></div>
<div id="tablaPag"></div>
</div>

<div class="row">
	
<div class="main">
<!-- fin header -->

    <h5><b><?php echo $titulo ?></b></h5>

    <div style='padding-top:10px;padding-bottom:10px;'>
	<div class="row">
	    <div class="col-md-8">
		<div class="row">
		    <div class="col-md-12 btn btn-success">
			    Filtrar desde: <input type="date" name="frm_fdesde" id="frm_fdesde" value="<?=$fDesde;?>" >
			    <br>Filtrar hasta:         <input type="date" name="frm_fhasta" id="frm_fhasta" value="<?=$fHasta;?>" >
		    </div>
		</div>
	    </div>
	    <div class="col-md-2">
		<button type="button" class="btn btn-primary" id="buscar">Buscar</button>
	    </div>
	    <div class="col-md-2">
		<a id="llamaCB" class="btn btn-success" ><i class="material-icons">&#xE147;</i> <span>Nuevo Movimiento</span></a>
	    </div>
	</div>
    </div>
<!--
	    data-remember-order="true"
	    data-side-pagination="server"
	    data-search="true"
	    data-page-list="[10, 25, 50, All]"
	    data-pagination="true"

-->

<div class="container-fluid">
    <div class="row">
        <div class="col-xs-12">

	<table class="tbodyalt"
	    id="table"
	    data-toggle="table"
	    data-height="500"
	    <?php echo $elurl ?> >

	    <thead>
	    <tr>

		<?php foreach( $campos as $cr){ ?>
		    <th class="text-right" data-field="<?php echo $cr[0] ?>" <?php echo $cr[1] ?>  ><?php echo $cr[2] ?></th>
		<?php } ?>

	    </tr>
	    </thead>
	</table>

        </div>
    </div>
</div>




<script>

function fn_action(value, row) {

    if (row.mb_id > 0){
	retD  = '<a  class="btn btn-danger"  onclick="return confirm(\'¿Confirma eliminar?\')" href="<?php echo $urldel ?>?id='+row.mb_id+'"><i class="fa fa-trash"></i></a>';
	return  retD;
    }
}

$(document).ready(function() {

    $( "#buscar" ).click(function() {
	fdesde = $("#frm_fdesde").val();
	fhasta = $("#frm_fhasta").val();
	$('#table').bootstrapTable("refresh", {
	    url: "<?php echo $urlrecupag ?>",
	    query: { fDesde: fdesde, fHasta: fhasta }
	});
    });

    $("#llamaCB").click(function(){
	abrirFormulario('/index.php/Moventreproy/cargaFormulario?name=frm-moventreproy','Nuevo Movimiento');
    });

    $("#dialog").dialog({
	autoOpen: false,
	modal: true,
	buttons: {
	    "Cerrar": function () {
		$(this).dialog("close");
	    }
	}
    });

})

</script>
<!-- footer -->
</div>
</div>
<?php $this->load->view('footer');?>
<!-- fin footer -->
