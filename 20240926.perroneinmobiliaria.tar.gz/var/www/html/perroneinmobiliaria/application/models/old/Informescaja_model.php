<?php

class Informescaja_model extends CI_Model {						// **->

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function __construct() {
	$this->config->load('nocrud_informes_caja.php');				// **->
	$this->load->database();
	$this->load->helper('funciones_helper');
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function XXdevuelveCaInforme($elGet){
	$idProyecto = $this->session->id_proyecto_activo;
	$desde      = $elGet['fdesde'];
	$hasta      = $elGet['fhasta'];
	$sql        = "SELECT
			     SUM(entradasMN) AS saldoemn
			    ,SUM(salidasMN)  AS saldosmn
			    ,SUM(entradasUS) AS saldoeus
			    ,SUM(salidasUS)  AS saldosus
			FROM vi_ctas_ctes_caja
			WHERE cc_proyecto_id = $idProyecto
			  AND cc_estado = 0
			  AND cc_fecha < '$desde'";
	$queryC     = $this->db->query($sql);
	$querySC    = $queryC->result_array();
	$saldoMN    = $querySC[0]['saldoemn'] - $querySC[0]['saldosmn'];
	$saldoUS    = $querySC[0]['saldoeus'] - $querySC[0]['saldosus'];
	$primRegC   = array(  'ccc_cuenta_corriente_id' => ''
			    , 'cc_fecha'                => ''
			    , 'tc_abreviadonume'        => '<b>Saldo Anterior</b>'
			    , 'tmc_descripcion'         => ''
			    , 'ccc_comentario'          => ''
			    , 'ccc_importe_divisa'      => ''
			    , 'mo1_simbolo'             => ''
			    , 'entradasmn'              => ''
			    , 'salidasmn'               => ''
			    , 'saldosmn'                => '<b>'.number_format($saldoMN,2).'</b>'
			    , 'entradasus'              => ''
			    , 'salidasus'               => ''
			    , 'saldosus'                => '<b>'.number_format($saldoUS,2).'</b>'
			    , 'banco'                   => ''
			    , 'serienume'               => ''
			    , 'ccc_fecha_emision'       => null
			    , 'ccc_fecha_acreditacion'  => ''
			    , 'ccc_e_chq'               => ''
			    , 'cc_entidad_id'           => null
			    , 'en_razon_social'         => null);
	$sql        = "SELECT 
			     ccc_cuenta_corriente_id
			    ,cc_fecha
			    ,tc_abreviado ||' '||cc_numero::text AS tc_abreviadonume
			    ,tmc_descripcion
			    ,ccc_comentario
			    ,ccc_importe_divisa
			    ,mo1_simbolo
			    ,entradasmn
			    ,salidasmn
			    ,0 AS saldosmn
			    ,entradasus
			    ,salidasus
			    ,0 AS saldosus
			    -- ,COALESCE(ba1_denominacion,ba2_denominacion,'') as banco
			    -- ,ccc_serie||LPAD(ccc_numero::text,8,'0') AS serienume
			    -- ,ccc_fecha_emision
			    -- ,ccc_fecha_acreditacion
			    ,substring(' E' ,ccc_e_chq+1,1) AS ccc_e_chq
			    ,cc_entidad_id
			    ,en_razon_social
			    ,COALESCE(ba3_denominacion,ba2_denominacion) AS banco
			    ,CASE WHEN ccc_numero IS NOT NULL THEN ccc_serie||LPAD(ccc_numero::text,8,'0')
				  WHEN ccch_numero IS NOT NULL THEN ccch_serie||LPAD(ccch_numero::text,8,'0') 
			     END AS serienume
			    ,to_char(COALESCE(ccch_fecha_emision,ccc_fecha_emision),'dd-mm-yyyy') AS f_emision
			    ,to_char(COALESCE(ccch_fecha_acreditacion,ccc_fecha_acreditacion),'dd-mm-yyyy') AS f_acreditacion
			    FROM vi_ctas_ctes_caja
			    WHERE cc_proyecto_id = $idProyecto
			      AND cc_estado = 0
			      AND cc_fecha BETWEEN '$desde' AND '$hasta'
			    ORDER BY cc_fecha ";

/* aca estan el banco y fechas cuando son de 3ros 
	$sqlP = "SELECT   ccc_importe
			, ccc_importe_divisa
			, mo1_denominacion
			, mo1_simbolo
			, tmc_descripcion
			, ccc_comentario,ccc_id
			, ba2_denominacion
			, to_char(ccc_fecha_emision,'dd-mm-yyyy') AS ccc_f_emi_dmy
			, to_char(ccc_fecha_acreditacion,'dd-mm-yyyy') AS ccc_f_acre_dmy
			, ccc_serie||' '||LPAD(ccc_numero::text,8,'0') AS serienro
			,cb_denominacion 
			,COALESCE(ba3_denominacion,ba2_denominacion) AS banco
			,to_char(COALESCE(ccch_fecha_emision,ccc_fecha_emision),'dd-mm-yyyy') AS f_emision
			,to_char(COALESCE(ccch_fecha_acreditacion,ccc_fecha_acreditacion),'dd-mm-yyyy') AS f_acreditacion
		FROM vi_ctas_ctes_caja WHERE ccc_cuenta_corriente_id = ?";
*/

	$queryC     = $this->db->query($sql);
	$queryRC    = $queryC->result_array();
	for($i = 0 ; $i < count($queryRC) ; $i++){
	    $saldoMN += ($queryRC[$i]['entradasmn']+0) - ($queryRC[$i]['salidasmn']+0);
	    $queryRC[$i]['entradasmn']  = ($queryRC[$i]['entradasmn']>0)  ? number_format($queryRC[$i]['entradasmn'] ,2):'';
	    $queryRC[$i]['salidasmn']   = ($queryRC[$i]['salidasmn']>0)   ? number_format($queryRC[$i]['salidasmn'],2):'';
	    $queryRC[$i]['saldosmn']    = '<b>'.number_format($saldoMN,2).'</b>';
	    $saldoUS += ($queryRC[$i]['entradasus']+0) - ($queryRC[$i]['salidasus']+0);
	    $queryRC[$i]['entradasus']  = ($queryRC[$i]['entradasus']>0) ? number_format($queryRC[$i]['entradasus'] ,2):'';
	    $queryRC[$i]['salidasus']   = ($queryRC[$i]['salidasus']>0)  ? number_format($queryRC[$i]['salidasus'],2):'';
	    $queryRC[$i]['saldosus']    = '<b>'.number_format($saldoUS,2).'</b>';
	}
	array_unshift($queryRC, $primRegC);
	$ultRegC    = array(  'ccc_cuenta_corriente_id' => ''
			    , 'cc_fecha'                => ''
			    , 'tc_abreviadonume'        => '<b>Saldo Final</b>'
			    , 'tmc_descripcion'         => ''
			    , 'ccc_comentario'          => ''
			    , 'ccc_importe_divisa'      => ''
			    , 'mo1_simbolo'             => ''
			    , 'entradasmn'              => ''
			    , 'salidasmn'               => ''
			    , 'saldosmn'                => '<b>'.number_format($saldoMN,2).'</b>'
			    , 'entradasus'              => ''
			    , 'salidasus'               => ''
			    , 'saldosus'                => '<b>'.number_format($saldoUS,2).'</b>'
			    , 'banco'                   => ''
			    , 'serienume'               => ''
			    , 'f_emision'       => null
			    , 'f_acreditacion'  => ''
			    , 'ccc_e_chq'               => ''
			    , 'cc_entidad_id'           => null
			    , 'en_razon_social'         => null);
	$queryRC[] = $ultRegC;
//	$queryRC = array_reverse($queryRC);  2022-11-02 pidio q se ordenen por fecha de manor a mayor
	return $queryRC;
    }


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function devuelveCaInforme($elGet){
	$idProyecto = $this->session->id_proyecto_activo;
	$desde      = $elGet['fdesde'];
	$hasta      = $elGet['fhasta'];
	$soloProy   = $elGet['soloproy'];
	$filProy    = "";
	if ($soloProy == "true"){
	    $filProy = " AND COALESCE( cc_proyecto_id, ccc_proyecto_id) = $idProyecto ";
	}

	$sql        = "SELECT
			SUM(CASE WHEN tmc_gestiona_cheques = 0 AND ccc_moneda_id = 1 THEN entradas_caja_mn - salidas_caja_mn
			    ELSE 0
			END) AS efectivomn,
			SUM(CASE WHEN tmc_gestiona_cheques = 0 AND ccc_moneda_id <> 1 THEN entradas_caja_us - salidas_caja_us
			    ELSE 0
			END) AS efectivous,
			SUM(CASE WHEN tmc_gestiona_cheques = 1 AND ccc_chq_a_depo = 1 THEN entradas_caja_mn - salidas_caja_mn
			    ELSE 0
			END) AS cheques,
			SUM(CASE WHEN tmc_gestiona_cheques = 1  AND ccc_chq_a_depo IS NULL THEN entradas_caja_mn - salidas_caja_mn
			    ELSE 0
			END) AS cheques_no_depo
			FROM vi_ctas_ctes_caja
			WHERE ccc_fecha_registro::date < '$desde' 
			  AND tmc_mov_en_banco NOT IN ( 2, 4, 5)
			$filProy";

//tmc_mov_en_banco NOT IN ( 2, 4, 5)
//no debe mostrar 2->chq y pagos x banco, 4->retenciones, 5->canjes 



	$queryC     = $this->db->query($sql);
	$querySC    = $queryC->result_array();
	$saldoMN    = $querySC[0]['efectivomn'];
	$saldoUS    = $querySC[0]['efectivous'];
	$saldoChq   = $querySC[0]['cheques'];
	$saldoChqND = $querySC[0]['cheques_no_depo'];
	$primRegC   = array(  'cc_fecha'                => ''
			    , 'tc_abreviadonume'        => '<b>Saldo Anterior</b>'
			    , 'tmc_descripcion'         => ''
			    , 'ccc_comentario'          => ''
			    , 'ccc_importe_divisa'      => ''
			    , 'efectivomn'              => '<b>'.number_format($saldoMN,2).'</b>'
			    , 'efectivous'              => '<b>'.number_format($saldoUS,2).'</b>'
			    , 'cheques'                 => '<b>'.number_format($saldoChq,2).'</b>'
			    , 'cheques_no_depo'         => '<b>'.number_format($saldoChqND,2).'</b>'
			    , 'el_chq'                  => ''
			    , 'ccc_fecha_emision'       => ''
			    , 'ccc_fecha_acreditacion'  => ''
			    , 'ccc_e_chq'               => ''
			    , 'cc_entidad_id'           => null
			    , 'en_razon_social'         => ''
			    , 'cc_proyecto_id'          => ''
			    , 'ccc_fecha_registro'      => '');

	$sql        = "SELECT
			ccc_id,
			ccc_cuenta_corriente_id,
			tc_abreviado ||' '||cc_numero::text AS tc_abreviadonume,
			tmc_txt_info_caja AS tmc_descripcion,
			ccc_comentario,
			cc_fecha,
			tc_abreviado,
			cc_entidad_id,
			ccc_proyecto_id,

			COALESCE( cc_proyecto_id, ccc_proyecto_id) AS xcc_proyecto_id,
			COALESCE( pr_nombre, prc_nombre) AS pr_nombre,

			en_razon_social,
			ccc_importe,
			tc_signo,
			tmc_e_chq,
			substring(' E' ,ccc_e_chq+1,1) AS ccc_e_chq,
			ba2_denominacion ||' '||ccc_serie||ccc_numero::text||' '||substring(' E' ,ccc_e_chq+1,1)  AS el_chq,
			ccc_fecha_emision,
			ccc_fecha_acreditacion,
			ccc_importe_divisa,

			CASE WHEN tmc_gestiona_cheques = 0 AND ccc_moneda_id = 1 THEN entradas_caja_mn - salidas_caja_mn
			    ELSE 0
			END AS efectivomn,

			CASE WHEN tmc_gestiona_cheques = 0 AND ccc_moneda_id = 2 THEN entradas_caja_us - salidas_caja_us
			    ELSE 0
			END AS efectivous,


			CASE WHEN tmc_gestiona_cheques = 1 AND ccc_chq_a_depo = 1 THEN entradas_caja_mn - salidas_caja_mn
			    ELSE 0
			END AS cheques,

			CASE WHEN tmc_gestiona_cheques = 1  AND ccc_chq_a_depo IS NULL THEN entradas_caja_mn - salidas_caja_mn
			    ELSE 0
			END AS cheques_no_depo,

			ccc_fecha_registro::date AS ccc_fecha_registro

			FROM vi_ctas_ctes_caja
			WHERE ccc_fecha_registro::date BETWEEN '$desde' AND '$hasta'
			  AND tmc_mov_en_banco NOT IN ( 2, 4, 5)

			$filProy
			ORDER BY ccc_fecha_registro, tc_abreviadonume ";
wh_log("info caja");
wh_log($sql);



	$queryC     = $this->db->query($sql);
	$queryRC    = $queryC->result_array();
	for($i = 0 ; $i < count($queryRC) ; $i++){
	    $saldoMN    += ($queryRC[$i]['efectivomn']+0) - ($queryRC[$i]['salidasmn']+0);
	    $saldoUS    += ($queryRC[$i]['efectivous']+0) - ($queryRC[$i]['salidasus']+0);
	    $saldoChq   += ($queryRC[$i]['cheques']+0);
	    $saldoChqND += ($queryRC[$i]['cheques_no_depo']+0);
	}
	array_unshift($queryRC, $primRegC);

	$ultRegC    = array(  'cc_fecha'                => ''
			    , 'tc_abreviadonume'        => '<b>Saldo Final</b>'
			    , 'tmc_descripcion'         => ''
			    , 'ccc_comentario'          => ''
			    , 'ccc_importe_divisa'      => ''
			    , 'efectivomn'              => '<b>'.number_format($saldoMN,2).'</b>'
			    , 'efectivous'              => '<b>'.number_format($saldoUS,2).'</b>'
			    , 'cheques'                 => '<b>'.number_format($saldoChq,2).'</b>'
			    , 'cheques_no_depo'         => '<b>'.number_format($saldoChqND,2).'</b>'
			    , 'el_chq'                  => ''
			    , 'ccc_fecha_emision'       => ''
			    , 'ccc_fecha_acreditacion'  => ''
			    , 'ccc_e_chq'               => ''
			    , 'cc_entidad_id'           => null
			    , 'en_razon_social'         => ''
			    , 'cc_proyecto_id'          => ''
			    , 'ccc_fecha_registro'      => ''
			    , 'pr_nombre'               => '');

	$queryRC[] = $ultRegC;

	return $queryRC;
    }


}