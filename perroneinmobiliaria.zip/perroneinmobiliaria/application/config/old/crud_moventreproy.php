<?php
defined('BASEPATH') OR exit('No direct script access allowed');


//se debe colocar el nombre correspondiente al crud, una sola palabra y comenzando con mayuscula
$config['nombreCrud']   = 'Moventreproy';

$config['nombreTabla']  = 'moventreproy';
$config['nombreVista']  = 'vi_moventreproy';

//componer los campos de acuerdo a la vista correspondiente para el crud
$config['camposGrilla'] = array(array("mb_id"                 ,'data-sortable ="false"'     ,"ID"         ),
				array("mb_fecha"              ,'data-sortable ="false"'     ,"Fecha"      ),
				array("importe_c_signo_mn"    ,'data-sortable ="false"'     ,"Importe $"  ),
				array("importe_c_signo_us"    ,'data-sortable ="false"'     ,"Importe u$s"),
				array("ccc_cotizacion_divisa" ,'data-sortable ="false"'     ,"Cotización" ),
				array("mb_comentario"         ,'data-sortable ="false"'     ,"Comentario" ),
				array("lo_id"                 ,'data-formatter="fn_action"' ,"Acciones"   ) );

$config['searchGrilla']     = "mb_id::text,mb_fecha::text,importe_c_signo::text,mb_comentario";
$config['urlRecuChqCart']   = '/index.php/'.$config['nombreCrud'].'/recuChqCart';

//////////////////////////////////////////////////////////////////////////
//esto no se debe tocar, son configuraciones fijas para cualquier crud  //
//////////////////////////////////////////////////////////////////////////
$config['urlGrid']      = 'data-url="' . base_url('index.php/'.$config['nombreCrud'].'/recuperaPagina') . '"'; //url de la funcion q necesita la tabla para paginar, filtrar, ordenar
$config['modelo']       = $config['nombreCrud'].'_model';
$config['vista']        = strtolower($config['nombreCrud']);
$config['urlDel']       = '/index.php/'.$config['nombreCrud'].'/eliminaRegistro';
$config['urlForm']      = '/index.php/'.$config['nombreCrud'].'/cargaFormulario';


