<?php
namespace App\ThirdParty;
namespace App\Controllers;

require APPPATH.'ThirdParty/dompdf/autoload.inc.php';
require APPPATH.'ThirdParty/dompdf/lib/Cpdf.php';

use Dompdf\Dompdf;

define("DOMPDF_ENABLE_REMOTE", true);
use App\Libraries\GroceryCrud;
use CodeIgniter\Database\Query;
use App\Models\ContratosModel;
class Listado_ventas extends BaseController {
    public $id_contrato;
	function __construct(){	
        $db = db_connect();
        helper('url');
        helper('admin_helper');
		$db = \Config\Database::connect();       
		$data['cliente']=get_cliente_info($id);
		$crud = new GroceryCrud();     
        $crud->setTheme('datatables'); //flexigrid tiene bugs

        $crud->setTable('vi_contratos');
        $crud->setPrimaryKey('cc_id', 'vi_contratos'); 
	}
	
	public function index(){
		 
	}
	
	public function ventas($id){  
        $db = \Config\Database::connect();       
		$data['cliente']=get_cliente_info($id);
        // Collect the Data
        /*
		[id] => 1
        [nombre] => Nicolás
		[documento_nro] => 33107916
		[calle] => Zelarrayán
		[numero] => 1511
		[departamento] => 
		[longitud] => 
		[latitud] => 
		[localidad_id] => 16353
		[calle_cobro] => 
		[numero_cobro] => 
		[departamento_cobro] => 
		[longitud_cobro] => 
		[latitud_cobro] => 
		[localidad_cobro_id] => 16353
		[cobrador_id] => 2
		[cobrador_original_id] => 1
*/
       
        //--------------------------NUEVO GROCERY CRUD--------------------------//
        $crud = new GroceryCrud();     
        $crud->setTheme('datatables'); //flexigrid tiene bugs

        $crud->setTable('vi_contratos');
        $crud->setPrimaryKey('cc_id', 'vi_contratos');  
		$crud->setApiUrlPath(get_direccion("ventas").$cliente_id);
		$this->id_contrato=$id;
		//--------------------------NUEVO GROCERY CRUD--------------------------//
		
		//------------------------------ALIGN RIGHT-----------------------------//
		$array_ids=[];
		//------------------------------ALIGN RIGHT-----------------------------//
		$array_ids=$crud->callbackColumn('cc_importe',array($this,'_column_bonus_right_align'));
		$crud->callbackColumn('cc_importe',array($this,'_column_bonus_right_align'));
		$crud->callbackColumn('cc_valor_cuota',array($this,'_column_bonus_right_align'));
        //$crud->callbackColumn('calculabalancecontrato(`cc`.`id`)',array($this,'_column_bonus_right_align'));
		//------------------------------ALIGN RIGHT-----------------------------//
		
		//---------------------------------UNSET--------------------------------//
		$crud->unsetAdd();
		$crud->unsetEdit();
		$crud->unsetDelete();
		$crud->setExport();
		//---------------------------------UNSET--------------------------------//
		
		//---------------------------------JOINS--------------------------------//
		//$crud->setRelation('localidad_id', 'localidades', 'nombre', ['estado' => '1']); //este join aplica un where al final
		//$crud->setRelation('localidad_cobro_id', 'localidades', 'nombre', ['estado' => '1']); 
		//$crud->setRelation('cobrador_id', 'cobradores', 'nombre');		
		//$crud->setRelation('cliente_id', 'clientes', 'nombre');
		//$crud->setRelation('articulo_id', 'articulos', 'descripcion');
		//$crud->setRelation('tipomovimiento_id', 'movimientos_positivos', 'descripcion');
        //---------------------------------JOINS--------------------------------//        
        
        //---------------------------------WHERE--------------------------------//        
        $crud->where('cc_cliente_id',$id);
        $crud->where('cc_tipomovimiento_id',1);
        //$crud->where('movimientos_positivos.signo = 1');        
        //---------------------------------WHERE--------------------------------//        
        
		//--------------------------ETIQUETAS COLUMNAS--------------------------//
		$crud->displayAs('montocontrato', 'Monto');
		$crud->displayAs('cc_valor_cuota', 'Valor Cuota');
		$crud->displayAs('cc_intervalo', 'Intervalo Cuota');
		$crud->displayAs('cc_cantidad_cuotas', 'Cantidad Cuotas');		
		$crud->displayAs('cc_fecha', 'Fecha');
		$crud->displayAs('c_nombre', 'Nombre Cobrador');
		$crud->displayAs('importecuota', 'Valor Cuota');
		$crud->displayAs('cc_id', 'ID Contrato');
		$crud->displayAs('cuotas_restantes', 'Cuotas Restantes');
		$crud->displayAs('cuotas_no_pagadas', 'Cuotas Impagas');
		//$crud->displayAs('calculabalancecontrato(`cc`.`id`)', 'Balance');
		//--------------------------ETIQUETAS COLUMNAS--------------------------//
		
		$crud->columns    (['cc_fecha',
				    'cc_id',
				    'cc_cantidad_cuotas',
				    'cuotas_pagadas',   
				    'cuotas_restantes',
				    'cuotas_no_pagadas',
				    'c_nombre',
				    'montocontrato',
				    'saldo',
				    'morosidad',
				    'importecuota'
                            ]);

	//no funciona $crud->defaultOrdering('cc_fecha' , 'DESC');

        
        //$crud->addAction('Ver Documentos Relacionados', '../../../images/eye-solid.svg','clientes/action_more','ui-icon-plus');
        
        //$crud->defaultOrdering('clientes.id', 'asc');
        
        //--------------------------SET ACTION BUTTON---------------------------//

		$crud->setActionButton('Ver Pagos', 'fa fa-eye', function ($row) {			
			return (site_url('listado_pagos/pagos/').$row);
		}, false);		
		//Si $row no devuelve valor, revisar que setTable y setPrimaryKey estén bien bien declaradas
		$crud->setActionButton('Imprimir Contrato', 'fa fa-eye', function ($row) {			
			return (base_url('index.php/listado_ventas/imprimir_contrato','https')."/".$row);
		}, false);
		$crud->setActionButton('Borrar', 'fa fa-trash', function ($row) {	
			return (site_url('borrar_contrato/borrarcontratos/').$row);
		}, false);
        //--------------------------SET ACTION BUTTON---------------------------//
		//$crud->callback_column('bonus_value',array($this,'_column_bonus_right_align'));
		
		
		
		
		$comp= $_SERVER['REQUEST_URI'];
		if (strpos($comp, 'print') == false){
			$crud->callbackColumn('cc_fecha', function ($value, $row){
				return "<span style='visibility:hidden;display:none;'>".date('Y-m-d', strtotime($value))."</span>".date('d/m/Y', strtotime($value));
			});
			$crud->callbackColumn('morosidad', function ($value, $row){
				//style="background-color:green; color:white;"
				switch (true){				
					case $value <= 10.01: 					
						$clase =  'class="morosidad-verde numero"';
						break;
					case $value <= 50: 					
						$clase =  'class="morosidad-amarillo numero"';
						break;
					case $value <= 100: 					
						$clase =  'class="morosidad-rojo numero"';
						break;	
						
					}
				return "<span ".$clase."'>".$value."%</span>";
			});
		}
		else{
			$crud->callbackColumn('cc_fecha', function ($value, $row){
				return date('d/m/Y', strtotime($value));
			});
			$crud->callbackColumn('morosidad', function ($value, $row){				
				return "<span>".$value."%</span>";
			});			
		}
		$crud->callbackColumn('cc_cantidad_cuotas', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('cuotas_restantes', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('cuotas_pagadas', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});		
		$crud->callbackColumn('cuotas_no_pagadas', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});	
		$crud->callbackColumn('saldo', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('montocontrato', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('importecuota', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		
        $data['output'] = $crud->render();   
		$searchVal = "http://";
		$replaceVal = "https://";
		//------------------------reemplaza los "http" de los archivos de estilo por "https" ------------------------//
		$data['output']->js_files = str_replace($searchVal, $replaceVal, $data['output']->js_files);
		$data['output']->css_files = str_replace($searchVal, $replaceVal, $data['output']->css_files);
		$data['output']->js_lib_files = str_replace($searchVal, $replaceVal, $data['output']->js_lib_files);
		//------------------------reemplaza los "http" de los archivos de estilo por "https" ------------------------//
		$data['id_cliente']=$id;
		
		//print_r $output;
		//echo view('templates/header',$data);
        //$this->load->view('listado_ventas',$data);
		
		$encabezado = generar_encabezado();		
		echo view($encabezado,$data);
        echo view('listado_ventas',$data);
		echo view('templates/footer',$data);
        /*
		$data['usuario_id']=$id;
		
        $data['output'] = $crud->render();
		$this->load->view('listado_facturas',$data);
        */
        //die();
    }
    function _column_bonus_right_align($value,$row){
        return "<span style=\"width:100%;text-align:right;display:block;\">".$value."</span>";
    }
    public function contratos($id_cobrador){
		
		$crud = new GroceryCrud();     
        $crud->setTheme('datatables'); //flexigrid tiene bugs

        $crud->setTable('vi_contratos');
        $crud->setPrimaryKey('cc_id', 'vi_contratos');  
		$crud->setApiUrlPath(get_direccion("ventas_cobradores").$id_cobrador);
		//$this->id_contrato=$id;
		$this->insert_id = $id_cobrador;			
		
		$data['cobrador']=get_cobrador_info($id_cobrador);
		// 06/08/2021 usar el cálculo de balance para mostrar cuáles contratos siguen pendientes y cuáles no
		//------------------------------SET & UNSET-----------------------------//
		//$crud->setRead();
		$crud->unsetEdit();
		$crud->unsetDelete();
		$crud->setExport();
		//$crud->setPrint();		
		$crud->unsetAdd();
		//------------------------------SET & UNSET-----------------------------//
		
		//---------------------------------JOINS--------------------------------//
		//$crud->setRelation('cliente_id', 'clientes', 'nombre');         
		//$crud->setRelation('articulo_id', 'articulos', 'descripcion'); 
		//$crud->setRelation('cobrador_id', 'cobradores', 'nombre');
		//$crud->setRelation('vendedor_id', 'cobradores', 'nombre');
		//$crud->setRelation('tipomovimiento_id', 'tipos_movimientos', 'descripcion', ['id' => 1]);
        //---------------------------------JOINS--------------------------------//        
        
		//---------------------------------WHERE--------------------------------//        
        //$crud->where('tipomovimiento_id = 1');
        //print_r($id_cliente);
        //$crud->where('cliente_id', "1");
		$crud->where('cc_cobrador_id', $id_cobrador);
        //---------------------------------WHERE--------------------------------//        
        
		//--------------------------ETIQUETAS COLUMNAS--------------------------//
		$crud->displayAs('montocontrato', 'Monto');
		$crud->displayAs('cc_valor_cuota', 'Valor Cuota');
		$crud->displayAs('cc_intervalo', 'Intervalo Cuota');
		$crud->displayAs('cc_cantidad_cuotas', 'Cantidad Cuotas');
		$crud->displayAs('cc_fecha', 'Fecha');
		$crud->displayAs('cl_nombre', 'Nombre Cliente');
		$crud->displayAs('importecuota', 'Valor Cuota');
		$crud->displayAs('cuotas_restantes', 'Cuotas Restantes');
		$crud->displayAs('cc_id', 'ID Contrato');
		
		
		//--------------------------ETIQUETAS COLUMNAS--------------------------//
        //id	fecha	cliente_id	tipomovimiento_id	cantidad_cuotas	intervalo	cobrador_id	fecha_inicio_cobro	vendedor_id	X_importe	X_valor_cuota
		//-------------------------------COLUMNAS-------------------------------//
		$crud->columns([	'cc_fecha',
							'cc_id',
							'cl_nombre',
							'cc_cantidad_cuotas',
							'cuotas_pagadas',
							'cuotas_restantes',
							'montocontrato',
							'saldo',							
							'morosidad',							
							'importecuota'							
                        ]);	
        //-------------------------------COLUMNAS-------------------------------//
		$comp= $_SERVER['REQUEST_URI'];
		if (strpos($comp, 'print') == false){
			$crud->callbackColumn('cc_fecha', function ($value, $row){
				return "<span style='visibility:hidden;display:none;'>".date('Y-m-d', strtotime($value))."</span>".date('d/m/Y', strtotime($value));
			});
			$crud->callbackColumn('morosidad', function ($value, $row){
				//style="background-color:green; color:white;"
				switch (true){				
					case $value <= 10.01: 					
						$clase =  'class="morosidad-verde numero"';
						break;
					case $value <= 50: 					
						$clase =  'class="morosidad-amarillo numero"';
						break;
					case $value <= 100: 					
						$clase =  'class="morosidad-rojo numero"';
						break;	
						
					}
				return "<span ".$clase."'>".$value."%</span>";
			});
		}
		else{
			$crud->callbackColumn('cc_fecha', function ($value, $row){
				return date('d/m/Y', strtotime($value));
			});
			$crud->callbackColumn('morosidad', function ($value, $row){				
				return "<span>".$value."%</span>";
			});			
		}
		$crud->callbackColumn('cc_cantidad_cuotas', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('cuotas_pagadas', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});		
		$crud->callbackColumn('cuotas_restantes', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('saldo', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('montocontrato', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		$crud->callbackColumn('importecuota', function ($value, $row){			
			return '<span class="numero">'.$value.'</span>';
		});
		
		
		$crud->setActionButton('Ver Pagos', 'fa fa-eye', function ($row) {			
			return (site_url('listado_pagos/pagos_cobradores/').$row);
			//'listado_pagos/pagos/'
		}, false);	
		$crud->setActionButton('Borrar', 'fa fa-trash', function ($row) {	
			return (site_url('borrar_contrato/borrarcontratoscobrador/').$row);
		}, false);
		$crud->setActionButton('Reasignar', 'fa fa-pencil', function ($row) {	
			return (site_url('reasignar_contrato/reasignarcontratos/').$row);
		}, false);
		$crud->setActionButton('Imprimir Contrato', 'fa fa-print', function ($row) {			
			return (base_url('index.php/listado_ventas/imprimir_contrato','https')."/".$row);
		}, false);		
		
		$data['linkvolver'] = get_direccion('cobradores');
		$data['output'] = $crud->render();
		$searchVal = "http://";
		$replaceVal = "https://";
		//------------------------reemplaza los "http" de los archivos de estilo por "https" ------------------------//
		$data['output']->js_files = str_replace($searchVal, $replaceVal, $data['output']->js_files);
		$data['output']->css_files = str_replace($searchVal, $replaceVal, $data['output']->css_files);
		$data['output']->js_lib_files = str_replace($searchVal, $replaceVal, $data['output']->js_lib_files);
		//------------------------reemplaza los "http" de los archivos de estilo por "https" ------------------------//
		
		$encabezado = generar_encabezado();		
		echo view($encabezado,$data);
		echo view('listado_cobradores_contratos',$data);
		echo view('templates/footer');
		
		
		
		
	}
	function imprimir_contrato($id_transaccion){	
		$info_contrato = get_contrato_parametros($id_transaccion);
		$model = new ContratosModel();
		//$date = date('Y-m-d H:i:s', strtotime($first_date);
		//print_r($info_contrato);
		$data['id'] 									= $info_contrato->cc_id;
		$data['cuentas_corrientes_fecha_inicio_cobro'] 	= date('d-m-Y', strtotime($info_contrato->cc_fecha_inicio_cobro));
		$data['cliente_nombre'] 						= $info_contrato->cl_nombre;
		$data['cliente_documento'] 						= $info_contrato->cl_documento_nro;
		$data['cliente_celular']						= $info_contrato->cl_celular;
		$data['cliente_celular_whatsapp']				= $info_contrato->cl_celular_whatsapp;
		$data['cliente_calle'] 							= $info_contrato->direccion;
		$data['localidad_nombre'] 						= $info_contrato->localidad_nombre;
		$data['articulo_codigo'] 						= $info_contrato->ar_codigo;
		$data['articulo_nombre'] 						= $info_contrato->ar_descripcion;
		$data['articulo_cantidad_num'] 					= $info_contrato->articulo_cantidad;
		$data['articulo_cantidad_letra'] 				= tranumlet_articulo($info_contrato->articulo_cantidad);
		$data['cuentas_corrientes_cantidad_cuotas'] 	= $info_contrato->cc_cantidad_cuotas;
		$data['cuentas_corrientes_importe_cuota_letra'] = tranumlet(($info_contrato->importecuota));
		$data['cuentas_corrientes_importe_cuota_num'] 	= ($info_contrato->importecuota);
		$data['cuentas_corrientes_importe_total'] 		= tranumlet($info_contrato->montocontrato);
		$data['remito_num'] 							= $info_contrato->remito_num;
		
		/*
		$data['id'] 									= $info_contrato->id;
		$data['cuentas_corrientes_fecha_inicio_cobro'] 	= date('d-m-Y', strtotime($info_contrato->fecha_inicio_cobro));
		$data['cliente_nombre'] 						= $info_contrato->cliente_nombre;
		$data['cliente_documento'] 						= $info_contrato->documento_nro;
		$data['cliente_celular']						= $info_contrato->cliente_celular;
		$data['cliente_celular_whatsapp']				= $info_contrato->cliente_celular_whatsapp;
		$data['cliente_calle'] 							= $info_contrato->cliente_direccion;
		$data['localidad_nombre'] 						= $info_contrato->localidad_nombre;
		$data['articulo_codigo'] 						= $info_contrato->articulo_codigo;
		$data['articulo_nombre'] 						= $info_contrato->articulo_nombre;
		$data['articulo_cantidad'] 						= $info_contrato->articulo_cantidad;
		$data['cuentas_corrientes_cantidad_cuotas'] 	= $info_contrato->cantidad_cuotas;
		$data['cuentas_corrientes_importe_cuota_letra'] = tranumlet(($info_contrato->importe_cuota*$data['articulo_cantidad']));
		$data['cuentas_corrientes_importe_cuota_num'] 	= ($info_contrato->importe_cuota*$data['articulo_cantidad']);
		$data['cuentas_corrientes_importe_total'] 		= tranumlet($info_contrato->importe_total);
		$data['remito_num'] 							= $info_contrato->remito_num;
		*/
		$fecharemito									= date('d-m-Y', strtotime($info_contrato->remito_fecha));
		//------------------------Si no existe fecha remito, se toma fecha de inicio del cobro---------------------//
		$fechacontrato									= date('d-m-Y', strtotime($info_contrato->cc_fecha));
		if ($fecharemito=="31-12-1969"){
			//$model->crearRemito($data['id'], $info_contrato->cc_fecha);
			
			$data['remito_fecha'] 						= date('d-m-Y', strtotime($info_contrato->cc_fecha));
			
		}
		else{
			$data['remito_fecha'] 						= date('d-m-Y', strtotime($info_contrato->remito_fecha));
		}
		
		$path = '/var/www/html/cobrosdiarios-desa/assets/img/logo_remito_1.jpg';		
		$type = pathinfo($path, PATHINFO_EXTENSION);
		$data_img = file_get_contents($path);
		$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data_img);
		$data['logo_remito']=$base64;
		//echo view('pdf_view',$data);
		
		$dompdf = new \Dompdf\Dompdf();
		//$dompdf->stream($fileNo.$name.$description.".pdf");

		$dompdf->loadHtml(view('pdf_view',$data));
		$dompdf->setPaper('A4');
		$dompdf->set_base_path("/www/cobrosdiarios-desa/assets/css/");
		$dompdf->render();
		$dompdf->stream("Contrato-".$data['id']."-".$fechacontrato.".pdf");
		
	}
}
