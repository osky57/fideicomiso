<?php $this->load->view('header');?>
<div class="row">
	
	<div class="main">
		<!-- Content Here -->
		

		<? echo $output; ?>
	</div>
</div>
<?php $this->load->view('footer');?>