<div id="message_box" class="footer fixed-bottom"></div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.1/js/bootstrap.min.js" integrity="sha512-UR25UO94eTnCVwjbXozyeVd6ZqpaAE9naiEUBK/A+QDbfSTQFhPGj5lOR6d8tsgbBk84Ggb5A3EkjsOgPRPcKA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://unpkg.com/bootstrap-table@1.20.0/dist/bootstrap-table.min.js"></script>

<? if( is_loged_in()) { ?>


<script src="<?php echo base_url('assets/js/sistema.js') ?>"></script> 
<script src="<?php echo base_url('assets/js/general.js') ?>"></script> 
<script src="<?php echo base_url('assets/js/formularios.js') ?>"></script> 
<script src="<?php echo base_url('assets/js/notificaciones.js') ?>"></script> 




<? } ?>



</body>
</html>